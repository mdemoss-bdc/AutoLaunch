// AutoLaunch Vehicle Assistant — Luca chat capture (Phase 2, v1).
//
// Marketplace buyer chats are Messenger threads on facebook.com. There
// is no official API into a personal account's chats, so Luca reads
// them the same way the poster works: in the rep's own signed-in
// Chrome. This script runs on Messenger / Marketplace inbox pages and
// adds one floating button — "Capture chat for Luca". On click it
// scrapes the OPEN thread (buyer name, the listing it belongs to, the
// visible messages with a left/right direction guess) and hands it to
// the worker, which stores it in Supabase as a Prospect + messages.
//
// v1 is deliberately manual (one click per chat, only what's on
// screen): deterministic for the two-account smoke test, and nothing
// is captured that the rep didn't choose to capture. Selectors are
// best-effort heuristics with fallbacks — if Facebook reshuffles its
// DOM, the failure mode is "captured little", never a broken page.
(function () {
  "use strict";

  var BTN_ID = "autolaunch-luca-capture-btn";

  // The floating chat popup (v2.1.28): sellers often read Marketplace
  // chats in the docked mini-window on a listing page, not the full
  // Messenger view — Matthew hit exactly that on 2026-10-25 and there
  // was no Capture button. The popup lives in a fixed-position
  // container holding a message box; the full Messenger thread is in
  // normal flow, so this returns null there and behavior is unchanged.
  function findChatPopup() {
    try {
      var inputs = document.querySelectorAll('[role="textbox"][aria-label], [contenteditable="true"][aria-label]');
      for (var i = 0; i < inputs.length; i++) {
        var lab = (inputs[i].getAttribute("aria-label") || "").toLowerCase();
        if (lab.indexOf("message") === -1 && lab !== "aa") continue;
        var node = inputs[i];
        for (var up = 0; up < 10 && node && node !== document.body; up++) {
          node = node.parentElement;
          if (!node) break;
          var cs = window.getComputedStyle ? window.getComputedStyle(node) : null;
          if (cs && cs.position === "fixed" && node.querySelectorAll('[dir="auto"]').length) return node;
        }
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return null;
  }

  // [GLUE358-BEGIN] — popover enumeration +
  // the popup-scoped buyer name (v2.1.158,
  // header note 99). findChatPopup() returns
  // the FIRST popover on the page; the
  // inbox-list walk needs every popover (a
  // pre-existing one may sit in front of the
  // one its click just opened) and the buyer
  // name of ONE specific popover. The decider
  // is pure (popupName358 in [PURE-WALK358]);
  // this is its DOM half.
  function findChatPopups358() {
    var out = [];
    try {
      var inputs = document.querySelectorAll('[role="textbox"][aria-label], [contenteditable="true"][aria-label]');
      for (var i = 0; i < inputs.length; i++) {
        var lab = (inputs[i].getAttribute("aria-label") || "").toLowerCase();
        if (lab.indexOf("message") === -1 && lab !== "aa") continue;
        var node = inputs[i];
        for (var up = 0; up < 10 && node && node !== document.body; up++) {
          node = node.parentElement;
          if (!node) break;
          var cs = window.getComputedStyle ? window.getComputedStyle(node) : null;
          if (cs && cs.position === "fixed" && node.querySelectorAll('[dir="auto"]').length) {
            if (out.indexOf(node) === -1) out.push(node);
            break;
          }
        }
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return out;
  }

  // The buyer name from WITHIN one popover:
  // the popover's own "Conversation titled"
  // label (on the node itself or inside it),
  // else its own headings. The document-scoped
  // findBuyerName reads the whole page — on an
  // inbox list that is other rows, other
  // popovers and page chrome, which is exactly
  // what starved the .157 walk's identity
  // proof. No name inside the popover means
  // the popover is honestly unnamed ("").
  function popupBuyerName358(popupNode) {
    if (!popupNode) return "";
    var titled = "", heads = [];
    try {
      var own = popupNode.getAttribute ? (popupNode.getAttribute("aria-label") || "") : "";
      if (/^Conversation titled /.test(own)) titled = own;
      if (!titled) {
        var t = popupNode.querySelector('[aria-label^="Conversation titled "]');
        if (t) titled = t.getAttribute("aria-label") || "";
      }
      var hs = popupNode.querySelectorAll("h1, h2");
      for (var i = 0; i < hs.length; i++) heads.push(textOf(hs[i]));
    } catch (e) { /* fall through with what we have */ }
    return popupName358(titled, heads);
  }
  // [GLUE358-END]
  // [GLUE360-BEGIN] — chat DOCK CARD
  // enumeration (v2.1.160, header note 101).
  // findChatPopups358() enumerates popovers by
  // walking up from a message textbox to a
  // position:fixed ancestor — on the
  // Marketplace inbox / you/selling surface
  // the chat windows are DOCK CARDS docked
  // side-by-side at the bottom-right of the
  // viewport, and that heuristic matches none
  // of them: the .159 walk reported "no
  // window" for every candidate while the
  // cards visibly opened and stacked,
  // unclosed (Matthew's recording,
  // 2026-11-19). A dock card is recognised
  // STRUCTURALLY instead: the smallest
  // ancestor of the card's own composer that
  // holds a close control and no second
  // composer. Each card comes back as a
  // first-class object — its node, the buyer
  // name + vehicle read from ITS OWN header,
  // its subheader listing label, and its OWN
  // close control — so the walk can match,
  // harvest and close cards one by one. The
  // deciders are pure ([PURE-WALK360]); this
  // is their DOM half.
  function dockCard360Composers() {
    var out = [];
    try {
      // v2.1.163: the seed no longer demands a
      // "message" aria-label — .162's desk walk
      // polled 21x over visibly open cards and
      // saw none, and a composer Facebook labels
      // otherwise (or not at all) was invisible
      // from the first gate. Every textbox /
      // contenteditable is a seed now; the climb
      // (one composer, a close control) is what
      // proves a card — the page's other inputs
      // (the inbox search box above all) die
      // there, and the funnel (fn) counts where.
      var inputs = document.querySelectorAll('[role="textbox"], [contenteditable="true"]');
      for (var i = 0; i < inputs.length; i++) out.push(inputs[i]);
    } catch (e) { /* heuristic only — never break the page */ }
    return out;
  }

  function dockCard360CloseEls(root) {
    var out = [];
    try {
      var els = root.querySelectorAll("[aria-label]");
      for (var i = 0; i < els.length; i++) {
        var lab = (els[i].getAttribute && els[i].getAttribute("aria-label")) || "";
        if (/close/i.test(lab)) out.push(els[i]);
      }
    } catch (e) { /* no controls readable */ }
    return out;
  }

  // The card root for one composer: ascend
  // while the ancestor wraps this composer
  // alone; the root is the SMALLEST such
  // ancestor that also holds a close control
  // (the card's header furniture). Reaching
  // an ancestor that wraps a second composer
  // first means the dock strip itself — no
  // card.
  function dockCard360RootOf(composer, composers, stats363) {
    var node = composer;
    var sawSingle363 = false;
    for (var up = 0; up < 14 && node && node !== document.body; up++) {
      node = node.parentElement;
      if (!node) break;
      var inside = 0;
      for (var i = 0; i < composers.length; i++) {
        try { if (node.contains && node.contains(composers[i])) inside++; } catch (e) { /* ignore */ }
      }
      if (inside !== 1) {
        // v2.1.163: the climb leaves single-
        // composer territory here — if it held
        // this composer alone anywhere and still
        // never met a close control, the seed
        // died on the close test (fn's x).
        if (sawSingle363 && stats363) stats363.x++;
        return null;
      }
      sawSingle363 = true;
      if (dockCard360CloseEls(node).length) return node;
    }
    // v2.1.163: the climb passed single-composer
    // ancestors all the way and died on the
    // close test alone — the funnel counts the
    // death (fn's x), so a blind walk names its
    // gate instead of reporting another zero.
    if (sawSingle363 && stats363) stats363.x++;
    return null;
  }

  // The card's header evidence, read from
  // WITHIN the card only: its titled label,
  // its headings, its title-shaped aria
  // labels, and the leaf texts in its header
  // zone (the top band of the card, where
  // the header and the subheader live).
  function dockCard360HeaderOf(root) {
    var titled = "", headings = [], ariaTitles = [], zoneTexts = [], subLines = [];
    try {
      var own = root.getAttribute ? (root.getAttribute("aria-label") || "") : "";
      if (/^Conversation titled /.test(own)) titled = own;
      if (!titled) {
        var t = root.querySelector('[aria-label^="Conversation titled "]');
        if (t) titled = t.getAttribute("aria-label") || "";
      }
      var hs = root.querySelectorAll("h1, h2");
      for (var i = 0; i < hs.length; i++) headings.push(textOf(hs[i]));
      var labelled = root.querySelectorAll("[aria-label]");
      for (var j = 0; j < labelled.length; j++) {
        var lab2 = (labelled[j].getAttribute && labelled[j].getAttribute("aria-label")) || "";
        if (lab2.indexOf(" · ") !== -1 && lab2.length <= 120 &&
            !/close|minimi|call|video|message|send|react|like/i.test(lab2)) ariaTitles.push(lab2);
      }
      var rr = root.getBoundingClientRect ? root.getBoundingClientRect() : { top: 0 };
      var all = root.querySelectorAll("*");
      for (var k = 0; k < all.length; k++) {
        var el = all[k];
        var txt = "";
        // Leaf text only: containers repeat
        // their children's text and would bury
        // the header lines under card chrome.
        try { txt = (el.children && el.children.length) ? "" : textOf(el); } catch (e) { txt = ""; }
        if (!txt) continue;
        var r = el.getBoundingClientRect ? el.getBoundingClientRect() : { top: rr.top };
        var dy = r.top - rr.top;
        if (dy < -4 || dy > 120) continue;
        if (txt.length <= 120 && txt.indexOf("·") !== -1) zoneTexts.push(txt);
        if (txt.length <= 110) subLines.push(txt);
      }
    } catch (e) { /* fall through with what we have */ }
    var head = dockCard360ParseHeader(titled, headings, ariaTitles, zoneTexts);
    return { name: head.name, vehicle: head.vehicle, subLabel: dockCard360Subheader(subLines) };
  }

  function dockCard360Describe(root) {
    var head = dockCard360HeaderOf(root);
    var closeEl = null;
    try {
      var els = dockCard360CloseEls(root);
      if (els.length) {
        closeEl = els[0];
        var rr2 = root.getBoundingClientRect ? root.getBoundingClientRect() : { top: 0 };
        for (var i = 0; i < els.length; i++) {
          var r2 = els[i].getBoundingClientRect ? els[i].getBoundingClientRect() : { top: rr2.top };
          if (Math.abs(r2.top - rr2.top) <= 72) { closeEl = els[i]; break; }
        }
      }
    } catch (e) { /* no close control readable */ }
    return {
      node: root,
      name: head.name || "",
      vehicle: head.vehicle || "",
      label: head.vehicle || head.subLabel || "",
      subLabel: head.subLabel || "",
      closeEl: closeEl
    };
  }
  // [GLUE360-ENUM]
  // [GLUE363-BEGIN] — header-seeded dock-card
  // enumeration (v2.1.163, header note 104),
  // the DOM half of [PURE-WALK363]. The
  // composer-seeded enumeration above starts
  // from the card's message box; this path
  // starts from the card's HEADER — the one
  // part of an open card that is always
  // rendered, composer or no composer, label
  // or no label — and climbs to the smallest
  // ancestor holding that header alone, one
  // composer, and a close-ish control: a
  // "close"-labelled element, or a button
  // sitting in the header's own band (the
  // card's × does not always carry a label).
  // An inbox LIST ROW can imitate a header —
  // it has neither a composer nor a close
  // control anywhere above it short of the
  // page root, so the climb starves and the
  // row is never a card. The two paths'
  // results merge by root node in the
  // enumeration itself; identity, harvest and
  // close all read the merged list exactly as
  // before (dockCard360Describe).
  // The funnel: where the LAST enumeration's
  // gates landed — s seeds (every textbox /
  // contenteditable on the page), c roots the
  // composer climb resolved, h header
  // candidates, r roots the header climb
  // resolved, x composer climbs that held a
  // composer alone somewhere and still died
  // on the close test. The enumeration
  // publishes into dockCard363Funnel (declared
  // with the pure deciders, [PURE-WALK363])
  // before it returns; the walk reads it into
  // the row's fn (walk363FunnelText).

  function dockCard363HeaderCandidates() {
    var out = [];
    var seen = [];
    function add(el) {
      if (el && seen.indexOf(el) === -1) { seen.push(el); out.push(el); }
    }
    try {
      var titled = document.querySelectorAll('[aria-label^="Conversation titled "]');
      for (var i = 0; i < titled.length; i++) {
        if (dockCard363HeaderShape(titled[i].getAttribute("aria-label") || "")) add(titled[i]);
      }
      var labelled = document.querySelectorAll("[aria-label]");
      for (var j = 0; j < labelled.length; j++) {
        var lab = (labelled[j].getAttribute && labelled[j].getAttribute("aria-label")) || "";
        if (lab.indexOf(" · ") === -1 || lab.length > 120) continue;
        if (/close|minimi|call|video|message|send|react|like/i.test(lab)) continue;
        if (dockCard363HeaderShape(lab)) add(labelled[j]);
      }
      var heads = document.querySelectorAll("h1, h2");
      for (var k = 0; k < heads.length; k++) {
        if (dockCard363HeaderShape(textOf(heads[k]))) add(heads[k]);
      }
      var all = document.querySelectorAll("*");
      for (var m = 0; m < all.length; m++) {
        var el = all[m];
        var txt = "";
        try {
          if (el.children && el.children.length) continue;
          txt = (el.textContent || "").trim().replace(/\s+/g, " ");
        } catch (e) { txt = ""; }
        if (!txt || txt.indexOf("·") === -1) continue;
        if (dockCard363HeaderShape(txt)) add(el);
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return out;
  }

  // How many DISTINCT headers live inside
  // node: a candidate nested inside another
  // candidate (a titled container wrapping
  // its own title text) is the same header,
  // so only the outermost candidates count.
  function dockCard363HeadsInside(node, candidates) {
    var inside = [];
    for (var i = 0; i < candidates.length; i++) {
      try { if (node.contains && node.contains(candidates[i])) inside.push(candidates[i]); } catch (e) { /* ignore */ }
    }
    var n = 0;
    for (var j = 0; j < inside.length; j++) {
      var nested = false;
      for (var k = 0; k < inside.length; k++) {
        if (inside[k] === inside[j]) continue;
        try { if (inside[k].contains && inside[k].contains(inside[j])) { nested = true; break; } } catch (e) { /* ignore */ }
      }
      if (!nested) n++;
    }
    return n;
  }

  // A button in the header's own band: the
  // card's header furniture sits on the header
  // element's line, within a card-header's
  // height of it, whether or not Facebook
  // labelled it. The LAST such button wins:
  // the × is the header's final action —
  // minimise and options sit to its left, and
  // a minimised card is still an open card.
  function dockCard363BandButton(root, headerEl) {
    try {
      var hr = headerEl && headerEl.getBoundingClientRect ? headerEl.getBoundingClientRect() : null;
      if (!hr) return null;
      var btns = root.querySelectorAll('button, [role="button"]');
      var found = null;
      for (var i = 0; i < btns.length; i++) {
        var r = btns[i].getBoundingClientRect ? btns[i].getBoundingClientRect() : null;
        if (r && Math.abs(r.top - hr.top) <= 48) found = btns[i];
      }
      return found;
    } catch (e) { /* no band readable */ }
    return null;
  }

  function dockCard363RootOf(headerEl, candidates) {
    var node = headerEl;
    for (var up = 0; up < 14 && node && node !== document.body; up++) {
      var heads = dockCard363HeadsInside(node, candidates);
      if (heads > 1) return null;
      if (heads === 1) {
        var composersIn = 0;
        try { composersIn = node.querySelectorAll('[role="textbox"], [contenteditable="true"]').length; } catch (e) { composersIn = 0; }
        if (composersIn > 1) return null;
        if (composersIn === 1) {
          var closeEl = null;
          var labelled = dockCard360CloseEls(node);
          if (labelled.length) closeEl = labelled[0];
          else closeEl = dockCard363BandButton(node, headerEl);
          if (closeEl) return { root: node, closeEl: closeEl };
        }
      }
      node = node.parentElement;
    }
    return null;
  }
  // [GLUE363-END]

  function findDockCards360() {
    var out = [];
    var fn363 = dockCard363Funnel;
    fn363.s = 0; fn363.c = 0; fn363.h = 0; fn363.r = 0; fn363.x = 0;
    try {
      var composers = dockCard360Composers();
      fn363.s = composers.length;
      var roots = [];
      for (var i = 0; i < composers.length; i++) {
        var root = dockCard360RootOf(composers[i], composers, fn363);
        if (root && roots.indexOf(root) === -1) roots.push(root);
      }
      fn363.c = roots.length;
      for (var j = 0; j < roots.length; j++) out.push(dockCard360Describe(roots[j]));
      // v2.1.163: the header-seeded path
      // ([GLUE363]) merged in by root node — a
      // card only this path can see keeps the
      // close control its own climb resolved.
      var candidates363 = dockCard363HeaderCandidates();
      fn363.h = candidates363.length;
      var hRoots363 = [], hSeen363 = [];
      for (var k = 0; k < candidates363.length; k++) {
        var hr363 = dockCard363RootOf(candidates363[k], candidates363);
        if (hr363 && hSeen363.indexOf(hr363.root) === -1) {
          hSeen363.push(hr363.root);
          hRoots363.push(hr363);
        }
      }
      fn363.r = hRoots363.length;
      for (var m = 0; m < hRoots363.length; m++) {
        if (roots.indexOf(hRoots363[m].root) !== -1) continue;
        var d363 = dockCard360Describe(hRoots363[m].root);
        if (!d363.closeEl && hRoots363[m].closeEl) d363.closeEl = hRoots363[m].closeEl;
        out.push(d363);
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return out;
  }
  // [GLUE360-END]

  function onChatSurface() {
    var p = window.location.pathname || "";
    return p.indexOf("/messages/") === 0 || p.indexOf("/marketplace/inbox") === 0 || !!findChatPopup();
  }

  function textOf(el) {
    return ((el && (el.innerText || el.textContent)) || "").trim().replace(/\s+/g, " ");
  }

  function findBuyerName() {
    // Best hook (v2.1.29, from Matthew's live capture): Facebook labels
    // the thread container "Conversation titled <Name> · <Listing>" —
    // the name is the part before the first "·".
    try {
      var titled = document.querySelector('[aria-label^="Conversation titled "]');
      if (titled) {
        var t = (titled.getAttribute("aria-label") || "").replace(/^Conversation titled\s*/, "");
        var nm = t.split("·")[0].trim();
        if (nm && nm.length >= 2 && nm.length <= 60 && !isJunkName(nm)) return nm;
      }
    } catch (e) { /* fall through to the heading scan */ }
    // Thread header usually carries the buyer's name in a heading.
    var main = document.querySelector('[role="main"]');
    var scopes = [findChatPopup(), main, document].filter(Boolean);
    for (var i = 0; i < scopes.length; i++) {
      var heads = scopes[i].querySelectorAll("h1, h2");
      for (var j = 0; j < heads.length; j++) {
        var t = textOf(heads[j]);
        if (t && t.length >= 2 && t.length <= 60 && !isJunkName(t) && !/messenger|marketplace|chats|inbox/i.test(t)) return t;
      }
    }
    // Fallback: the document title on thread pages is often the name.
    var title = (document.title || "").replace(/\s*[|·•-]\s*Facebook.*$/i, "").replace(/^\(\d+\)\s*/, "").trim();
    if (title && !isJunkName(title) && !/messenger|facebook/i.test(title) && title.length <= 60) return title;
    return "";
  }

  // The thread-header listing link's subtree includes its action
  // buttons, so the raw text arrives as "$23,220 - 2026 Volkswagen
  // Jetta View buyer More options" (Matthew's live capture, 2026-10-25).
  // Cut at the first chrome token and drop a leading "Marketplace".
  function cleanListingLabel(label) {
    var s = String(label || "").trim();
    s = s.split(/\s+(?:View buyer|More options)\b/)[0];
    s = s.replace(/^Marketplace\s+(?=\$)/, "");
    return s.trim();
  }

  function findListing(scopeNode358) {
    // Marketplace threads link the listing; the first item link in the
    // thread pane is the car this chat is about. v2.1.156: the search
    // is scoped to the chat popup when one is open — document-wide,
    // the first item link on the inbox page is a LIST ROW's car, and
    // the 2026-11-19 merged capture filed its thread under one.
    // v2.1.158: scrape() may name the exact popover to read (the
    // walk's opened thread) — that node wins over the first popover.
    var links = (scopeNode358 || findChatPopup() || document).querySelectorAll('a[href*="/marketplace/item/"]');
    // v2.1.162: the label is DECIDED over
    // every item link in scope (label362Decide)
    // — a notification banner's fused text is
    // never the label, and the thread's own
    // listing header wins even when a banner
    // link renders first (Husen, 2026-11-19:
    // the banner named a different car). The
    // first href survives as the item identity
    // when no label does; banner362 counts the
    // rejections for the walk report.
    var labels362 = [], hrefs362 = [];
    for (var i = 0; i < links.length; i++) {
      labels362.push(cleanListingLabel(textOf(links[i]) || (links[i].getAttribute("aria-label") || "").trim()));
      hrefs362.push(links[i].href || "");
    }
    var pick362 = label362Decide(labels362);
    if (pick362.label) return { vehicleText: pick362.label.slice(0, 140), itemUrl: hrefs362[pick362.index] || "", banner362: pick362.banner };
    return { vehicleText: "", itemUrl: hrefs362[0] || "", banner362: pick362.banner };
  }

  // Chrome-label filter (v2.1.48): the thread page's info rail and
  // header render their labels as dir="auto" text too, and the
  // scrape stored them as if they were the rep's own messages —
  // "Mute", "Customize chat", "Chat members", the thread's own
  // title — polluting the Prospects view and Luca's voice data.
  // Two defenses: (1) an exact whole-text denylist of the known
  // Facebook chrome labels, plus the thread's own title text;
  // (2) a structural rule — a real message bubble is a plain text
  // block, never the whole content of a control (quick-reply chips
  // and rail rows are controls) and never inside a chrome region
  // (page header, nav, info rail, form). Whole-text only, always:
  // a real sentence that merely mentions a label is a message.
  var FB_CHROME_LABELS = {
    "Mute": 1, "Unmute": 1,
    "Customize chat": 1, "Chat members": 1,
    "Media, files and links": 1, "Privacy & support": 1,
    "Buyer details": 1, "Seller details": 1,
    "Send a quick response": 1,
    "View buyer": 1, "View seller": 1, "More options": 1,
    // v2.50 (sync repair): the generic participant placeholder and
    // composer/header furniture from half-rendered threads —
    // Matthew's live junk rows, 2026-10-27. Never a message body,
    // never a buyer name.
    "Facebook user": 1, "Compose": 1, "Conversation with Facebook user": 1,
    // v2.1.105 (note 58): list-surface page chrome — a
    // /messages/ list scrape filed "Notifications" as a
    // buyer name (2026-11-12 desk proof); "Messenger"
    // and "Chats" are the same class of heading, fenced
    // here too (they were only regex-excluded inside
    // one findBuyerName branch, not in the shared list).
    "Notifications": 1, "Messenger": 1, "Chats": 1
  };

  // v2.50: a scraped "name" that is really Facebook chrome is NOT
  // a resolved buyer — the worker's gate treats it as unresolved,
  // so it must never leave this script as a participant name.
  function isJunkName(n) {
    if (!n) return true;
    return !!FB_CHROME_LABELS[String(n).trim()];
  }

  // Transient delivery-state labels (v2.51): Messenger paints the
  // state of the rep's last bubble — "Sending", "Delivered",
  // "Seen", "Edited" — as its own dir="auto" text under the
  // bubble, and the scrape stored it as a message (Matthew's live
  // thread, 2026-10-27: an out/rep row whose body was literally
  // "Sending"). Whole-text only: a real sentence that STARTS with
  // one of these words ("Sending the paperwork now") is a message
  // and must survive. "You sent" is the delivery caption variant.
  var FB_TRANSIENT_STATES = {
    "Sending": 1, "Sending...": 1, "Sending…": 1,
    "Delivered": 1, "Seen": 1, "Edited": 1, "You sent": 1,
    "Message sent": 1, "Message delivered": 1
  };

  function isTransientStateText(t) {
    return !!FB_TRANSIENT_STATES[t];
  }

  // Group-thread system lines (v2.51): Marketplace conversations
  // are GROUP threads, and Facebook narrates group events in the
  // transcript itself — "Matthew DeMoss created this group",
  // "Matthew named the group Matthew · 2026 Honda CR-V.",
  // "Matthew changed the group photo." The scrape stored them
  // as buyer messages (seen live 2026-10-26 and again 2026-10-27,
  // even after the 2.48/2.50 filters — only the "created this
  // group" tail was covered). The match is the system-line
  // grammar — an actor name followed by a group-event verb —
  // which is how these lines are shaped; a buyer's ordinary
  // sentence does not take this form.
  var GROUP_SYSTEM_RE = /^.{1,80}?\s+(?:named the group|changed the group (?:photo|name|image|picture)|created this group|added\s+\S.*\s+to (?:the|this) group|left the group|joined the group|removed\s+\S.*\s+from the group)\b/;

  function isGroupSystemText(t) {
    return GROUP_SYSTEM_RE.test(t);
  }

  function threadTitleTexts() {
    // The strings this thread's own header shows as its title —
    // "Name · Listing" from the aria-label, the header element's
    // visible text, and the name + listing pair rebuilt from the
    // scrapers. If the scrape meets one of these as a "message",
    // it is the header talking, not a person.
    var out = {};
    try {
      var titled = document.querySelector('[aria-label^="Conversation titled "]');
      if (titled) {
        var t = (titled.getAttribute("aria-label") || "").replace(/^Conversation titled\s*/, "").trim();
        if (t) out[t] = 1;
        var vis = textOf(titled);
        if (vis) out[vis] = 1;
      }
    } catch (e) { /* heuristic only */ }
    try {
      var name = findBuyerName();
      var lv = findListing().vehicleText || "";
      // v2.51: the full listing label itself ("$38,008 - 2026
      // Honda CR-V") is header/card text — when it shows up as
      // a dir="auto" node in the pane it is the listing card
      // talking, not a person, so it joins the title set whole.
      if (lv) out[lv] = 1;
      var lt = lv.replace(/^\$[\d,]+\s*-\s*/, "").trim();
      if (name && lt) out[name + " · " + lt] = 1;
    } catch (e) { /* heuristic only */ }
    return out;
  }

  function isChromeText(t, titles) {
    if (!t) return false;
    if (FB_CHROME_LABELS[t]) return true;
    if (FB_TRANSIENT_STATES[t]) return true; // v2.51: state labels, every path
    if (titles && titles[t]) return true;
    return false;
  }

  function inChromeStructure(node, t) {
    // Structural containment: walk the node's ancestors. Chrome
    // regions (header / nav / complementary rail / search / form)
    // disqualify outright. A control (button / role=button) whose
    // ENTIRE text is this text also disqualifies — the node is the
    // control's label. A control holding more than this text (a
    // message row with hover actions) does not, and a link inside
    // a bubble (a pasted URL) never does.
    try {
      var el = node;
      for (var up = 0; up < 14 && el && el !== document.body; up++) {
        var role = el.getAttribute ? (el.getAttribute("role") || "") : "";
        var tag = el.tagName || "";
        if (role === "complementary" || role === "banner" || role === "navigation" ||
            role === "search" || tag === "HEADER" || tag === "NAV" || tag === "FORM") return true;
        if ((role === "button" || tag === "BUTTON") && textOf(el) === t) return true;
        el = el.parentElement;
      }
    } catch (e) { /* heuristic only — the text checks still apply */ }
    return false;
  }

  // Direction by EDGE-HUGGING (v2.51): the old rule compared a
  // bubble's center to the midpoint of [role="main"] — but main
  // spans the nav, the thread column AND the info rail (and, on
  // a wide monitor, dead space past the rail), so the "midpoint"
  // sat well right of the conversation and a LONG rep bubble's
  // center fell left of it: the rep's own words were filed as
  // the buyer's (Matthew's live group thread, 2026-10-27, where
  // both sides also share the display name "Matthew", so no name
  // check could catch it). Messenger aligns bubbles: the rep's
  // hug the column's RIGHT edge, the buyer's hug the LEFT edge.
  // The column bounds come from the candidate bubbles themselves,
  // so the rail never enters the math. A bubble flush with one
  // edge is placed by that edge at ANY width (a long rep bubble
  // still lands flush right); a bubble spanning nearly the whole
  // column floats, so only its center can speak, inside a tight
  // dead zone; anything else follows the nearer edge. What
  // cannot be placed returns null and the caller SKIPS it —
  // guessing a side is how the rep's words end up in the
  // buyer's mouth. (A lone visible bubble defines its own
  // column and is unplaceable by construction; the inbox-list
  // snippet sync still carries its line for a known prospect.)
  function bubbleDirection(r, colLeft, colRight, colWidth) {
    if (!(colWidth > 0)) return null;
    var leftGap = r.left - colLeft;
    var rightGap = colRight - (r.left + r.width);
    if (rightGap <= 0.01 * colWidth && leftGap > rightGap) return "out";
    if (leftGap <= 0.01 * colWidth && rightGap > leftGap) return "in";
    if (r.width >= 0.92 * colWidth) {
      var mid = colLeft + colWidth / 2;
      var center = r.left + r.width / 2;
      var dz = 0.01 * colWidth;
      if (center > mid + dz) return "out";
      if (center < mid - dz) return "in";
      return null;
    }
    if (rightGap < leftGap) return "out";
    if (leftGap < rightGap) return "in";
    return null;
  }

  // [PURE-CAPTURE356-BEGIN] — thread isolation
  // decider (v2.1.156, header note 97).
  // Extracted and unit-exercised by the test
  // harness; keep free of DOM references (the
  // caller resolves the two booleans).
  // A full capture may read ONLY an isolated
  // conversation: the floating chat popup's own
  // container, or a dedicated thread page (its
  // URL carries the thread id). Anything else —
  // above all the Marketplace inbox LIST with a
  // thread open as a popover the popup-finder
  // could not isolate — is "blocked": the
  // harvest never runs, so a list can never be
  // filed as one merged conversation (the
  // 2026-11-19 Husen captures: 25 "messages"
  // that were other rows' titles and other
  // threads' lines, under the right buyer's
  // name). A blocked capture fails clean; a
  // merged prospect is the one outcome that is
  // never acceptable.
  function captureScope356(hasPopup, threadKey) {
    if (hasPopup) return "popup";
    if (threadKey) return "thread_page";
    return "blocked";
  }
  // [PURE-CAPTURE356-END]
  // [PURE-WALK357-BEGIN] — inbox-list walk
  // planner (v2.1.157, header note 98).
  // Extracted and unit-exercised by the test
  // harness; keep free of DOM references (the
  // caller resolves candidates, the registry
  // and worker responses into plain data).
  // The walk exists because .156 made capture
  // from the inbox LIST fail clean — correct,
  // but useless: the rep should not have to
  // open every thread by hand (Matthew,
  // 2026-11-19). The walk opens threads itself,
  // one at a time, and files each through the
  // unchanged .156 isolated scrape. These pure
  // functions decide WHO is walked and what an
  // outcome MEANS; the glue in [WALK357] does
  // the clicking, waiting and sending.
  //
  // Identity: the thread's numeric /t/<id> when
  // any ref carries one — the same derivation
  // the worker's prospect_tombstones key uses,
  // so the helper registry and the server
  // tombstone agree on what a thread IS. Rows
  // whose props yield no id fall back to a
  // buyer+listing key ("bl:<name>|<label>").
  function walk357Identity(cand) {
    var ref = String((cand && cand.threadRef) || (cand && cand.threadUrl) || "");
    var m = ref.match(/\/t\/(\d+)/);
    if (m) return m[1];
    var nm = String((cand && cand.buyerName) || "").trim().toLowerCase().replace(/\s+/g, " ");
    var lb = String((cand && (cand.vehicleLabel || cand.vehicleText)) || "").trim().toLowerCase().replace(/\s+/g, " ");
    if (nm) return "bl:" + nm + "|" + lb;
    return "";
  }
  // The plan: registry members are skipped —
  // ANY state. "captured" was filed before;
  // "deleted" is a tombstone (the rep deleted
  // the prospect; the walk must never resurrect
  // it); "skip" is a terminal non-prospect
  // (self thread). Skips never consume the cap.
  // Order: unread first (true, then unknown,
  // then read) — stable, so list order breaks
  // ties. The cap bounds NEW attempts per run.
  function walk357Plan(cands, reg, cap) {
    var todo = [], skippedOld = 0;
    var list = Array.isArray(cands) ? cands : [];
    for (var i = 0; i < list.length; i++) {
      var c = list[i] || {};
      if (!c.key) continue;
      if (reg && reg[c.key]) { skippedOld++; continue; }
      todo.push(c);
    }
    var rank = function (c) { return c.unread === true ? 0 : (c.unread === false ? 2 : 1); };
    todo = todo.map(function (c, ix) { return { c: c, ix: ix }; })
      .sort(function (a, b) { return (rank(a.c) - rank(b.c)) || (a.ix - b.ix); })
      .map(function (w) { return w.c; });
    var n = (typeof cap === "number" && cap >= 0) ? Math.floor(cap) : todo.length;
    return { todo: todo.slice(0, n), skippedOld: skippedOld, deferred: Math.max(0, todo.length - n) };
  }
  // What a worker response means for the
  // registry. Only terminal outcomes are
  // recorded: a stored capture, the deletion
  // tombstone, a terminal non-prospect. Render-
  // dependent skips (unresolved_name,
  // no_seller_signal), transport-shaped skips
  // (no_thread_id, hub_list_surface) and dead
  // channels stay UNRECORDED — a later run may
  // legitimately succeed, and recording them
  // would bury a real thread forever.
  // v2.1.161: "stored" is judged on EVIDENCE,
  // not transport. The capture handler wraps
  // EVERY worker result as ok:true — including
  // the merge guard's {skipped:"no_thread_id"}
  // drop — so ok alone proved nothing, and a
  // refused capture counted as captured (and
  // was recorded here). A capture is captured
  // only when the answer carries the saved
  // prospect's name and no skipped code — the
  // shape of handleCaptureChat's one success
  // return. Any skipped code is a non-save:
  // deleted_by_user / self_thread keep their
  // terminal meanings; the rest are failures
  // whose code the walk reports as the reason
  // (walk361OutcomeReason).
  function walk357Outcome(resp) {
    if (!resp || typeof resp !== "object") return "failed";
    if (resp.skipped) {
      if (resp.skipped === "deleted_by_user") return "deleted";
      if (resp.skipped === "self_thread") return "skip";
      return "failed";
    }
    if (resp.ok && typeof resp.prospectName === "string" && resp.prospectName) return "captured";
    return "failed";
  }
  // The registry is bounded: past the cap, the
  // oldest entries (by recorded time) fall off.
  // Tombstones are entries like any other — a
  // pruned tombstone's thread is still guarded
  // server-side by prospect_tombstones, which
  // the walk re-learns from the deleted_by_user
  // response before anything can be created.
  function walk357Prune(reg, max) {
    var out = {};
    if (!reg || typeof reg !== "object") return out;
    var keys = Object.keys(reg);
    var capN = (typeof max === "number" && max > 0) ? Math.floor(max) : 400;
    if (keys.length > capN) {
      keys.sort(function (a, b) { return ((reg[a] && reg[a].at) || 0) - ((reg[b] && reg[b].at) || 0); });
      keys = keys.slice(keys.length - capN);
    }
    for (var i = 0; i < keys.length; i++) out[keys[i]] = reg[keys[i]];
    return out;
  }
  // [PURE-WALK357-END]
  // [PURE-WALK358-BEGIN] — popover identity
  // deciders (v2.1.158, header note 99).
  // Extracted and unit-exercised by the test
  // harness; keep free of DOM references (the
  // caller resolves the popup's label, headings
  // and listing into plain data).
  // The .157 walk proved identity on the
  // id-less popup lane by the buyer's name
  // alone — but scrape() took that name from
  // DOCUMENT-scoped selectors, and on the
  // Marketplace inbox list they resolve nothing
  // usable, so the proof could never pass and
  // every walked thread timed out as failed
  // (2026-11-19 desk proof: "Walk ✓ 0 new ·
  // 1 seen · 5 failed", zero captures reached
  // the server). These deciders judge only
  // POPUP-scoped evidence:
  // - popupName358: the buyer name from the
  //   popup's OWN "Conversation titled" label,
  //   else its OWN headings — a name found
  //   elsewhere in the document is never
  //   accepted as the popup's buyer.
  // - walk358IdentityVerdict: a popup name
  //   matching the clicked row passes; a popup
  //   name that is positively DIFFERENT is a
  //   hard mismatch (the open popover belongs
  //   to another thread — file nothing, and do
  //   not let a matching listing talk us out
  //   of it); only a popup that yields NO name
  //   may fall back to listing-label agreement
  //   (year/make/model core + price).
  function popupName358(titledLabel, headingTexts) {
    var t = String(titledLabel || "").replace(/^Conversation titled\s*/, "");
    if (t) {
      var nm = t.split("·")[0].trim();
      if (nm && nm.length >= 2 && nm.length <= 60 && !isJunkName(nm)) return nm;
    }
    var heads = Array.isArray(headingTexts) ? headingTexts : [];
    for (var i = 0; i < heads.length; i++) {
      var h = String(heads[i] || "").trim().replace(/\s+/g, " ");
      if (h && h.length >= 2 && h.length <= 60 && !isJunkName(h) && !/messenger|marketplace|chats|inbox/i.test(h)) return h;
    }
    return "";
  }

  function walk358NormName(s) {
    return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
  }

  // The comparable core of a listing label:
  // its price (digits only), its year, and its
  // make/model words (price, year and filler
  // removed).
  function walk358LabelParts(label) {
    var s = String(label || "").toLowerCase();
    var pm = s.match(/\$\s*([\d,]+)/);
    var ym = s.match(/\b(?:19|20)\d{2}\b/);
    var words = s.replace(/\$\s*[\d,]+/g, " ").replace(/\b(?:19|20)\d{2}\b/g, " ")
      .replace(/[^a-z0-9 ]+/g, " ").split(/\s+/).filter(function (w) {
        return w.length >= 3 && ["the", "for", "sale", "with", "and"].indexOf(w) === -1;
      });
    return { price: pm ? pm[1].replace(/,/g, "") : "", year: ym ? ym[0] : "", words: words };
  }

  // Agreement = a shared make/model word AND
  // no contradiction on the hard facts: prices
  // that both appear must be equal, years that
  // both appear must be equal, and at least
  // one hard fact (a price or a year) must be
  // present on the pair — two vague labels
  // never "agree".
  function walk358LabelAgree(labelA, labelB) {
    var pa = walk358LabelParts(labelA), pb = walk358LabelParts(labelB);
    if (!pa.words.length || !pb.words.length) return false;
    if (!pa.price && !pb.price && !pa.year && !pb.year) return false;
    if (pa.price && pb.price && pa.price !== pb.price) return false;
    if (pa.year && pb.year && pa.year !== pb.year) return false;
    for (var i = 0; i < pa.words.length; i++) {
      if (pb.words.indexOf(pa.words[i]) !== -1) return true;
    }
    return false;
  }

  function walk358IdentityVerdict(cand, cap) {
    var capName = walk358NormName(cap && cap.buyerName);
    if (capName) {
      var candName = walk358NormName(cand && cand.buyerName);
      return !!candName && capName === candName;
    }
    return walk358LabelAgree(cand && (cand.vehicleLabel || cand.vehicleText), cap && cap.vehicleText);
  }
  // [PURE-WALK358-END]
  // [PURE-WALK359-BEGIN] — anchor verdict,
  // label conflict and the walk report's
  // reason tally (v2.1.159, header note 100).
  // Extracted and unit-exercised by the test
  // harness; keep free of DOM references (the
  // caller resolves the anchored popover into
  // plain data: its own name, its own listing
  // label, its own message count).
  // .158 judged the scrape of a named popover,
  // but scrape() still read seller context,
  // the counterparty identity and the message
  // hygiene from the DOCUMENT, and its close
  // knew one strategy and one gone-test; the
  // .158 desk proof failed identically to
  // .157 ("Walk ✓ 0 new · 1 seen · 5 failed",
  // popovers still stacked open). The .159
  // walk harvests STRICTLY from the popover
  // its click produced (the anchor), and these
  // deciders judge only anchor-local evidence:
  // - a buyer name found INSIDE the anchor
  //   decides: a match passes ("name"); a
  //   positively different name is a hard
  //   reject ("wrong_buyer") — no listing can
  //   talk us out of it (the .158 rule);
  // - with no name inside the anchor, a
  //   listing that AGREES passes ("label");
  //   a listing that positively CONFLICTS —
  //   a hard fact contradicts (price, year,
  //   or a disjoint make/model word set) —
  //   is a hard reject ("wrong_car");
  // - with no name and no listing verdict
  //   either way, an anchor holding messages
  //   passes on provenance alone ("messages"):
  //   the popover exists because THIS row was
  //   clicked, and nothing inside it
  //   contradicts the row;
  // - anything else proves nothing ("empty").
  function walk359LabelConflict(labelA, labelB) {
    var pa = walk358LabelParts(labelA), pb = walk358LabelParts(labelB);
    if (pa.price && pb.price && pa.price !== pb.price) return true;
    if (pa.year && pb.year && pa.year !== pb.year) return true;
    if (pa.words.length && pb.words.length) {
      var shared = false;
      for (var i = 0; i < pa.words.length; i++) {
        if (pb.words.indexOf(pa.words[i]) !== -1) { shared = true; break; }
      }
      if (!shared) return true;
    }
    return false;
  }

  function walk359Verdict(cand, anchor) {
    var name = walk358NormName(anchor && anchor.name);
    if (name) {
      var candName = walk358NormName(cand && cand.buyerName);
      if (candName) return name === candName ? "name" : "wrong_buyer";
      // [WALK370] The candidate carries NO buyer name (the
      // inbox-row scrape resolved none): there is no name
      // evidence to differ FROM, so the name branch cannot
      // hard-reject — this block's own header rule makes
      // wrong_buyer a POSITIVELY different name only. On
      // 2026-11-21 the walk opened Armando's real thread (7
      // messages, the Silverado label) under an unnamed
      // candidate and this line failed it wrong_buyer. Fall
      // through: the label and message evidence below judge
      // the card, exactly as they already did when the
      // card's own name was empty.
    }
    var candLabel = (cand && (cand.vehicleLabel || cand.vehicleText)) || "";
    var anchorLabel = (anchor && anchor.label) || "";
    if (walk358LabelAgree(candLabel, anchorLabel)) return "label";
    if (walk359LabelConflict(candLabel, anchorLabel)) return "wrong_car";
    if (anchor && anchor.msgCount > 0) return "messages";
    return "empty";
  }

  // The pill's failure reasons, tallied from
  // the walk report's rows: only failed rows
  // speak, in first-seen order, capped at
  // three so the label stays one line. The
  // full per-candidate story lives in the
  // stored report (see [WALK359]).
  var WALK359_REASON_TEXT = {
    no_window: "no window",
    wrong_buyer: "wrong buyer",
    wrong_car: "wrong car",
    empty: "empty thread",
    not_isolated: "not isolated",
    send_failed: "send failed",
    close_failed: "close failed",
    row_not_found: "row gone"
  };
  function walk359ReasonSuffix(rows) {
    var order = [], tally = {};
    var list = Array.isArray(rows) ? rows : [];
    for (var i = 0; i < list.length; i++) {
      var r = list[i] || {};
      if (r.outcome !== "failed" || !r.reason) continue;
      if (!tally[r.reason]) { tally[r.reason] = 0; order.push(r.reason); }
      tally[r.reason]++;
    }
    if (!order.length) return "";
    var parts = [];
    for (var j = 0; j < order.length && j < 3; j++) {
      parts.push((WALK359_REASON_TEXT[order[j]] || order[j]) + "×" + tally[order[j]]);
    }
    return " — " + parts.join(", ");
  }
  // [PURE-WALK359-END]
  // [PURE-WALK360-BEGIN] — dock-card header
  // parsing, the subheader listing label and
  // the walk's card pick (v2.1.160, header
  // note 101). Extracted and unit-exercised
  // by the test harness; keep free of DOM
  // references (the caller resolves a card's
  // header evidence into plain data).
  // .159 anchored its harvest on the popover
  // its click produced — but its popover
  // ENUMERATION (a message-textbox +
  // fixed-ancestor heuristic inherited from
  // findChatPopup) matches none of Facebook's
  // chat DOCK CARDS on the Marketplace inbox /
  // you/selling surface, so on Matthew's desk
  // the walk reported "no window" for every
  // candidate (pill: "Walk ✓ 0 new · 0 seen ·
  // 5 failed — no window×5", 2026-11-19) while
  // the cards visibly opened and stacked,
  // unclosed. These deciders judge the
  // evidence [GLUE360] reads from the dock
  // cards themselves:
  // - dockCard360TitleParts / ParseHeader: the
  //   buyer name and vehicle from the card's
  //   OWN header title ("Buyer Name · Vehicle"),
  //   whichever layer of the header carries
  //   it (titled label, heading, title-shaped
  //   aria label, header-zone text);
  // - dockCard360Subheader: the listing label
  //   from the card's subheader line
  //   ("Marketplace / $37,523 · 2026 Kia
  //   Sorento" -> "$37,523 · 2026 Kia Sorento");
  // - walk360Pick: which enumerated card, if
  //   any, is the clicked row's thread — the
  //   .159 verdict over card-local evidence,
  //   judged ONLY within the pool the click
  //   produced: when the click opened fresh
  //   cards, a pre-existing card is never
  //   picked (it may be a decoy the rep had
  //   open); a pre-existing card is claimed
  //   only when the click opened nothing.
  function dockCard360TitleParts(text) {
    var s = String(text || "").trim().replace(/\s+/g, " ");
    if (!s) return null;
    var idx = s.indexOf("·");
    var name = (idx === -1 ? s : s.slice(0, idx)).trim();
    var vehicle = idx === -1 ? "" : s.slice(idx + 1).trim();
    // [WALK370] The header layers ParseHeader feeds here are
    // not all pre-cleaned: a heading or zone text can wrap the
    // real title in chrome phrasing ("Open chat titled
    // Armando", "Conversation titled Armando" — ParseHeader
    // strips that prefix from the titled layer only). Unwrap
    // it here so every layer yields the buyer, not the wrapper.
    name = name.replace(/^(?:open chat titled|conversation titled)\s+/i, "").trim();
    if (!name || name.length < 2 || name.length > 60) return null;
    if (/^\$/.test(name)) return null;
    if (isJunkName(name)) return null;
    if (/messenger|marketplace|chats|inbox|notifications/i.test(name)) return null;
    // [WALK370] Header chrome that is never a buyer, scraped
    // as card names on 2026-11-21 (walk trace names: "Meta AI ·
    // Armando · Write to Armando · Messages") and fatal at the
    // identity verdict: the assistant entry ("Meta AI"), the
    // inbox root ("Messages" — the chrome regex above fences
    // it only inside a longer string), and the composer
    // placeholder ("Write to Armando" — the composer, not a
    // participant; fenced, never unwrapped into a name).
    if (/^meta ai$/i.test(name)) return null;
    if (/^messages$/i.test(name)) return null;
    if (/^write to\s+/i.test(name)) return null;
    return { name: name, vehicle: vehicle.slice(0, 100) };
  }

  function dockCard360ParseHeader(titledLabel, headingTexts, ariaTitles, zoneTexts) {
    var t = String(titledLabel || "").replace(/^Conversation titled\s*/, "");
    var fromTitled = dockCard360TitleParts(t);
    if (fromTitled) return fromTitled;
    var layers = [
      { texts: headingTexts, needVehicle: false },
      { texts: ariaTitles, needVehicle: false },
      { texts: zoneTexts, needVehicle: true }
    ];
    var firstName = null;
    for (var li = 0; li < layers.length; li++) {
      var texts = Array.isArray(layers[li].texts) ? layers[li].texts : [];
      for (var i = 0; i < texts.length; i++) {
        var p = dockCard360TitleParts(texts[i]);
        if (!p) continue;
        if (layers[li].needVehicle && !p.vehicle) continue;
        if (p.vehicle) return p;
        if (!firstName) firstName = p;
      }
    }
    return firstName || { name: "", vehicle: "" };
  }

  function dockCard360Subheader(lines) {
    var list = Array.isArray(lines) ? lines : [];
    for (var i = 0; i < list.length; i++) {
      var s = String(list[i] || "").trim().replace(/\s+/g, " ");
      if (!s || s.length > 110) continue;
      if (!/\$\s*[\d,]+/.test(s)) continue;
      s = s.replace(/^marketplace\s*[/·]\s*/i, "");
      return s.slice(0, 140);
    }
    return "";
  }

  var WALK360_PASS_VERDICTS = { name: 1, label: 1, messages: 1 };
  function walk360Pick(cards, cand) {
    var list = Array.isArray(cards) ? cards : [];
    var freshIdx = [];
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].fresh) freshIdx.push(i);
    }
    var poolIdx = freshIdx.length ? freshIdx
      : list.map(function (_, i) { return i; });
    var sawWrongBuyer = false, sawWrongCar = false;
    for (var j = 0; j < poolIdx.length; j++) {
      var c = list[poolIdx[j]] || {};
      var v = walk359Verdict(cand, {
        name: c.name || "", label: c.label || "", msgCount: c.msgCount || 0
      });
      if (WALK360_PASS_VERDICTS[v]) return { index: poolIdx[j], verdict: v, reason: "" };
      if (v === "wrong_buyer") sawWrongBuyer = true;
      if (v === "wrong_car") sawWrongCar = true;
    }
    var reason = sawWrongBuyer ? "wrong_buyer"
      : sawWrongCar ? "wrong_car"
      : !list.length ? "no_window"
      : !freshIdx.length ? "no_window"
      : "empty";
    return { index: -1, verdict: "", reason: reason };
  }
  // [PURE-WALK360-END]
  // [PURE-WALK361-BEGIN] — truthful walk
  // outcomes and thread-identity resolution
  // (v2.1.161, header note 102). Extracted and
  // unit-exercised by the test harness; keep
  // free of DOM references.
  // .160 counted a capture "captured" on the
  // transport's ok alone — but the capture
  // handler wraps EVERY worker result as
  // ok:true, including the merge guard's
  // {skipped:"no_thread_id"} drop, so a
  // refused capture filed nothing yet counted
  // as a win (Kyara, 2026-11-19: 16 messages
  // harvested from her dock card, nothing
  // saved, the walk still reported captured).
  // The deciders here restore the evidence
  // rule: a capture is captured only when the
  // worker's answer evidences a real save —
  // handleCaptureChat's single success return
  // carries the saved prospect's name and no
  // skipped field; every refusal carries a
  // skipped code instead (see walk357Outcome).
  // The refusal's code, verbatim — it rides
  // the pill and the trace as the candidate's
  // reason, so a refused capture names WHY.
  function walk361OutcomeReason(resp) {
    if (!resp || typeof resp !== "object") return "";
    if (typeof resp.skipped === "string" && resp.skipped) return resp.skipped;
    return "";
  }
  // The walk's thread identity, in order of
  // trust: the capture's own URL (the
  // thread-page lane always carries the real
  // /t/<id>), the candidate's verified ref
  // (an anchor href, or the row's React-props
  // mining), then the matched dock card's own
  // thread anchor. Only a ref carrying a real
  // /t/<id> counts — the worker's tombstone
  // key and its prospect thread matching key
  // off that same id, so anything weaker
  // would file under a guess. "" means no
  // real identity exists: the walk must NOT
  // send the capture (the merge guard would
  // rightly drop it) and fails the candidate
  // at walk level as no_thread_id instead.
  function walk361ResolveThreadRef(capUrl, candRef, cardRef) {
    var refs = [capUrl, candRef, cardRef];
    for (var i = 0; i < refs.length; i++) {
      if (/\/t\/\d+/.test(String(refs[i] || ""))) return String(refs[i]);
    }
    return "";
  }
  // The pill learns the new failure's name.
  if (typeof WALK359_REASON_TEXT !== "undefined") {
    WALK359_REASON_TEXT.no_thread_id = "no thread id";
  }
  // [PURE-WALK361-END]
  // [PURE-LABEL362-BEGIN] — the vehicle
  // label deciders (v2.1.162, header note
  // 103). Extracted and unit-exercised by
  // the test harness; keep free of DOM
  // references.
  // .161's first landed walk capture (Husen,
  // 2026-11-19) filed its prospect under a
  // fused notification banner — "UnreadYour
  // listing received 28 clicks: 2014
  // Chevrolet Silverado.4h" — text about a
  // DIFFERENT car, carried by the thread
  // page's first item link, while the
  // thread's own listing header ("$31,563 ·
  // 2020 Lexus ES") sat unread further down.
  // A wrong label is worse than none: it
  // poisons Luca's availability matching.
  // These deciders are the one place label
  // candidates are judged, for both capture
  // lanes — findListing (the thread page,
  // and the dock card's own item link) and
  // the harvest's header fallback:
  // banner-shaped text is rejected outright,
  // and the first surviving candidate in
  // preference order wins.
  // Is this candidate notification/banner
  // text? The shapes are Facebook's seller
  // notifications, never a listing label: a
  // leading "Unread" badge (fused or not),
  // a "Your listing received …" line, a
  // click / view count, or a trailing
  // relative-time fragment ("·4h", ".4h").
  function label362IsBanner(s) {
    var t = String(s || "").trim().replace(/\s+/g, " ");
    if (!t) return false;
    if (/^unread/i.test(t)) return true;
    if (/your listing received/i.test(t)) return true;
    if (/\b\d[\d,]*\s*(?:clicks?|views?)\b/i.test(t)) return true;
    if (/[·.]\s*\d{1,3}\s*[mhd]\s*$/i.test(t)) return true;
    return false;
  }
  // Decide a capture's vehicle label over
  // its candidates, in preference order (the
  // conversation's own listing identity
  // first). Returns the first candidate that
  // is a plausible label and not banner text;
  // when none survives, the label is "" — an
  // honest empty. banner counts the
  // non-empty candidates rejected as banner
  // text, so the walk report can say the
  // label is empty BECAUSE everything
  // offered was a banner, not because
  // nothing was read.
  function label362Decide(cands) {
    var list = Array.isArray(cands) ? cands : [];
    var banner = 0;
    for (var i = 0; i < list.length; i++) {
      var s = String(list[i] || "").trim().replace(/\s+/g, " ");
      if (!s) continue;
      if (label362IsBanner(s)) { banner++; continue; }
      if (s.length >= 4) return { label: s, index: i, banner: banner };
    }
    return { label: "", index: -1, banner: banner };
  }
  // [PURE-LABEL362-END]
  // [PURE-WALK363-BEGIN] — the header-shape
  // decider and the enumeration funnel text
  // (v2.1.163, header note 104). Extracted and
  // unit-exercised by the test harness; keep
  // free of DOM references (the caller resolves
  // elements to plain text / plain counts).
  // .162's desk walk ended "0 new · 1 seen ·
  // 5 failed — no window×5" while dock cards
  // stood visibly open: the enumeration's one
  // chain — a composer seed gated on a
  // "message" aria-label, then a climb gated
  // on a "close"-labelled control — died
  // silently at one of its gates, and nothing
  // recorded which. .163 gives the walk a
  // second, independent enumeration seeded on
  // the cards' HEADERS (their DOM half is
  // [GLUE363]) and a funnel that counts every
  // gate, so a blind walk names where it died.
  // Is this text a dock card's header title?
  // The shape is the one dockCard360ParseHeader
  // already trusts — "Buyer Name · Vehicle" —
  // judged by dockCard360TitleParts, with the
  // vehicle half REQUIRED: a bare name is page
  // chrome too often to seed a card hunt. The
  // one exception is Facebook's own
  // "Conversation titled …" label, which only
  // ever sits on a conversation's furniture,
  // so its remainder is judged as-is.
  function dockCard363HeaderShape(text) {
    var s = String(text || "").trim().replace(/\s+/g, " ");
    if (!s) return null;
    if (/^Conversation titled /.test(s)) {
      return dockCard360TitleParts(s.replace(/^Conversation titled\s*/, ""));
    }
    var p = dockCard360TitleParts(s);
    if (!p || !p.vehicle) return null;
    return p;
  }
  // The enumeration funnel as one compact
  // trace field: "s<seeds>,c<composer roots>,
  // h<header candidates>,r<header roots>,
  // x<close-test deaths>". c/h/r/x describe
  // the LAST poll; s is the max seed count
  // seen across the candidate's polls — seeds
  // only grow as cards open, and the max is
  // the number that says whether anything was
  // ever there to find.
  function walk363FunnelText(funnel, maxSeeds) {
    var f = funnel || {};
    var s = Math.max(maxSeeds || 0, f.s || 0);
    return "s" + s + ",c" + (f.c || 0) + ",h" + (f.h || 0) +
           ",r" + (f.r || 0) + ",x" + (f.x || 0);
  }
  // The funnel record itself: plain counts,
  // no DOM. It is declared HERE, with the
  // deciders, because the walk reads it on
  // every surface the enumeration serves —
  // the enumeration ([GLUE363]) publishes
  // into it on each run; where the enumeration
  // never ran it honestly reads all zeros.
  var dockCard363Funnel = { s: 0, c: 0, h: 0, r: 0, x: 0 };
  // [PURE-WALK363-END]
  // [PURE-WALK364-BEGIN] — thread-page
  // identity fallback deciders (v2.1.164,
  // header note 105). Extracted and
  // unit-exercised by the test harness; keep
  // free of DOM references (the caller
  // resolves URLs, menu items, page evidence
  // and registry state into plain data).
  // .163's desk walk FIXED detection — cards
  // found, harvested, closed — and then all
  // five candidates failed at ONE gate: no
  // thread id. The .161 identity sources (the
  // capture's URL, the row's mined ref, the
  // card's own /t/ anchor) are all absent for
  // ordinary Marketplace rows; Husen, the one
  // success, worked only because his row
  // carried a notification thread-page link.
  // The fallback mints the identity from the
  // thread page itself: open the candidate's
  // conversation full-page from its card,
  // read the /t/<id> out of the address bar,
  // and file the already-harvested capture
  // under it — but only after the landed
  // page's own header proves it is the
  // candidate's thread. These deciders judge
  // the plain evidence; the DOM half is
  // [GLUE364].
  // The canonical thread ref for a URL: the
  // same /t/<id> extraction walk357Identity
  // and the worker's prospect_tombstones key
  // use, so the minted key and the tombstone
  // agree on what a thread IS. "" when the
  // URL carries no real thread id.
  function walk364RefFromUrl(url) {
    var m = String(url || "").match(/\/t\/(\d+)/);
    return m ? "https://www.facebook.com/messages/t/" + m[1] : "";
  }
  // Which item of a card menu may be clicked
  // to reach the thread page. Items arrive as
  // plain {label, href, target}. First pass:
  // an item whose href carries a real thread
  // id and does NOT open a new tab (a _blank
  // item would strand the walk in this tab
  // and litter the rep's browser) — an
  // "Open in Messenger" label preferred, then
  // any such anchor. Second pass: a same-tab
  // item LABELLED "Open in Messenger" with no
  // href at all (an SPA navigation button).
  // Anything else — profile links, mute,
  // block — is never clicked: the fallback
  // navigates and reads only.
  function walk364MenuItemPick(items) {
    var list = Array.isArray(items) ? items : [];
    var i, it;
    for (i = 0; i < list.length; i++) {
      it = list[i] || {};
      if (it.href && /\/t\/\d+/.test(String(it.href)) && it.target !== "_blank" &&
          /open in messenger/i.test(String(it.label || ""))) return i;
    }
    for (i = 0; i < list.length; i++) {
      it = list[i] || {};
      if (it.href && /\/t\/\d+/.test(String(it.href)) && it.target !== "_blank") return i;
    }
    for (i = 0; i < list.length; i++) {
      it = list[i] || {};
      if (!it.href && it.target !== "_blank" &&
          /open in messenger/i.test(String(it.label || ""))) return i;
    }
    return -1;
  }
  // The fallback's verdict over plain
  // evidence: did a navigation land on a
  // thread page, did the landed page's header
  // prove the candidate's thread, and what
  // does the registry already know about the
  // minted key. "file" is the only verdict
  // that sends anything; a registry hit of
  // ANY terminal state means the thread was
  // already handled — "deleted" keeps its
  // tombstone meaning, every other state is
  // a plain skip — and a landed page whose
  // header does not prove the candidate is a
  // mismatch: file nothing, ever, under an
  // unverified id.
  function walk364Judge(landed, verified, regState) {
    if (!landed) return "no_nav";
    if (!verified) return "mismatch";
    if (regState === "deleted") return "deleted";
    if (regState) return "skip";
    return "file";
  }
  // The identity diagnostic as one compact
  // trace field (the row's idn): what
  // identity material was present and what
  // the fallback did. "r<n>" thread hrefs in
  // the candidate's row, "c<n>" in its card,
  // "d<0|1>" a menu/title toggle was found,
  // then one "<mech>:<result>" per rung
  // attempted — mech menu | title | row,
  // result verified | mismatch | no_nav |
  // no_item | seen | na. A fallback that
  // never ran (no card to open from) reads
  // "r0,c0,d0,na".
  function walk364IdnText(d) {
    var o = d || {};
    var head = "r" + (o.r || 0) + ",c" + (o.c || 0) + ",d" + (o.d ? 1 : 0);
    if (o.na) return head + ",na";
    var steps = Array.isArray(o.steps) ? o.steps : [];
    if (!steps.length) return head + ",na";
    var parts = [];
    for (var i = 0; i < steps.length; i++) {
      var s = steps[i] || {};
      parts.push(String(s.m || "?") + ":" + String(s.r || "?"));
    }
    return head + "," + parts.join("/");
  }
  // [PURE-WALK364-END]
  // [PURE-WALK365-BEGIN] — Messages-view
  // walk deciders (v2.1.165, header note
  // 106). Extracted and unit-exercised by
  // the test harness; keep free of DOM
  // references (the caller resolves list
  // rows, page evidence and registry state
  // into plain data).
  // .164's desk walk proved the Marketplace
  // inbox surface has NO road to a thread
  // URL: its card menus hold buyer actions
  // (WhatsApp, Call), its card title opens
  // a Members box, its row clicks only
  // toggle dock cards — all five candidates
  // were found, harvested and closed, and
  // still failed as no_thread_id; zero
  // prospects landed. The thread's identity
  // lives on facebook.com/messages instead:
  // a thread opened there carries
  // /messages/t/<id> in the address bar,
  // and a Marketplace conversation shows
  // its listing card at the top — the
  // inside-thread lane has captured from
  // those pages since October (Husen's
  // landed ref is a /messages/t/ URL).
  // These deciders judge the plain evidence
  // for that route: the list row's name and
  // snippet, the match over same-name rows,
  // the landed page's proof, and the mv
  // diagnostic text. The DOM half is
  // [GLUE365].
  // Comparison text for snippets: case
  // folded, whitespace collapsed, and a
  // leading "You:"/"You " (the rep's own
  // latest line, as list previews mark it)
  // removed — the two surfaces prefix it
  // inconsistently.
  function walk365NormText(s) {
    return String(s || "").trim().toLowerCase().replace(/\s+/g, " ")
      .replace(/^you[:\s]+/, "");
  }
  // Snippet agreement: normalized
  // containment either way (the two lists
  // truncate the same line differently).
  // Short snippets (under 8 normalized
  // chars) must be exactly equal — a
  // fragment of a fragment proves nothing.
  // An empty side never agrees.
  function walk365SnippetAgree(a, b) {
    var na = walk365NormText(a), nb = walk365NormText(b);
    if (!na || !nb) return false;
    if (na.length < 8 || nb.length < 8) return na === nb;
    return na.indexOf(nb) !== -1 || nb.indexOf(na) !== -1;
  }
  // A Messages-list row's text, parsed into
  // { name, snippet }: the name is the
  // first " · " segment (a fused "You:"
  // tail cut, a long fused segment
  // rejected — the heuristics
  // collectThreadStubs applies); the
  // snippet is the longest remaining
  // segment that is neither a time token
  // nor a listing label; a fused row with
  // no usable segment falls back to the
  // text after its year/make/model label
  // (the snippetTailFallback rule).
  var WALK365_TIME_RE = /^(\d{1,2}:\d{2}\s?(AM|PM)?|\d+\s?[mhdw]|Mon|Tue|Wed|Thu|Fri|Sat|Sun|Jan \d+|Feb \d+|Mar \d+|Apr \d+|May \d+|Jun \d+|Jul \d+|Aug \d+|Sep \d+|Oct \d+|Nov \d+|Dec \d+|Just now|Yesterday)$/i;
  function walk365ParseRowText(rowText) {
    var text = String(rowText || "").trim().replace(/\s+/g, " ");
    if (!text) return { name: "", snippet: "" };
    var segs = text.split(" · ").map(function (s) { return s.trim(); }).filter(Boolean);
    var name = segs.length ? segs[0] : "";
    var youAt = name.indexOf("You:");
    if (youAt > 0) name = name.slice(0, youAt).trim();
    if (name.length > 30) name = "";
    if (!name || /\$/.test(name) || /^(Chats|Marketplace|New message|Meta AI|Facebook user)/i.test(name)) name = "";
    var rest = segs.slice(1).filter(function (s) {
      return !WALK365_TIME_RE.test(s) && !/^\$[\d,]+\s*-/.test(s) && s.length > 1;
    });
    var snippet = rest.reduce(function (a, b) { return b.length > a.length ? b : a; }, "");
    if (!snippet) {
      var lm = text.match(/\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z0-9]+/);
      if (lm) {
        var tail = text.slice(text.indexOf(lm[0]) + lm[0].length)
          .replace(/^[\s·|-]+/, "")
          .replace(/\s+\d{1,2}:\d{2}\s?(AM|PM)?\s*$/i, "")
          .replace(/\s+\d+\s?[mhdw]\s*$/i, "")
          .trim();
        if (tail.length >= 2) snippet = tail;
      }
    }
    return { name: name, snippet: snippet.slice(0, 140) };
  }
  // The match over the Messages list: rows
  // arrive as plain { key, name, snippet }.
  // The rule is name + snippet (the brief's
  // deterministic finder — no surface
  // search or filter is trusted with it):
  // - exactly one name match whose snippet
  //   agrees: open it (via "snippet");
  // - exactly one name match with no
  //   snippet verdict against it: open it
  //   (via "name") — the thread page's own
  //   proof still decides before anything
  //   files;
  // - a single name match whose snippet
  //   positively DISAGREES: probe it (open
  //   only to read its header — the
  //   thread's own latest line may have
  //   moved past the inbox preview);
  // - several name matches the snippet
  //   cannot single out: probe the
  //   snippet-agreeing subset when there
  //   is one, else every name match;
  // - no name match at all: "none".
  // Probing never files on its own: the
  // glue files only when exactly one
  // probed thread proves name + label +
  // snippet (see [GLUE365]).
  function walk365Match(cand, rows) {
    var list = Array.isArray(rows) ? rows : [];
    var cn = walk358NormName(cand && cand.buyerName);
    if (!cn) return { action: "none", why: "no_row" };
    var nameIdx = [];
    for (var i = 0; i < list.length; i++) {
      if (list[i] && walk358NormName(list[i].name) === cn) nameIdx.push(i);
    }
    if (!nameIdx.length) return { action: "none", why: "no_row" };
    var cs = (cand && cand.snippet) || "";
    var snipIdx = nameIdx.filter(function (ix) { return walk365SnippetAgree(cs, list[ix].snippet); });
    if (snipIdx.length === 1) return { action: "open", index: snipIdx[0], via: "snippet" };
    if (snipIdx.length > 1) return { action: "probe", indices: snipIdx };
    if (nameIdx.length === 1) {
      if (cs && list[nameIdx[0]].snippet) return { action: "probe", indices: nameIdx };
      return { action: "open", index: nameIdx[0], via: "name" };
    }
    return { action: "probe", indices: nameIdx };
  }
  // The landed thread page's verdict over
  // plain evidence: the header name proof
  // (the inside-thread lane's own — the
  // page's buyer name must equal the
  // candidate's), the listing state (the
  // thread's listing header: "agree" —
  // present and not contradicting the
  // candidate's label; "conflict" —
  // present and contradicting; "absent" —
  // the thread carries NO listing header,
  // so it is not a Marketplace thread at
  // all), and what the registry already
  // knows about the minted key. Order is
  // deliberate: identity before registry
  // (a mis-proven page's key is not the
  // candidate's key, so its registry state
  // must not decide), and registry before
  // the listing verdicts (a thread the rep
  // deleted keeps its tombstone meaning
  // even if its label would quarrel).
  // "file" is the only verdict that sends
  // anything; an absent listing is
  // not_marketplace — the thread stays
  // manual-only, exactly as Matthew scoped
  // label-less threads (2026-11-19).
  function walk365Judge(ev) {
    var o = ev || {};
    if (!o.nameOk) return "mismatch";
    if (o.regState === "deleted") return "deleted";
    if (o.regState) return "skip";
    if (o.labelState === "conflict") return "mismatch";
    if (o.labelState === "absent") return "not_marketplace";
    return "file";
  }
  // The Messages-route diagnostic as one
  // compact trace field (the row's mv):
  // one "<step>:<result>" per step the
  // route took, "/" joined — nav (direct |
  // list | no_nav), find (the name-matched
  // row count), pick (snippet | name |
  // probe | ambiguous), open (ok |
  // no_thread_url), verify (ok |
  // name_mismatch | label_conflict |
  // not_marketplace), reg (seen), back
  // (ok | return_failed). A route that
  // never ran reads "na".
  function walk365MvText(d) {
    var steps = (d && Array.isArray(d.steps)) ? d.steps : [];
    if (!steps.length) return "na";
    var parts = [];
    for (var i = 0; i < steps.length; i++) {
      var s = steps[i] || {};
      parts.push(String(s.m || "?") + ":" + String(s.r || "?"));
    }
    return parts.join("/");
  }
  // The pill learns the route's failure
  // names.
  if (typeof WALK359_REASON_TEXT !== "undefined") {
    WALK359_REASON_TEXT.ambiguous_thread = "ambiguous thread";
    WALK359_REASON_TEXT.name_mismatch = "name mismatch";
    WALK359_REASON_TEXT.no_row = "not in Messages";
    WALK359_REASON_TEXT.no_thread_url = "no thread URL";
    WALK359_REASON_TEXT.return_failed = "couldn't get back";
  }
  // [PURE-WALK365-END]
  function findMessages(scopeNode356) {
    // Popup first: when the chat is the floating mini-window, scope to
    // it — its own midpoint is what separates buyer (left) from rep
    // (right); measured against the whole page the popup sits right of
    // center and every bubble would read as the rep's.
    // v2.1.156: scrape() passes its isolated scope in —
    // on a blocked surface this function is never
    // called at all.
    var main = scopeNode356 || findChatPopup() || document.querySelector('[role="main"]') || document.body;
    // Message text lives in dir="auto" blocks; a bubble is the closest
    // reasonably-sized container around one.
    var nodes = main.querySelectorAll('[dir="auto"]');
    var titles = threadTitleTexts();
    // Participant names (v2.51): a node whose WHOLE text is a
    // participant's name is a sender caption or the info card's
    // name line, never a message — both were stored live as buyer
    // "messages" ("Matthew", "Matthew DeMoss"). Names come from
    // the thread title scrape and from the actor position of the
    // group system lines themselves, which name every actor in
    // full ("Matthew DeMoss created this group").
    var participantNames = {};
    try {
      var bn = findBuyerName();
      if (bn) participantNames[bn] = 1;
    } catch (e) { /* the caption rule just disarms */ }
    for (var a = 0; a < nodes.length; a++) {
      var at = textOf(nodes[a]);
      if (!at) continue;
      var am = at.match(/^(.{2,60}?)\s+(?:named the group|changed the group|created this group|added\s|left the group|joined the group|removed\s)/);
      if (am) participantNames[am[1].trim()] = 1;
    }
    var cands = [];
    for (var i = 0; i < nodes.length; i++) {
      var t = textOf(nodes[i]);
      if (!t || t.length < 1 || t.length > 1000) continue;
      // Skip UI chrome that also uses dir="auto". The second pattern
      // set is Matthew's live thread (2026-10-25): header card labels,
      // group-system lines, and pane furniture that are NOT messages.
      if (/^(Seen|Delivered|Sent|Type a message|Aa|Search|Active now|You're friends on Facebook|You're both on Facebook)/.test(t)) continue;
      if (/^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(t)) continue; // timestamp dividers ("1:57 PM") are not messages
      if (/^[.·]?\s*\d{1,3}\s*[mhdw]$/i.test(t)) continue; // v2.1.133 (note 83): relative time labels (".15m", "2h") are thread furniture, not messages
      if (t === "Message sent" || t === "Message delivered") continue; // status furniture, not a message
      if (/^(View buyer|More options|Privacy & support|Messages|Send a quick response|Marketplace)$/.test(t)) continue;
      if (/^Conversation titled /.test(t)) continue;
      if (/^Conversation with /.test(t)) continue; // v2.50: half-rendered thread header
      if (/ created this group$/.test(t)) continue;
      if (isGroupSystemText(t)) continue; // v2.51: group-event narration ("… named the group …", "… changed the group photo.")
      if (/^\$[\d,]+\s*[-–—]\s*(19|20)\d{2}\s+\S/.test(t) && t.length <= 60) continue; // v2.51: the listing card's label line
      if (/^Highly rated\b/.test(t) || t === "on Marketplace") continue; // v2.51: buyer-card ratings furniture (split-node form)
      if (participantNames[t]) continue; // v2.51: sender caption / info-card name line
      if (/mutual friends/.test(t) || /badge on Marketplace/.test(t)) continue;
      // Info-panel guard (v2.1.39): the thread page's right rail
      // (Media, files and links) lives inside [role=main] too — its
      // attachment rows (filenames, sizes, dates) are not messages.
      // Seen live 2026-10-25 vacuuming a files list into a thread.
      if (nodes[i].closest && nodes[i].closest('[role="complementary"]')) continue;
      if (/\.(csv|txt|pdf|jpe?g|png|gif|mp3|wav|zip|docx?|xlsx?)$/i.test(t)) continue;
      if (/^\d+(\.\d+)?\s?(KB|MB|GB|B)$/.test(t)) continue;
      if (/Unread message:/.test(t)) continue;
      // Chrome-label filter (v2.1.48): the exact denylist + this
      // thread's title, and the structural containment rule. The
      // denylist check now also covers the v2.51 transient states.
      if (isChromeText(t, titles)) continue;
      if (inChromeStructure(nodes[i], t)) continue;
      var r = nodes[i].getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      cands.push({ text: t, rect: r });
    }
    if (!cands.length) return [];
    // Direction pass (v2.51): the conversation column is the span
    // the surviving bubbles themselves occupy — the page pane's
    // midpoint never enters into it (see bubbleDirection).
    var colLeft = Infinity, colRight = -Infinity;
    for (var b = 0; b < cands.length; b++) {
      if (cands[b].rect.left < colLeft) colLeft = cands[b].rect.left;
      var rr = cands[b].rect.left + cands[b].rect.width;
      if (rr > colRight) colRight = rr;
    }
    var colWidth = colRight - colLeft;
    var out = [];
    var seen = {};
    for (var k = 0; k < cands.length; k++) {
      var dir = bubbleDirection(cands[k].rect, colLeft, colRight, colWidth);
      if (!dir) continue; // unplaceable — skip rather than guess a side
      var key = cands[k].text + "|" + dir;
      if (seen[key]) continue;
      seen[key] = true;
      out.push({ direction: dir, body: cands[k].text });
    }
    // Capture-hygiene cuts (v2.1.111, note 62) — applied
    // to the scraped rows AFTER direction assignment, on
    // purpose: the awaiting-reply banner's wide,
    // right-hugging bubble is part of what defines the
    // column the direction pass measures against, so
    // cutting it during the candidate loop would shrink
    // the column and can leave the buyer's real message
    // unplaceable in exactly the minimal first-message
    // thread this feature serves (proven in the 3.11
    // harness: with the banner cut early, the desk
    // fixture's question spans the narrowed column and is
    // skipped as unplaceable). (1) HEADER NAME: the thread
    // header's name line can survive the loop above as the
    // FIRST scraped message — the participant-name filter
    // keys on the titled label's name form, while the
    // header element renders the buyer's full name
    // (Matthew's live thread, 2026-11-13: "Matthew
    // DeMoss" stored ahead of the buyer's real first
    // message). A first message whose whole text is a name
    // this scrape itself resolved for the buyer — from the
    // titled label, the header's visible title text, or
    // the header heading — is the header element, not a
    // message, when at least one more message follows it.
    // Anywhere else, or alone, a name is kept.
    // (2) WAITING BANNER: a row whose WHOLE text matches
    // the banner pattern is UI chrome, never a message.
    var resolvedNames311 = {};
    if (typeof bn !== "undefined" && bn) resolvedNames311[bn] = 1;
    try {
      var titled311 = document.querySelector('[aria-label^="Conversation titled "]');
      if (titled311) {
        var visName311 = textOf(titled311).split("·")[0].trim();
        if (visName311 && visName311.length >= 2 && visName311.length <= 60) resolvedNames311[visName311] = 1;
      }
    } catch (e) { /* heuristic only */ }
    try {
      var headScope311 = findChatPopup() || document.querySelector('[role="main"]');
      if (headScope311) {
        var heads311 = headScope311.querySelectorAll("h1, h2");
        for (var hj = 0; hj < heads311.length; hj++) {
          var ht311 = textOf(heads311[hj]);
          if (ht311 && ht311.length >= 2 && ht311.length <= 60 && !isJunkName(ht311) && !/messenger|marketplace|chats|inbox/i.test(ht311)) { resolvedNames311[ht311] = 1; break; }
        }
      }
    } catch (e) { /* heuristic only */ }
    if (out.length >= 2 && resolvedNames311[out[0].body]) out.shift();
    out = out.filter(function (m) { return !/^.+ is waiting for your response\.?$/.test(m.body); });
    // DOM order is chronological; keep the most recent 30.
    return out.slice(-30);
  }

  // Seller-side evidence for the worker's auto-create gate
  // (v2.1.46): which surface this thread was read on, and whether
  // the thread pane carries the SELLER's controls. "View buyer"
  // renders only when the signed-in user is the listing's seller;
  // a buyer-side thread shows "View seller" instead.
  function threadSurface() {
    var p = window.location.pathname || "";
    return p.indexOf("/marketplace/inbox") === 0 ? "marketplace_inbox" : "";
  }

  function findSellerContext() {
    try {
      var scope = findChatPopup() || document.querySelector('[role="main"]') || document;
      var els = scope.querySelectorAll("a, button, [role='button'], span");
      for (var i = 0; i < els.length; i++) {
        if ((els[i].textContent || "").trim() === "View buyer") return true;
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return false;
  }

  // Facebook identity (v2.1.47, worker header note 23): the gate's
  // self test compares IDENTITIES, never names — the rep tests from
  // a second account under the same display name, and real buyers
  // can share his name. Tokens are canonical: "id:<digits>" for
  // numeric profile ids, "vanity:<lowercased>" otherwise; an id
  // token never equals a vanity token (unproven = not self).
  var FB_RESERVED_SEGMENTS = {
    messages: 1, marketplace: 1, groups: 1, watch: 1, gaming: 1,
    friends: 1, notifications: 1, settings: 1, help: 1, events: 1,
    pages: 1, login: 1, sharer: 1, dialog: 1, plugins: 1, people: 1,
    search: 1, bookmarks: 1, me: 1, home: 1, "profile.php": 1,
    "photo.php": 1, "permalink.php": 1
  };

  function fbIdentityFromHref(href) {
    try {
      var u = new URL(href);
      if (!/(^|\.)facebook\.com$/.test(u.hostname)) return "";
      if (/\/profile\.php$/.test(u.pathname)) {
        var m = (u.search || "").match(/[?&]id=(\d+)/);
        return m ? "id:" + m[1] : "";
      }
      var seg = (u.pathname || "").split("/").filter(Boolean);
      if (seg.length === 1 && !FB_RESERVED_SEGMENTS[seg[0].toLowerCase()]) {
        return "vanity:" + seg[0].toLowerCase();
      }
    } catch (e) { /* not a profile link */ }
    return "";
  }

  function findSelfFbId() {
    // c_user is the signed-in account's numeric id, readable by the
    // page. Fallback: a profile.php link pointing at the account.
    try {
      var m = (document.cookie || "").match(/(?:^|;\s*)c_user=(\d+)/);
      if (m) return "id:" + m[1];
    } catch (e) { /* fall through */ }
    try {
      var links = document.querySelectorAll('a[href*="profile.php?id="]');
      for (var i = 0; i < links.length; i++) {
        var id = fbIdentityFromHref(links[i].href || "");
        if (id) return id;
      }
    } catch (e) { /* heuristic only */ }
    return "";
  }

  function findBuyerFbId(selfId) {
    // The counterparty's profile link lives on the thread pane —
    // the header / buyer card and the info rail, which on group-
    // flavored Marketplace threads is also where "Chat members"
    // links render. Take the pane's profile identities in order:
    // the buyer is the first that isn't provably the signed-in
    // user; if ALL of them are the signed-in user, the counterparty
    // IS the user (a true self thread). Tightest scope wins.
    try {
      var scopes = [findChatPopup(), document.querySelector('[role="main"]'), document].filter(Boolean);
      for (var s = 0; s < scopes.length; s++) {
        var seen = [];
        var links = scopes[s].querySelectorAll("a[href]");
        for (var i = 0; i < links.length; i++) {
          var id = fbIdentityFromHref(links[i].href || "");
          if (id && seen.indexOf(id) === -1) seen.push(id);
        }
        if (!seen.length) continue;
        for (var j = 0; j < seen.length; j++) {
          if (!selfId || seen[j] !== selfId) return seen[j];
        }
        return selfId;
      }
    } catch (e) { /* heuristic only */ }
    return "";
  }

  function scrape(popupOverride358) {
    // [CAPTURE-356] thread isolation decides FIRST
    // (see captureScope356): the popup's own
    // container, a dedicated thread page, or
    // blocked — and blocked means the message
    // harvest never runs, so a list surface can
    // never be filed as one merged conversation.
    // [WALK358] the caller may name the exact
    // popover to read (the inbox walk's opened
    // thread); in popup mode the buyer name then
    // comes from WITHIN that popover — the
    // document-scoped findBuyerName resolves
    // nothing usable on an inbox list (note 99).
    var popup356 = popupOverride358 || findChatPopup();
    var mode356 = captureScope356(!!popup356, threadKeyOf(window.location.href));
    var listing = findListing(popup356);
    var selfId = findSelfFbId();
    return {
      buyerName: mode356 === "popup" ? popupBuyerName358(popup356) : findBuyerName(),
      vehicleText: listing.vehicleText,
      itemUrl: listing.itemUrl,
      threadUrl: window.location.href,
      surface: threadSurface(),
      sellerContext: findSellerContext(),
      selfFbId: selfId,
      buyerFbId: findBuyerFbId(selfId),
      messages: mode356 === "blocked" ? [] : findMessages(mode356 === "popup" ? popup356 : null),
      isolated356: mode356 !== "blocked"
    };
  }

  // Capture failure reasons (v2.1.47): a bare "Capture failed" told
  // the rep nothing. After a helper update, an already-open
  // Facebook tab runs an ORPHANED script whose sendMessage throws
  // (context invalidated) — the fix is reloading the tab, and the
  // label now says so. Worker-declined captures carry its code.
  function captureFailLabel(lastError, resp) {
    var msg = (lastError && lastError.message) || "";
    if (/context invalidated|receiving end does not exist|message port closed/i.test(msg)) {
      return "Capture failed — reload this Facebook tab";
    }
    if (resp && resp.error === "not_signed_in") return "Capture failed — open AutoLaunch & sign in";
    if (resp && resp.error === "no_buyer") return "Capture failed — no buyer found in this chat";
    if (resp && resp.error) return "Capture failed — try again in a moment";
    return "Capture failed — is AutoLaunch signed in?";
  }

  // [LABEL358-BEGIN] — persistent labels
  // (v2.1.158, header note 99): the walk's
  // result must stay readable until the rep's
  // next press — the .157 desk proof lost its
  // counts to the 4-second revert before they
  // could be read. A label set with persist358
  // stays; the generation counter keeps any
  // older pending revert from erasing a newer
  // label, and walk358LabelHold stops the auto
  // pass's status line from painting over a
  // held result. Manual labels keep the 4s
  // revert exactly as before.
  var btnLabelGen358 = 0;
  var walk358LabelHold = false;
  function setBtnLabel(btn, label, ok, persist358) {
    btn.textContent = label;
    btn.style.background = ok === true ? "#059669" : ok === false ? "#e11d48" : "#2563eb";
    var gen358 = ++btnLabelGen358;
    if (persist358) { walk358LabelHold = true; return; }
    setTimeout(function () {
      if (gen358 !== btnLabelGen358) return;
      btn.textContent = "🌙 Capture chat for Luca";
      btn.style.background = "#2563eb";
    }, 4000);
  }
  // [LABEL358-END]

  function injectButton() {
    if (!onChatSurface() || document.getElementById(BTN_ID)) return;
    var btn = document.createElement("button");
    btn.id = BTN_ID;
    btn.textContent = "🌙 Capture chat for Luca";
    btn.style.cssText = [
      "position:fixed", "right:16px", "bottom:16px", "z-index:2147483647",
      "background:#2563eb", "color:#fff", "border:none", "border-radius:999px",
      "padding:10px 16px", "font:600 13px system-ui, sans-serif",
      "box-shadow:0 4px 14px rgba(0,0,0,.35)", "cursor:pointer"
    ].join(";");
    btn.addEventListener("click", function () {
      walk358LabelHold = false; // [WALK358] a fresh press retires the held walk result (note 99)
      var capture = scrape();
      if (onInboxListSurface() && capture.isolated356 === false) {
        // [WALK357] the press landed on an inbox
        // list with no thread isolated: walk the
        // list (v2.1.157, note 98) — the helper
        // opens each NEW thread itself instead of
        // failing clean and making the rep do it.
        alWalk357Run(btn);
        return;
      }
      if (!capture.messages.length && !capture.buyerName && onInboxListSurface()) {
        autoPass();
        setBtnLabel(btn, "Synced ✓", true);
        return;
      }
      if (capture.isolated356 === false && capture.buyerName) {
        // [CAPTURE-356] a thread is on screen (its
        // title resolved a buyer) but could not be
        // isolated — fail clean, send nothing. A
        // merged prospect is never acceptable.
        setBtnLabel(btn, "Capture failed — open the chat fully first", false);
        return;
      }
      if (!capture.messages.length && !capture.buyerName) {
        setBtnLabel(btn, "Nothing found — open a chat first", false);
        return;
      }
      btn.textContent = "Capturing…";
      try {
        chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CAPTURE_CHAT", capture: capture }, function (resp) {
          if (chrome.runtime.lastError || !resp || !resp.ok) {
            setBtnLabel(btn, captureFailLabel(chrome.runtime.lastError, resp), false);
            return;
          }
          setBtnLabel(btn, "Captured ✓ " + (resp.added || 0) + " new · " + (resp.prospectName || "prospect"), true);
          alWalk357NoteOutcome(capture, resp); // [WALK357] registry: the manual lane's captures count as captured
        });
      } catch (e) {
        setBtnLabel(btn, "Capture failed — reload this Facebook tab", false);
      }
    });
    document.body.appendChild(btn);
  }

  // ---- AUTO-CAPTURE v1 (v2.1.31, Matthew's ask): no more clicking
  // Capture per chat. While an inbox surface is open in Chrome:
  //  - every visible thread-list row becomes a STUB capture (the
  //    prospect exists in AutoLaunch with its thread link; the worker
  //    matches by thread, so rows never duplicate a real prospect);
  //  - the OPEN thread (full view or floating popup) is fully captured
  //    whenever its content changes (new message = new hash).
  // The helper never clicks or navigates anything — it only reads
  // what is already on screen, on a slow timer.
  function onInboxListSurface() {
    var p = window.location.pathname || "";
    return p.indexOf("/messages") === 0 || p.indexOf("/marketplace/inbox") === 0;
  }

  function threadKeyOf(url) {
    var m = String(url || "").match(/\/t\/(\d+)/);
    return m ? m[1] : "";
  }

  function collectThreadStubs() {
    var out = [];
    var seen = {};
    var links = document.querySelectorAll('a[href*="/messages/t/"]');
    for (var i = 0; i < links.length && out.length < 15; i++) {
      var key = threadKeyOf(links[i].href || "");
      if (!key || seen[key]) continue;
      var rowText = textOf(links[i]);
      if (!rowText || rowText.length < 3) continue;
      seen[key] = true;
      // Rows lead with the buyer name, then separators/snippets. The
      // worker self-heals names from later full captures, so a rough
      // name here is acceptable — a wrong THREAD never is, and the
      // thread key comes from the href, not the text.
      var nm = rowText.split(" · ")[0].trim();
      var youAt = nm.indexOf("You:");
      if (youAt > 0) nm = nm.slice(0, youAt).trim();
      // A long first segment means the name fused with the snippet —
      // a placeholder (which full captures self-heal) beats a wrong
      // name that never gets corrected.
      if (nm.length > 30) nm = "";
      if (!nm || /\$/.test(nm) || /^(Chats|Marketplace|New message)/i.test(nm)) nm = "";
      if (isJunkName(nm)) nm = ""; // v2.50: a chrome placeholder is not a name
      var vm = rowText.match(/\$\d[\d,]*\s*-\s*[^·]{4,80}/);
      if (!vm) vm = rowText.match(/\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z0-9]+/); // year/make/model label also proves Marketplace
      // Commerce gate (v2.1.34): the plain /messages list mixes in
      // personal chats, business-page chats and the Meta AI chat —
      // none of those are buyers. A row is only SENT with Marketplace
      // evidence: a priced listing label, a year/make/model label,
      // or the Marketplace inbox surface itself (which is commerce-
      // only by construction). Since v2.1.46 this pre-filter no
      // longer decides creation — the worker's autoCreateGate does,
      // and it fails closed where this pass cannot tell.
      var onMarketplaceInbox = (window.location.pathname || "").indexOf("/marketplace/inbox") === 0;
      var yearMake = /\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z]+/.test(rowText);
      if (!onMarketplaceInbox && !vm && !yearMake) continue;
      if (/^(Meta AI|Facebook user)\b/i.test(nm) && !vm) continue;
      out.push({
        buyerName: nm,
        vehicleText: vm ? cleanListingLabel(vm[0]) : "",
        itemUrl: "",
        threadUrl: "https://www.facebook.com/messages/t/" + key,
        // v2.1.46: the worker's auto-create gate keys its surface
        // signal on this — a stub born on the Marketplace inbox is
        // commerce-surface evidence; a plain /messages row is not.
        surface: onMarketplaceInbox ? "marketplace_inbox" : "",
        sellerContext: false,
        selfFbId: findSelfFbId(),
        buyerFbId: "",
        messages: [],
        stub: true
      });
    }
    return out;
  }

  // v2.1.105 (note 58): the preview tail of a list row whose
  // text never separates into list segments (the /messages/
  // Marketplace folder renders some rows fused): the text
  // after the year/make/model label, minus a trailing time
  // token. The year/make/model match is bounded, so it
  // cannot swallow the preview the way the price-label
  // match could on a fused row. "" when no label anchors it.
  function snippetTailFallback(rowText) {
    var lm = rowText.match(/\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z0-9]+/);
    if (!lm) return "";
    var tail = rowText.slice(rowText.indexOf(lm[0]) + lm[0].length)
      .replace(/^[\s\u00b7|-]+/, "")
      .replace(/\s+\d{1,2}:\d{2}\s?(AM|PM)?\s*$/i, "")
      .replace(/\s+\d+\s?[mhdw]\s*$/i, "")
      .trim();
    return (tail.length >= 2 && !isChromeText(tail, null)) ? tail : "";
  }

  // Snippet sync (v2.1.33): each list row also carries the conversation's
  // NEWEST line as a preview — and that preview updates live when a
  // buyer writes, no click needed. We forward those lines for every
  // visible row; the worker stores them only for threads that already
  // belong to a prospect (personal chats are never pulled in). "You:"
  // prefixes mark the rep's own latest line.
  function collectThreadSnippets() {
    var out = [];
    var seen = {};
    var timeLike = /^(\d{1,2}:\d{2}\s?(AM|PM)?|\d+\s?[mhdw]|Mon|Tue|Wed|Thu|Fri|Sat|Sun|Jan \d+|Feb \d+|Mar \d+|Apr \d+|May \d+|Jun \d+|Jul \d+|Aug \d+|Sep \d+|Oct \d+|Nov \d+|Dec \d+|Just now|Yesterday)$/i;
    var links = document.querySelectorAll('a[href*="/messages/t/"]');
    for (var i = 0; i < links.length && out.length < 15; i++) {
      var key = threadKeyOf(links[i].href || "");
      if (!key || seen[key]) continue;
      var rowText = textOf(links[i]);
      if (!rowText || rowText.length < 3) continue;
      seen[key] = true;
      var segs = rowText.split(" · ").map(function (s) { return s.trim(); }).filter(Boolean);
      if (segs.length < 2) {
        var tailF = snippetTailFallback(rowText);
        if (tailF) segs = [segs[0] || "", tailF];
      }
      if (segs.length < 2) continue;
      var rest = segs.slice(1).filter(function (s) {
        return !timeLike.test(s) && !/^\$[\d,]+\s*-/.test(s) && s.length > 1;
      });
      if (!rest.length) {
        var tailF2 = snippetTailFallback(rowText);
        if (tailF2) rest = [tailF2];
      }
      if (!rest.length) continue;
      var snippet = rest.reduce(function (a, b) { return b.length > a.length ? b : a; }, "");
      var direction = "in";
      if (/^You[:\s]/i.test(snippet)) {
        direction = "out";
        snippet = snippet.replace(/^You[:\s]+/i, "").trim();
      }
      if (snippet.length < 2) continue;
      if (isChromeText(snippet, null)) continue; // v2.1.48: a chrome label is not a snippet
      out.push({
        threadRef: "https://www.facebook.com/messages/t/" + key,
        snippet: snippet.slice(0, 140),
        direction: direction
      });
    }
    return out;
  }

  // ---- Marketplace inbox BUTTON rows (v2.1.108, note 60) ----
  // facebook.com/marketplace/inbox renders conversation rows
  // as <button> elements (role="button") with NO href and NO
  // contained <a> — proven by live DOM inspection 2026-11-13
  // (zero anchors matching a[href*="/messages/t/"] on the
  // whole page). The anchor harvest above has therefore
  // never seen this surface. Rows sit inside <main>
  // alongside the Selling/Buying/Jobs tabs. This harvest
  // reads rendered row text only: it NEVER clicks a row and
  // NEVER marks anything read.
  var INBOX_ROW_TIME_RE = /^(\d{1,2}:\d{2}\s?(AM|PM)|Yesterday|Today|(Mon|Tue|Wed|Thu|Fri|Sat|Sun)(day)?|(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}|\d{1,2}\/\d{1,2}(\/\d{2,4})?)$/i;
  // Pure line parser (lines in, fields out) so the harness
  // exercises the exact shipped code on the live row texts.
  // Lines: header ("<Name> · <Label>" or a bare "<Name>"),
  // the preview line(s), an optional trailing timestamp.
  function parseInboxButtonRow(lines) {
    var ls = (lines || []).map(function (s) { return String(s || "").replace(/\s+/g, " ").trim(); }).filter(Boolean);
    // v2.1.110 (note 61): the live row renders its header
    // SPLIT — the buyer's name on one line, "· <Label>"
    // on its own line (the nbsp-only line between them
    // collapsed away above). Rejoin any line that begins
    // with "·" onto the previous line, so the " · "
    // split below sees the one-line header this parser was
    // written for. Single-line headers are untouched; a
    // leading "·" line has no previous line and stays
    // as-is, exactly as before.
    for (var li = 1; li < ls.length; li++) {
      if (ls[li].indexOf("·") === 0) { ls[li - 1] += " " + ls[li]; ls.splice(li, 1); li--; }
    }
    if (ls.length && INBOX_ROW_TIME_RE.test(ls[ls.length - 1])) ls.pop();
    if (ls.length < 2) return null;
    var header = ls[0];
    var preview = ls.slice(1).join(" ");
    var name = header, label = "";
    var cut = header.indexOf(" · ");
    if (cut > 0) { name = header.slice(0, cut).trim(); label = header.slice(cut + 3).trim(); }
    name = name.trim();
    label = cleanListingLabel(label);
    if (!name || isJunkName(name)) return null;
    if (/^(Selling|Buying|Jobs|Inbox|Notifications|Create)/i.test(name)) return null;
    if (!preview) return null;
    return { buyerName: name, vehicleLabel: label, preview: preview.slice(0, 140) };
  }
  function inboxRowUnread(rowEl) {
    try {
      var els = rowEl.querySelectorAll ? rowEl.querySelectorAll("[aria-label]") : [];
      for (var i = 0; i < els.length; i++) {
        if (/unread/i.test(els[i].getAttribute("aria-label") || "")) return true;
      }
      if (/unread/i.test((rowEl.getAttribute && rowEl.getAttribute("aria-label")) || "")) return true;
    } catch (e) { /* best-effort */ }
    return null;
  }
  // Best-effort thread identity from the row's React props:
  // a /messages/t/<id> string in any prop value, or a
  // thread-named key carrying a numeric id. Bounded walk;
  // yields "" when the props hold nothing thread-shaped.
  function inboxPropsThreadId(val, depth, budget) {
    if (val == null || depth > 4 || !budget || budget.n <= 0) return "";
    budget.n--;
    if (typeof val === "string") {
      var m = val.match(/\/messages\/t\/(\d{6,})/);
      return m ? m[1] : "";
    }
    if (typeof val !== "object") return "";
    var keys;
    try { keys = Object.keys(val); } catch (e) { return ""; }
    for (var i = 0; i < keys.length && i < 48; i++) {
      var k = keys[i], v = val[k];
      if (/thread/i.test(k) && (typeof v === "string" || typeof v === "number")) {
        var s = String(v);
        if (/^\d{10,19}$/.test(s)) return s;
        var m2 = s.match(/\/messages\/t\/(\d{6,})/);
        if (m2) return m2[1];
      }
      var r = inboxPropsThreadId(v, depth + 1, budget);
      if (r) return r;
    }
    return "";
  }
  function inboxRowThreadRef(rowEl) {
    try {
      var budget = { n: 800 };
      var stack = [{ node: rowEl, depth: 0 }];
      var guard = 0;
      while (stack.length && guard < 300) {
        guard++;
        var cur = stack.pop();
        var node = cur.node;
        if (!node || typeof node !== "object") continue;
        var keys = Object.keys(node);
        for (var i = 0; i < keys.length; i++) {
          if (keys[i].indexOf("__reactProps$") === 0 || keys[i].indexOf("__reactFiber$") === 0) {
            var hit = inboxPropsThreadId(node[keys[i]], 0, budget);
            if (hit) return "https://www.facebook.com/messages/t/" + hit;
          }
        }
        if (cur.depth < 3 && node.children) {
          for (var j = 0; j < node.children.length; j++) stack.push({ node: node.children[j], depth: cur.depth + 1 });
        }
      }
    } catch (e) { /* best-effort only */ }
    return "";
  }
  function collectInboxButtonRows() {
    var out = [];
    if ((window.location.pathname || "").indexOf("/marketplace/inbox") !== 0) return out;
    // v2.1.110 (note 61): the live inbox has NO <main>
    // tag — its rows live inside a [role="main"] container
    // (the 3.09 desk trace: hasMainTag false, all 15 rows
    // inside the single role=main). Fall back to it; a
    // page WITH a <main> tag behaves exactly as before.
    var main = document.querySelector("main") || document.querySelector('[role="main"]');
    if (!main) return out;
    var rows = main.querySelectorAll('button, [role="button"]');
    for (var i = 0; i < rows.length && out.length < 15; i++) {
      var el = rows[i];
      var raw = el.innerText || el.textContent || "";
      var parsed = parseInboxButtonRow(String(raw).split(/\n+/));
      if (!parsed) continue;
      // Conversation rows carry a thumbnail or a listing
      // label; the bare tab/chrome buttons carry neither.
      var hasImg = false;
      try { hasImg = !!el.querySelector("img"); } catch (e) { /* ignore */ }
      if (!hasImg && !parsed.vehicleLabel) continue;
      out.push({
        rowKind: "inbox_button",
        threadRef: inboxRowThreadRef(el),
        snippet: parsed.preview,
        direction: "in",
        buyerName: parsed.buyerName,
        vehicleLabel: parsed.vehicleLabel,
        unread: inboxRowUnread(el)
      });
    }
    return out;
  }

  function sendCapture(capture) {
    // Every caller of this shared sender is an AUTO path (list pass,
    // observer, app-driven sync) — tag it so the worker can apply
    // the Marketplace-only auto rule. The manual Capture button has
    // its own send and stays untagged (a deliberate click is how a
    // rep adds a non-Marketplace thread).
    capture = Object.assign({}, capture, { auto: true });
    // Returns a promise that resolves when the worker has finished
    // (its handler responds only after the database write), so the
    // app-driven sync below can report TRUE completion.
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CAPTURE_CHAT", capture: capture }, function (resp) {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  // Gate-skip retry (v2.50, background.js header note 24): the
  // worker's auto-create gate fails CLOSED on a half-rendered
  // page — unresolved_name before the header paints the buyer's
  // name, no_seller_signal before the seller controls / listing
  // link render. Those skips used to be FINAL: the open thread's
  // full capture is hash-deduped below, so a thread skipped
  // mid-render was never re-asked even after the page finished
  // painting. Track render-dependent skips per thread and re-ask
  // on later passes; terminal outcomes (created, self_thread,
  // deleted_by_user) clear the thread. Bounded per page session —
  // a thread that genuinely never resolves is retried a handful
  // of times, not forever.
  var GATE_RETRY_MAX = 10;
  var RENDER_SKIP_REASONS = { unresolved_name: 1, no_seller_signal: 1 };
  var gateSkipped = {}; // threadKey -> { capture, tries }

  function gateRetryKey(capture) {
    return threadKeyOf((capture && capture.threadUrl) || "") ||
      String((capture && capture.threadUrl) || "");
  }

  function noteCaptureResult(capture, resp) {
    var key = gateRetryKey(capture);
    if (!key) return;
    alWalk357NoteOutcome(capture, resp); // [WALK357] registry: tombstones + captured marks from every tracked path
    if (resp && resp.skipped) {
      if (RENDER_SKIP_REASONS[resp.skipped]) {
        var g = gateSkipped[key] || { tries: 0 };
        g.capture = capture;
        g.tries += 1;
        gateSkipped[key] = g;
      } else {
        delete gateSkipped[key]; // terminal skip (self / deleted)
      }
    } else if (resp && resp.ok) {
      delete gateSkipped[key];
    }
  }

  function sendCaptureTracked(capture) {
    var p = sendCapture(capture);
    // sendCapture resolves with the worker's response (or null on
    // a dead channel) — learning the outcome is the whole point.
    if (p && p.then) p.then(function (resp) {
      try { noteCaptureResult(capture, resp); } catch (e) { /* bookkeeping only */ }
    });
    return p;
  }

  function gateRetryDue(key) {
    var g = gateSkipped[key];
    return !!g && g.tries < GATE_RETRY_MAX;
  }

  var lastFullHash = "";
  function autoFullCapture() {
    if (!onChatSurface()) return null;
    // v2.1.103 (note 56): never full-scrape a LIST surface.
    // With no real thread open, scrape() keys its harvest to
    // the list page's own URL and the worker files the whole
    // list as one fake conversation (2026-10-28 diagnosis;
    // the 3.02 hub tab made it fire on Matthew's desk,
    // 2026-11-12). A thread counts as open here only when
    // the URL carries its /t/<id> or a floating chat popup is
    // actually on screen. Stub + snippet collection on list
    // surfaces is unchanged, and the worker drops id-less
    // auto captures regardless (defense in depth).
    // v2.1.156 (note 97): the isolation decision itself
    // moved into scrape() (captureScope356) — one
    // decider for the auto pass and the manual button,
    // which previously had no gate at all.
    var c = scrape();
    if (!c.isolated356) return null;
    if (!c.messages.length && !c.buyerName) return null;
    var h = (c.threadUrl || "") + "|" + c.messages.map(function (m) { return m.direction + ":" + m.body; }).join("~");
    // A thread with a render-dependent skip on file bypasses the
    // hash dedupe while its retry budget lasts — the page may
    // have finished rendering around the very same messages.
    if (h === lastFullHash && !gateRetryDue(threadKeyOf(c.threadUrl || ""))) return null;
    lastFullHash = h;
    var sent = sendCaptureTracked(c);
    // Hash honesty (v2.51): the hash used to stay marked no
    // matter what the worker answered, so any outcome that
    // stored NOTHING — a not_signed_in error while the app tab
    // re-delivered the session, a thrown save, a dead channel —
    // poisoned the dedupe for the rest of the page session and
    // the open thread went silent until its text changed
    // (Matthew's ~10 quiet minutes with a rendered thread open,
    // 2026-10-27; the manual button, which bypasses the hash,
    // worked instantly). Only a CONFIRMED outcome keeps the
    // hash: stored (ok), or a skip the worker decided (render
    // skips re-ask through the gateSkipped bypass above;
    // terminal skips must never re-ask). Anything else re-arms.
    if (sent && sent.then) sent.then(function (resp) {
      try {
        var confirmed = !!(resp && (resp.ok || resp.skipped));
        if (!confirmed && lastFullHash === h) lastFullHash = "";
      } catch (e) { /* bookkeeping only */ }
    });
    return sent;
  }

  // [WALK357-BEGIN] — INBOX-LIST WALK
  // (v2.1.157, header note 98): the manual
  // Capture button, pressed on an inbox LIST
  // with no thread open, walks the list itself.
  // It enumerates candidate threads, opens each
  // NEW one programmatically (one at a time,
  // paced), captures it through the unchanged
  // .156 isolated scrape, returns to the list,
  // and moves on. The list page itself is never
  // harvested — the .156 isolation gate stays
  // absolute, and a candidate whose opened
  // thread cannot be identity-verified against
  // the row that was clicked is skipped, never
  // filed under a guess.
  //
  // NEW-ONLY: a persistent registry in
  // chrome.storage.local remembers every thread
  // the helper has terminally handled, keyed
  // exactly as the worker keys its
  // prospect_tombstones (the numeric /t/<id>,
  // else a buyer+listing key). A thread the rep
  // DELETED stays "deleted" here — and the
  // worker's server-side tombstone is the
  // backstop the walk re-learns from any
  // deleted_by_user response, so a deletion
  // made anywhere (another machine, the app)
  // re-tombstones locally before anything can
  // be created. The auto paths never walk:
  // walking clicks, and only the rep's explicit
  // Capture press may do that.
  var WALK357_CAP = 5;          // new-thread attempts per run
  var WALK357_GAP_MS = 2000;    // pacing between threads
  var WALK357_OPEN_WAIT_MS = 8000;
  var WALK358_CLOSE_WAIT_MS = 3200; // [WALK358] close-verify budget per popover
  var WALK357_REG_KEY = "luca_walk361_registry";
  var WALK357_REG_MAX = 400;
  var walk357Running = false;
  var walk357RegChain = Promise.resolve();

  function walk357WaitMs(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function alWalk357LoadRegistry() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get([WALK357_REG_KEY], function (o) {
          void chrome.runtime.lastError;
          var reg = o && o[WALK357_REG_KEY];
          resolve(reg && typeof reg === "object" ? reg : {});
        });
      } catch (e) { resolve({}); }
    });
  }

  // Serialized load-mutate-save: the walk, the
  // gate bookkeeping hook and the manual button
  // can all record outcomes; the chain keeps
  // their writes from clobbering each other.
  function alWalk357UpdateRegistry(mutate) {
    var run = walk357RegChain.then(async function () {
      var reg = await alWalk357LoadRegistry();
      mutate(reg);
      reg = walk357Prune(reg, WALK357_REG_MAX);
      await new Promise(function (resolve) {
        try {
          var o = {}; o[WALK357_REG_KEY] = reg;
          chrome.storage.local.set(o, function () { void chrome.runtime.lastError; resolve(); });
        } catch (e) { resolve(); }
      });
      return reg;
    });
    walk357RegChain = run.then(function () {}, function () {});
    return run;
  }

  // The registry learns from EVERY capture
  // outcome, not just the walk's: hooked into
  // noteCaptureResult (all tracked sends) and
  // the manual button's callback. A stub's ok
  // does NOT mark a thread captured — a stub is
  // only a placeholder card, and the walk still
  // owes that thread its full capture.
  function alWalk357NoteOutcome(capture, resp) {
    try {
      if (!capture) return;
      var outcome = walk357Outcome(resp);
      if (outcome === "failed") return;
      if (outcome === "captured" && capture.stub) return;
      var key = walk357Identity({
        threadRef: capture.threadUrl || "",
        buyerName: capture.buyerName || "",
        vehicleLabel: capture.vehicleText || ""
      });
      if (!key) return;
      alWalk357UpdateRegistry(function (reg) {
        reg[key] = { at: Date.now(), state: outcome };
      });
    } catch (e) { /* bookkeeping only — never break a capture */ }
  }

  // Candidates from the two existing list
  // collectors (the anchor harvest and the
  // Marketplace button-row harvest — both
  // already commerce-gated: a listing label, or
  // the Marketplace inbox surface itself).
  function alWalk357Candidates() {
    var out = [];
    var seen = {};
    function push(cand) {
      cand.key = walk357Identity(cand);
      if (!cand.key || seen[cand.key]) return;
      seen[cand.key] = 1;
      out.push(cand);
    }
    try {
      collectThreadStubs().forEach(function (c) {
        push({
          kind: "anchor",
          threadKey: threadKeyOf(c.threadUrl || ""),
          threadRef: c.threadUrl || "",
          buyerName: c.buyerName || "",
          vehicleLabel: c.vehicleText || "",
          unread: null
        });
      });
    } catch (e) { /* one lane failing never blocks the other */ }
    try {
      collectInboxButtonRows().forEach(function (r) {
        push({
          kind: "button",
          threadKey: threadKeyOf(r.threadRef || ""),
          threadRef: r.threadRef || "",
          buyerName: r.buyerName || "",
          vehicleLabel: r.vehicleLabel || "",
          snippet: r.snippet || "", // [WALK365] the Messages route's match rule needs the inbox row's snippet
          unread: (r.unread === true || r.unread === false) ? r.unread : null
        });
      });
    } catch (e) { /* same */ }
    return out;
  }

  // The row element is resolved FRESH at open
  // time — the list re-renders constantly, and a
  // stale element would click the wrong thread
  // or nothing at all.
  function alWalk357FindRowEl(cand) {
    try {
      if (cand.kind === "anchor" && cand.threadKey) {
        var links = document.querySelectorAll('a[href*="/messages/t/"]');
        for (var i = 0; i < links.length; i++) {
          if (threadKeyOf(links[i].href || "") === cand.threadKey) return links[i];
        }
        return null;
      }
      var main = document.querySelector("main") || document.querySelector('[role="main"]');
      if (!main) return null;
      var rows = main.querySelectorAll('button, [role="button"]');
      for (var j = 0; j < rows.length; j++) {
        var raw = rows[j].innerText || rows[j].textContent || "";
        var parsed = parseInboxButtonRow(String(raw).split(/\n+/));
        if (!parsed) continue;
        var key = walk357Identity({
          threadRef: inboxRowThreadRef(rows[j]),
          buyerName: parsed.buyerName,
          vehicleLabel: parsed.vehicleLabel
        });
        if (key && key === cand.key) return rows[j];
      }
    } catch (e) { /* best-effort */ }
    return null;
  }

  function alWalk357IdentityMatch(cand, cap) {
    if (!cap || !cap.isolated356) return false;
    var capKey = threadKeyOf(cap.threadUrl || "");
    if (capKey) return !!cand.threadKey && capKey === cand.threadKey;
    // Isolated with no key in the URL is the
    // floating-popup lane (a thread page always
    // carries its id): the identity proof there
    // is the pure [PURE-WALK358] verdict over
    // popup-scoped evidence — the popover's own
    // buyer name (a positively different name
    // is a hard mismatch), or, only when the
    // popover yields no name, listing-label
    // agreement between the row and the popover.
    return walk358IdentityVerdict(cand, cap);
  }

  // [WALK360-BEGIN] — dock-card walk
  // (v2.1.160, header note 101): .159 anchored
  // on the popover its click produced, but
  // its popover enumeration matched none of
  // Facebook's chat DOCK CARDS on the inbox /
  // you/selling surface — the walk saw no
  // window at all while the cards visibly
  // opened and stacked, unclosed. The walk
  // now works on the dock itself:
  // - ENUMERATE: findDockCards360() lists
  //   every dock card as a first-class
  //   object (node, header identity from the
  //   card's OWN header, subheader label,
  //   its own close control);
  // - MATCH: after the row click,
  //   walk360Pick chooses the card whose
  //   header matches the candidate — a card
  //   the click opened first; an already-open
  //   card with a matching header is claimed
  //   only when the click opened nothing
  //   (Matthew's desk case: Husen's card was
  //   already open at walk start). Only a
  //   positively different header is a
  //   mismatch;
  // - HARVEST strictly inside the matched
  //   card (the .159 anchor-scoped rule,
  //   re-aimed at the dock card; the list
  //   page itself is never harvested);
  // - CLOSE via the card's own ×, verified
  //   by that card's header being gone from
  //   the dock before the next candidate; a
  //   card that will not close stops the
  //   walk (carried rule).
  // The run leaves a persistent report
  // (chrome.storage.local
  // "luca_walk360_report" + AUTOLAUNCH_TRACE
  // walk360_* rows), and the per-candidate
  // failure reasons ride the pill's main
  // line (walk359ReasonSuffix).
  var WALK361_REPORT_KEY = "luca_walk361_report";
  var WALK360_CLOSE_BUDGET_MS = 3000;

  // The anchor-local title set for the chrome
  // filter: the anchor's own titled label and
  // the name + listing pair it shows — the
  // document-wide title scrape would import
  // other threads' headers mid-walk.
  function alWalk359AnchorTitles(node, anchorName, anchorLabel) {
    var out = {};
    try {
      var titled = node.querySelector('[aria-label^="Conversation titled "]');
      if (titled) {
        var t = (titled.getAttribute("aria-label") || "").replace(/^Conversation titled\s*/, "").trim();
        if (t) out[t] = 1;
        var vis = textOf(titled);
        if (vis) out[vis] = 1;
      }
    } catch (e) { /* heuristic only */ }
    if (anchorLabel) {
      out[anchorLabel] = 1;
      var lt = anchorLabel.replace(/^\$[\d,]+\s*-\s*/, "").trim();
      if (anchorName && lt) out[anchorName + " · " + lt] = 1;
    }
    return out;
  }

  // The message harvest, anchor-scoped: the
  // .156/.157 message rules (chrome denylist,
  // transient states, group-system lines,
  // listing-card line, participant captions,
  // the geometry direction pass, the header
  // and banner hygiene cuts) with every
  // document read replaced by its anchor
  // equivalent — nodes, titles, participants
  // and headings all come from the anchor.
  function alWalk359AnchorMessages(node, anchorName, anchorLabel) {
    var titles = alWalk359AnchorTitles(node, anchorName, anchorLabel);
    var nodes = [];
    try { nodes = node.querySelectorAll('[dir="auto"]'); } catch (e) { return []; }
    var participantNames = {};
    if (anchorName) participantNames[anchorName] = 1;
    for (var a = 0; a < nodes.length; a++) {
      var at = textOf(nodes[a]);
      if (!at) continue;
      var am = at.match(/^(.{2,60}?)\s+(?:named the group|changed the group|created this group|added\s|left the group|joined the group|removed\s)/);
      if (am) participantNames[am[1].trim()] = 1;
    }
    var cands = [];
    for (var i = 0; i < nodes.length; i++) {
      var t = textOf(nodes[i]);
      if (!t || t.length < 1 || t.length > 1000) continue;
      if (/^(Seen|Delivered|Sent|Type a message|Aa|Search|Active now|You're friends on Facebook|You're both on Facebook)/.test(t)) continue;
      if (/^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(t)) continue;
      if (/^[.·]?\s*\d{1,3}\s*[mhdw]$/i.test(t)) continue;
      if (t === "Message sent" || t === "Message delivered") continue;
      if (/^(View buyer|More options|Privacy & support|Messages|Send a quick response|Marketplace)$/.test(t)) continue;
      if (/^Conversation titled /.test(t)) continue;
      if (/^Conversation with /.test(t)) continue;
      if (/ created this group$/.test(t)) continue;
      if (isGroupSystemText(t)) continue;
      if (/^\$[\d,]+\s*[-–—]\s*(19|20)\d{2}\s+\S/.test(t) && t.length <= 60) continue;
      if (/^Highly rated\b/.test(t) || t === "on Marketplace") continue;
      if (participantNames[t]) continue;
      if (/mutual friends/.test(t) || /badge on Marketplace/.test(t)) continue;
      if (nodes[i].closest && nodes[i].closest('[role="complementary"]')) continue;
      if (/\.(csv|txt|pdf|jpe?g|png|gif|mp3|wav|zip|docx?|xlsx?)$/i.test(t)) continue;
      if (/^\d+(\.\d+)?\s?(KB|MB|GB|B)$/.test(t)) continue;
      if (/Unread message:/.test(t)) continue;
      if (isChromeText(t, titles)) continue;
      if (inChromeStructure(nodes[i], t)) continue;
      var r = nodes[i].getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      cands.push({ text: t, rect: r });
    }
    if (!cands.length) return [];
    var colLeft = Infinity, colRight = -Infinity;
    for (var b = 0; b < cands.length; b++) {
      if (cands[b].rect.left < colLeft) colLeft = cands[b].rect.left;
      var rr = cands[b].rect.left + cands[b].rect.width;
      if (rr > colRight) colRight = rr;
    }
    var colWidth = colRight - colLeft;
    var out = [], seen = {};
    for (var k = 0; k < cands.length; k++) {
      var dir = bubbleDirection(cands[k].rect, colLeft, colRight, colWidth);
      if (!dir) continue;
      var key = cands[k].text + "|" + dir;
      if (seen[key]) continue;
      seen[key] = true;
      out.push({ direction: dir, body: cands[k].text });
    }
    // Hygiene, anchor-local: the header's name
    // line as the first message is the header
    // element, not a message, when more
    // follow; the awaiting-reply banner is
    // chrome (it did its work in the direction
    // pass above, widening the column).
    if (out.length >= 2 && anchorName && out[0].body === anchorName) out.shift();
    out = out.filter(function (m) { return !/^.+ is waiting for your response\.?$/.test(m.body); });
    return out.slice(-30);
  }

  // The seller signal from WITHIN the anchor:
  // "View buyer" renders in this popover's
  // own header when the signed-in user is the
  // listing's seller.
  function alWalk359SellerContext(node) {
    try {
      var els = node.querySelectorAll("a, button, [role='button'], span");
      for (var i = 0; i < els.length; i++) {
        if ((els[i].textContent || "").trim() === "View buyer") return true;
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return false;
  }

  // The counterparty identity from WITHIN the
  // anchor: the first profile identity in the
  // popover that is not provably the rep's.
  function alWalk359BuyerFbId(node, selfId) {
    try {
      var seen = [];
      var links = node.querySelectorAll("a[href]");
      for (var i = 0; i < links.length; i++) {
        var id = fbIdentityFromHref(links[i].href || "");
        if (id && seen.indexOf(id) === -1) seen.push(id);
      }
      for (var j = 0; j < seen.length; j++) {
        if (!selfId || seen[j] !== selfId) return seen[j];
      }
      if (seen.length) return selfId;
    } catch (e) { /* heuristic only */ }
    return "";
  }

  // Strategy (b): Escape, delivered to the
  // anchor and to the document.
  function alWalk359Escape(node) {
    var sent = false;
    try {
      var ev = null;
      try {
        ev = new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true });
      } catch (e1) {
        ev = { type: "keydown", key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true };
      }
      if (node && node.dispatchEvent) { node.dispatchEvent(ev); sent = true; }
      if (typeof document !== "undefined" && document && document.dispatchEvent) { document.dispatchEvent(ev); sent = true; }
    } catch (e) { /* strategy unavailable */ }
    return sent;
  }

  // One candidate's capture, harvested
  // strictly from its matched dock card: the
  // buyer name and listing label come from
  // the card's own header / listing link,
  // and the messages are read by the
  // anchor-scoped reader inside the card
  // node only. isolated356 stays absolute:
  // the list page itself is never harvested.
  // The matched card's OWN thread identity
  // (v2.1.161): a dock card carries anchors —
  // its header title links the conversation
  // itself — and the first in-card anchor
  // whose href carries a real /t/<id> is this
  // thread's ref. The card was matched to the
  // candidate by its header before harvest,
  // so its thread anchor is the matched
  // thread's identity, never a neighbour's.
  function alWalk361CardThreadRef(node) {
    try {
      var links = node.querySelectorAll("a[href]");
      for (var i = 0; i < links.length; i++) {
        var href = links[i].href || (links[i].getAttribute && links[i].getAttribute("href")) || "";
        if (/\/t\/\d+/.test(href)) return href;
      }
    } catch (e) { /* heuristic only */ }
    return "";
  }

  function alWalk360Harvest(card, cand) {
    var node = card.node;
    var listing = { vehicleText: "", itemUrl: "" };
    try { listing = findListing(node); } catch (e) { /* no listing link in the card */ }
    var name = card.name || "";
    // v2.1.162: the label is DECIDED over the
    // card's own listing identity — the item
    // link's text first (findListing has
    // already banner-filtered it), the
    // header/subheader parse second — and
    // banner text never wins (label362Decide).
    // labelBanner counts every banner
    // candidate rejected on the way, for the
    // walk report: an empty label with a
    // nonzero count is an honest empty, not
    // a missing scrape.
    var pick362 = label362Decide([listing.vehicleText, card.label]);
    var label = pick362.label;
    var labelBanner = (listing.banner362 || 0) + pick362.banner;
    var selfId = "";
    try { selfId = findSelfFbId(); } catch (e) { /* identity unknown */ }
    var messages = alWalk359AnchorMessages(node, name, label);
    var capture = {
      buyerName: name,
      vehicleText: label,
      itemUrl: listing.itemUrl || "",
      threadUrl: window.location.href,
      surface: threadSurface(),
      sellerContext: alWalk359SellerContext(node),
      selfFbId: selfId,
      buyerFbId: alWalk359BuyerFbId(node, selfId),
      messages: messages,
      isolated356: true
    };
    return {
      capture: capture,
      header: { name: name, label: label },
      msgCount: messages.length,
      threadRef: alWalk361CardThreadRef(node),
      labelBanner: labelBanner
    };
  }

  // Is this card still in the dock? Judged
  // on the enumerated cards' own headers:
  // the buyer name when the header had one,
  // else its listing label. A headerless
  // card is judged by its node.
  function alWalk360CardPresent(card, header) {
    var cards = findDockCards360();
    var i;
    if (header && (header.name || header.label)) {
      for (i = 0; i < cards.length; i++) {
        if (header.name && cards[i].name) {
          if (walk358NormName(cards[i].name) === walk358NormName(header.name)) return true;
        } else if (header.label && cards[i].label) {
          if (walk358LabelAgree(header.label, cards[i].label)) return true;
        }
      }
      return false;
    }
    if (!card || !card.node) return false;
    for (i = 0; i < cards.length; i++) {
      if (cards[i].node === card.node) return true;
    }
    return false;
  }

  // Close ONE dock card and verify it is
  // gone from the dock, on a shared 3000ms
  // budget (.159's shape, re-aimed):
  // (a) the card's OWN × — re-resolved
  // against the CURRENT dock at click time,
  // because the DOM churns and a stale
  // control can point at a dead subtree;
  // (b) Escape delivered into the card.
  // A minimise toggle is NOT a close and is
  // never clicked: a minimised card is still
  // an open card, and the walk's rule is
  // that every card it opened or claimed is
  // closed back down.
  async function alWalk360CloseCard(card, header) {
    if (!card || !card.node) return { ok: true, strategy: "none" };
    var hdr = header || { name: card.name || "", label: card.label || "" };
    if (!alWalk360CardPresent(card, hdr)) return { ok: true, strategy: "already" };
    var deadline = Date.now() + WALK360_CLOSE_BUDGET_MS;
    var strategies = [
      { name: "close_btn", run: function () {
          var cards = findDockCards360();
          for (var i = 0; i < cards.length; i++) {
            var same = cards[i].node === card.node;
            if (!same && hdr.name && cards[i].name &&
                walk358NormName(cards[i].name) === walk358NormName(hdr.name)) same = true;
            if (same && cards[i].closeEl) {
              try { cards[i].closeEl.click(); return true; } catch (e) { return false; }
            }
          }
          if (card.closeEl) {
            try { card.closeEl.click(); return true; } catch (e) { return false; }
          }
          return false;
        } },
      { name: "escape", run: function () { return alWalk359Escape(card.node); } }
    ];
    for (var s = 0; s < strategies.length; s++) {
      if (!strategies[s].run()) continue;
      while (Date.now() < deadline) {
        await walk357WaitMs(300);
        if (!alWalk360CardPresent(card, hdr)) return { ok: true, strategy: strategies[s].name };
      }
      if (!alWalk360CardPresent(card, hdr)) return { ok: true, strategy: strategies[s].name };
    }
    return { ok: !alWalk360CardPresent(card, hdr), strategy: "FAILED" };
  }

  // Open one candidate: snapshot the dock,
  // click its row, then poll the dock —
  // enumerating EVERY card each pass and
  // harvesting inside each — until
  // walk360Pick matches a card to the
  // candidate or the wait expires. Cards the
  // click opened are "fresh"; pre-existing
  // cards join the pool only when the click
  // opened nothing. Every fresh card is
  // handed to the return step for closing —
  // matched or not, so a failed candidate
  // never stacks cards either. The
  // thread-page lane (.157) is carried
  // verbatim: a click that navigates to the
  // thread page is harvested there and
  // returned from via history.
  async function alWalk357Open(cand, row360) {
    // v2.1.161 diagnostics: what the dock
    // enumeration actually sees, per poll —
    // the .160 walk read cards:0 for threads
    // whose cards were visibly open on screen,
    // and only a desk run's evidence can say
    // whether the enumerator or the timing was
    // blind. Seeded by the pre-click snapshot.
    row360.diag = { polls: [], names: [], rejects: 0, fn: "" };
    var fnMaxS363 = 0;
    var el = alWalk357FindRowEl(cand);
    if (!el) {
      row360.reason = "row_not_found";
      return { capture: null, anchorCard: null, closeCards: [], header: null };
    }
    // v2.1.161: collection-time ref mining
    // raced the list's render — re-mine the
    // LIVE row element (its React props carry
    // the thread id) before the click.
    if (!threadKeyOf(cand.threadRef || "")) {
      try {
        var ref361 = inboxRowThreadRef(el);
        if (ref361) cand.threadRef = ref361;
      } catch (e) { /* identity stays unresolved — the run's gate decides */ }
    }
    var before = findDockCards360();
    row360.diag.polls.push(before.length);
    // v2.1.163: the enumeration funnel rides
    // the row as fn — where each poll's
    // enumeration died, named at last (the
    // .162 walk's 21 zeros carried no such
    // evidence). s is held at the max seeds
    // seen across this candidate's polls.
    fnMaxS363 = dockCard363Funnel.s;
    row360.diag.fn = walk363FunnelText(dockCard363Funnel, fnMaxS363);
    var beforeNodes = before.map(function (c) { return c.node; });
    try { el.click(); } catch (e) {
      row360.reason = "no_window";
      return { capture: null, anchorCard: null, closeCards: [], header: null };
    }
    var lastPick = null, lastDescs = [];
    var end = Date.now() + WALK357_OPEN_WAIT_MS;
    while (Date.now() < end) {
      await walk357WaitMs(400);
      var cards = findDockCards360();
      row360.cards = cards.length;
      var descs = [];
      for (var ci = 0; ci < cards.length; ci++) {
        var h = null;
        try { h = alWalk360Harvest(cards[ci], cand); } catch (e) { h = null; }
        descs.push({
          card: cards[ci],
          fresh: beforeNodes.indexOf(cards[ci].node) === -1,
          name: cards[ci].name || (h ? h.header.name : ""),
          label: h ? (h.capture.vehicleText || cards[ci].label || "") : (cards[ci].label || ""),
          msgCount: h ? h.msgCount : 0,
          capture: h ? h.capture : null,
          cardRef: h ? (h.threadRef || "") : "",
          labelBanner: h ? (h.labelBanner || 0) : 0,
          header: h ? h.header : { name: cards[ci].name || "", label: cards[ci].label || "" }
        });
      }
      // v2.1.161 diagnostics: this poll's card
      // count, the header names the enumerator
      // read, and how many enumerated cards
      // yielded no identity at all (structural
      // rejects — a card was there but its
      // header gave neither name nor label).
      row360.diag.polls.push(cards.length);
      if (dockCard363Funnel.s > fnMaxS363) fnMaxS363 = dockCard363Funnel.s;
      row360.diag.fn = walk363FunnelText(dockCard363Funnel, fnMaxS363);
      for (var di = 0; di < descs.length; di++) {
        if (descs[di].name && row360.diag.names.indexOf(descs[di].name) === -1 && row360.diag.names.length < 8) {
          row360.diag.names.push(descs[di].name);
        }
        if (!descs[di].name && !descs[di].label) row360.diag.rejects++;
      }
      lastDescs = descs;
      var pick = walk360Pick(descs, cand);
      lastPick = pick;
      if (pick.index >= 0) {
        var chosen = descs[pick.index];
        if (chosen.capture && (chosen.msgCount || chosen.name)) {
          row360.anchor = true;
          row360.claimed = !chosen.fresh;
          row360.name = chosen.header.name;
          row360.msgs = chosen.msgCount;
          row360.verdict = pick.verdict;
          row360.labelBanner = chosen.labelBanner || 0;
          var closeCards = [];
          for (var fi = 0; fi < descs.length; fi++) {
            if (fi === pick.index) continue;
            if (descs[fi].fresh) closeCards.push(descs[fi].card);
          }
          closeCards.push(chosen.card);
          return { capture: chosen.capture, anchorCard: chosen.card, closeCards: closeCards, header: chosen.header, threadRef: chosen.cardRef || "" };
        }
      }
      if (!cards.length && threadKeyOf(window.location.href)) {
        var c2 = null;
        try { c2 = scrape(); } catch (e) { c2 = null; }
        if (c2 && alWalk357IdentityMatch(cand, c2) && (c2.messages.length || c2.buyerName)) {
          row360.name = c2.buyerName || "";
          row360.msgs = c2.messages.length;
          row360.verdict = "thread_page";
          // v2.1.162: this lane's label came
          // through findListing too — recount
          // its banner rejections (same scope
          // scrape() just read, same decision)
          // for the report.
          try { row360.labelBanner = (findListing() || {}).banner362 || 0; } catch (e) { /* the count stays 0 */ }
          return { capture: c2, anchorCard: null, closeCards: [], header: null };
        }
        if (c2 && !c2.isolated356) row360.reason = "not_isolated";
      }
    }
    // Timed out: record the best evidence the
    // dock offered, and hand the fresh cards
    // to the return step so even a failed
    // candidate never stacks.
    var freshCards = [];
    var best = null;
    for (var bi = 0; bi < lastDescs.length; bi++) {
      if (lastDescs[bi].fresh) freshCards.push(lastDescs[bi].card);
      if (!best && lastDescs[bi].name) best = lastDescs[bi];
    }
    row360.anchor = !!freshCards.length;
    if (best) { row360.name = best.name; row360.msgs = best.msgCount; }
    if (lastPick && lastPick.verdict) row360.verdict = lastPick.verdict;
    if (!row360.reason) row360.reason = lastPick ? lastPick.reason : "no_window";
    return { capture: null, anchorCard: null, closeCards: freshCards, header: best ? best.header : null };
  }

  // Return from one candidate. On a thread
  // page, history-back (carried). In the
  // dock, close every card the click opened
  // — strays first, the harvested card LAST,
  // so its header stays readable until the
  // strays are down — each verified gone by
  // its own header before the next; the
  // first card that will not close fails the
  // return and stops the walk.
  async function alWalk357Return(closeCards, anchorCard, anchorHeader) {
    try {
      if (threadKeyOf(window.location.href)) {
        window.history.back();
        var end = Date.now() + 6000;
        while (Date.now() < end) {
          await walk357WaitMs(400);
          if (onInboxListSurface() && !threadKeyOf(window.location.href)) return { ok: true, strategy: "history" };
        }
        return { ok: true, strategy: "history" };
      }
      var cards = Array.isArray(closeCards) ? closeCards : (closeCards ? [closeCards] : []);
      var lastStrategy = "none";
      for (var i = 0; i < cards.length; i++) {
        var hdr = (anchorCard && cards[i] === anchorCard) ? (anchorHeader || null)
          : { name: cards[i].name || "", label: cards[i].label || "" };
        var res = await alWalk360CloseCard(cards[i], hdr);
        lastStrategy = res.strategy;
        if (!res.ok) return { ok: false, strategy: res.strategy };
      }
      return { ok: true, strategy: lastStrategy };
    } catch (e) { return { ok: true, strategy: "error" }; }
  }

  // Persist the walk's report where the next
  // diagnosis can find it without the pill:
  // chrome.storage.local (survives the tab)
  // and the AUTOLAUNCH_TRACE channel via
  // ccDlv (public.helper_trace), the same
  // server-bound channel the .158/.159
  // diagnoses used. Best-effort both ways —
  // the pill still carries the summary.
  function alWalk360SaveReport(report) {
    try {
      var o = {};
      o[WALK361_REPORT_KEY] = report;
      chrome.storage.local.set(o, function () { void chrome.runtime.lastError; });
    } catch (e) { /* the pill still carries the summary */ }
    try {
      if (typeof ccDlv === "function") {
        for (var i = 0; i < report.rows.length; i++) {
          var r = report.rows[i];
          ccDlv("walk361_candidate", {
            buyer: r.buyer || "", anchor: r.anchor ? 1 : 0, claimed: r.claimed ? 1 : 0,
            name: r.name || "", msgs: r.msgs || 0, verdict: r.verdict || "",
            outcome: r.outcome || "", reason: r.reason || "", close: r.close || "",
            cards: r.cards || 0,
            label_banner: r.labelBanner || 0,
            polls: (r.diag && r.diag.polls || []).join(","),
            names: (r.diag && r.diag.names || []).join(" \u00b7 "),
            rejects: (r.diag && r.diag.rejects) || 0,
            fn: (r.diag && r.diag.fn) || "",
            idn: r.idn || "",
            mv: r.mv || ""
          }, r.threadRef || null);
        }
        ccDlv("walk361_summary", {
          v: 161, new: report.counts.captured, seen: report.counts.skippedOld,
          failed: report.counts.failed, stopped: report.stopped ? 1 : 0
        }, null);
      }
    } catch (e) { /* traces are best-effort */ }
  }

  // [GLUE364-BEGIN] — thread-page identity
  // fallback (v2.1.164, header note 105), the
  // DOM half of [PURE-WALK364]. It runs for
  // ONE shape of candidate: a dock card was
  // anchored and harvested, yet no identity
  // source (.161's three) produced a real
  // /t/<id> — the .163 desk walk's five
  // no_thread_id failures. The fallback opens
  // the candidate's OWN thread page from its
  // card, reads the id from the address bar,
  // proves the landed page is the candidate's
  // thread (its header name, judged by the
  // .358 verdict — alWalk357IdentityMatch's
  // keyed branch cannot serve here: it
  // demands the very key being minted), checks
  // the registry under the minted key, and
  // hands the run back either a verified ref
  // to file the dock harvest under, a terminal
  // registry state to skip by, or nothing.
  // Navigation mechanism, in the brief's
  // preference order, as the card's structure
  // supports it:
  // (a) the card's conversation MENU — its
  // toggle is a header button declaring
  // aria-haspopup, or, on the Marketplace
  // card Matthew's desk runs, the header
  // TITLE itself (the ⌄ rides in the title:
  // "Kyara · 2025 Ford Explorer ⌄", beside
  // the − and the ×). A menu renders in a
  // portal OUTSIDE the card — which is why
  // the card-scoped anchor scan never saw its
  // "Open in Messenger" thread link. The item
  // clicked is walk364MenuItemPick's: a
  // same-tab thread link, never a _blank one.
  // (b) the same title click, when it
  // navigates directly instead of opening a
  // menu (recorded as mech "title").
  // (c) a full re-click on the matched inbox
  // row — the .157-proven navigation
  // primitive — with any card the re-click
  // stacks closed again node-precisely, so a
  // failed rung leaves the dock as it found
  // it. ONE navigation per candidate, total:
  // the first rung that lands ends the hunt.
  // The fallback never sends, never clicks a
  // message action; it navigates and reads.
  function alWalk364CountRefs(node) {
    var n = 0;
    try {
      var links = node.querySelectorAll("a[href]");
      for (var i = 0; i < links.length; i++) {
        var href = links[i].href || (links[i].getAttribute && links[i].getAttribute("href")) || "";
        if (/\/t\/\d+/.test(href)) n++;
      }
    } catch (e) { /* diagnostics only */ }
    return n;
  }

  // The card's header title element — the
  // same evidence order dockCard360HeaderOf
  // reads: Facebook's titled label, a
  // header-shaped aria label, a heading, a
  // header-shaped leaf.
  function alWalk364TitleEl(card) {
    var node = card && card.node;
    if (!node) return null;
    try {
      var t = node.querySelector('[aria-label^="Conversation titled "]');
      if (t) return t;
      var labelled = node.querySelectorAll("[aria-label]");
      for (var i = 0; i < labelled.length; i++) {
        var lab = (labelled[i].getAttribute && labelled[i].getAttribute("aria-label")) || "";
        if (dockCard363HeaderShape(lab)) return labelled[i];
      }
      var heads = node.querySelectorAll("h1, h2");
      for (var j = 0; j < heads.length; j++) {
        if (dockCard363HeaderShape(textOf(heads[j]))) return heads[j];
      }
      var all = node.querySelectorAll("*");
      for (var k = 0; k < all.length; k++) {
        var el = all[k];
        if (el.children && el.children.length) continue;
        var txt = "";
        try { txt = (el.textContent || "").trim().replace(/\s+/g, " "); } catch (e) { txt = ""; }
        if (txt && dockCard363HeaderShape(txt)) return el;
      }
    } catch (e) { /* heuristic only */ }
    return null;
  }

  // A header button that declares a menu —
  // never the card's own close control.
  function alWalk364MenuToggle(card) {
    var node = card && card.node;
    if (!node) return null;
    try {
      var btns = node.querySelectorAll('button, [role="button"]');
      for (var i = 0; i < btns.length; i++) {
        var hp = (btns[i].getAttribute && btns[i].getAttribute("aria-haspopup")) || "";
        if (hp !== "menu" && hp !== "true") continue;
        if (card.closeEl && btns[i] === card.closeEl) continue;
        var lab = (btns[i].getAttribute && btns[i].getAttribute("aria-label")) || "";
        if (/close/i.test(lab)) continue;
        return btns[i];
      }
    } catch (e) { /* heuristic only */ }
    return null;
  }

  // A menu open anywhere in the document
  // (menus render in a portal at the root):
  // the LAST menu root, with its items as
  // plain data plus their elements.
  function alWalk364FindMenu() {
    try {
      var roots = document.querySelectorAll('[role="menu"], [role="listbox"]');
      if (!roots.length) return null;
      var root = roots[roots.length - 1];
      var els = root.querySelectorAll('[role="menuitem"], a[href], button, [role="button"]');
      var items = [];
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        items.push({
          el: el,
          label: ((el.getAttribute && el.getAttribute("aria-label")) || textOf(el) || "").trim(),
          href: el.href || (el.getAttribute && el.getAttribute("href")) || "",
          target: (el.getAttribute && el.getAttribute("target")) || ""
        });
      }
      return { root: root, items: items };
    } catch (e) { return null; }
  }

  // Poll for the address bar to carry a
  // thread id (the navigation landed).
  async function alWalk364WaitKey(ms) {
    var end = Date.now() + ms;
    while (Date.now() < end) {
      await walk357WaitMs(300);
      var k = threadKeyOf(window.location.href);
      if (k) return k;
    }
    return threadKeyOf(window.location.href);
  }

  // Poll for EITHER a landed navigation or
  // an opened menu — whichever the toggle
  // click produces first.
  async function alWalk364WaitMenuOrKey(ms) {
    var end = Date.now() + ms;
    while (Date.now() < end) {
      await walk357WaitMs(300);
      var k = threadKeyOf(window.location.href);
      if (k) return { key: k, menu: null };
      var menu = alWalk364FindMenu();
      if (menu) return { key: "", menu: menu };
    }
    return { key: threadKeyOf(window.location.href), menu: alWalk364FindMenu() };
  }

  // Close cards that were NOT in the dock
  // before (a failed row re-click can stack
  // a fresh copy of the candidate's card),
  // each by its OWN close control, verified
  // by that NODE leaving the enumeration —
  // never by header, which would take the
  // original card and leave the copy.
  async function alWalk364CloseNewNodes(beforeNodes) {
    var allOk = true;
    var cards = findDockCards360();
    for (var i = 0; i < cards.length; i++) {
      if (beforeNodes.indexOf(cards[i].node) !== -1) continue;
      var desc = cards[i];
      if (desc.closeEl) { try { desc.closeEl.click(); } catch (e) { /* the verify below decides */ } }
      var gone = false;
      var end = Date.now() + 1500;
      while (Date.now() < end && !gone) {
        await walk357WaitMs(300);
        gone = true;
        var now = findDockCards360();
        for (var j = 0; j < now.length; j++) { if (now[j].node === desc.node) { gone = false; break; } }
      }
      if (!gone) {
        var still = findDockCards360();
        gone = true;
        for (var k = 0; k < still.length; k++) { if (still[k].node === desc.node) { gone = false; break; } }
      }
      if (!gone) allOk = false;
    }
    return allOk;
  }

  // The landed thread page's identity proof,
  // through the existing inside-thread lane:
  // scrape() reads the thread page's own
  // header name, and that name must agree
  // with the candidate's buyer name — an
  // unnamed or differently-named page never
  // verifies. The scrape capture rides
  // along: it is the re-harvest source when
  // the dock harvest came back empty.
  function alWalk364Verify(cand) {
    var cap = null;
    try { cap = (typeof scrape === "function") ? scrape() : null; } catch (e) { cap = null; }
    var name = cap && cap.buyerName ? String(cap.buyerName) : "";
    var ok = !!name && !!walk358NormName(name) &&
      walk358NormName(name) === walk358NormName((cand && cand.buyerName) || "");
    return { ok: ok, name: name, capture: cap };
  }

  // Back to the inbox list (the .157 return's
  // own standard: the list surface, and no
  // thread id in the address bar).
  async function alWalk364GoBack() {
    try { window.history.back(); } catch (e) { return false; }
    var end = Date.now() + 6000;
    while (Date.now() < end) {
      await walk357WaitMs(400);
      if (onInboxListSurface() && !threadKeyOf(window.location.href)) return true;
    }
    return onInboxListSurface() && !threadKeyOf(window.location.href);
  }

  // The fallback itself. Returns:
  // { ref, capture, seenOutcome, mintedRef,
  //   stopWalk, stopText } — ref/capture for
  // the run's normal send path, seenOutcome
  // ("deleted" | "skip") when the minted key
  // is already terminally handled, stopWalk
  // when the walk must end after this
  // candidate (it could not get back to the
  // list, or a card it stacked would not
  // close). row360.idn is written on every
  // path.
  async function alWalk364IdentityFallback(cand, cap, opened, row360) {
    var out = { ref: "", capture: null, seenOutcome: "", mintedRef: "", stopWalk: false, stopText: "" };
    var idn = { r: 0, c: 0, d: 0, steps: [] };
    var card = opened && opened.anchorCard;
    try { var rowEl0 = alWalk357FindRowEl(cand); if (rowEl0) idn.r = alWalk364CountRefs(rowEl0); } catch (e) { /* diagnostics only */ }
    if (card && card.node) idn.c = alWalk364CountRefs(card.node);
    if (!card || !card.node) {
      row360.idn = walk364IdnText({ r: idn.r, c: idn.c, d: 0, na: true });
      return out;
    }
    var landedKey = "", landedMech = "";
    // Rung 1: the card's menu toggle, or its
    // title (the ⌄ rides in the title on the
    // Marketplace card).
    var menuBtn = alWalk364MenuToggle(card);
    var titleEl = menuBtn ? null : alWalk364TitleEl(card);
    var toggle = menuBtn || titleEl;
    if (toggle) {
      idn.d = 1;
      var mech1 = menuBtn ? "menu" : "title";
      try { toggle.click(); } catch (e) { /* the poll decides */ }
      var w1 = await alWalk364WaitMenuOrKey(3600);
      if (w1.key) {
        landedKey = w1.key; landedMech = mech1;
        idn.steps.push({ m: mech1, r: "landed" });
      } else if (w1.menu) {
        var plain = w1.menu.items.map(function (it) { return { label: it.label, href: it.href, target: it.target }; });
        var pick = walk364MenuItemPick(plain);
        if (pick < 0) {
          idn.steps.push({ m: "menu", r: "no_item" });
          try { alWalk359Escape(w1.menu.root); } catch (e) { /* the menu's fate is not the walk's */ }
        } else {
          try { w1.menu.items[pick].el.click(); } catch (e) { /* the poll decides */ }
          var k2 = await alWalk364WaitKey(3600);
          if (k2) { landedKey = k2; landedMech = "menu"; idn.steps.push({ m: "menu", r: "landed" }); }
          else idn.steps.push({ m: "menu", r: "no_nav" });
        }
      } else {
        idn.steps.push({ m: mech1, r: "no_nav" });
      }
    } else {
      idn.steps.push({ m: "menu", r: "na" });
    }
    // Rung 2: a full re-click on the matched
    // row — and whatever it stacks, closed
    // again if it did not navigate.
    if (!landedKey) {
      var beforeNodes = findDockCards360().map(function (c) { return c.node; });
      var rowEl2 = null;
      try { rowEl2 = alWalk357FindRowEl(cand); } catch (e) { /* no row, no rung */ }
      if (rowEl2) {
        try { rowEl2.click(); } catch (e) { /* the poll decides */ }
        var k3 = await alWalk364WaitKey(3600);
        if (k3) { landedKey = k3; landedMech = "row"; idn.steps.push({ m: "row", r: "landed" }); }
        else {
          idn.steps.push({ m: "row", r: "no_nav" });
          var cleaned = await alWalk364CloseNewNodes(beforeNodes);
          if (!cleaned) out.stopWalk = true; // the pill's close text names this one
        }
      } else {
        idn.steps.push({ m: "row", r: "na" });
      }
    }
    if (!landedKey) {
      row360.idn = walk364IdnText(idn);
      return out;
    }
    // Landed. Mint the identity from the
    // address bar, prove the page is the
    // candidate's thread, and ask the
    // registry what it knows about the key.
    out.mintedRef = walk364RefFromUrl(window.location.href);
    var mintedKey = threadKeyOf(out.mintedRef);
    var ver = alWalk364Verify(cand);
    var reg = await alWalk357LoadRegistry();
    var regState = (reg && mintedKey && reg[mintedKey]) ? String(reg[mintedKey].state || "") : "";
    var judge = walk364Judge(true, ver.ok, regState);
    var lastStep = idn.steps[idn.steps.length - 1];
    if (lastStep) lastStep.r = judge === "file" ? "verified" : (judge === "mismatch" ? "mismatch" : "seen");
    row360.idn = walk364IdnText(idn);
    if (judge === "mismatch") {
      var backM = await alWalk364GoBack();
      if (!backM) { out.stopWalk = true; out.stopText = "Walk stopped — couldn't get back to the inbox"; }
      return out; // no ref, no filing: the run fails this candidate as no_thread_id
    }
    if (judge === "deleted" || judge === "skip") {
      out.seenOutcome = judge;
      var backS = await alWalk364GoBack();
      if (!backS) { out.stopWalk = true; out.stopText = "Walk stopped — couldn't get back to the inbox"; }
      return out;
    }
    // judge === "file": the dock harvest is
    // filed under the minted ref; only an
    // EMPTY dock harvest re-reads the thread
    // here — the verify scrape's own capture,
    // re-keyed to the minted ref.
    out.ref = out.mintedRef;
    if (!cap.messages || !cap.messages.length) {
      var tc = ver.capture;
      if (tc && tc.messages && tc.messages.length) {
        try { tc.threadUrl = out.mintedRef; } catch (e) { /* a frozen capture keeps its own URL */ }
        try { tc.isolated356 = true; } catch (e) { /* as above */ }
        out.capture = tc;
        row360.msgs = tc.messages.length;
        if (tc.buyerName) row360.name = tc.buyerName;
      }
    }
    var backF = await alWalk364GoBack();
    if (!backF) { out.stopWalk = true; out.stopText = "Walk stopped — couldn't get back to the inbox"; }
    return out;
  }
  // [GLUE364-END]
  // [GLUE365-BEGIN] — Messages-view walk
  // route (v2.1.165, header note 106), the
  // DOM half of [PURE-WALK365]. The walk's
  // per-candidate route, run BEFORE the
  // dock flow: it takes the candidate to
  // the one surface that carries thread
  // identity — facebook.com/messages —
  // opens its thread there, and captures
  // through the existing inside-thread
  // lane (scrape(), the same read the
  // manual button and the .164 verify
  // use). Two shapes:
  // - the candidate's row already yielded
  //   a real /t/<id> (the .161 props
  //   mining, hoisted to the route's
  //   start): navigate straight to the
  //   thread URL — no list, no dock;
  // - no id anywhere: navigate to the
  //   Messages list and find the thread by
  //   the deterministic rule — buyer-name
  //   equality AND snippet agreement with
  //   the inbox row's snippet
  //   (walk365Match). Ambiguity is never
  //   guessed away: same-name rows the
  //   snippet cannot single out may be
  //   OPENED to read their headers, and a
  //   capture files only when exactly one
  //   probed thread proves name + label +
  //   snippet; otherwise the candidate
  //   fails honestly as ambiguous_thread.
  // On any landed thread the identity is
  // judged before anything files
  // (walk365Judge): the header name must
  // equal the candidate's; the registry
  // is re-read fresh under the REAL key —
  // a tombstone there skips the candidate
  // as deleted, any other terminal state
  // as a plain skip; a thread with NO
  // listing header is not a Marketplace
  // thread and is skipped as
  // not_marketplace (manual-only, per
  // Matthew's scope). After the candidate
  // resolves, the route returns to the
  // Marketplace inbox before handing
  // back; a candidate it could not bring
  // back ends the walk after itself with
  // an honest pill (the .164 rule).
  // NAVIGATION is SPA-only: a temporary
  // anchor's click, routed by the page's
  // own router — the mechanism the .164
  // menu item's click rode. This code
  // NEVER assigns location.href: a full
  // document load would end the walk's
  // own script mid-run. When the router
  // does not take a click, the landing
  // poll simply never fires and the route
  // fails soft — the dock flow (and its
  // .164 ladder, unchanged) still gets
  // its turn, exactly as before .165.
  // The route never sends anything: it
  // navigates and reads; the run's own
  // send path files what it brings back.
  function alWalk365Path(href) {
    var s = String(href || "").replace(/^https?:\/\/[^/]+/i, "");
    var cut = s.search(/[?#]/);
    return cut === -1 ? s : s.slice(0, cut);
  }
  function alWalk365OnInbox() {
    return alWalk365Path(window.location.href).indexOf("/marketplace/inbox") === 0 &&
      !threadKeyOf(window.location.href);
  }
  function alWalk365OnMsgList() {
    return alWalk365Path(window.location.href).indexOf("/messages") === 0 &&
      !threadKeyOf(window.location.href);
  }
  function alWalk365Navigate(url) {
    try {
      var a = document.createElement("a");
      a.href = url;
      try { a.setAttribute("style", "display:none"); } catch (e) { /* cosmetic */ }
      document.body.appendChild(a);
      a.click();
      try { a.remove(); } catch (e) { /* a stray hidden anchor is harmless */ }
      return true;
    } catch (e) { return false; }
  }
  async function alWalk365WaitUrl(pred, ms) {
    var end = Date.now() + ms;
    while (Date.now() < end) {
      await walk357WaitMs(300);
      try { if (pred(window.location.href)) return true; } catch (e) { /* keep polling */ }
    }
    try { return !!pred(window.location.href); } catch (e) { return false; }
  }
  // The Messages conversation list, read
  // as plain rows plus their elements:
  // every /messages/t/ anchor, keyed by
  // its thread id (first occurrence wins),
  // its text parsed by the pure
  // walk365ParseRowText.
  function alWalk365ListRows() {
    var out = [], seen = {};
    try {
      var links = document.querySelectorAll('a[href*="/messages/t/"]');
      for (var i = 0; i < links.length && out.length < 40; i++) {
        var key = threadKeyOf(links[i].href || "");
        if (!key || seen[key]) continue;
        seen[key] = true;
        var parsed = walk365ParseRowText(textOf(links[i]));
        if (!parsed.name) continue;
        out.push({ key: key, name: parsed.name, snippet: parsed.snippet, el: links[i] });
      }
    } catch (e) { /* the caller's poll retries */ }
    return out;
  }
  // Poll the landed thread page until the
  // inside-thread lane can read it — the
  // .164 verify (scrape()'s own header
  // name against the candidate's), waited
  // out. Returns the last verify; its
  // capture may still be null when the
  // page never became readable.
  async function alWalk365VerifyPoll(cand, ms) {
    var end = Date.now() + ms;
    var ver = null;
    while (Date.now() < end) {
      await walk357WaitMs(400);
      ver = alWalk364Verify(cand);
      var cap = ver && ver.capture;
      if (cap && cap.isolated356 && (ver.name || (cap.messages && cap.messages.length) || cap.vehicleText)) return ver;
    }
    return ver;
  }
  // The thread's listing state against the
  // candidate's label, for walk365Judge:
  // no listing header on the thread at all
  // is "absent"; a present header the
  // candidate's label cannot quarrel with
  // is "agree"; a present header whose
  // hard facts contradict it is
  // "conflict" (the .358 agreement rule).
  function alWalk365LabelState(cand, cap) {
    var threadLabel = (cap && cap.vehicleText) || "";
    if (!threadLabel) return "absent";
    var candLabel = (cand && cand.vehicleLabel) || "";
    if (!candLabel) return "agree";
    return walk358LabelAgree(candLabel, threadLabel) ? "agree" : "conflict";
  }
  // Back to the Marketplace inbox: history
  // first (the route pushed at most two
  // entries of its own), then a direct
  // SPA navigation. The walk's candidate
  // list lives on the inbox — anything
  // short of it is not "back".
  async function alWalk365ReturnToInbox() {
    if (alWalk365OnInbox()) return true;
    for (var i = 0; i < 3 && !alWalk365OnInbox(); i++) {
      try { window.history.back(); } catch (e) { break; }
      if (await alWalk365WaitUrl(function () { return alWalk365OnInbox(); }, 2500)) return true;
    }
    if (alWalk365OnInbox()) return true;
    if (alWalk365Navigate("https://www.facebook.com/marketplace/inbox")) {
      if (await alWalk365WaitUrl(function () { return alWalk365OnInbox(); }, 4000)) return true;
    }
    return alWalk365OnInbox();
  }
  // Back to the Messages LIST (between
  // probes): one history step, else a
  // direct navigation.
  async function alWalk365BackToList() {
    if (alWalk365OnMsgList()) return true;
    try { window.history.back(); } catch (e) { /* the direct navigation decides */ }
    if (await alWalk365WaitUrl(function () { return alWalk365OnMsgList(); }, 4000)) return true;
    if (alWalk365Navigate("https://www.facebook.com/messages")) {
      if (await alWalk365WaitUrl(function () { return alWalk365OnMsgList(); }, 4000)) return true;
    }
    return alWalk365OnMsgList();
  }
  // Open a list row's thread: the row's
  // own click first (the surface's native
  // gesture), then a direct navigation to
  // the row's canonical ref. Landed =
  // the address bar carries the row's own
  // thread id.
  async function alWalk365OpenRow(row) {
    var key = row.key;
    try { row.el.click(); } catch (e) { /* the direct navigation is the fallback */ }
    if (await alWalk365WaitUrl(function (h) { return threadKeyOf(h) === key; }, 4000)) return true;
    if (alWalk365Navigate(walk364RefFromUrl("https://www.facebook.com/messages/t/" + key))) {
      if (await alWalk365WaitUrl(function (h) { return threadKeyOf(h) === key; }, 4000)) return true;
    }
    return threadKeyOf(window.location.href) === key;
  }
  // Judge a landed thread page (the caller
  // is ON it, with its verify): identity,
  // registry, listing — walk365Judge over
  // the fresh evidence. Returns the
  // fb364-shaped outcome minus the return
  // (the caller owns it): { ref, capture }
  // to file, { seenOutcome, mintedRef }
  // for a terminal registry/listing
  // state, { failReason } for a soft
  // failure, or null when the page never
  // became readable at all.
  async function alWalk365Landed(cand, row360, steps, key, ver) {
    var cap = ver && ver.capture;
    if (!cap) return null;
    var mintedRef = walk364RefFromUrl("https://www.facebook.com/messages/t/" + key);
    if (!ver.ok) {
      steps.push({ m: "verify", r: "name_mismatch" });
      return { failReason: "name_mismatch" };
    }
    var reg = await alWalk357LoadRegistry();
    var regState = (reg && reg[key]) ? String(reg[key].state || "") : "";
    var judge = walk365Judge({ nameOk: true, labelState: alWalk365LabelState(cand, cap), regState: regState });
    if (judge === "deleted" || judge === "skip") {
      steps.push({ m: "reg", r: "seen" });
      return { seenOutcome: judge, mintedRef: mintedRef };
    }
    if (judge === "mismatch") {
      steps.push({ m: "verify", r: "label_conflict" });
      return { failReason: "wrong_car" };
    }
    if (judge === "not_marketplace") {
      steps.push({ m: "verify", r: "not_marketplace" });
      // The thread is real but carries no
      // listing: it stays manual-only, and
      // the skip is recorded under the
      // minted key (walk365Judge returns
      // not_marketplace only when the key
      // had no registry state, so this
      // write can never overwrite a
      // tombstone).
      var skipKey365 = key;
      await alWalk357UpdateRegistry(function (r) { r[skipKey365] = { at: Date.now(), state: "skip" }; });
      return { seenOutcome: "skip", mintedRef: mintedRef };
    }
    steps.push({ m: "verify", r: "ok" });
    row360.name = cap.buyerName || row360.name;
    row360.msgs = (cap.messages || []).length;
    row360.verdict = "messages_view";
    try { cap.threadUrl = mintedRef; } catch (e) { /* a frozen capture keeps its own URL */ }
    return { ref: mintedRef, capture: cap, mintedRef: mintedRef };
  }
  // Shape a judged outcome into the
  // route's result, returning to the
  // inbox first. A verified ref or a
  // terminal outcome survives a failed
  // return (the walk then stops after
  // this candidate, the .164 rule); a
  // soft failure with no way back becomes
  // the stopped-walk result instead.
  async function alWalk365Finish(row360, steps, landed) {
    var back = await alWalk365ReturnToInbox();
    steps.push({ m: "back", r: back ? "ok" : "return_failed" });
    if (!landed) return null;
    if (landed.ref || landed.seenOutcome) {
      if (!back) {
        landed.stopWalk = true;
        landed.stopText = "Walk stopped — couldn't get back to the inbox";
      }
      return landed;
    }
    if (landed.stranded) {
      if (back) return { failReason: "ambiguous_thread" };
      row360.reason = "return_failed";
      return { stopWalk: true, stopText: "Walk stopped — couldn't get back to the inbox", failReason: "return_failed" };
    }
    if (!back) {
      row360.reason = "return_failed";
      return { stopWalk: true, stopText: "Walk stopped — couldn't get back to the inbox", failReason: "return_failed" };
    }
    return landed;
  }
  // The direct shape: the candidate's row
  // already yielded a real thread id.
  async function alWalk365Direct(cand, row360, steps, key) {
    var ref = walk364RefFromUrl("https://www.facebook.com/messages/t/" + key);
    steps.push({ m: "nav", r: "direct" });
    var landed = false;
    if (alWalk365Navigate(ref)) {
      landed = await alWalk365WaitUrl(function (h) { return threadKeyOf(h) === key; }, 6000);
    }
    if (!landed) {
      // No landing, no evidence about the
      // thread itself: fail soft WITHOUT a
      // failReason — the dock flow decides
      // this candidate, as before .165.
      steps.push({ m: "open", r: "no_thread_url" });
      return null;
    }
    steps.push({ m: "open", r: "ok" });
    var ver = await alWalk365VerifyPoll(cand, 6000);
    var judged = await alWalk365Landed(cand, row360, steps, key, ver);
    return alWalk365Finish(row360, steps, judged);
  }
  // The list shape: find the candidate's
  // thread among the Messages rows.
  async function alWalk365ViaList(cand, row360, steps) {
    steps.push({ m: "nav", r: "list" });
    if (!alWalk365OnMsgList()) {
      var navOk = alWalk365Navigate("https://www.facebook.com/messages");
      var onList = navOk && await alWalk365WaitUrl(function () { return alWalk365OnMsgList(); }, 6000);
      if (!onList) {
        steps[steps.length - 1].r = "no_nav";
        return null;
      }
    }
    // Poll the list: rows render lazily,
    // and a probe verdict reached on a
    // partial list earns a beat for the
    // rest of the rows to arrive.
    var rows = [], match = null, probeSince = 0;
    var end = Date.now() + 7000;
    while (Date.now() < end) {
      rows = alWalk365ListRows();
      match = walk365Match(cand, rows);
      if (match.action === "open") break;
      if (match.action === "probe") {
        if (match.indices.length >= 2) break;
        if (!probeSince) probeSince = Date.now();
        if (Date.now() - probeSince > 2000) break;
      }
      await walk357WaitMs(400);
    }
    rows = alWalk365ListRows();
    match = walk365Match(cand, rows);
    var nameCount = 0;
    var cn = walk358NormName(cand.buyerName);
    for (var i = 0; i < rows.length; i++) {
      if (walk358NormName(rows[i].name) === cn) nameCount++;
    }
    steps.push({ m: "find", r: String(nameCount) });
    if (match.action === "none") {
      return alWalk365Finish(row360, steps, { failReason: "no_row" });
    }
    if (match.action === "open") {
      var orow = rows[match.index];
      steps.push({ m: "pick", r: match.via || "name" });
      var ook = await alWalk365OpenRow(orow);
      if (!ook) {
        steps.push({ m: "open", r: "no_thread_url" });
        return alWalk365Finish(row360, steps, {});
      }
      steps.push({ m: "open", r: "ok" });
      var over = await alWalk365VerifyPoll(cand, 6000);
      var ojudged = await alWalk365Landed(cand, row360, steps, orow.key, over);
      return alWalk365Finish(row360, steps, ojudged);
    }
    // Probe: open each name-matched row
    // ONLY to read its header. A probed
    // thread qualifies when its own
    // evidence proves name + label +
    // snippet (its newest line against
    // the inbox snippet). Exactly one
    // qualifier files; zero or two is
    // ambiguous_thread — never a guess.
    steps.push({ m: "pick", r: "probe" });
    var qualifiers = [];
    var idxs = match.indices.slice(0, 3);
    for (var pi = 0; pi < idxs.length; pi++) {
      var prow = rows[idxs[pi]];
      if (!prow) continue;
      var popen = await alWalk365OpenRow(prow);
      if (popen) {
        var pver = await alWalk365VerifyPoll(cand, 5000);
        var pcap = pver && pver.capture;
        if (pcap && pver.ok && alWalk365LabelState(cand, pcap) === "agree") {
          var lastMsg = "";
          if (pcap.messages && pcap.messages.length) lastMsg = pcap.messages[pcap.messages.length - 1].body || "";
          if (!cand.snippet || !lastMsg || walk365SnippetAgree(cand.snippet, lastMsg)) {
            qualifiers.push({ key: prow.key, capture: pcap });
          }
        }
      }
      var backList = await alWalk365BackToList();
      if (!backList) return alWalk365Finish(row360, steps, { stranded: true });
      rows = alWalk365ListRows();
    }
    if (qualifiers.length === 1) {
      var win = qualifiers[0];
      var mintedRefW = walk364RefFromUrl("https://www.facebook.com/messages/t/" + win.key);
      var regW = await alWalk357LoadRegistry();
      var regStateW = (regW && regW[win.key]) ? String(regW[win.key].state || "") : "";
      if (regStateW) {
        steps.push({ m: "reg", r: "seen" });
        return alWalk365Finish(row360, steps, { seenOutcome: regStateW === "deleted" ? "deleted" : "skip", mintedRef: mintedRefW });
      }
      steps.push({ m: "verify", r: "ok" });
      row360.name = win.capture.buyerName || row360.name;
      row360.msgs = (win.capture.messages || []).length;
      row360.verdict = "messages_view";
      try { win.capture.threadUrl = mintedRefW; } catch (e) { /* as above */ }
      return alWalk365Finish(row360, steps, { ref: mintedRefW, capture: win.capture, mintedRef: mintedRefW });
    }
    steps.push({ m: "pick", r: "ambiguous" });
    return alWalk365Finish(row360, steps, { failReason: "ambiguous_thread" });
  }
  // The route itself. Returns the
  // fb364-shaped result ({ ref, capture }
  // to file under the minted ref,
  // { seenOutcome, mintedRef } for a
  // terminal state, { stopWalk, stopText }
  // when the walk must end after this
  // candidate), a bare { failReason } for
  // a diagnosed soft failure, or null for
  // an undiagnosed one — the dock flow
  // decides those, exactly as before
  // .165. row360.mv is written on every
  // path the route actually ran.
  async function alWalk365Route(cand, row360) {
    if (!cand || !walk358NormName(cand.buyerName)) return null;
    var steps = [];
    var result = null;
    try {
      // Re-mine the live row's ref first
      // (the .161 mining, hoisted): a
      // candidate whose row yields a real
      // /t/<id> takes the direct path and
      // never needs the Messages list.
      try {
        var rowEl365 = alWalk357FindRowEl(cand);
        if (rowEl365 && !threadKeyOf(cand.threadRef || "")) {
          var mined365 = inboxRowThreadRef(rowEl365);
          if (mined365) cand.threadRef = mined365;
        }
      } catch (e) { /* mining is best-effort — the list path needs no row */ }
      var directKey = threadKeyOf(cand.threadRef || "");
      if (directKey) result = await alWalk365Direct(cand, row360, steps, directKey);
      else result = await alWalk365ViaList(cand, row360, steps);
    } catch (e) {
      result = null; /* a route error is a soft failure — never a broken walk */
    }
    row360.mv = walk365MvText({ steps: steps });
    return result;
  }
  // [GLUE365-END]
  async function alWalk357Run(btn) {
    if (walk357Running) return;
    walk357Running = true;
    var counts = { captured: 0, skippedOld: 0, failed: 0 };
    var stopped360 = false;
    var stopText364 = ""; // [WALK364] the fallback's own stop text, when it has one
    var rows360 = [];
    try {
      if (btn) { btn.textContent = "Walking inbox…"; }
      var reg = await alWalk357LoadRegistry();
      var plan = walk357Plan(alWalk357Candidates(), reg, WALK357_CAP);
      counts.skippedOld = plan.skippedOld;
      for (var i = 0; i < plan.todo.length; i++) {
        var cand = plan.todo[i];
        if (i > 0) await walk357WaitMs(WALK357_GAP_MS);
        var row360 = { key: cand.key || "", buyer: cand.buyerName || "", threadRef: cand.threadRef || "",
                       anchor: false, claimed: false, name: "", msgs: 0, cards: 0, verdict: "",
                       outcome: "failed", reason: "", close: "", labelBanner: 0, idn: "", mv: "" };
        rows360.push(row360);
        var fb364 = null; // [WALK364] this candidate's fallback result
        // [WALK365] the Messages route runs FIRST (see [GLUE365]):
        // on the real surface its result is the candidate's
        // outcome; on a surface where it cannot navigate it fails
        // soft (null) and the dock flow below decides, exactly as
        // before .165 — the .164 ladder inside that flow stays a
        // gated last resort, reachable only behind a route that
        // produced nothing. A route capture flows into the if
        // (cap) block untouched: its threadUrl already carries
        // the minted real ref, so the identity resolution below
        // resolves it and the fallback never triggers. A route
        // seen outcome is accounted here, keyed to the REAL
        // thread key the route proved on the thread page.
        var mv365 = await alWalk365Route(cand, row360);
        var opened360 = null, cap = null, routeSeen365 = false;
        if (mv365 && mv365.seenOutcome) {
          row360.outcome = mv365.seenOutcome;
          row360.threadRef = mv365.mintedRef || row360.threadRef;
          counts.skippedOld++;
          var seenKey365 = threadKeyOf(mv365.mintedRef || "") || cand.key;
          var seenState365 = mv365.seenOutcome;
          await alWalk357UpdateRegistry(function (r) { r[seenKey365] = { at: Date.now(), state: seenState365 }; });
          routeSeen365 = true;
        } else if (mv365 && mv365.ref) {
          cap = mv365.capture;
        } else {
          opened360 = await alWalk357Open(cand, row360);
          cap = opened360 ? opened360.capture : null;
        }
        if (routeSeen365) {
          // [WALK365] resolved by the route as already-seen:
          // nothing to send, nothing to harvest — only the
          // return/stop tail below runs for this candidate.
        } else if (cap) {
          // v2.1.161: the capture's thread
          // identity is resolved from REAL refs
          // only — its own URL (the thread-page
          // lane), the candidate's verified ref,
          // the matched card's own thread
          // anchor. With no real /t/<id>
          // anywhere, the worker's merge guard
          // would (rightly) drop the capture —
          // so the walk does not send a doomed
          // capture: the candidate fails here,
          // honestly, as no_thread_id, and stays
          // unrecorded (a later run may find
          // the identity). A sent capture that
          // the worker refuses reports the
          // refusal's own code as its reason.
          var ref361Run = walk361ResolveThreadRef(cap.threadUrl || "", cand.threadRef || "",
                                                  (opened360 && opened360.threadRef) || "");
          // v2.1.164: no real identity anywhere
          // is no longer the end of the road —
          // the thread-page fallback ([GLUE364])
          // opens the candidate's own thread
          // page from its card, mints the id from
          // the address bar and proves the page
          // before the ref is trusted. A registry
          // hit on the minted key skips the
          // candidate as seen/deleted, no filing.
          if (!ref361Run && opened360 && opened360.anchorCard) {
            fb364 = await alWalk364IdentityFallback(cand, cap, opened360, row360);
            if (fb364.capture) cap = fb364.capture;
            if (fb364.ref) ref361Run = fb364.ref;
          }
          if (fb364 && fb364.seenOutcome) {
            row360.outcome = fb364.seenOutcome;
            row360.threadRef = fb364.mintedRef || row360.threadRef;
            counts.skippedOld++;
            var seenKey364 = cand.key;
            var seenState364 = fb364.seenOutcome;
            await alWalk357UpdateRegistry(function (r) { r[seenKey364] = { at: Date.now(), state: seenState364 }; });
          } else if (!ref361Run) {
            row360.outcome = "failed";
            row360.reason = "no_thread_id";
            counts.failed++;
          } else {
            if (ref361Run !== (cap.threadUrl || "")) {
              cap = Object.assign({}, cap, { threadUrl: ref361Run });
            }
            row360.threadRef = ref361Run;
            var resp = await sendCaptureTracked(cap);
            var outcome = walk357Outcome(resp);
            row360.outcome = outcome;
            if (outcome === "captured") counts.captured++;
            else if (outcome === "deleted" || outcome === "skip") counts.skippedOld++;
            else { counts.failed++; row360.reason = walk361OutcomeReason(resp) || "send_failed"; }
            if (outcome !== "failed") {
              var key = cand.key;
              var state = outcome;
              await alWalk357UpdateRegistry(function (r) { r[key] = { at: Date.now(), state: state }; });
            }
          }
        } else {
          counts.failed++;
          if (!row360.reason) row360.reason = "empty";
        }
        // [WALK365] a route-diagnosed failure names the candidate
        // when the dock flow's own accounting would otherwise
        // blame the dock (no identity / empty harvest / the row
        // itself gone): the route only sets failReason after
        // actually landing somewhere, so an undiagnosed route
        // (null) never triggers this, and a dock-decided failure
        // keeps its own name.
        if (!routeSeen365 && row360.outcome === "failed" && mv365 && mv365.failReason &&
            (row360.reason === "no_thread_id" || row360.reason === "empty" || row360.reason === "row_not_found")) {
          row360.reason = mv365.failReason;
        }
        var ret360 = await alWalk357Return(opened360 ? opened360.closeCards : [],
                                            opened360 ? opened360.anchorCard : null,
                                            opened360 ? opened360.header : null);
        row360.close = ret360.strategy;
        if (!ret360.ok) {
          row360.close = "FAILED";
          if (!row360.reason) row360.reason = "close_failed";
          stopped360 = true;
        }
        if (fb364 && fb364.stopWalk) {
          stopped360 = true;
          if (fb364.stopText) stopText364 = fb364.stopText;
        }
        if (mv365 && mv365.stopWalk) {
          stopped360 = true;
          if (mv365.stopText) stopText364 = mv365.stopText;
        }
        if (stopped360) break;
      }
      alWalk360SaveReport({ v: 161, at: Date.now(), counts: counts, stopped: stopped360, rows: rows360 });
      if (btn) {
        if (stopped360) {
          setBtnLabel(btn, stopText364 || "Walk stopped — a chat window would not close", false, true);
        } else {
          setBtnLabel(btn, "Walk ✓ " + counts.captured + " new · " + counts.skippedOld + " seen · " + counts.failed + " failed" + walk359ReasonSuffix(rows360),
            counts.captured > 0 ? true : (counts.failed > 0 ? false : true), true);
        }
      }
    } catch (e) {
      if (btn) setBtnLabel(btn, "Capture failed — try again in a moment", false, true);
    } finally {
      walk357Running = false;
    }
  }
  // [WALK360-END]
 // [WALK357-END]
  // App-driven sync (v2.1.38): the AutoLaunch page asks (through the
  // worker) for a capture RIGHT NOW and waits for the writes to land.
  // This exists because a BACKGROUND tab's own timers are throttled
  // by Chrome to ~1/minute — the exact lag Matthew measured — while a
  // runtime message wakes the script immediately.
  async function autoPassSync() {
    var jobs = [];
    try {
      if (onInboxListSurface()) {
        collectThreadStubs().forEach(function (c) { jobs.push(sendCaptureTracked(c)); });
        var snippets = collectThreadSnippets().concat(collectInboxButtonRows());
        if (snippets.length) {
          jobs.push(new Promise(function (resolve) {
            try {
              chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CHAT_SNIPPETS", snippets: snippets }, function () {
                void chrome.runtime.lastError;
                resolve(null);
              });
            } catch (e) { resolve(null); }
          }));
        }
      }
      var full = autoFullCapture();
      if (full) jobs.push(full);
    } catch (e) { /* partial completion still counts */ }
    await Promise.all(jobs);
  }

  function autoPass() {
    try {
      if (onInboxListSurface()) {
        var stubKeys = {};
        collectThreadStubs().forEach(function (c) {
          stubKeys[gateRetryKey(c)] = 1;
          sendCaptureTracked(c);
        });
        // v2.50: re-ask for gate-skipped stub threads that have
        // scrolled out of the rendered list — their last capture
        // rides again while the retry budget lasts.
        Object.keys(gateSkipped).forEach(function (key) {
          if (stubKeys[key] || !gateRetryDue(key)) return;
          var g = gateSkipped[key];
          if (g.capture && g.capture.stub) sendCaptureTracked(g.capture);
        });
        var snippets = collectThreadSnippets().concat(collectInboxButtonRows());
        if (snippets.length) {
          try {
            chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CHAT_SNIPPETS", snippets: snippets }, function () {
              void chrome.runtime.lastError;
            });
          } catch (e) { /* next pass retries */ }
        }
      }
      autoFullCapture();
      var btn = document.getElementById(BTN_ID);
      if (btn && onInboxListSurface() && !walk358LabelHold) btn.textContent = "🌙 Luca auto-sync on · Capture now";
    } catch (e) { /* heuristics must never break the page */ }
  }

  // Fast pickup (v2.1.33): a new buyer message rewrites its list row
  // within seconds. Watch the list for changes and run a pass shortly
  // after (debounced, at most ~4x a minute) instead of waiting out the
  // 45-second timer. The worker dedupes anything unchanged.
  var lastObservedPass = 0;
  var observedTimer = null;
  try {
    var listObserver = new MutationObserver(function () {
      if (!onInboxListSurface() && !onChatSurface()) return;
      if (observedTimer) return;
      observedTimer = setTimeout(function () {
        observedTimer = null;
        if (Date.now() - lastObservedPass < 6000) return;
        lastObservedPass = Date.now();
        autoPass();
      }, 2000);
    });
    listObserver.observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) { /* the 45s timer still covers it */ }

  // Facebook is a SPA: the button must survive route changes.
  setInterval(injectButton, 1500);
  injectButton();
  setTimeout(autoPass, 3500);
  setInterval(autoPass, 45000);

  // [CCDLV315-BEGIN] DELIVERY TRACE forwarder
  // (v2.1.115, header note 66 in the worker). Relays the
  // dlv_* delivery stages to the worker's trace sink
  // (AUTOLAUNCH_TRACE -> public.helper_trace):
  // dlv_composer (what findComposer resolved), dlv_type
  // (the COMMIT GATE story: one attempt record per
  // typing path — its ok flag, whether the composer
  // RE-READ showed the body committed, and the text as
  // read back), dlv_submit (which submit mechanism
  // fired), dlv_verify (per attempt: the composer text,
  // whether the EXACT body is present as an out bubble
  // in the thread's message list, and the last three
  // bubbles with direction), dlv_error (every swallowed
  // exception on the path). Fail-silent everywhere.
  var ccDlvAttempt315 = 0;
  var ccDlvBtnLabel315 = null;
  function ccDlv(stage, detail, threadRef) {
    try {
      chrome.runtime.sendMessage({ type: "AUTOLAUNCH_TRACE", stage: stage, threadRef: threadRef || null, detail: detail || {} }, function () { void chrome.runtime.lastError; });
    } catch (e) { /* fail-silent */ }
  }
  function ccDlvKind315(el) {
    try {
      return { tag: String((el && el.tagName) || ""), role: el && el.getAttribute ? el.getAttribute("role") : null, ariaLabel: el && el.getAttribute ? el.getAttribute("aria-label") : null, editable: el && el.getAttribute ? el.getAttribute("contenteditable") : null };
    } catch (e) { return { tag: "", role: null, ariaLabel: null, editable: null }; }
  }
  function ccDlvErr315(step, e, threadRef) {
    ccDlv("dlv_error", { step: String(step || "?"), message: String((e && e.message) || e || "").slice(0, 120) }, threadRef);
  }
  // [CCDLV315-END]

  // ---- OUTBOUND DELIVERY (v2.1.32): the worker claims a queued reply
  // in the database, parks it in the luca_pending_delivery storage
  // slot, and points a Facebook tab at the thread. This script does
  // the typing HERE: CDP insertText (works in background tabs, where
  // execCommand silently no-ops), Enter to send, then VERIFY the
  // message actually appears as our bubble before reporting success.
  // Delivery only ever happens on the thread's own page — never
  // through a floating popup, whose conversation can't be matched to
  // the pending thread with certainty (wrong-person risk).
  var delivering = false;
  function waitMs(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitForValue(fn, timeoutMs, stepMs) {
    var end = Date.now() + timeoutMs;
    while (Date.now() < end) {
      var v = fn();
      if (v) return v;
      await waitMs(stepMs || 400);
    }
    return null;
  }
  function replyCdpRequest(payload) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(
          Object.assign({ type: "AUTOLAUNCH_CDP" }, payload),
          function (resp) {
            void chrome.runtime.lastError;
            resolve(resp && typeof resp === "object" ? resp : { ok: false, error: "cdp_no_response" });
          });
      } catch (e) { ccDlvErr315("cdp_request", e, null); resolve({ ok: false, error: "cdp_send_failed" }); } /*D315R*/
    });
  }
  var replyCdpAttached = false;
  async function replyCdp(action, extra) {
    var res = await replyCdpRequest(Object.assign({ action: action }, extra || {}));
    if (action === "attach" && res && res.ok) replyCdpAttached = true;
    if (action === "detach") replyCdpAttached = false;
    return res;
  }
  function findComposer() {
    var scopes = [document.querySelector('[role="main"]'), document].filter(Boolean);
    for (var i = 0; i < scopes.length; i++) {
      var boxes = scopes[i].querySelectorAll('[role="textbox"]');
      for (var j = 0; j < boxes.length; j++) {
        var lab = (boxes[j].getAttribute("aria-label") || "").toLowerCase();
        if (lab.indexOf("message") !== -1 || lab === "aa") return boxes[j];
      }
      // Fallback (v2.1.36): label wording varies by surface — the
      // thread composer is the LAST visible contenteditable textbox
      // on the page (search boxes above it are plain inputs, never
      // contenteditable).
      var editables = [];
      for (var k = 0; k < boxes.length; k++) {
        if (boxes[k].getAttribute("contenteditable") === "true" && boxes[k].offsetParent !== null) editables.push(boxes[k]);
      }
      if (editables.length) return editables[editables.length - 1];
    }
    return null;
  }
  function normMsg(s) { return String(s || "").trim().replace(/\s+/g, " ").toLowerCase(); }

  function findSendButton(composer) {
    // The composer's Send control (paper-plane arrow) is a real
    // clickable button near the textbox. Walk up from the composer,
    // searching each wider container; "send"-labeled only, and the
    // like button ("Send a like") is deliberately excluded.
    var node = composer;
    for (var depth = 0; depth < 7 && node; depth++) {
      node = node.parentElement;
      if (!node || !node.querySelectorAll) continue;
      var cands = node.querySelectorAll('[role="button"], button');
      for (var i = 0; i < cands.length; i++) {
        var lab = (cands[i].getAttribute("aria-label") || "").trim().toLowerCase();
        if (lab.indexOf("send") === 0 && lab.indexOf("like") === -1) {
          var r = cands[i].getBoundingClientRect();
          if (r.width > 0 && r.height > 0) return cands[i];
        }
      }
    }
    return null;
  }

  // [DLV317-BEGIN] DELIVERY 3.17 (v2.1.117, note 68):
  // two changes ahead of the unchanged 3.15 ladder +
  // 3.16 focus step. (1) VISIBILITY-AWARE COMPOSER:
  // the 3.16 desk trace (the Mustang thread, helper
  // 2.1.116) found the composer as a ZERO-WIDTH,
  // off-viewport ghost — getBoundingClientRect
  // {w: 0, h: 20, x: -26, y: 18} on a long-lived
  // reused tab — so the click rung refused
  // (zero_rect), the DOM rung anchored a selection
  // nobody could type into, and every typing path
  // read back empty. ccAwaitComposer317 validates
  // the found box's rect (width > 40, re-read after
  // a scrollIntoView), rescans for a sane candidate
  // when the first hit is a ghost, and traces
  // dlv_composer with EVERY candidate's rect plus
  // the chosen one. (2) FOCUS EMULATION state:
  // ccEmuFocus317 carries the hasFocus readings that
  // bracket the worker-side focus-emulation enable
  // in deliverPending (a background tab's document
  // never holds OS focus — hasFocus read FALSE for
  // the entire 3.16 run); the [FOCUS316] ladder's
  // dlv_focus record carries both readings plus
  // whether the enable landed.
  var ccEmuFocus317 = { before: null, after: null, emuOk: null, emuError: null };
  function ccHasFocus317() {
    try { return !!(document.hasFocus && document.hasFocus()); } catch (e) { return false; }
  }
  function ccRectOf317(el) {
    try {
      var r = el.getBoundingClientRect();
      return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
    } catch (e) { return null; }
  }
  function ccRectSane317(r) { return !!(r && r.w > 40 && r.h > 0); }
  function ccCandidateRects317() {
    var out = [];
    try {
      var boxes = document.querySelectorAll('[role="textbox"]');
      for (var i = 0; i < boxes.length && out.length < 8; i++) {
        var rr = ccRectOf317(boxes[i]);
        out.push({ label: String((boxes[i].getAttribute && boxes[i].getAttribute("aria-label")) || "").slice(0, 40), rect: rr, sane: ccRectSane317(rr) });
      }
    } catch (e) { /* the trace stays partial */ }
    return out;
  }
  function ccRescanComposer317(exclude) {
    var scopes = [];
    try { var mainEl317 = document.querySelector('[role="main"]'); if (mainEl317) scopes.push(mainEl317); } catch (e) { /* the document scope below still applies */ }
    scopes.push(document);
    var lastEdit = null;
    for (var i = 0; i < scopes.length; i++) {
      var boxes = scopes[i].querySelectorAll('[role="textbox"]');
      for (var j = 0; j < boxes.length; j++) {
        if (boxes[j] === exclude) continue;
        var lab = (boxes[j].getAttribute("aria-label") || "").toLowerCase();
        if ((lab.indexOf("message") !== -1 || lab === "aa") && ccRectSane317(ccRectOf317(boxes[j]))) return boxes[j];
        if (boxes[j].getAttribute("contenteditable") === "true" && boxes[j].offsetParent !== null && ccRectSane317(ccRectOf317(boxes[j]))) lastEdit = boxes[j];
      }
    }
    return lastEdit;
  }
  async function ccAwaitComposer317(threadRef) {
    var deadline = Date.now() + 18000;
    var lastEl = null, lastDetail = null;
    while (true) {
      var el = null;
      try { el = findComposer(); } catch (e) { ccDlvErr315("composer_find", e, threadRef); }
      if (el) {
        lastEl = el;
        var r = ccRectOf317(el);
        if (ccRectSane317(r)) {
          ccDlv("dlv_composer", { found: true, kind: ccDlvKind315(el), candidates: ccCandidateRects317(), chosenRect: r, rectSane: true, rescanned: false, scrolled: false }, threadRef);
          return el;
        }
        var scrolled = false;
        try { if (el.scrollIntoView) { el.scrollIntoView({ block: "center" }); scrolled = true; } } catch (e) { ccDlvErr315("composer_scroll", e, threadRef); }
        if (scrolled) { await waitMs(250); r = ccRectOf317(el); }
        if (ccRectSane317(r)) {
          ccDlv("dlv_composer", { found: true, kind: ccDlvKind315(el), candidates: ccCandidateRects317(), chosenRect: r, rectSane: true, rescanned: false, scrolled: true }, threadRef);
          return el;
        }
        var alt = null;
        try { alt = ccRescanComposer317(el); } catch (e) { ccDlvErr315("composer_rescan", e, threadRef); }
        if (alt) {
          ccDlv("dlv_composer", { found: true, kind: ccDlvKind315(alt), candidates: ccCandidateRects317(), chosenRect: ccRectOf317(alt), rectSane: true, rescanned: true, scrolled: scrolled }, threadRef);
          return alt;
        }
        lastDetail = { found: true, kind: ccDlvKind315(el), candidates: ccCandidateRects317(), chosenRect: r, rectSane: false, rescanned: false, scrolled: scrolled };
      }
      if (Date.now() >= deadline) break;
      await waitMs(600);
    }
    if (lastEl) { ccDlv("dlv_composer", lastDetail, threadRef); return lastEl; }
    ccDlv("dlv_composer", { found: false, candidates: ccCandidateRects317() }, threadRef);
    return null;
  }
  // [DLV317-END]

  // [FOCUS316-BEGIN] FOCUS STEP (v2.1.116, note 67):
  // the 3.15 desk proof (2026-11-14, the Mustang
  // group thread, helper 2.1.115) cleared the honesty
  // half — no commit, no submit, the row settled
  // failed — and then showed all three typing paths
  // reporting ok into a composer that read back
  // EMPTY (the row settled text_not_committed): the
  // text never landed. The 3.15 path LOCATED the
  // composer but never gave it keyboard focus: its
  // only focus gestures were a best-effort DOM
  // focus()/click() pair, and CDP Input events
  // dispatch at the CURRENT selection — which was
  // never inside the box. The proven note-53
  // price-edit path clicks into the field with a CDP
  // trusted mouse FIRST, and it commits on
  // Facebook's editor. 3.16 adds that step to
  // delivery, ahead of the unchanged 3.15 ladder:
  // rung 1 is a CDP trusted mouse press+release at
  // the composer's center (the worker's existing
  // "click" action — CDP input works on background
  // tabs, and the user's tab is NEVER activated);
  // rung 2, only if the click did not focus it, is
  // DOM: element.focus() + caret placement at the
  // end of the composer. Focus is VERIFIED after
  // each rung (document focus + whether the active
  // element / the selection anchor sits inside the
  // composer) and the whole step is traced as
  // dlv_focus (the rect used, every state reading).
  // Still unfocused after both rungs -> the
  // delivery fails loud as focus_not_achieved
  // BEFORE any typing: no submit of any kind.
  function ccFocusState316(el) {
    var st = { hasFocus: false, activeInside: false, anchorInside: false };
    try { st.hasFocus = !!(document.hasFocus && document.hasFocus()); } catch (e) { /* state stays false */ }
    try {
      var ae = document.activeElement;
      st.activeInside = !!(el && ae && (ae === el || (el.contains && el.contains(ae))));
    } catch (e) { /* same */ }
    try {
      var sel = window.getSelection ? window.getSelection() : null;
      if (sel && sel.anchorNode && el && el.contains) st.anchorInside = !!el.contains(sel.anchorNode);
    } catch (e) { /* same */ }
    return st;
  }
  async function ccFocusComposer316(composer, attachedOk, threadRef) {
    var rec = { rect: null, before: ccFocusState316(composer), click: null, afterClick: null, dom: null, afterDom: null, focused: false, hasFocusBeforeEmulation: ccEmuFocus317.before, hasFocusAfterEmulation: ccEmuFocus317.after, emuFocusEnabled: ccEmuFocus317.emuOk };
    var isFocused = function (st) { return !!(st && (st.activeInside || st.anchorInside)); };
    if (isFocused(rec.before)) { rec.focused = true; ccDlv("dlv_focus", rec, threadRef); return rec; }
    if (attachedOk) {
      try { if (composer.scrollIntoView) composer.scrollIntoView({ block: "center" }); } catch (e) { ccDlvErr315("focus_scroll", e, threadRef); }
      await waitMs(150);
      var r = null;
      try { r = composer.getBoundingClientRect(); } catch (e) { ccDlvErr315("focus_rect", e, threadRef); }
      if (r) rec.rect = { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
      if (rec.rect && rec.rect.w > 0 && rec.rect.h > 0) {
        var clk = await replyCdp("click", { x: rec.rect.x, y: rec.rect.y });
        rec.click = { ok: !!(clk && clk.ok), error: (clk && clk.error) || null };
        await waitMs(250);
        rec.afterClick = ccFocusState316(composer);
      } else {
        rec.click = { ok: false, error: "zero_rect" };
      }
    } else {
      rec.click = { ok: false, error: "cdp_not_attached" };
    }
    if (!isFocused(rec.afterClick)) {
      var domOk = true;
      try { composer.focus(); } catch (e) { domOk = false; ccDlvErr315("focus_dom", e, threadRef); }
      try {
        var sel2 = window.getSelection ? window.getSelection() : null;
        if (sel2 && document.createRange) {
          var rg = document.createRange();
          rg.selectNodeContents(composer);
          rg.collapse(false);
          sel2.removeAllRanges();
          sel2.addRange(rg);
        }
      } catch (e) { ccDlvErr315("focus_caret", e, threadRef); }
      rec.dom = { tried: true, ok: domOk };
      await waitMs(150);
      rec.afterDom = ccFocusState316(composer);
    }
    var endState = rec.afterDom || rec.afterClick || rec.before;
    rec.focused = isFocused(endState);
    ccDlv("dlv_focus", rec, threadRef);
    return rec;
  }
  // [FOCUS316-END]

  // [DLVFIX315-BEGIN] DELIVERY FIX (v2.1.115, note 66):
  // the typeViaKeys315 helper + the deliverPending below
  // replace the 3.13 body wholesale. (1) COMMIT GATE:
  // each typing path — CDP Input.insertText, then the
  // execCommand fallback, then (NEW) CDP trusted
  // per-character key dispatch — is followed by a
  // composer RE-READ, and only a path whose body is
  // SEEN in the box counts as committed (the
  // rule-(a)-shaped compare). No path commits -> NO
  // submit; the delivery fails loud as
  // text_not_committed and the row settles failed,
  // never "sent". (2) VERIFY: rule (b) is DELETED —
  // "sent" requires the thread re-read to find the
  // OUT bubble inside the existing 12 s / 600 ms
  // window; an empty composer is not evidence.
  async function typeViaKeys315(body) {
    // CDP trusted per-character key dispatch (the
    // note-63 price-edit input family): keyDown/keyUp
    // per char with the char carried as `text`, which
    // editors that read characters from the key event
    // accept. A newline is typed as a space — an
    // Enter here would submit mid-body.
    for (var i = 0; i < body.length; i++) {
      var ch = body.charAt(i);
      var key = ch, code = "";
      if (ch === "\n" || ch === "\r") { key = " "; code = "Space"; ch = " "; }
      else if (/[a-zA-Z]/.test(ch)) code = "Key" + ch.toUpperCase();
      else if (/[0-9]/.test(ch)) code = "Digit" + ch;
      else if (ch === " ") code = "Space";
      var r = await replyCdp("key", code ? { key: key, code: code, text: ch } : { key: key, text: ch });
      if (!r || !r.ok) return false;
    }
    return true;
  }
  async function deliverPending(p) {
    var result = { ok: false, error: null };
    ccDlvAttempt315 = 0;
    try {
      // [DLV317-INNER-BEGIN] (v2.1.117, note 68):
      // visibility-aware composer acquisition — the
      // picker in the [DLV317] span validates the
      // found box's rect (the 3.16 desk run typed
      // into a zero-width ghost), scrolls + rescans
      // for a sane candidate, and traces dlv_composer
      // itself with every candidate's rect.
      var composer = await ccAwaitComposer317(p.threadRef);
      if (!composer) { result.error = "composer_not_found"; return result; }
      // [DLV317-INNER-END]
      var attached = await replyCdp("attach");
      var attachedOk = !!(attached && attached.ok);
      // [EMU317-INNER-BEGIN] (v2.1.117, note 68):
      // focus emulation ON — right after attach,
      // before any typing — via the worker's
      // "emuFocus" CDP action
      // (Emulation.setFocusEmulationEnabled). A
      // background tab's document never holds OS
      // focus (the 3.16 trace read hasFocus FALSE
      // for the whole run) and the editor treats
      // input into an unfocused document as noise.
      // The two readings bracket the enable so
      // dlv_focus can prove the flip; the settle
      // finally below disables emulation again
      // before detach, so the override never leaks
      // into other jobs on this tab.
      ccEmuFocus317.before = ccHasFocus317();
      if (attachedOk) {
        var emu317 = await replyCdp("emuFocus", { enabled: true });
        ccEmuFocus317.emuOk = !!(emu317 && emu317.ok);
        ccEmuFocus317.emuError = (emu317 && emu317.error) || null;
        if (!ccEmuFocus317.emuOk) ccDlvErr315("emu_focus_on", new Error(ccEmuFocus317.emuError || "emu_failed"), p.threadRef);
        await waitMs(150);
      }
      ccEmuFocus317.after = ccHasFocus317();
      // [EMU317-INNER-END]
      // [FOCUS316-INNER-BEGIN] (v2.1.116, note 67):
      // focus BEFORE any typing — the focus ladder
      // in ccFocusComposer316 (CDP trusted click,
      // then the DOM focus+caret rung), traced as
      // dlv_focus. Unfocused after both rungs ->
      // fail loud here; the typing ladder below
      // never runs and nothing is submitted.
      var focus316 = await ccFocusComposer316(composer, attachedOk, p.threadRef);
      if (!focus316 || !focus316.focused) { result.error = "focus_not_achieved"; return result; }
      // [FOCUS316-INNER-END]
      // ---- COMMIT GATE (note 66): a typing path only
      // counts when the composer RE-READ shows the body
      // in the box (same compare shape as verify rule
      // (a): exact, or starting with the body's first
      // 60 normalized chars).
      var want = normMsg(p.body);
      var gateHit = function () {
        var ct = normMsg(textOf(composer));
        return ct === want || ct.indexOf(want.slice(0, 60)) === 0;
      };
      var attempts = [];
      var committed = false;
      var committedBy = null;
      if (attachedOk) {
        var ins = await replyCdp("insertText", { text: p.body });
        await waitMs(400);
        var hit1 = gateHit();
        attempts.push({ path: "cdp_insertText", ok: !!(ins && ins.ok), committed: hit1, textAfter: textOf(composer).slice(0, 120) });
        if (hit1) { committed = true; committedBy = "cdp_insertText"; }
      } else {
        attempts.push({ path: "cdp_insertText", ok: false, skipped: "cdp_not_attached", committed: false, textAfter: textOf(composer).slice(0, 120) });
      }
      if (!committed) {
        var ecOk = false;
        try { ecOk = document.execCommand("insertText", false, p.body); } catch (e) { ccDlvErr315("exec_command", e, p.threadRef); /* ladder continues */ }
        await waitMs(400);
        var hit2 = gateHit();
        attempts.push({ path: "execCommand", ok: !!ecOk, committed: hit2, textAfter: textOf(composer).slice(0, 120) });
        if (hit2) { committed = true; committedBy = "execCommand"; }
      }
      if (!committed && attachedOk) {
        var keyOk = await typeViaKeys315(String(p.body || ""));
        await waitMs(400);
        var hit3 = gateHit();
        attempts.push({ path: "cdp_key_chars", ok: !!keyOk, committed: hit3, textAfter: textOf(composer).slice(0, 120) });
        if (hit3) { committed = true; committedBy = "cdp_key_chars"; }
      }
      ccDlv("dlv_type", { attempts: attempts, committed: committed, committedBy: committedBy }, p.threadRef);
      if (!committed) { result.error = "text_not_committed"; return result; }
      // ---- SUBMIT: only ever reached with the body
      // SEEN sitting in the composer.
      if (attachedOk) {
        await replyCdp("key", { key: "Enter", code: "Enter" });
        ccDlv("dlv_submit", { method: "cdp_key_enter", targetKind: "composer" }, p.threadRef);
      } else {
        var evInit = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
        composer.dispatchEvent(new KeyboardEvent("keydown", evInit));
        composer.dispatchEvent(new KeyboardEvent("keypress", evInit));
        composer.dispatchEvent(new KeyboardEvent("keyup", evInit));
        ccDlv("dlv_submit", { method: "synthetic_key_events", targetKind: "composer" }, p.threadRef);
      }
      await waitMs(700);
      // Send-button fallback (v2.1.41, kept): when the
      // text is still sitting in the box, the Enter
      // didn't take — click the composer's own Send
      // control (a real button near the textbox).
      if (gateHit()) {
        var sendBtn = findSendButton(composer);
        if (sendBtn) { ccDlvBtnLabel315 = (sendBtn.getAttribute && sendBtn.getAttribute("aria-label")) || "send_button"; try { sendBtn.click(); } catch (e) { ccDlvErr315("send_button_click", e, p.threadRef); /* the verify below decides */ } }
      }
      if (ccDlvBtnLabel315) { ccDlv("dlv_submit", { method: "send_button_click", targetKind: ccDlvBtnLabel315 }, p.threadRef); ccDlvBtnLabel315 = null; }
      // ---- VERIFY (note 66): rule (a) ONLY. The
      // thread re-read must find our OUT bubble
      // matching the body; the composer-emptied rung
      // is deleted — an empty composer proves nothing.
      var hit = await waitForValue(function () {
        var msgs = findMessages();
        var inThread = msgs.some(function (m) {
          return m.direction === "out" && (normMsg(m.body) === want || normMsg(m.body).indexOf(want.slice(0, 60)) === 0);
        });
        try {
          ccDlvAttempt315 += 1;
          ccDlv("dlv_verify", { attempt: ccDlvAttempt315, composerText: textOf(composer).slice(0, 120), threadHasBody: inThread, tailBubbles: msgs.slice(-3).map(function (mm) { return { dir: mm.direction, text: String(mm.body || "").slice(0, 80) }; }) }, p.threadRef);
        } catch (e) { /* fail-silent */ }
        if (inThread) return true;
        return null;
      }, 12000, 600);
      result.ok = !!hit;
      if (!hit) result.error = "not_verified_in_thread" + (attachedOk ? "" : "_nocdp");
      return result;
    } finally {
      if (replyCdpAttached) {
        // [EMU317-SETTLE-BEGIN] (v2.1.117, note 68):
        // emulation OFF before detach — never leak
        // the focus override into other jobs on
        // this tab.
        try { await replyCdp("emuFocus", { enabled: false }); } catch (e) { ccDlvErr315("emu_focus_off", e, p.threadRef); /* best effort */ }
        // [EMU317-SETTLE-END]
        try { await replyCdp("detach"); } catch (e) { ccDlvErr315("cdp_detach", e, p.threadRef); /* session hygiene best effort */ }
      }
    }
  }
  // [DLVFIX315-END]

  async function maybeDeliverPending() {
    if (delivering) return;
    var store = await chrome.storage.local.get(["luca_pending_delivery", "luca_delivery_claim"]);
    var p = store && store.luca_pending_delivery;
    if (!p || !p.messageId || !p.threadRef) return;
    if (threadKeyOf(window.location.href) !== threadKeyOf(p.threadRef)) return;
    // Cross-tab claim: another Facebook tab on the same thread must
    // not deliver twice. Storage claims aren't atomic, but a 30s
    // claim window makes a double-send a genuine rarity.
    var claim = store.luca_delivery_claim;
    if (claim && claim.messageId === p.messageId && Date.now() - (claim.at || 0) < 30000) return;
    await chrome.storage.local.set({ luca_delivery_claim: { messageId: p.messageId, at: Date.now() } });
    delivering = true;
    try {
      var res = await deliverPending(p);
      chrome.runtime.sendMessage(
        { type: "AUTOLAUNCH_REPLY_RESULT", messageId: p.messageId, ok: res.ok, error: res.error || null },
        function () { void chrome.runtime.lastError; });
    } catch (e) {
      ccDlvErr315("maybe_deliver", e, p.threadRef); /*D315*/
      try {
        chrome.runtime.sendMessage(
          { type: "AUTOLAUNCH_REPLY_RESULT", messageId: p.messageId, ok: false, error: "exception" },
          function () { void chrome.runtime.lastError; });
      } catch (e2) { /* worker will time the pending slot out */ }
    } finally {
      delivering = false;
    }
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.type === "AUTOLAUNCH_DELIVER_NOW") {
      // ACK first (v2.1.35): the worker treats no-ACK as a dead
      // script and reloads the tab, so answering is what proves this
      // script is alive. Delivery itself proceeds async.
      try { sendResponse({ accepted: true }); } catch (e) { /* channel quirks are non-fatal */ }
      maybeDeliverPending();
      return;
    }
    if (msg && msg.type === "AUTOLAUNCH_SYNC_NOW") {
      // App-driven sync (v2.1.38): run a pass and answer only when
      // the worker has confirmed the database writes, so the app can
      // repaint with the new messages already in place.
      autoPassSync().then(function () {
        try { sendResponse({ ok: true }); } catch (e) { /* page moved on */ }
      });
      return true;
    }
  });
  setTimeout(maybeDeliverPending, 2500);
  setInterval(maybeDeliverPending, 20000);
})();
