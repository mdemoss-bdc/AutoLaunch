// AutoLaunch Vehicle Assistant — Luca chat capture (Phase 2, v1).
//
// Marketplace buyer chats are Messenger threads on facebook.com. There
// is no official API into a personal account's chats, so Luca reads
// them the same way the poster works: in the rep's own signed-in
// Chrome. This script runs on Messenger / Marketplace inbox pages and
// adds one floating button — "Capture chat for Luca". On click it
// scrapes the OPEN thread (buyer name, the listing it belongs to, the
// visible messages with a left/right direction guess) and hands it to
// the worker, which stores it in Supabase as a Prospect + messages.
//
// v1 is deliberately manual (one click per chat, only what's on
// screen): deterministic for the two-account smoke test, and nothing
// is captured that the rep didn't choose to capture. Selectors are
// best-effort heuristics with fallbacks — if Facebook reshuffles its
// DOM, the failure mode is "captured little", never a broken page.
(function () {
  "use strict";

  var BTN_ID = "autolaunch-luca-capture-btn";

  // The floating chat popup (v2.1.28): sellers often read Marketplace
  // chats in the docked mini-window on a listing page, not the full
  // Messenger view — Matthew hit exactly that on 2026-10-25 and there
  // was no Capture button. The popup lives in a fixed-position
  // container holding a message box; the full Messenger thread is in
  // normal flow, so this returns null there and behavior is unchanged.
  function findChatPopup() {
    try {
      var inputs = document.querySelectorAll('[role="textbox"][aria-label], [contenteditable="true"][aria-label]');
      for (var i = 0; i < inputs.length; i++) {
        var lab = (inputs[i].getAttribute("aria-label") || "").toLowerCase();
        if (lab.indexOf("message") === -1 && lab !== "aa") continue;
        var node = inputs[i];
        for (var up = 0; up < 10 && node && node !== document.body; up++) {
          node = node.parentElement;
          if (!node) break;
          var cs = window.getComputedStyle ? window.getComputedStyle(node) : null;
          if (cs && cs.position === "fixed" && node.querySelectorAll('[dir="auto"]').length) return node;
        }
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return null;
  }

  function onChatSurface() {
    var p = window.location.pathname || "";
    return p.indexOf("/messages/") === 0 || p.indexOf("/marketplace/inbox") === 0 || !!findChatPopup();
  }

  function textOf(el) {
    return ((el && (el.innerText || el.textContent)) || "").trim().replace(/\s+/g, " ");
  }

  function findBuyerName() {
    // Best hook (v2.1.29, from Matthew's live capture): Facebook labels
    // the thread container "Conversation titled <Name> · <Listing>" —
    // the name is the part before the first "·".
    try {
      var titled = document.querySelector('[aria-label^="Conversation titled "]');
      if (titled) {
        var t = (titled.getAttribute("aria-label") || "").replace(/^Conversation titled\s*/, "");
        var nm = t.split("·")[0].trim();
        if (nm && nm.length >= 2 && nm.length <= 60 && !isJunkName(nm)) return nm;
      }
    } catch (e) { /* fall through to the heading scan */ }
    // Thread header usually carries the buyer's name in a heading.
    var main = document.querySelector('[role="main"]');
    var scopes = [findChatPopup(), main, document].filter(Boolean);
    for (var i = 0; i < scopes.length; i++) {
      var heads = scopes[i].querySelectorAll("h1, h2");
      for (var j = 0; j < heads.length; j++) {
        var t = textOf(heads[j]);
        if (t && t.length >= 2 && t.length <= 60 && !isJunkName(t) && !/messenger|marketplace|chats|inbox/i.test(t)) return t;
      }
    }
    // Fallback: the document title on thread pages is often the name.
    var title = (document.title || "").replace(/\s*[|·•-]\s*Facebook.*$/i, "").replace(/^\(\d+\)\s*/, "").trim();
    if (title && !isJunkName(title) && !/messenger|facebook/i.test(title) && title.length <= 60) return title;
    return "";
  }

  // The thread-header listing link's subtree includes its action
  // buttons, so the raw text arrives as "$23,220 - 2026 Volkswagen
  // Jetta View buyer More options" (Matthew's live capture, 2026-10-25).
  // Cut at the first chrome token and drop a leading "Marketplace".
  function cleanListingLabel(label) {
    var s = String(label || "").trim();
    s = s.split(/\s+(?:View buyer|More options)\b/)[0];
    s = s.replace(/^Marketplace\s+(?=\$)/, "");
    return s.trim();
  }

  function findListing() {
    // Marketplace threads link the listing; the first item link in the
    // thread pane is the car this chat is about.
    var links = document.querySelectorAll('a[href*="/marketplace/item/"]');
    for (var i = 0; i < links.length; i++) {
      var label = cleanListingLabel(textOf(links[i]) || (links[i].getAttribute("aria-label") || "").trim());
      var href = links[i].href || "";
      if (label && label.length >= 4) return { vehicleText: label.slice(0, 140), itemUrl: href };
      if (href) return { vehicleText: "", itemUrl: href };
    }
    return { vehicleText: "", itemUrl: "" };
  }

  // Chrome-label filter (v2.1.48): the thread page's info rail and
  // header render their labels as dir="auto" text too, and the
  // scrape stored them as if they were the rep's own messages —
  // "Mute", "Customize chat", "Chat members", the thread's own
  // title — polluting the Prospects view and Luca's voice data.
  // Two defenses: (1) an exact whole-text denylist of the known
  // Facebook chrome labels, plus the thread's own title text;
  // (2) a structural rule — a real message bubble is a plain text
  // block, never the whole content of a control (quick-reply chips
  // and rail rows are controls) and never inside a chrome region
  // (page header, nav, info rail, form). Whole-text only, always:
  // a real sentence that merely mentions a label is a message.
  var FB_CHROME_LABELS = {
    "Mute": 1, "Unmute": 1,
    "Customize chat": 1, "Chat members": 1,
    "Media, files and links": 1, "Privacy & support": 1,
    "Buyer details": 1, "Seller details": 1,
    "Send a quick response": 1,
    "View buyer": 1, "View seller": 1, "More options": 1,
    // v2.50 (sync repair): the generic participant placeholder and
    // composer/header furniture from half-rendered threads —
    // Matthew's live junk rows, 2026-10-27. Never a message body,
    // never a buyer name.
    "Facebook user": 1, "Compose": 1, "Conversation with Facebook user": 1,
    // v2.1.105 (note 58): list-surface page chrome — a
    // /messages/ list scrape filed "Notifications" as a
    // buyer name (2026-11-12 desk proof); "Messenger"
    // and "Chats" are the same class of heading, fenced
    // here too (they were only regex-excluded inside
    // one findBuyerName branch, not in the shared list).
    "Notifications": 1, "Messenger": 1, "Chats": 1
  };

  // v2.50: a scraped "name" that is really Facebook chrome is NOT
  // a resolved buyer — the worker's gate treats it as unresolved,
  // so it must never leave this script as a participant name.
  function isJunkName(n) {
    if (!n) return true;
    return !!FB_CHROME_LABELS[String(n).trim()];
  }

  // Transient delivery-state labels (v2.51): Messenger paints the
  // state of the rep's last bubble — "Sending", "Delivered",
  // "Seen", "Edited" — as its own dir="auto" text under the
  // bubble, and the scrape stored it as a message (Matthew's live
  // thread, 2026-10-27: an out/rep row whose body was literally
  // "Sending"). Whole-text only: a real sentence that STARTS with
  // one of these words ("Sending the paperwork now") is a message
  // and must survive. "You sent" is the delivery caption variant.
  var FB_TRANSIENT_STATES = {
    "Sending": 1, "Sending...": 1, "Sending…": 1,
    "Delivered": 1, "Seen": 1, "Edited": 1, "You sent": 1,
    "Message sent": 1, "Message delivered": 1
  };

  function isTransientStateText(t) {
    return !!FB_TRANSIENT_STATES[t];
  }

  // Group-thread system lines (v2.51): Marketplace conversations
  // are GROUP threads, and Facebook narrates group events in the
  // transcript itself — "Matthew DeMoss created this group",
  // "Matthew named the group Matthew · 2026 Honda CR-V.",
  // "Matthew changed the group photo." The scrape stored them
  // as buyer messages (seen live 2026-10-26 and again 2026-10-27,
  // even after the 2.48/2.50 filters — only the "created this
  // group" tail was covered). The match is the system-line
  // grammar — an actor name followed by a group-event verb —
  // which is how these lines are shaped; a buyer's ordinary
  // sentence does not take this form.
  var GROUP_SYSTEM_RE = /^.{1,80}?\s+(?:named the group|changed the group (?:photo|name|image|picture)|created this group|added\s+\S.*\s+to (?:the|this) group|left the group|joined the group|removed\s+\S.*\s+from the group)\b/;

  function isGroupSystemText(t) {
    return GROUP_SYSTEM_RE.test(t);
  }

  function threadTitleTexts() {
    // The strings this thread's own header shows as its title —
    // "Name · Listing" from the aria-label, the header element's
    // visible text, and the name + listing pair rebuilt from the
    // scrapers. If the scrape meets one of these as a "message",
    // it is the header talking, not a person.
    var out = {};
    try {
      var titled = document.querySelector('[aria-label^="Conversation titled "]');
      if (titled) {
        var t = (titled.getAttribute("aria-label") || "").replace(/^Conversation titled\s*/, "").trim();
        if (t) out[t] = 1;
        var vis = textOf(titled);
        if (vis) out[vis] = 1;
      }
    } catch (e) { /* heuristic only */ }
    try {
      var name = findBuyerName();
      var lv = findListing().vehicleText || "";
      // v2.51: the full listing label itself ("$38,008 - 2026
      // Honda CR-V") is header/card text — when it shows up as
      // a dir="auto" node in the pane it is the listing card
      // talking, not a person, so it joins the title set whole.
      if (lv) out[lv] = 1;
      var lt = lv.replace(/^\$[\d,]+\s*-\s*/, "").trim();
      if (name && lt) out[name + " · " + lt] = 1;
    } catch (e) { /* heuristic only */ }
    return out;
  }

  function isChromeText(t, titles) {
    if (!t) return false;
    if (FB_CHROME_LABELS[t]) return true;
    if (FB_TRANSIENT_STATES[t]) return true; // v2.51: state labels, every path
    if (titles && titles[t]) return true;
    return false;
  }

  function inChromeStructure(node, t) {
    // Structural containment: walk the node's ancestors. Chrome
    // regions (header / nav / complementary rail / search / form)
    // disqualify outright. A control (button / role=button) whose
    // ENTIRE text is this text also disqualifies — the node is the
    // control's label. A control holding more than this text (a
    // message row with hover actions) does not, and a link inside
    // a bubble (a pasted URL) never does.
    try {
      var el = node;
      for (var up = 0; up < 14 && el && el !== document.body; up++) {
        var role = el.getAttribute ? (el.getAttribute("role") || "") : "";
        var tag = el.tagName || "";
        if (role === "complementary" || role === "banner" || role === "navigation" ||
            role === "search" || tag === "HEADER" || tag === "NAV" || tag === "FORM") return true;
        if ((role === "button" || tag === "BUTTON") && textOf(el) === t) return true;
        el = el.parentElement;
      }
    } catch (e) { /* heuristic only — the text checks still apply */ }
    return false;
  }

  // Direction by EDGE-HUGGING (v2.51): the old rule compared a
  // bubble's center to the midpoint of [role="main"] — but main
  // spans the nav, the thread column AND the info rail (and, on
  // a wide monitor, dead space past the rail), so the "midpoint"
  // sat well right of the conversation and a LONG rep bubble's
  // center fell left of it: the rep's own words were filed as
  // the buyer's (Matthew's live group thread, 2026-10-27, where
  // both sides also share the display name "Matthew", so no name
  // check could catch it). Messenger aligns bubbles: the rep's
  // hug the column's RIGHT edge, the buyer's hug the LEFT edge.
  // The column bounds come from the candidate bubbles themselves,
  // so the rail never enters the math. A bubble flush with one
  // edge is placed by that edge at ANY width (a long rep bubble
  // still lands flush right); a bubble spanning nearly the whole
  // column floats, so only its center can speak, inside a tight
  // dead zone; anything else follows the nearer edge. What
  // cannot be placed returns null and the caller SKIPS it —
  // guessing a side is how the rep's words end up in the
  // buyer's mouth. (A lone visible bubble defines its own
  // column and is unplaceable by construction; the inbox-list
  // snippet sync still carries its line for a known prospect.)
  function bubbleDirection(r, colLeft, colRight, colWidth) {
    if (!(colWidth > 0)) return null;
    var leftGap = r.left - colLeft;
    var rightGap = colRight - (r.left + r.width);
    if (rightGap <= 0.01 * colWidth && leftGap > rightGap) return "out";
    if (leftGap <= 0.01 * colWidth && rightGap > leftGap) return "in";
    if (r.width >= 0.92 * colWidth) {
      var mid = colLeft + colWidth / 2;
      var center = r.left + r.width / 2;
      var dz = 0.01 * colWidth;
      if (center > mid + dz) return "out";
      if (center < mid - dz) return "in";
      return null;
    }
    if (rightGap < leftGap) return "out";
    if (leftGap < rightGap) return "in";
    return null;
  }

  function findMessages() {
    // Popup first: when the chat is the floating mini-window, scope to
    // it — its own midpoint is what separates buyer (left) from rep
    // (right); measured against the whole page the popup sits right of
    // center and every bubble would read as the rep's.
    var main = findChatPopup() || document.querySelector('[role="main"]') || document.body;
    // Message text lives in dir="auto" blocks; a bubble is the closest
    // reasonably-sized container around one.
    var nodes = main.querySelectorAll('[dir="auto"]');
    var titles = threadTitleTexts();
    // Participant names (v2.51): a node whose WHOLE text is a
    // participant's name is a sender caption or the info card's
    // name line, never a message — both were stored live as buyer
    // "messages" ("Matthew", "Matthew DeMoss"). Names come from
    // the thread title scrape and from the actor position of the
    // group system lines themselves, which name every actor in
    // full ("Matthew DeMoss created this group").
    var participantNames = {};
    try {
      var bn = findBuyerName();
      if (bn) participantNames[bn] = 1;
    } catch (e) { /* the caption rule just disarms */ }
    for (var a = 0; a < nodes.length; a++) {
      var at = textOf(nodes[a]);
      if (!at) continue;
      var am = at.match(/^(.{2,60}?)\s+(?:named the group|changed the group|created this group|added\s|left the group|joined the group|removed\s)/);
      if (am) participantNames[am[1].trim()] = 1;
    }
    var cands = [];
    for (var i = 0; i < nodes.length; i++) {
      var t = textOf(nodes[i]);
      if (!t || t.length < 1 || t.length > 1000) continue;
      // Skip UI chrome that also uses dir="auto". The second pattern
      // set is Matthew's live thread (2026-10-25): header card labels,
      // group-system lines, and pane furniture that are NOT messages.
      if (/^(Seen|Delivered|Sent|Type a message|Aa|Search|Active now|You're friends on Facebook|You're both on Facebook)/.test(t)) continue;
      if (/^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(t)) continue; // timestamp dividers ("1:57 PM") are not messages
      if (t === "Message sent" || t === "Message delivered") continue; // status furniture, not a message
      if (/^(View buyer|More options|Privacy & support|Messages|Send a quick response|Marketplace)$/.test(t)) continue;
      if (/^Conversation titled /.test(t)) continue;
      if (/^Conversation with /.test(t)) continue; // v2.50: half-rendered thread header
      if (/ created this group$/.test(t)) continue;
      if (isGroupSystemText(t)) continue; // v2.51: group-event narration ("… named the group …", "… changed the group photo.")
      if (/^\$[\d,]+\s*[-–—]\s*(19|20)\d{2}\s+\S/.test(t) && t.length <= 60) continue; // v2.51: the listing card's label line
      if (/^Highly rated\b/.test(t) || t === "on Marketplace") continue; // v2.51: buyer-card ratings furniture (split-node form)
      if (participantNames[t]) continue; // v2.51: sender caption / info-card name line
      if (/mutual friends/.test(t) || /badge on Marketplace/.test(t)) continue;
      // Info-panel guard (v2.1.39): the thread page's right rail
      // (Media, files and links) lives inside [role=main] too — its
      // attachment rows (filenames, sizes, dates) are not messages.
      // Seen live 2026-10-25 vacuuming a files list into a thread.
      if (nodes[i].closest && nodes[i].closest('[role="complementary"]')) continue;
      if (/\.(csv|txt|pdf|jpe?g|png|gif|mp3|wav|zip|docx?|xlsx?)$/i.test(t)) continue;
      if (/^\d+(\.\d+)?\s?(KB|MB|GB|B)$/.test(t)) continue;
      if (/Unread message:/.test(t)) continue;
      // Chrome-label filter (v2.1.48): the exact denylist + this
      // thread's title, and the structural containment rule. The
      // denylist check now also covers the v2.51 transient states.
      if (isChromeText(t, titles)) continue;
      if (inChromeStructure(nodes[i], t)) continue;
      var r = nodes[i].getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      cands.push({ text: t, rect: r });
    }
    if (!cands.length) return [];
    // Direction pass (v2.51): the conversation column is the span
    // the surviving bubbles themselves occupy — the page pane's
    // midpoint never enters into it (see bubbleDirection).
    var colLeft = Infinity, colRight = -Infinity;
    for (var b = 0; b < cands.length; b++) {
      if (cands[b].rect.left < colLeft) colLeft = cands[b].rect.left;
      var rr = cands[b].rect.left + cands[b].rect.width;
      if (rr > colRight) colRight = rr;
    }
    var colWidth = colRight - colLeft;
    var out = [];
    var seen = {};
    for (var k = 0; k < cands.length; k++) {
      var dir = bubbleDirection(cands[k].rect, colLeft, colRight, colWidth);
      if (!dir) continue; // unplaceable — skip rather than guess a side
      var key = cands[k].text + "|" + dir;
      if (seen[key]) continue;
      seen[key] = true;
      out.push({ direction: dir, body: cands[k].text });
    }
    // Capture-hygiene cuts (v2.1.111, note 62) — applied
    // to the scraped rows AFTER direction assignment, on
    // purpose: the awaiting-reply banner's wide,
    // right-hugging bubble is part of what defines the
    // column the direction pass measures against, so
    // cutting it during the candidate loop would shrink
    // the column and can leave the buyer's real message
    // unplaceable in exactly the minimal first-message
    // thread this feature serves (proven in the 3.11
    // harness: with the banner cut early, the desk
    // fixture's question spans the narrowed column and is
    // skipped as unplaceable). (1) HEADER NAME: the thread
    // header's name line can survive the loop above as the
    // FIRST scraped message — the participant-name filter
    // keys on the titled label's name form, while the
    // header element renders the buyer's full name
    // (Matthew's live thread, 2026-11-13: "Matthew
    // DeMoss" stored ahead of the buyer's real first
    // message). A first message whose whole text is a name
    // this scrape itself resolved for the buyer — from the
    // titled label, the header's visible title text, or
    // the header heading — is the header element, not a
    // message, when at least one more message follows it.
    // Anywhere else, or alone, a name is kept.
    // (2) WAITING BANNER: a row whose WHOLE text matches
    // the banner pattern is UI chrome, never a message.
    var resolvedNames311 = {};
    if (typeof bn !== "undefined" && bn) resolvedNames311[bn] = 1;
    try {
      var titled311 = document.querySelector('[aria-label^="Conversation titled "]');
      if (titled311) {
        var visName311 = textOf(titled311).split("·")[0].trim();
        if (visName311 && visName311.length >= 2 && visName311.length <= 60) resolvedNames311[visName311] = 1;
      }
    } catch (e) { /* heuristic only */ }
    try {
      var headScope311 = findChatPopup() || document.querySelector('[role="main"]');
      if (headScope311) {
        var heads311 = headScope311.querySelectorAll("h1, h2");
        for (var hj = 0; hj < heads311.length; hj++) {
          var ht311 = textOf(heads311[hj]);
          if (ht311 && ht311.length >= 2 && ht311.length <= 60 && !isJunkName(ht311) && !/messenger|marketplace|chats|inbox/i.test(ht311)) { resolvedNames311[ht311] = 1; break; }
        }
      }
    } catch (e) { /* heuristic only */ }
    if (out.length >= 2 && resolvedNames311[out[0].body]) out.shift();
    out = out.filter(function (m) { return !/^.+ is waiting for your response\.?$/.test(m.body); });
    // DOM order is chronological; keep the most recent 30.
    return out.slice(-30);
  }

  // Seller-side evidence for the worker's auto-create gate
  // (v2.1.46): which surface this thread was read on, and whether
  // the thread pane carries the SELLER's controls. "View buyer"
  // renders only when the signed-in user is the listing's seller;
  // a buyer-side thread shows "View seller" instead.
  function threadSurface() {
    var p = window.location.pathname || "";
    return p.indexOf("/marketplace/inbox") === 0 ? "marketplace_inbox" : "";
  }

  function findSellerContext() {
    try {
      var scope = findChatPopup() || document.querySelector('[role="main"]') || document;
      var els = scope.querySelectorAll("a, button, [role='button'], span");
      for (var i = 0; i < els.length; i++) {
        if ((els[i].textContent || "").trim() === "View buyer") return true;
      }
    } catch (e) { /* heuristic only — never break the page */ }
    return false;
  }

  // Facebook identity (v2.1.47, worker header note 23): the gate's
  // self test compares IDENTITIES, never names — the rep tests from
  // a second account under the same display name, and real buyers
  // can share his name. Tokens are canonical: "id:<digits>" for
  // numeric profile ids, "vanity:<lowercased>" otherwise; an id
  // token never equals a vanity token (unproven = not self).
  var FB_RESERVED_SEGMENTS = {
    messages: 1, marketplace: 1, groups: 1, watch: 1, gaming: 1,
    friends: 1, notifications: 1, settings: 1, help: 1, events: 1,
    pages: 1, login: 1, sharer: 1, dialog: 1, plugins: 1, people: 1,
    search: 1, bookmarks: 1, me: 1, home: 1, "profile.php": 1,
    "photo.php": 1, "permalink.php": 1
  };

  function fbIdentityFromHref(href) {
    try {
      var u = new URL(href);
      if (!/(^|\.)facebook\.com$/.test(u.hostname)) return "";
      if (/\/profile\.php$/.test(u.pathname)) {
        var m = (u.search || "").match(/[?&]id=(\d+)/);
        return m ? "id:" + m[1] : "";
      }
      var seg = (u.pathname || "").split("/").filter(Boolean);
      if (seg.length === 1 && !FB_RESERVED_SEGMENTS[seg[0].toLowerCase()]) {
        return "vanity:" + seg[0].toLowerCase();
      }
    } catch (e) { /* not a profile link */ }
    return "";
  }

  function findSelfFbId() {
    // c_user is the signed-in account's numeric id, readable by the
    // page. Fallback: a profile.php link pointing at the account.
    try {
      var m = (document.cookie || "").match(/(?:^|;\s*)c_user=(\d+)/);
      if (m) return "id:" + m[1];
    } catch (e) { /* fall through */ }
    try {
      var links = document.querySelectorAll('a[href*="profile.php?id="]');
      for (var i = 0; i < links.length; i++) {
        var id = fbIdentityFromHref(links[i].href || "");
        if (id) return id;
      }
    } catch (e) { /* heuristic only */ }
    return "";
  }

  function findBuyerFbId(selfId) {
    // The counterparty's profile link lives on the thread pane —
    // the header / buyer card and the info rail, which on group-
    // flavored Marketplace threads is also where "Chat members"
    // links render. Take the pane's profile identities in order:
    // the buyer is the first that isn't provably the signed-in
    // user; if ALL of them are the signed-in user, the counterparty
    // IS the user (a true self thread). Tightest scope wins.
    try {
      var scopes = [findChatPopup(), document.querySelector('[role="main"]'), document].filter(Boolean);
      for (var s = 0; s < scopes.length; s++) {
        var seen = [];
        var links = scopes[s].querySelectorAll("a[href]");
        for (var i = 0; i < links.length; i++) {
          var id = fbIdentityFromHref(links[i].href || "");
          if (id && seen.indexOf(id) === -1) seen.push(id);
        }
        if (!seen.length) continue;
        for (var j = 0; j < seen.length; j++) {
          if (!selfId || seen[j] !== selfId) return seen[j];
        }
        return selfId;
      }
    } catch (e) { /* heuristic only */ }
    return "";
  }

  function scrape() {
    var listing = findListing();
    var selfId = findSelfFbId();
    return {
      buyerName: findBuyerName(),
      vehicleText: listing.vehicleText,
      itemUrl: listing.itemUrl,
      threadUrl: window.location.href,
      surface: threadSurface(),
      sellerContext: findSellerContext(),
      selfFbId: selfId,
      buyerFbId: findBuyerFbId(selfId),
      messages: findMessages()
    };
  }

  // Capture failure reasons (v2.1.47): a bare "Capture failed" told
  // the rep nothing. After a helper update, an already-open
  // Facebook tab runs an ORPHANED script whose sendMessage throws
  // (context invalidated) — the fix is reloading the tab, and the
  // label now says so. Worker-declined captures carry its code.
  function captureFailLabel(lastError, resp) {
    var msg = (lastError && lastError.message) || "";
    if (/context invalidated|receiving end does not exist|message port closed/i.test(msg)) {
      return "Capture failed — reload this Facebook tab";
    }
    if (resp && resp.error === "not_signed_in") return "Capture failed — open AutoLaunch & sign in";
    if (resp && resp.error === "no_buyer") return "Capture failed — no buyer found in this chat";
    if (resp && resp.error) return "Capture failed — try again in a moment";
    return "Capture failed — is AutoLaunch signed in?";
  }

  function setBtnLabel(btn, label, ok) {
    btn.textContent = label;
    btn.style.background = ok === true ? "#059669" : ok === false ? "#e11d48" : "#2563eb";
    setTimeout(function () {
      btn.textContent = "🌙 Capture chat for Luca";
      btn.style.background = "#2563eb";
    }, 4000);
  }

  function injectButton() {
    if (!onChatSurface() || document.getElementById(BTN_ID)) return;
    var btn = document.createElement("button");
    btn.id = BTN_ID;
    btn.textContent = "🌙 Capture chat for Luca";
    btn.style.cssText = [
      "position:fixed", "right:16px", "bottom:16px", "z-index:2147483647",
      "background:#2563eb", "color:#fff", "border:none", "border-radius:999px",
      "padding:10px 16px", "font:600 13px system-ui, sans-serif",
      "box-shadow:0 4px 14px rgba(0,0,0,.35)", "cursor:pointer"
    ].join(";");
    btn.addEventListener("click", function () {
      var capture = scrape();
      if (!capture.messages.length && !capture.buyerName && onInboxListSurface()) {
        autoPass();
        setBtnLabel(btn, "Synced ✓", true);
        return;
      }
      if (!capture.messages.length && !capture.buyerName) {
        setBtnLabel(btn, "Nothing found — open a chat first", false);
        return;
      }
      btn.textContent = "Capturing…";
      try {
        chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CAPTURE_CHAT", capture: capture }, function (resp) {
          if (chrome.runtime.lastError || !resp || !resp.ok) {
            setBtnLabel(btn, captureFailLabel(chrome.runtime.lastError, resp), false);
            return;
          }
          setBtnLabel(btn, "Captured ✓ " + (resp.added || 0) + " new · " + (resp.prospectName || "prospect"), true);
        });
      } catch (e) {
        setBtnLabel(btn, "Capture failed — reload this Facebook tab", false);
      }
    });
    document.body.appendChild(btn);
  }

  // ---- AUTO-CAPTURE v1 (v2.1.31, Matthew's ask): no more clicking
  // Capture per chat. While an inbox surface is open in Chrome:
  //  - every visible thread-list row becomes a STUB capture (the
  //    prospect exists in AutoLaunch with its thread link; the worker
  //    matches by thread, so rows never duplicate a real prospect);
  //  - the OPEN thread (full view or floating popup) is fully captured
  //    whenever its content changes (new message = new hash).
  // The helper never clicks or navigates anything — it only reads
  // what is already on screen, on a slow timer.
  function onInboxListSurface() {
    var p = window.location.pathname || "";
    return p.indexOf("/messages") === 0 || p.indexOf("/marketplace/inbox") === 0;
  }

  function threadKeyOf(url) {
    var m = String(url || "").match(/\/t\/(\d+)/);
    return m ? m[1] : "";
  }

  function collectThreadStubs() {
    var out = [];
    var seen = {};
    var links = document.querySelectorAll('a[href*="/messages/t/"]');
    for (var i = 0; i < links.length && out.length < 15; i++) {
      var key = threadKeyOf(links[i].href || "");
      if (!key || seen[key]) continue;
      var rowText = textOf(links[i]);
      if (!rowText || rowText.length < 3) continue;
      seen[key] = true;
      // Rows lead with the buyer name, then separators/snippets. The
      // worker self-heals names from later full captures, so a rough
      // name here is acceptable — a wrong THREAD never is, and the
      // thread key comes from the href, not the text.
      var nm = rowText.split(" · ")[0].trim();
      var youAt = nm.indexOf("You:");
      if (youAt > 0) nm = nm.slice(0, youAt).trim();
      // A long first segment means the name fused with the snippet —
      // a placeholder (which full captures self-heal) beats a wrong
      // name that never gets corrected.
      if (nm.length > 30) nm = "";
      if (!nm || /\$/.test(nm) || /^(Chats|Marketplace|New message)/i.test(nm)) nm = "";
      if (isJunkName(nm)) nm = ""; // v2.50: a chrome placeholder is not a name
      var vm = rowText.match(/\$\d[\d,]*\s*-\s*[^·]{4,80}/);
      if (!vm) vm = rowText.match(/\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z0-9]+/); // year/make/model label also proves Marketplace
      // Commerce gate (v2.1.34): the plain /messages list mixes in
      // personal chats, business-page chats and the Meta AI chat —
      // none of those are buyers. A row is only SENT with Marketplace
      // evidence: a priced listing label, a year/make/model label,
      // or the Marketplace inbox surface itself (which is commerce-
      // only by construction). Since v2.1.46 this pre-filter no
      // longer decides creation — the worker's autoCreateGate does,
      // and it fails closed where this pass cannot tell.
      var onMarketplaceInbox = (window.location.pathname || "").indexOf("/marketplace/inbox") === 0;
      var yearMake = /\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z]+/.test(rowText);
      if (!onMarketplaceInbox && !vm && !yearMake) continue;
      if (/^(Meta AI|Facebook user)\b/i.test(nm) && !vm) continue;
      out.push({
        buyerName: nm,
        vehicleText: vm ? cleanListingLabel(vm[0]) : "",
        itemUrl: "",
        threadUrl: "https://www.facebook.com/messages/t/" + key,
        // v2.1.46: the worker's auto-create gate keys its surface
        // signal on this — a stub born on the Marketplace inbox is
        // commerce-surface evidence; a plain /messages row is not.
        surface: onMarketplaceInbox ? "marketplace_inbox" : "",
        sellerContext: false,
        selfFbId: findSelfFbId(),
        buyerFbId: "",
        messages: [],
        stub: true
      });
    }
    return out;
  }

  // v2.1.105 (note 58): the preview tail of a list row whose
  // text never separates into list segments (the /messages/
  // Marketplace folder renders some rows fused): the text
  // after the year/make/model label, minus a trailing time
  // token. The year/make/model match is bounded, so it
  // cannot swallow the preview the way the price-label
  // match could on a fused row. "" when no label anchors it.
  function snippetTailFallback(rowText) {
    var lm = rowText.match(/\b(19|20)\d{2}\s+[A-Z][A-Za-z]+\s+[A-Z][A-Za-z0-9]+/);
    if (!lm) return "";
    var tail = rowText.slice(rowText.indexOf(lm[0]) + lm[0].length)
      .replace(/^[\s\u00b7|-]+/, "")
      .replace(/\s+\d{1,2}:\d{2}\s?(AM|PM)?\s*$/i, "")
      .replace(/\s+\d+\s?[mhdw]\s*$/i, "")
      .trim();
    return (tail.length >= 2 && !isChromeText(tail, null)) ? tail : "";
  }

  // Snippet sync (v2.1.33): each list row also carries the conversation's
  // NEWEST line as a preview — and that preview updates live when a
  // buyer writes, no click needed. We forward those lines for every
  // visible row; the worker stores them only for threads that already
  // belong to a prospect (personal chats are never pulled in). "You:"
  // prefixes mark the rep's own latest line.
  function collectThreadSnippets() {
    var out = [];
    var seen = {};
    var timeLike = /^(\d{1,2}:\d{2}\s?(AM|PM)?|\d+\s?[mhdw]|Mon|Tue|Wed|Thu|Fri|Sat|Sun|Jan \d+|Feb \d+|Mar \d+|Apr \d+|May \d+|Jun \d+|Jul \d+|Aug \d+|Sep \d+|Oct \d+|Nov \d+|Dec \d+|Just now|Yesterday)$/i;
    var links = document.querySelectorAll('a[href*="/messages/t/"]');
    for (var i = 0; i < links.length && out.length < 15; i++) {
      var key = threadKeyOf(links[i].href || "");
      if (!key || seen[key]) continue;
      var rowText = textOf(links[i]);
      if (!rowText || rowText.length < 3) continue;
      seen[key] = true;
      var segs = rowText.split(" · ").map(function (s) { return s.trim(); }).filter(Boolean);
      if (segs.length < 2) {
        var tailF = snippetTailFallback(rowText);
        if (tailF) segs = [segs[0] || "", tailF];
      }
      if (segs.length < 2) continue;
      var rest = segs.slice(1).filter(function (s) {
        return !timeLike.test(s) && !/^\$[\d,]+\s*-/.test(s) && s.length > 1;
      });
      if (!rest.length) {
        var tailF2 = snippetTailFallback(rowText);
        if (tailF2) rest = [tailF2];
      }
      if (!rest.length) continue;
      var snippet = rest.reduce(function (a, b) { return b.length > a.length ? b : a; }, "");
      var direction = "in";
      if (/^You[:\s]/i.test(snippet)) {
        direction = "out";
        snippet = snippet.replace(/^You[:\s]+/i, "").trim();
      }
      if (snippet.length < 2) continue;
      if (isChromeText(snippet, null)) continue; // v2.1.48: a chrome label is not a snippet
      out.push({
        threadRef: "https://www.facebook.com/messages/t/" + key,
        snippet: snippet.slice(0, 140),
        direction: direction
      });
    }
    return out;
  }

  // ---- Marketplace inbox BUTTON rows (v2.1.108, note 60) ----
  // facebook.com/marketplace/inbox renders conversation rows
  // as <button> elements (role="button") with NO href and NO
  // contained <a> — proven by live DOM inspection 2026-11-13
  // (zero anchors matching a[href*="/messages/t/"] on the
  // whole page). The anchor harvest above has therefore
  // never seen this surface. Rows sit inside <main>
  // alongside the Selling/Buying/Jobs tabs. This harvest
  // reads rendered row text only: it NEVER clicks a row and
  // NEVER marks anything read.
  var INBOX_ROW_TIME_RE = /^(\d{1,2}:\d{2}\s?(AM|PM)|Yesterday|Today|(Mon|Tue|Wed|Thu|Fri|Sat|Sun)(day)?|(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}|\d{1,2}\/\d{1,2}(\/\d{2,4})?)$/i;
  // Pure line parser (lines in, fields out) so the harness
  // exercises the exact shipped code on the live row texts.
  // Lines: header ("<Name> · <Label>" or a bare "<Name>"),
  // the preview line(s), an optional trailing timestamp.
  function parseInboxButtonRow(lines) {
    var ls = (lines || []).map(function (s) { return String(s || "").replace(/\s+/g, " ").trim(); }).filter(Boolean);
    // v2.1.110 (note 61): the live row renders its header
    // SPLIT — the buyer's name on one line, "· <Label>"
    // on its own line (the nbsp-only line between them
    // collapsed away above). Rejoin any line that begins
    // with "·" onto the previous line, so the " · "
    // split below sees the one-line header this parser was
    // written for. Single-line headers are untouched; a
    // leading "·" line has no previous line and stays
    // as-is, exactly as before.
    for (var li = 1; li < ls.length; li++) {
      if (ls[li].indexOf("·") === 0) { ls[li - 1] += " " + ls[li]; ls.splice(li, 1); li--; }
    }
    if (ls.length && INBOX_ROW_TIME_RE.test(ls[ls.length - 1])) ls.pop();
    if (ls.length < 2) return null;
    var header = ls[0];
    var preview = ls.slice(1).join(" ");
    var name = header, label = "";
    var cut = header.indexOf(" · ");
    if (cut > 0) { name = header.slice(0, cut).trim(); label = header.slice(cut + 3).trim(); }
    name = name.trim();
    label = cleanListingLabel(label);
    if (!name || isJunkName(name)) return null;
    if (/^(Selling|Buying|Jobs|Inbox|Notifications|Create)/i.test(name)) return null;
    if (!preview) return null;
    return { buyerName: name, vehicleLabel: label, preview: preview.slice(0, 140) };
  }
  function inboxRowUnread(rowEl) {
    try {
      var els = rowEl.querySelectorAll ? rowEl.querySelectorAll("[aria-label]") : [];
      for (var i = 0; i < els.length; i++) {
        if (/unread/i.test(els[i].getAttribute("aria-label") || "")) return true;
      }
      if (/unread/i.test((rowEl.getAttribute && rowEl.getAttribute("aria-label")) || "")) return true;
    } catch (e) { /* best-effort */ }
    return null;
  }
  // Best-effort thread identity from the row's React props:
  // a /messages/t/<id> string in any prop value, or a
  // thread-named key carrying a numeric id. Bounded walk;
  // yields "" when the props hold nothing thread-shaped.
  function inboxPropsThreadId(val, depth, budget) {
    if (val == null || depth > 4 || !budget || budget.n <= 0) return "";
    budget.n--;
    if (typeof val === "string") {
      var m = val.match(/\/messages\/t\/(\d{6,})/);
      return m ? m[1] : "";
    }
    if (typeof val !== "object") return "";
    var keys;
    try { keys = Object.keys(val); } catch (e) { return ""; }
    for (var i = 0; i < keys.length && i < 48; i++) {
      var k = keys[i], v = val[k];
      if (/thread/i.test(k) && (typeof v === "string" || typeof v === "number")) {
        var s = String(v);
        if (/^\d{10,19}$/.test(s)) return s;
        var m2 = s.match(/\/messages\/t\/(\d{6,})/);
        if (m2) return m2[1];
      }
      var r = inboxPropsThreadId(v, depth + 1, budget);
      if (r) return r;
    }
    return "";
  }
  function inboxRowThreadRef(rowEl) {
    try {
      var budget = { n: 800 };
      var stack = [{ node: rowEl, depth: 0 }];
      var guard = 0;
      while (stack.length && guard < 300) {
        guard++;
        var cur = stack.pop();
        var node = cur.node;
        if (!node || typeof node !== "object") continue;
        var keys = Object.keys(node);
        for (var i = 0; i < keys.length; i++) {
          if (keys[i].indexOf("__reactProps$") === 0 || keys[i].indexOf("__reactFiber$") === 0) {
            var hit = inboxPropsThreadId(node[keys[i]], 0, budget);
            if (hit) return "https://www.facebook.com/messages/t/" + hit;
          }
        }
        if (cur.depth < 3 && node.children) {
          for (var j = 0; j < node.children.length; j++) stack.push({ node: node.children[j], depth: cur.depth + 1 });
        }
      }
    } catch (e) { /* best-effort only */ }
    return "";
  }
  function collectInboxButtonRows() {
    var out = [];
    if ((window.location.pathname || "").indexOf("/marketplace/inbox") !== 0) return out;
    // v2.1.110 (note 61): the live inbox has NO <main>
    // tag — its rows live inside a [role="main"] container
    // (the 3.09 desk trace: hasMainTag false, all 15 rows
    // inside the single role=main). Fall back to it; a
    // page WITH a <main> tag behaves exactly as before.
    var main = document.querySelector("main") || document.querySelector('[role="main"]');
    if (!main) return out;
    var rows = main.querySelectorAll('button, [role="button"]');
    for (var i = 0; i < rows.length && out.length < 15; i++) {
      var el = rows[i];
      var raw = el.innerText || el.textContent || "";
      var parsed = parseInboxButtonRow(String(raw).split(/\n+/));
      if (!parsed) continue;
      // Conversation rows carry a thumbnail or a listing
      // label; the bare tab/chrome buttons carry neither.
      var hasImg = false;
      try { hasImg = !!el.querySelector("img"); } catch (e) { /* ignore */ }
      if (!hasImg && !parsed.vehicleLabel) continue;
      out.push({
        rowKind: "inbox_button",
        threadRef: inboxRowThreadRef(el),
        snippet: parsed.preview,
        direction: "in",
        buyerName: parsed.buyerName,
        vehicleLabel: parsed.vehicleLabel,
        unread: inboxRowUnread(el)
      });
    }
    return out;
  }

  function sendCapture(capture) {
    // Every caller of this shared sender is an AUTO path (list pass,
    // observer, app-driven sync) — tag it so the worker can apply
    // the Marketplace-only auto rule. The manual Capture button has
    // its own send and stays untagged (a deliberate click is how a
    // rep adds a non-Marketplace thread).
    capture = Object.assign({}, capture, { auto: true });
    // Returns a promise that resolves when the worker has finished
    // (its handler responds only after the database write), so the
    // app-driven sync below can report TRUE completion.
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CAPTURE_CHAT", capture: capture }, function (resp) {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  // Gate-skip retry (v2.50, background.js header note 24): the
  // worker's auto-create gate fails CLOSED on a half-rendered
  // page — unresolved_name before the header paints the buyer's
  // name, no_seller_signal before the seller controls / listing
  // link render. Those skips used to be FINAL: the open thread's
  // full capture is hash-deduped below, so a thread skipped
  // mid-render was never re-asked even after the page finished
  // painting. Track render-dependent skips per thread and re-ask
  // on later passes; terminal outcomes (created, self_thread,
  // deleted_by_user) clear the thread. Bounded per page session —
  // a thread that genuinely never resolves is retried a handful
  // of times, not forever.
  var GATE_RETRY_MAX = 10;
  var RENDER_SKIP_REASONS = { unresolved_name: 1, no_seller_signal: 1 };
  var gateSkipped = {}; // threadKey -> { capture, tries }

  function gateRetryKey(capture) {
    return threadKeyOf((capture && capture.threadUrl) || "") ||
      String((capture && capture.threadUrl) || "");
  }

  function noteCaptureResult(capture, resp) {
    var key = gateRetryKey(capture);
    if (!key) return;
    if (resp && resp.skipped) {
      if (RENDER_SKIP_REASONS[resp.skipped]) {
        var g = gateSkipped[key] || { tries: 0 };
        g.capture = capture;
        g.tries += 1;
        gateSkipped[key] = g;
      } else {
        delete gateSkipped[key]; // terminal skip (self / deleted)
      }
    } else if (resp && resp.ok) {
      delete gateSkipped[key];
    }
  }

  function sendCaptureTracked(capture) {
    var p = sendCapture(capture);
    // sendCapture resolves with the worker's response (or null on
    // a dead channel) — learning the outcome is the whole point.
    if (p && p.then) p.then(function (resp) {
      try { noteCaptureResult(capture, resp); } catch (e) { /* bookkeeping only */ }
    });
    return p;
  }

  function gateRetryDue(key) {
    var g = gateSkipped[key];
    return !!g && g.tries < GATE_RETRY_MAX;
  }

  var lastFullHash = "";
  function autoFullCapture() {
    if (!onChatSurface()) return null;
    // v2.1.103 (note 56): never full-scrape a LIST surface.
    // With no real thread open, scrape() keys its harvest to
    // the list page's own URL and the worker files the whole
    // list as one fake conversation (2026-10-28 diagnosis;
    // the 3.02 hub tab made it fire on Matthew's desk,
    // 2026-11-12). A thread counts as open here only when
    // the URL carries its /t/<id> or a floating chat popup is
    // actually on screen. Stub + snippet collection on list
    // surfaces is unchanged, and the worker drops id-less
    // auto captures regardless (defense in depth).
    if (!threadKeyOf(window.location.href) && !findChatPopup()) return null;
    var c = scrape();
    if (!c.messages.length && !c.buyerName) return null;
    var h = (c.threadUrl || "") + "|" + c.messages.map(function (m) { return m.direction + ":" + m.body; }).join("~");
    // A thread with a render-dependent skip on file bypasses the
    // hash dedupe while its retry budget lasts — the page may
    // have finished rendering around the very same messages.
    if (h === lastFullHash && !gateRetryDue(threadKeyOf(c.threadUrl || ""))) return null;
    lastFullHash = h;
    var sent = sendCaptureTracked(c);
    // Hash honesty (v2.51): the hash used to stay marked no
    // matter what the worker answered, so any outcome that
    // stored NOTHING — a not_signed_in error while the app tab
    // re-delivered the session, a thrown save, a dead channel —
    // poisoned the dedupe for the rest of the page session and
    // the open thread went silent until its text changed
    // (Matthew's ~10 quiet minutes with a rendered thread open,
    // 2026-10-27; the manual button, which bypasses the hash,
    // worked instantly). Only a CONFIRMED outcome keeps the
    // hash: stored (ok), or a skip the worker decided (render
    // skips re-ask through the gateSkipped bypass above;
    // terminal skips must never re-ask). Anything else re-arms.
    if (sent && sent.then) sent.then(function (resp) {
      try {
        var confirmed = !!(resp && (resp.ok || resp.skipped));
        if (!confirmed && lastFullHash === h) lastFullHash = "";
      } catch (e) { /* bookkeeping only */ }
    });
    return sent;
  }

  // App-driven sync (v2.1.38): the AutoLaunch page asks (through the
  // worker) for a capture RIGHT NOW and waits for the writes to land.
  // This exists because a BACKGROUND tab's own timers are throttled
  // by Chrome to ~1/minute — the exact lag Matthew measured — while a
  // runtime message wakes the script immediately.
  async function autoPassSync() {
    var jobs = [];
    try {
      if (onInboxListSurface()) {
        collectThreadStubs().forEach(function (c) { jobs.push(sendCaptureTracked(c)); });
        var snippets = collectThreadSnippets().concat(collectInboxButtonRows());
        if (snippets.length) {
          jobs.push(new Promise(function (resolve) {
            try {
              chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CHAT_SNIPPETS", snippets: snippets }, function () {
                void chrome.runtime.lastError;
                resolve(null);
              });
            } catch (e) { resolve(null); }
          }));
        }
      }
      var full = autoFullCapture();
      if (full) jobs.push(full);
    } catch (e) { /* partial completion still counts */ }
    await Promise.all(jobs);
  }

  function autoPass() {
    try {
      if (onInboxListSurface()) {
        var stubKeys = {};
        collectThreadStubs().forEach(function (c) {
          stubKeys[gateRetryKey(c)] = 1;
          sendCaptureTracked(c);
        });
        // v2.50: re-ask for gate-skipped stub threads that have
        // scrolled out of the rendered list — their last capture
        // rides again while the retry budget lasts.
        Object.keys(gateSkipped).forEach(function (key) {
          if (stubKeys[key] || !gateRetryDue(key)) return;
          var g = gateSkipped[key];
          if (g.capture && g.capture.stub) sendCaptureTracked(g.capture);
        });
        var snippets = collectThreadSnippets().concat(collectInboxButtonRows());
        if (snippets.length) {
          try {
            chrome.runtime.sendMessage({ type: "AUTOLAUNCH_CHAT_SNIPPETS", snippets: snippets }, function () {
              void chrome.runtime.lastError;
            });
          } catch (e) { /* next pass retries */ }
        }
      }
      autoFullCapture();
      var btn = document.getElementById(BTN_ID);
      if (btn && onInboxListSurface()) btn.textContent = "🌙 Luca auto-sync on · Capture now";
    } catch (e) { /* heuristics must never break the page */ }
  }

  // Fast pickup (v2.1.33): a new buyer message rewrites its list row
  // within seconds. Watch the list for changes and run a pass shortly
  // after (debounced, at most ~4x a minute) instead of waiting out the
  // 45-second timer. The worker dedupes anything unchanged.
  var lastObservedPass = 0;
  var observedTimer = null;
  try {
    var listObserver = new MutationObserver(function () {
      if (!onInboxListSurface() && !onChatSurface()) return;
      if (observedTimer) return;
      observedTimer = setTimeout(function () {
        observedTimer = null;
        if (Date.now() - lastObservedPass < 6000) return;
        lastObservedPass = Date.now();
        autoPass();
      }, 2000);
    });
    listObserver.observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) { /* the 45s timer still covers it */ }

  // Facebook is a SPA: the button must survive route changes.
  setInterval(injectButton, 1500);
  injectButton();
  setTimeout(autoPass, 3500);
  setInterval(autoPass, 45000);

  // [CCDLV315-BEGIN] DELIVERY TRACE forwarder
  // (v2.1.115, header note 66 in the worker). Relays the
  // dlv_* delivery stages to the worker's trace sink
  // (AUTOLAUNCH_TRACE -> public.helper_trace):
  // dlv_composer (what findComposer resolved), dlv_type
  // (the COMMIT GATE story: one attempt record per
  // typing path — its ok flag, whether the composer
  // RE-READ showed the body committed, and the text as
  // read back), dlv_submit (which submit mechanism
  // fired), dlv_verify (per attempt: the composer text,
  // whether the EXACT body is present as an out bubble
  // in the thread's message list, and the last three
  // bubbles with direction), dlv_error (every swallowed
  // exception on the path). Fail-silent everywhere.
  var ccDlvAttempt315 = 0;
  var ccDlvBtnLabel315 = null;
  function ccDlv(stage, detail, threadRef) {
    try {
      chrome.runtime.sendMessage({ type: "AUTOLAUNCH_TRACE", stage: stage, threadRef: threadRef || null, detail: detail || {} }, function () { void chrome.runtime.lastError; });
    } catch (e) { /* fail-silent */ }
  }
  function ccDlvKind315(el) {
    try {
      return { tag: String((el && el.tagName) || ""), role: el && el.getAttribute ? el.getAttribute("role") : null, ariaLabel: el && el.getAttribute ? el.getAttribute("aria-label") : null, editable: el && el.getAttribute ? el.getAttribute("contenteditable") : null };
    } catch (e) { return { tag: "", role: null, ariaLabel: null, editable: null }; }
  }
  function ccDlvErr315(step, e, threadRef) {
    ccDlv("dlv_error", { step: String(step || "?"), message: String((e && e.message) || e || "").slice(0, 120) }, threadRef);
  }
  // [CCDLV315-END]

  // ---- OUTBOUND DELIVERY (v2.1.32): the worker claims a queued reply
  // in the database, parks it in the luca_pending_delivery storage
  // slot, and points a Facebook tab at the thread. This script does
  // the typing HERE: CDP insertText (works in background tabs, where
  // execCommand silently no-ops), Enter to send, then VERIFY the
  // message actually appears as our bubble before reporting success.
  // Delivery only ever happens on the thread's own page — never
  // through a floating popup, whose conversation can't be matched to
  // the pending thread with certainty (wrong-person risk).
  var delivering = false;
  function waitMs(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitForValue(fn, timeoutMs, stepMs) {
    var end = Date.now() + timeoutMs;
    while (Date.now() < end) {
      var v = fn();
      if (v) return v;
      await waitMs(stepMs || 400);
    }
    return null;
  }
  function replyCdpRequest(payload) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(
          Object.assign({ type: "AUTOLAUNCH_CDP" }, payload),
          function (resp) {
            void chrome.runtime.lastError;
            resolve(resp && typeof resp === "object" ? resp : { ok: false, error: "cdp_no_response" });
          });
      } catch (e) { ccDlvErr315("cdp_request", e, null); resolve({ ok: false, error: "cdp_send_failed" }); } /*D315R*/
    });
  }
  var replyCdpAttached = false;
  async function replyCdp(action, extra) {
    var res = await replyCdpRequest(Object.assign({ action: action }, extra || {}));
    if (action === "attach" && res && res.ok) replyCdpAttached = true;
    if (action === "detach") replyCdpAttached = false;
    return res;
  }
  function findComposer() {
    var scopes = [document.querySelector('[role="main"]'), document].filter(Boolean);
    for (var i = 0; i < scopes.length; i++) {
      var boxes = scopes[i].querySelectorAll('[role="textbox"]');
      for (var j = 0; j < boxes.length; j++) {
        var lab = (boxes[j].getAttribute("aria-label") || "").toLowerCase();
        if (lab.indexOf("message") !== -1 || lab === "aa") return boxes[j];
      }
      // Fallback (v2.1.36): label wording varies by surface — the
      // thread composer is the LAST visible contenteditable textbox
      // on the page (search boxes above it are plain inputs, never
      // contenteditable).
      var editables = [];
      for (var k = 0; k < boxes.length; k++) {
        if (boxes[k].getAttribute("contenteditable") === "true" && boxes[k].offsetParent !== null) editables.push(boxes[k]);
      }
      if (editables.length) return editables[editables.length - 1];
    }
    return null;
  }
  function normMsg(s) { return String(s || "").trim().replace(/\s+/g, " ").toLowerCase(); }

  function findSendButton(composer) {
    // The composer's Send control (paper-plane arrow) is a real
    // clickable button near the textbox. Walk up from the composer,
    // searching each wider container; "send"-labeled only, and the
    // like button ("Send a like") is deliberately excluded.
    var node = composer;
    for (var depth = 0; depth < 7 && node; depth++) {
      node = node.parentElement;
      if (!node || !node.querySelectorAll) continue;
      var cands = node.querySelectorAll('[role="button"], button');
      for (var i = 0; i < cands.length; i++) {
        var lab = (cands[i].getAttribute("aria-label") || "").trim().toLowerCase();
        if (lab.indexOf("send") === 0 && lab.indexOf("like") === -1) {
          var r = cands[i].getBoundingClientRect();
          if (r.width > 0 && r.height > 0) return cands[i];
        }
      }
    }
    return null;
  }

  // [DLV317-BEGIN] DELIVERY 3.17 (v2.1.117, note 68):
  // two changes ahead of the unchanged 3.15 ladder +
  // 3.16 focus step. (1) VISIBILITY-AWARE COMPOSER:
  // the 3.16 desk trace (the Mustang thread, helper
  // 2.1.116) found the composer as a ZERO-WIDTH,
  // off-viewport ghost — getBoundingClientRect
  // {w: 0, h: 20, x: -26, y: 18} on a long-lived
  // reused tab — so the click rung refused
  // (zero_rect), the DOM rung anchored a selection
  // nobody could type into, and every typing path
  // read back empty. ccAwaitComposer317 validates
  // the found box's rect (width > 40, re-read after
  // a scrollIntoView), rescans for a sane candidate
  // when the first hit is a ghost, and traces
  // dlv_composer with EVERY candidate's rect plus
  // the chosen one. (2) FOCUS EMULATION state:
  // ccEmuFocus317 carries the hasFocus readings that
  // bracket the worker-side focus-emulation enable
  // in deliverPending (a background tab's document
  // never holds OS focus — hasFocus read FALSE for
  // the entire 3.16 run); the [FOCUS316] ladder's
  // dlv_focus record carries both readings plus
  // whether the enable landed.
  var ccEmuFocus317 = { before: null, after: null, emuOk: null, emuError: null };
  function ccHasFocus317() {
    try { return !!(document.hasFocus && document.hasFocus()); } catch (e) { return false; }
  }
  function ccRectOf317(el) {
    try {
      var r = el.getBoundingClientRect();
      return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
    } catch (e) { return null; }
  }
  function ccRectSane317(r) { return !!(r && r.w > 40 && r.h > 0); }
  function ccCandidateRects317() {
    var out = [];
    try {
      var boxes = document.querySelectorAll('[role="textbox"]');
      for (var i = 0; i < boxes.length && out.length < 8; i++) {
        var rr = ccRectOf317(boxes[i]);
        out.push({ label: String((boxes[i].getAttribute && boxes[i].getAttribute("aria-label")) || "").slice(0, 40), rect: rr, sane: ccRectSane317(rr) });
      }
    } catch (e) { /* the trace stays partial */ }
    return out;
  }
  function ccRescanComposer317(exclude) {
    var scopes = [];
    try { var mainEl317 = document.querySelector('[role="main"]'); if (mainEl317) scopes.push(mainEl317); } catch (e) { /* the document scope below still applies */ }
    scopes.push(document);
    var lastEdit = null;
    for (var i = 0; i < scopes.length; i++) {
      var boxes = scopes[i].querySelectorAll('[role="textbox"]');
      for (var j = 0; j < boxes.length; j++) {
        if (boxes[j] === exclude) continue;
        var lab = (boxes[j].getAttribute("aria-label") || "").toLowerCase();
        if ((lab.indexOf("message") !== -1 || lab === "aa") && ccRectSane317(ccRectOf317(boxes[j]))) return boxes[j];
        if (boxes[j].getAttribute("contenteditable") === "true" && boxes[j].offsetParent !== null && ccRectSane317(ccRectOf317(boxes[j]))) lastEdit = boxes[j];
      }
    }
    return lastEdit;
  }
  async function ccAwaitComposer317(threadRef) {
    var deadline = Date.now() + 18000;
    var lastEl = null, lastDetail = null;
    while (true) {
      var el = null;
      try { el = findComposer(); } catch (e) { ccDlvErr315("composer_find", e, threadRef); }
      if (el) {
        lastEl = el;
        var r = ccRectOf317(el);
        if (ccRectSane317(r)) {
          ccDlv("dlv_composer", { found: true, kind: ccDlvKind315(el), candidates: ccCandidateRects317(), chosenRect: r, rectSane: true, rescanned: false, scrolled: false }, threadRef);
          return el;
        }
        var scrolled = false;
        try { if (el.scrollIntoView) { el.scrollIntoView({ block: "center" }); scrolled = true; } } catch (e) { ccDlvErr315("composer_scroll", e, threadRef); }
        if (scrolled) { await waitMs(250); r = ccRectOf317(el); }
        if (ccRectSane317(r)) {
          ccDlv("dlv_composer", { found: true, kind: ccDlvKind315(el), candidates: ccCandidateRects317(), chosenRect: r, rectSane: true, rescanned: false, scrolled: true }, threadRef);
          return el;
        }
        var alt = null;
        try { alt = ccRescanComposer317(el); } catch (e) { ccDlvErr315("composer_rescan", e, threadRef); }
        if (alt) {
          ccDlv("dlv_composer", { found: true, kind: ccDlvKind315(alt), candidates: ccCandidateRects317(), chosenRect: ccRectOf317(alt), rectSane: true, rescanned: true, scrolled: scrolled }, threadRef);
          return alt;
        }
        lastDetail = { found: true, kind: ccDlvKind315(el), candidates: ccCandidateRects317(), chosenRect: r, rectSane: false, rescanned: false, scrolled: scrolled };
      }
      if (Date.now() >= deadline) break;
      await waitMs(600);
    }
    if (lastEl) { ccDlv("dlv_composer", lastDetail, threadRef); return lastEl; }
    ccDlv("dlv_composer", { found: false, candidates: ccCandidateRects317() }, threadRef);
    return null;
  }
  // [DLV317-END]

  // [FOCUS316-BEGIN] FOCUS STEP (v2.1.116, note 67):
  // the 3.15 desk proof (2026-11-14, the Mustang
  // group thread, helper 2.1.115) cleared the honesty
  // half — no commit, no submit, the row settled
  // failed — and then showed all three typing paths
  // reporting ok into a composer that read back
  // EMPTY (the row settled text_not_committed): the
  // text never landed. The 3.15 path LOCATED the
  // composer but never gave it keyboard focus: its
  // only focus gestures were a best-effort DOM
  // focus()/click() pair, and CDP Input events
  // dispatch at the CURRENT selection — which was
  // never inside the box. The proven note-53
  // price-edit path clicks into the field with a CDP
  // trusted mouse FIRST, and it commits on
  // Facebook's editor. 3.16 adds that step to
  // delivery, ahead of the unchanged 3.15 ladder:
  // rung 1 is a CDP trusted mouse press+release at
  // the composer's center (the worker's existing
  // "click" action — CDP input works on background
  // tabs, and the user's tab is NEVER activated);
  // rung 2, only if the click did not focus it, is
  // DOM: element.focus() + caret placement at the
  // end of the composer. Focus is VERIFIED after
  // each rung (document focus + whether the active
  // element / the selection anchor sits inside the
  // composer) and the whole step is traced as
  // dlv_focus (the rect used, every state reading).
  // Still unfocused after both rungs -> the
  // delivery fails loud as focus_not_achieved
  // BEFORE any typing: no submit of any kind.
  function ccFocusState316(el) {
    var st = { hasFocus: false, activeInside: false, anchorInside: false };
    try { st.hasFocus = !!(document.hasFocus && document.hasFocus()); } catch (e) { /* state stays false */ }
    try {
      var ae = document.activeElement;
      st.activeInside = !!(el && ae && (ae === el || (el.contains && el.contains(ae))));
    } catch (e) { /* same */ }
    try {
      var sel = window.getSelection ? window.getSelection() : null;
      if (sel && sel.anchorNode && el && el.contains) st.anchorInside = !!el.contains(sel.anchorNode);
    } catch (e) { /* same */ }
    return st;
  }
  async function ccFocusComposer316(composer, attachedOk, threadRef) {
    var rec = { rect: null, before: ccFocusState316(composer), click: null, afterClick: null, dom: null, afterDom: null, focused: false, hasFocusBeforeEmulation: ccEmuFocus317.before, hasFocusAfterEmulation: ccEmuFocus317.after, emuFocusEnabled: ccEmuFocus317.emuOk };
    var isFocused = function (st) { return !!(st && (st.activeInside || st.anchorInside)); };
    if (isFocused(rec.before)) { rec.focused = true; ccDlv("dlv_focus", rec, threadRef); return rec; }
    if (attachedOk) {
      try { if (composer.scrollIntoView) composer.scrollIntoView({ block: "center" }); } catch (e) { ccDlvErr315("focus_scroll", e, threadRef); }
      await waitMs(150);
      var r = null;
      try { r = composer.getBoundingClientRect(); } catch (e) { ccDlvErr315("focus_rect", e, threadRef); }
      if (r) rec.rect = { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
      if (rec.rect && rec.rect.w > 0 && rec.rect.h > 0) {
        var clk = await replyCdp("click", { x: rec.rect.x, y: rec.rect.y });
        rec.click = { ok: !!(clk && clk.ok), error: (clk && clk.error) || null };
        await waitMs(250);
        rec.afterClick = ccFocusState316(composer);
      } else {
        rec.click = { ok: false, error: "zero_rect" };
      }
    } else {
      rec.click = { ok: false, error: "cdp_not_attached" };
    }
    if (!isFocused(rec.afterClick)) {
      var domOk = true;
      try { composer.focus(); } catch (e) { domOk = false; ccDlvErr315("focus_dom", e, threadRef); }
      try {
        var sel2 = window.getSelection ? window.getSelection() : null;
        if (sel2 && document.createRange) {
          var rg = document.createRange();
          rg.selectNodeContents(composer);
          rg.collapse(false);
          sel2.removeAllRanges();
          sel2.addRange(rg);
        }
      } catch (e) { ccDlvErr315("focus_caret", e, threadRef); }
      rec.dom = { tried: true, ok: domOk };
      await waitMs(150);
      rec.afterDom = ccFocusState316(composer);
    }
    var endState = rec.afterDom || rec.afterClick || rec.before;
    rec.focused = isFocused(endState);
    ccDlv("dlv_focus", rec, threadRef);
    return rec;
  }
  // [FOCUS316-END]

  // [DLVFIX315-BEGIN] DELIVERY FIX (v2.1.115, note 66):
  // the typeViaKeys315 helper + the deliverPending below
  // replace the 3.13 body wholesale. (1) COMMIT GATE:
  // each typing path — CDP Input.insertText, then the
  // execCommand fallback, then (NEW) CDP trusted
  // per-character key dispatch — is followed by a
  // composer RE-READ, and only a path whose body is
  // SEEN in the box counts as committed (the
  // rule-(a)-shaped compare). No path commits -> NO
  // submit; the delivery fails loud as
  // text_not_committed and the row settles failed,
  // never "sent". (2) VERIFY: rule (b) is DELETED —
  // "sent" requires the thread re-read to find the
  // OUT bubble inside the existing 12 s / 600 ms
  // window; an empty composer is not evidence.
  async function typeViaKeys315(body) {
    // CDP trusted per-character key dispatch (the
    // note-63 price-edit input family): keyDown/keyUp
    // per char with the char carried as `text`, which
    // editors that read characters from the key event
    // accept. A newline is typed as a space — an
    // Enter here would submit mid-body.
    for (var i = 0; i < body.length; i++) {
      var ch = body.charAt(i);
      var key = ch, code = "";
      if (ch === "\n" || ch === "\r") { key = " "; code = "Space"; ch = " "; }
      else if (/[a-zA-Z]/.test(ch)) code = "Key" + ch.toUpperCase();
      else if (/[0-9]/.test(ch)) code = "Digit" + ch;
      else if (ch === " ") code = "Space";
      var r = await replyCdp("key", code ? { key: key, code: code, text: ch } : { key: key, text: ch });
      if (!r || !r.ok) return false;
    }
    return true;
  }
  async function deliverPending(p) {
    var result = { ok: false, error: null };
    ccDlvAttempt315 = 0;
    try {
      // [DLV317-INNER-BEGIN] (v2.1.117, note 68):
      // visibility-aware composer acquisition — the
      // picker in the [DLV317] span validates the
      // found box's rect (the 3.16 desk run typed
      // into a zero-width ghost), scrolls + rescans
      // for a sane candidate, and traces dlv_composer
      // itself with every candidate's rect.
      var composer = await ccAwaitComposer317(p.threadRef);
      if (!composer) { result.error = "composer_not_found"; return result; }
      // [DLV317-INNER-END]
      var attached = await replyCdp("attach");
      var attachedOk = !!(attached && attached.ok);
      // [EMU317-INNER-BEGIN] (v2.1.117, note 68):
      // focus emulation ON — right after attach,
      // before any typing — via the worker's
      // "emuFocus" CDP action
      // (Emulation.setFocusEmulationEnabled). A
      // background tab's document never holds OS
      // focus (the 3.16 trace read hasFocus FALSE
      // for the whole run) and the editor treats
      // input into an unfocused document as noise.
      // The two readings bracket the enable so
      // dlv_focus can prove the flip; the settle
      // finally below disables emulation again
      // before detach, so the override never leaks
      // into other jobs on this tab.
      ccEmuFocus317.before = ccHasFocus317();
      if (attachedOk) {
        var emu317 = await replyCdp("emuFocus", { enabled: true });
        ccEmuFocus317.emuOk = !!(emu317 && emu317.ok);
        ccEmuFocus317.emuError = (emu317 && emu317.error) || null;
        if (!ccEmuFocus317.emuOk) ccDlvErr315("emu_focus_on", new Error(ccEmuFocus317.emuError || "emu_failed"), p.threadRef);
        await waitMs(150);
      }
      ccEmuFocus317.after = ccHasFocus317();
      // [EMU317-INNER-END]
      // [FOCUS316-INNER-BEGIN] (v2.1.116, note 67):
      // focus BEFORE any typing — the focus ladder
      // in ccFocusComposer316 (CDP trusted click,
      // then the DOM focus+caret rung), traced as
      // dlv_focus. Unfocused after both rungs ->
      // fail loud here; the typing ladder below
      // never runs and nothing is submitted.
      var focus316 = await ccFocusComposer316(composer, attachedOk, p.threadRef);
      if (!focus316 || !focus316.focused) { result.error = "focus_not_achieved"; return result; }
      // [FOCUS316-INNER-END]
      // ---- COMMIT GATE (note 66): a typing path only
      // counts when the composer RE-READ shows the body
      // in the box (same compare shape as verify rule
      // (a): exact, or starting with the body's first
      // 60 normalized chars).
      var want = normMsg(p.body);
      var gateHit = function () {
        var ct = normMsg(textOf(composer));
        return ct === want || ct.indexOf(want.slice(0, 60)) === 0;
      };
      var attempts = [];
      var committed = false;
      var committedBy = null;
      if (attachedOk) {
        var ins = await replyCdp("insertText", { text: p.body });
        await waitMs(400);
        var hit1 = gateHit();
        attempts.push({ path: "cdp_insertText", ok: !!(ins && ins.ok), committed: hit1, textAfter: textOf(composer).slice(0, 120) });
        if (hit1) { committed = true; committedBy = "cdp_insertText"; }
      } else {
        attempts.push({ path: "cdp_insertText", ok: false, skipped: "cdp_not_attached", committed: false, textAfter: textOf(composer).slice(0, 120) });
      }
      if (!committed) {
        var ecOk = false;
        try { ecOk = document.execCommand("insertText", false, p.body); } catch (e) { ccDlvErr315("exec_command", e, p.threadRef); /* ladder continues */ }
        await waitMs(400);
        var hit2 = gateHit();
        attempts.push({ path: "execCommand", ok: !!ecOk, committed: hit2, textAfter: textOf(composer).slice(0, 120) });
        if (hit2) { committed = true; committedBy = "execCommand"; }
      }
      if (!committed && attachedOk) {
        var keyOk = await typeViaKeys315(String(p.body || ""));
        await waitMs(400);
        var hit3 = gateHit();
        attempts.push({ path: "cdp_key_chars", ok: !!keyOk, committed: hit3, textAfter: textOf(composer).slice(0, 120) });
        if (hit3) { committed = true; committedBy = "cdp_key_chars"; }
      }
      ccDlv("dlv_type", { attempts: attempts, committed: committed, committedBy: committedBy }, p.threadRef);
      if (!committed) { result.error = "text_not_committed"; return result; }
      // ---- SUBMIT: only ever reached with the body
      // SEEN sitting in the composer.
      if (attachedOk) {
        await replyCdp("key", { key: "Enter", code: "Enter" });
        ccDlv("dlv_submit", { method: "cdp_key_enter", targetKind: "composer" }, p.threadRef);
      } else {
        var evInit = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
        composer.dispatchEvent(new KeyboardEvent("keydown", evInit));
        composer.dispatchEvent(new KeyboardEvent("keypress", evInit));
        composer.dispatchEvent(new KeyboardEvent("keyup", evInit));
        ccDlv("dlv_submit", { method: "synthetic_key_events", targetKind: "composer" }, p.threadRef);
      }
      await waitMs(700);
      // Send-button fallback (v2.1.41, kept): when the
      // text is still sitting in the box, the Enter
      // didn't take — click the composer's own Send
      // control (a real button near the textbox).
      if (gateHit()) {
        var sendBtn = findSendButton(composer);
        if (sendBtn) { ccDlvBtnLabel315 = (sendBtn.getAttribute && sendBtn.getAttribute("aria-label")) || "send_button"; try { sendBtn.click(); } catch (e) { ccDlvErr315("send_button_click", e, p.threadRef); /* the verify below decides */ } }
      }
      if (ccDlvBtnLabel315) { ccDlv("dlv_submit", { method: "send_button_click", targetKind: ccDlvBtnLabel315 }, p.threadRef); ccDlvBtnLabel315 = null; }
      // ---- VERIFY (note 66): rule (a) ONLY. The
      // thread re-read must find our OUT bubble
      // matching the body; the composer-emptied rung
      // is deleted — an empty composer proves nothing.
      var hit = await waitForValue(function () {
        var msgs = findMessages();
        var inThread = msgs.some(function (m) {
          return m.direction === "out" && (normMsg(m.body) === want || normMsg(m.body).indexOf(want.slice(0, 60)) === 0);
        });
        try {
          ccDlvAttempt315 += 1;
          ccDlv("dlv_verify", { attempt: ccDlvAttempt315, composerText: textOf(composer).slice(0, 120), threadHasBody: inThread, tailBubbles: msgs.slice(-3).map(function (mm) { return { dir: mm.direction, text: String(mm.body || "").slice(0, 80) }; }) }, p.threadRef);
        } catch (e) { /* fail-silent */ }
        if (inThread) return true;
        return null;
      }, 12000, 600);
      result.ok = !!hit;
      if (!hit) result.error = "not_verified_in_thread" + (attachedOk ? "" : "_nocdp");
      return result;
    } finally {
      if (replyCdpAttached) {
        // [EMU317-SETTLE-BEGIN] (v2.1.117, note 68):
        // emulation OFF before detach — never leak
        // the focus override into other jobs on
        // this tab.
        try { await replyCdp("emuFocus", { enabled: false }); } catch (e) { ccDlvErr315("emu_focus_off", e, p.threadRef); /* best effort */ }
        // [EMU317-SETTLE-END]
        try { await replyCdp("detach"); } catch (e) { ccDlvErr315("cdp_detach", e, p.threadRef); /* session hygiene best effort */ }
      }
    }
  }
  // [DLVFIX315-END]

  async function maybeDeliverPending() {
    if (delivering) return;
    var store = await chrome.storage.local.get(["luca_pending_delivery", "luca_delivery_claim"]);
    var p = store && store.luca_pending_delivery;
    if (!p || !p.messageId || !p.threadRef) return;
    if (threadKeyOf(window.location.href) !== threadKeyOf(p.threadRef)) return;
    // Cross-tab claim: another Facebook tab on the same thread must
    // not deliver twice. Storage claims aren't atomic, but a 30s
    // claim window makes a double-send a genuine rarity.
    var claim = store.luca_delivery_claim;
    if (claim && claim.messageId === p.messageId && Date.now() - (claim.at || 0) < 30000) return;
    await chrome.storage.local.set({ luca_delivery_claim: { messageId: p.messageId, at: Date.now() } });
    delivering = true;
    try {
      var res = await deliverPending(p);
      chrome.runtime.sendMessage(
        { type: "AUTOLAUNCH_REPLY_RESULT", messageId: p.messageId, ok: res.ok, error: res.error || null },
        function () { void chrome.runtime.lastError; });
    } catch (e) {
      ccDlvErr315("maybe_deliver", e, p.threadRef); /*D315*/
      try {
        chrome.runtime.sendMessage(
          { type: "AUTOLAUNCH_REPLY_RESULT", messageId: p.messageId, ok: false, error: "exception" },
          function () { void chrome.runtime.lastError; });
      } catch (e2) { /* worker will time the pending slot out */ }
    } finally {
      delivering = false;
    }
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.type === "AUTOLAUNCH_DELIVER_NOW") {
      // ACK first (v2.1.35): the worker treats no-ACK as a dead
      // script and reloads the tab, so answering is what proves this
      // script is alive. Delivery itself proceeds async.
      try { sendResponse({ accepted: true }); } catch (e) { /* channel quirks are non-fatal */ }
      maybeDeliverPending();
      return;
    }
    if (msg && msg.type === "AUTOLAUNCH_SYNC_NOW") {
      // App-driven sync (v2.1.38): run a pass and answer only when
      // the worker has confirmed the database writes, so the app can
      // repaint with the new messages already in place.
      autoPassSync().then(function () {
        try { sendResponse({ ok: true }); } catch (e) { /* page moved on */ }
      });
      return true;
    }
  });
  setTimeout(maybeDeliverPending, 2500);
  setInterval(maybeDeliverPending, 20000);
})();
