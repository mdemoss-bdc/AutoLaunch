importScripts("dws_sync.js");

// AutoLaunch Vehicle Assistant — background service worker (v2)
//
// Phase 2 changes vs the original:
//  1. HANDSHAKE: the user id now arrives from bridge.js, a content script
//     on the AutoLaunch origin that forwards the app's
//     AUTOLAUNCH_EXT_LOGIN window message. (The old code waited for
//     onMessageExternal "SET_USER_ID", which the app never sent and could
//     not send — a web page cannot message an extension it cannot name.)
//     The external listener is kept as a secondary path.
//  2. POLLING: chrome.alarms instead of setInterval. MV3 service workers
//     are killed when idle, which silently killed the 20s interval.
//  3. STATUS VOCABULARY: one vocabulary everywhere, matching the web UI —
//     pending -> processing -> posted / failed. The old code wrote
//     "completed", which the UI does not know.
//  4. CLAIMING: a queue row is claimed with a conditional PATCH
//     (status must still be pending) so two polls can never take the
//     same car twice.
//  5. DAILY LIMIT: before claiming, count today's posts from
//     scraped_inventory.marketplace_posted_at against the user's saved
//     daily_post_limit (user_settings). At the cap, nothing is claimed.
//  6. POSTED MEANS POSTED: this worker never marks a row posted. Only the
//     content script can do that, and only after it has detected a real
//     publish success on Facebook. Unconfirmed = failed, with a reason.
//  7. SESSION TOKEN: the queue / settings / inventory tables are
//     RLS-locked to the `authenticated` role with auth.uid() owner
//     policies, so the publishable key alone can see and claim NOTHING.
//     The app now sends the signed-in user's Supabase access token
//     through the bridge with the user id; the worker stores it in
//     chrome.storage.local and sends it as Authorization: Bearer on
//     every REST call. A 401/403 marks the session expired and stops
//     claiming until a NEW token arrives — no retry hammering. The
//     token is never logged and never written into any error record.
//  8. PHOTO RELAY: the content script runs on facebook.com, so its direct
//     fetch of a dealer photo URL is page-CORS-bound — and dealer photo
//     servers (mosescars.com proven) send no Access-Control-Allow-Origin,
//     so the fetch dies and the job fails with photo_download_failed.
//     Fetches from this worker are extension fetches: with host
//     permission for the origin they are NOT page-CORS-bound. The
//     content script now asks the worker for the bytes
//     (AUTOLAUNCH_FETCH_PHOTO) and rebuilds the File itself; its
//     fallback is the photo-proxy Edge Function, and only if both fail
//     does the job fail honestly — a photoless car is never posted.
//  9. CDP TRUSTED INPUT (filler v3): Year/Make/Model/Price resisted two
//     generations of DOM fills — Facebook commits those fields only
//     through its suggestion-listbox selection / trusted input pipeline,
//     and React resets values set any other way. The content script's
//     last-resort rung now asks this worker to drive REAL input through
//     the DevTools protocol (AUTOLAUNCH_CDP: attach / click /
//     insertText / key / detach via chrome.debugger on the Facebook
//     tab). While attached Chrome shows a "…is debugging this browser"
//     infobar; it disappears on detach, which happens when the fill
//     sequence ends or the job finishes/fails. An attach failure (e.g.
//     the user has DevTools open on the tab) is a structured error, and
//     the content script's verify-or-report still decides the outcome.
//     Field diagnostics (AUTOLAUNCH_FIELD_DIAG) ride the same path into
//     autolaunch_failure_log when a field defeats every rung.
// 10. DIAG-TO-DB (v3.1, fourth live test): run 4's installed build WAS
//     2.1.0 (card verified) and both attempts failed honestly with
//     fields_unfilled:Year,Make,Model,Price — but the field_diag
//     forensics NEVER appeared in autolaunch_failure_log: Matthew pulled
//     exactly two bare {at, queueId, reason} entries. The separate
//     diag-message → storage path could not be trusted, so the records
//     now ride the AUTOLAUNCH_JOB_FAILED message itself, and this
//     worker compacts them into the queue row's error_message column
//     in the same PATCH that marks the row failed (outerHTML ≤160
//     chars per field, whole string ≤3500) — the evidence lives in the
//     database, readable with a plain SELECT, no console archaeology.
//     If the error_message write is rejected, the row still ends
//     failed via a status-only PATCH. logFailure's storage writes are
//     also serialized through a promise chain now: the old
//     get-modify-write cycles from near-simultaneous callers (four
//     field diags + the job failure) could overwrite each other. And a
//     CDP attach refused with "Another debugger is already attached"
//     is retried ONCE after 3s before the reason is recorded — a
//     transient DevTools attach shouldn't cost the rung.
// 11. FORM MAP RIDES ALONG (v3.2, fifth live test): run 5's
//     error_message stayed NULL under a working diag-to-DB — the
//     content script's jobDiags was empty because the four fields
//     were never LOCATED, so the ladder (and its diagnostics) never
//     ran for them. Location is fixed content-side (container label
//     text); here, compactDiagError now also preserves each record's
//     `note` and the one-per-job `formMap` entry (the failing step's
//     visible controls with their computed container labels), and
//     the cap rises to 6000 chars — formMap entries are shed first,
//     so the field records always survive.
// 12. STEP NOTES RIDE ALONG (v2.1.3, filler v3.3): the first
//     successful post still needed Matthew's hands for the step-2
//     color dropdowns and the clean-title box — best-effort fields
//     whose misses were silent. The content script now records a
//     non-fatal "step note" for each step-2 outcome (color requested
//     -> option chosen -> read-back; clean-title click path) on the
//     same diagnostic channels. Here, compactDiagError also
//     preserves each record's `detail` string (shed with readBack
//     under cap pressure), and the FIELD_DIAG handler stores `note`
//     + `detail` in autolaunch_failure_log alongside the forensics.
// 13. FULL AUTO + DELETE JOBS (v2.1.4): the claim loop now serves
//     the queue's `action` column. (a) FULL AUTO: user_settings is
//     fetched once per cycle (daily_post_limit + the new
//     full_auto_enabled); the flag rides the job payload
//     (current_posting_job.fullAuto) so the content script can turn
//     confirm mode off and click Publish itself. (b) DELETE JOBS
//     (action='delete', target_channel='facebook', queued by the
//     app's "Remove from Facebook"): claimed under the same
//     conditional-claim + session-token rules, but the daily POST
//     limit never blocks them (the limit counts posts, not
//     removals), the no-photo rule does not apply (a car whose
//     photos vanished is exactly the car you remove), and the tab
//     opened is the selling page, not the create form. A delete
//     whose inventory row is gone is still claimed — the payload
//     falls back to the queue row's own stamped year/make/model and
//     price (producers stamp all four at insert; the contract is
//     producer-agnostic, since an inventory-lifecycle auto-removal
//     rule will create these rows when a car leaves inventory).
//     Only a row stamped without a price leaves the strict matcher
//     nothing to match — and then it refuses (listing_not_found)
//     rather than guessing. Completion is a
//     third finish path (AUTOLAUNCH_JOB_DELETED ->
//     finishJobDeleted): the queue row ends "completed" (the table
//     has no status check constraint; the app's queue view renders
//     it) with executed_at set, and the car's
//     marketplace_posted_at is cleared — the same column the app
//     derives "Posted" from, so the car truthfully returns to
//     unposted. A mid-finish token death stashes outcome "deleted"
//     alongside "posted"/"failed". Delete failures compact their
//     diagnostics into error_message too, not just fields_unfilled
//     ones — the delete step notes are the evidence there.
// 14. VERIFY FAILURES + TAB AUTO-CLOSE (v2.1.7): (a) a post that
//     ends publish_unverified (the content script clicked Publish,
//     then could not find the listing on the Selling page after
//     repeated strict-match scans) compacts its diagnostics into
//     error_message too — the records are the verify scans, the
//     evidence the listing truly was not there. (b) TAB AUTO-CLOSE:
//     every job used to leave its Facebook tab behind, and they
//     piled up across a testing session. The claim now records the
//     opened tab's id on the job (current_posting_job.tabId), and
//     the two SUCCESS finishes (posted, deleted — including a
//     delete that finished goal-achieved) schedule that tab's
//     closure ~4s later, once the success banner has been readable.
//     Failures NEVER close — the tab is the user's evidence — and
//     neither does a token-stash replay (flushPendingFinish calls
//     the apply* writes directly; by replay time the moment has
//     passed). Only the exact tab this worker opened is ever
//     closed; a tab the user already closed is a no-op.
// 15. JOB-SLOT RECONCILIATION (v2.1.8): the current_posting_job
//     slot used to be cleared ONLY by a finish message from the
//     job's own content script. Stop a run any other way — cancel
//     the queue row in the app, close the job's tab — and the
//     finish never arrives: the slot stays occupied forever and
//     every claim cycle silently returns at `if (activeJob)`, with
//     a healthy awake worker, a valid token, and a pending row
//     nobody will ever claim. Proven live 2026-10-22 ~19:46 EDT:
//     storage held a job claimed at 23:14:48Z whose queue row the
//     user had deleted; a fresh pending row sat unclaimed 15+
//     minutes. claimedAt was written at claim time but never read.
//     checkQueue now reconciles the slot against its queue row
//     before honouring it (one lightweight read, only when a slot
//     is occupied): row gone, terminal (posted/failed/completed),
//     or pending again -> the run it belonged to is dead; clear
//     the slot and fall through to claim fresh work in the SAME
//     pass. Row still "processing" -> the slot is kept, UNLESS
//     claimedAt is older than 45 minutes — past every legitimate
//     run (the 10-minute confirm watch + the ~4-minute
//     verification cap, with generous margin) — in which case the
//     content script is certainly dead, so the row is failed
//     honestly as job_orphaned (diagnostics compacted into
//     error_message, token-death stash behaviour as in the other
//     finishes), the slot cleared, and the cycle continues. A
//     lookup that itself errors (network/auth) changes NOTHING:
//     the slot is kept and the cycle skips, so a transient failure
//     can never free a live job's slot or fail its row; auth
//     errors keep the session-expired semantics sbFetch already
//     records. Every reconciliation action is logged — the old
//     failure was invisible precisely because the skip was silent.
// 16. DELETE CLICK LADDER — CDP MOUSE SEQUENCE (v2.1.9): the
//     delete flow's menu-opening ladder gains a third rung above
//     the instantaneous press+release "click": action "clickSeq"
//     dispatches Input.dispatchMouseEvent mouseMoved, then
//     mousePressed, a brief pause, then mouseReleased at the
//     content-supplied coordinates — the hover/press timing some
//     Facebook menus arm on. Same contract as every CDP action:
//     {ok:true} / {ok:false, error}, and the cdp_not_attached
//     guard applies unchanged. Purely additive: claim logic, the
//     finish paths and every other action are untouched, and the
//     delete stage notes the content script records ride the
//     existing FIELD_DIAG / diag-compaction channels — no worker
//     change was needed for them (delete failures already compact
//     diagnostics into error_message, note 13).
// 17. SETUP-PAGE PING (v2.1.10): the app's Chrome Extension page asks,
//     through bridge.js, whether this worker is present and ready.
//     {type:"AUTOLAUNCH_PING"} is answered {hasToken} — true exactly
//     when a session token is currently stored under
//     autolaunch_access_token in chrome.storage.local (the key the
//     login handoff writes; read via storedAccessToken()). The token
//     value itself is never returned, logged, or otherwise exposed —
//     only the boolean. Purely additive: no claim, finish, CDP, photo
//     or diag behaviour changes.
// 18. BACKGROUND JOB TABS (v2.1.12, Matthew's request): navigating the
//     helper's Facebook tab away mid-fill destroys that attempt's page
//     and everything typed into it. Fully automated work therefore no
//     longer steals the user's place: Full Auto posts and all delete
//     jobs open with active:false, so the user can keep working in
//     their current tab while the helper works in its own background
//     tab, and the job tab is marked autoDiscardable:false so Chrome's
//     memory saver cannot discard it mid-run. Confirm-mode posts were
//     the deliberate exception in 2.1.12 (they opened in front because
//     the user personally has to click Publish there) — Matthew
//     overruled that on 2026-10-23 after his son's cross-account
//     test, so v2.1.13 opens EVERY job tab in the background; a
//     confirm-mode form waits, filled and bannered, until the user
//     clicks over to review and publish.
// 19. POST PACING + DEALER BLOCK (v2.1.42): two settings that live in
//     user_settings — and are promised by the app's UI copy — but
//     that no code ever read. (a) PACING: the claim cycle runs on a
//     1-minute alarm and used to claim the next POST the moment the
//     previous job's slot cleared, so a queued batch drained
//     back-to-back (proven live 2026-10-26: a post completed at
//     09:31 EDT and the next car was processing by 09:33, despite
//     post_delay_minutes = 15). userSettings now also reads
//     post_delay_minutes, and checkQueue refuses to claim a POST
//     until that many minutes have passed since the newest
//     scraped_inventory.marketplace_posted_at stamp — the stamp
//     applyPosted writes at completion, so the gap anchors on the
//     COMPLETED post, survives worker restarts, and needs no new
//     state. Deletes are NOT paced (a removal is not a post, the
//     same exemption the daily limit uses). An absent/zero delay
//     means no gate, and a failed last-post lookup fails OPEN (no
//     hold) — a flaky read must never wedge the queue. (b) DEALER
//     BLOCK: userSettings also reads dealership_name /
//     dealership_address, carried on the job payload like fullAuto,
//     so the content script can close the Marketplace description
//     with the dealership's name and address (Matthew's request,
//     2026-10-26). Either may be empty; the description appends
//     whatever exists and never blocks on a missing identity.
// 20. STOCK NUMBER IN DESCRIPTION (v2.1.43): the app's Posting
//     preferences have always saved an include_stock checkbox to
//     user_settings, but no code ever read it — the switch changed
//     nothing. userSettings now also reads include_stock and it
//     rides the job payload like the dealership identity, so the
//     content script can put a "Stock #:" line under the VIN in the
//     Marketplace description (Matthew's request, 2026-10-26).
//     Fail-open both ways: the preference off, or a car with no
//     stock number, leaves the description exactly as it was.
// 21. STOCK FALLBACK FROM INVENTORY (v2.1.44): 2.1.43 read the
//     stock number off the QUEUE row (stock_num) — but the app's
//     single-car enqueue never stamped it, so a hand-queued car's
//     queue row carried NULL and its listing shipped with no
//     Stock # line even though scraped_inventory knew the number
//     (proven live 2026-10-26: the Yukon VT60164B posted with the
//     dealership block but no stock line). The claim path already
//     holds the inventory row it fetched by VIN: jobCarWithStock
//     now stamps the payload car's stock_num from the queue row
//     first, then the inventory row's stock_number, so the content
//     script always sees the best-known value. Fail-open: no
//     stock anywhere still means no line, exactly as before.
// 22. AUTO-CREATE GATE (v2.1.46): the old Marketplace-only auto rule
//     keyed creation on the mere PRESENCE of a listing label — and
//     labels leak: a plain 1:1 Messenger chat about tires scraped
//     one, and a thread whose counterparty is the rep himself (a
//     Marketplace system/self thread) matched his own car's label.
//     On 2026-10-26 both became junk prospects on Matthew's account
//     the moment the app synced. Creation now runs through
//     autoCreateGate: a resolved participant name is mandatory (an
//     unresolved name NEVER auto-creates), a counterparty resolving
//     to the rep himself never creates, and at least one positive
//     seller-side signal must fire — the Marketplace inbox surface,
//     the seller's own thread controls ("View buyer"), or a label
//     matching one of the user's own posted cars. Snippet sync and
//     updates to known prospects are untouched: the gate decides
//     CREATION only, and it fails closed.
// 23. SELF BY IDENTITY + CAPTURE REASONS (v2.1.47): note 22's self
//     test matched the counterparty's NAME against the rep's —
//     but Matthew tests Marketplace chats from a second Facebook
//     account under the same display name ("Matthew DeMoss"), so
//     the name test blocked his own alt-account buyer threads, and
//     would block any real buyer who shares his name. The gate now
//     blocks as self ONLY on a proven Facebook-identity match: the
//     capture carries canonical identity tokens (buyerFbId /
//     selfFbId, scraped from profile links and the c_user cookie),
//     and a name match alone is no signal at all. Same release:
//     manual Capture stopped failing silently — the worker returns
//     a short error code (not_signed_in / no_buyer / save_failed)
//     and the button names the cause ("reload this Facebook tab"
//     for an orphaned script after a helper update, the bare
//     "Capture failed" case Matthew hit on 2026-10-26), and a
//     manual capture with no matched prospect and no resolvable
//     participant declines as no_buyer instead of filing a
//     nameless "Marketplace buyer" card.
// 24. SYNC REPAIR (v2.50): three fixes from Matthew's live
//     session, 2026-10-27. (a) CHROME NAMES: a half-rendered
//     thread paints the generic participant placeholder
//     "Facebook user" (plus "Compose" / "Conversation with
//     Facebook user" furniture); those strings were saved as
//     messages and even filed as a prospect NAME. chat_capture.js
//     now filters them everywhere, and autoCreateGate below
//     treats them as an unresolved name. (b) RENDER-SKIP RETRY:
//     gate skips for render-dependent reasons (unresolved_name /
//     no_seller_signal) are no longer final — chat_capture.js
//     tracks the worker's skip response per thread and re-sends
//     on later passes, bounded per page session. (c) TOMBSTONES:
//     deleting a prospect used to be undone by the next
//     auto-sync pass — the Facebook thread still exists, so
//     find-or-create simply re-created the card. A trigger now
//     records every deleted prospect's thread key in
//     prospect_tombstones; the auto path below checks it before
//     creating (skip reason deleted_by_user — terminal, never
//     retried) and a MANUAL Capture of the same thread removes
//     the tombstone (explicit undelete).
// 25. CAPTURE HYGIENE (v2.51): four fixes from Matthew's live
//     group thread, 2026-10-27. (a) GROUP CHROME: Marketplace
//     threads are group chats — Facebook's own narration ("…
//     named the group …", "… changed the group photo."), the
//     buyer card (participant's full name, ratings lines), the
//     listing label line and bare sender captions were all
//     stored as buyer messages; chat_capture.js now patterns
//     the whole family, not just yesterday's strings. (b)
//     DIRECTION: the scrape placed bubbles by center-vs-pane-
//     midpoint, but the pane spans nav + thread + info rail, so
//     a long rep bubble's center fell on the "buyer" side — the
//     rep's own delivered reply was re-filed as the buyer's.
//     The scrape now classifies by edge-hugging against the
//     bubble column itself and skips what it cannot place; and
//     handleCaptureChat refuses a long body already stored
//     under the OPPOSITE direction (same text, other side = the
//     same message mis-read; short echoes like "Yes" exempt —
//     both sides really say those). (c) TRANSIENT STATES:
//     "Sending" / "Delivered" / "Seen" / "Edited" / "You sent"
//     are delivery furniture, never message bodies, on every
//     storage path. (d) AUTO-PASS SILENCE: the content script
//     marked a thread's content hash before the worker
//     answered, so an errored pass (e.g. not_signed_in during a
//     session handover) silenced that thread until its text
//     changed; the hash now survives only a confirmed outcome.
// 26. OUTCOME TRUTH (v2.52 — the 2026-10-28 Passport incident;
//     content.js header note 26 carries the scan side): the
//     worker half of the same repairs. (a) CLAIM-TIME STAMP
//     CHECK: a POST row whose inventory record already carries
//     marketplace_posted_at is completed as posted at claim —
//     no tab, no second post; the existing stamp is the truth
//     and is left untouched, and the row's executed_at
//     fingerprints the path (applyPosted rows carry none).
//     (b) ORPHAN RECOVERY: a stale (>45 min) processing POST
//     row is no longer failed blind — the worker first arms
//     the stored job for Selling-page verification
//     (verifyPublished with orphanRecovery) and opens a
//     Selling tab to run the status-aware scan; the scan's
//     ordinary finish settles the row (live → posted, shells
//     → duplicate_rejected, nothing → job_orphaned). Only
//     when the scan cannot start, or produces no verdict
//     within 6 minutes, does the old blind fail land — with
//     the recovery outcome named in its diagnostics. Delete
//     rows keep the blind fail exactly as before. (c)
//     finishJobFailed now compacts diagnostics for
//     duplicate_rejected and job_orphaned too, so the scan
//     evidence rides error_message like every other honest
//     failure.

// 27. INTRO VIDEO ON MARKETPLACE (v2.1.53 — Intro Video Phase 4;
//     content.js header note 27 carries the composer side): the
//     composer test on Matthew's account (2026-10-28) proved the
//     vehicle composer takes ONE video (60 seconds max) through
//     a dedicated control alongside the photos, so Marketplace
//     is IN. userSettings now also reads intro_video_enabled /
//     intro_video_mode / intro_selected_video_id, and checkQueue
//     resolves the clip AT CLAIM TIME (resolveIntroVideo,
//     [PURE-INTRO-RESOLVE]): 'selected' uses the pinned row,
//     'random' picks one of the user's rows per post. The
//     resolved { url, videoId } rides the stored job only —
//     nothing is added to queue rows, per the spec's lookup-at-
//     use design — so the toggle and Delete take effect from
//     the very next post. STRICTLY FAIL-OPEN (spec invariant
//     2): disabled, an empty library, a vanished selection, or
//     a failed lookup each resolve to a named skip and the post
//     proceeds exactly as before this version. The worker also
//     relays the clip bytes to the content script (the AUTO
//     LAUNCH_FETCH_VIDEO message), mirroring the photo relay:
//     the page cannot fetch cross-origin itself.
// 28. BOUNDED VIDEO FETCH + JOB LIVENESS (v2.54 — the
//     2026-10-28 Accord wedge; content.js header note 28
//     carries the composer side): the relay fetcher below ran
//     a bare fetch + arrayBuffer() with no time limit, so a
//     stalled download never settled, the content script's
//     relay wait never answered, and the post wedged silently
//     behind the previous banner step. fetchVideoForContent
//     now aborts its fetch at 30s and answers the structured
//     refusal video_fetch_timeout; the content side races the
//     relay answer and bounds its own fallback, so a dead
//     download becomes the ordinary intro_video_download_
//     failed skip and the post proceeds without the clip.
//     The worker also answers AUTOLAUNCH_JOB_LIVENESS: the
//     content script asks, before filling, whether its stored
//     job is still the live slot — the same incident's second
//     half was a surviving tab re-driving a fill for a row
//     this worker had already settled. The verdict is
//     definitive-only: the slot holding a different job (or
//     no job), a missing queue row, or a row already in a
//     terminal state (or pending again, per reconcileActive
//     Job's reading) answers { live: false }; a matching slot
//     with a processing row answers { live: true }; and any
//     lookup failure answers { live: true } too — uncertainty
//     never blocks a fill.
// 29. SHARE TO FEED (v2.1.55 — Matthew's spec, 2026-10-29;
//     content.js header note 29 carries the Selling-page side):
//     two entry points, ONE mechanism. (a) The app's "Share to
//     my feed" button inserts an auto_posting_queue row with
//     action 'share' — the worker claims it exactly like a
//     delete (same Selling-page tab, same pacing/limit
//     exemption class, same missing-inventory-row fallback to
//     the row's stamped fields, same conditional claim), and
//     the content script shares the strictly matched listing
//     to the user's personal feed. A share NEVER touches
//     scraped_inventory.marketplace_posted_at: the listing
//     stays posted; the row settles 'completed'. (b) The
//     settings toggle (user_settings.share_to_feed, read at
//     claim time by userSettings exactly like the intro trio)
//     rides POST jobs as job.shareToFeed; when a post job
//     finalizes SUCCESSFULLY, finishJobPosted queues ONE share
//     row for the just-posted car through maybeQueueFeedShare
//     (dedupe-checked against live share rows for the VIN).
//     STRICTLY FAIL-OPEN, mirroring the intro-video skip
//     contract: the share insert is wrapped so it can never
//     throw into, fail, or delay the completed post — the post
//     is already final when it runs — and the share job itself
//     is an ordinary queue row whose own failure settles
//     'failed' with field_diag evidence, exactly like a delete.
//     Post failure never reaches finishJobPosted, so a failed
//     post never queues a share; toggle off queues nothing.
// 30. SHARE HARDENING (v2.1.56 — content.js header note 30
//     carries the incident and the two gates): share rows now
//     carry the listing's description text in the new
//     auto_posting_queue.share_text column, and the worker
//     carries it on share jobs as job.shareText for the
//     content script's composer placement. The worker-side
//     producer (maybeQueueFeedShare) stamps it with
//     buildShareTextForCar — a rebuild of the listing
//     description from the same inputs the posting composer
//     uses: the description TEXT is built in the content
//     script at post time and never reported back to the
//     worker, so the worker reconstructs it from the job's
//     car row plus the claim-time settings (dealership
//     identity + include_stock ride every job payload). The
//     auth-stash replay builds the same text: the stash's
//     shareCar now also carries trim / mileage / color /
//     transmission / condition and the stash carries the
//     identity + stock settings, so a replayed insert is
//     identical to the direct one. A claimed share whose row
//     predates the column simply carries shareText "" and the
//     content side fails it share_text_unplaced — a bare
//     share is never an acceptable outcome.
//
// 31. DEALERSHIP TAG ON FEED SHARES (v2.1.59 — content.js
//     header note 33 carries the design): the content
//     script now appends a best-effort Facebook @mention
//     of the dealership Page to the share composer's
//     details text. NO worker change was needed: the
//     dealership name has ridden every claimed job since
//     the description's closing block existed —
//     jobPayload sets dealershipName from the claim-time
//     settings (user_settings.dealership_name, read with
//     the settings block at claim) unconditionally, share
//     rows included, and the content script already binds
//     it at the top of every job. Both share producers
//     (app button + auto-share) claim through the same
//     path, so both arrive tagged-capable. This note is
//     the whole worker-side delta: comment only.
//
// 32. ONE ACTIVE HELPER — THE LEASE (v2.1.60 — Matthew's
//     spec, 2026-10-29; proven necessary the same night):
//     two helper workers holding the same user's session
//     raced one queue — an old pre-share build on Matthew's
//     home PC kept claiming rows, and its claim-time
//     already-posted shortcut closed SHARE rows "posted"
//     without ever opening Facebook (three shares eaten;
//     caught live by watching a row flip pending -> posted
//     in 5 seconds with the desk helper switched OFF).
//     Rule from this build: only ONE helper instance per
//     account may CLAIM queue jobs. The lease lives on the
//     user's own user_settings row (helper_lease_id /
//     helper_lease_expires_at — two nullable columns; the
//     own-row RLS policies already cover them). Each
//     instance owns a random UUID (al_instance_id in
//     chrome.storage.local, created on first need, stable
//     for the install — deliberately distinct from the
//     trial-abuse al_install_id). checkQueue reads the
//     lease with the claim cycle's existing settings fetch
//     (no extra round trip): empty, expired, or MINE ->
//     renew (one PATCH, expiry now + 10 min) and claim as
//     before; FOREIGN and unexpired -> claim NOTHING this
//     cycle and keep cycling (dormant) — the lease may
//     expire or be yielded. The lease gates NEW claims
//     only: job-slot reconciliation, every finish function,
//     the auth-stash replay (flushPendingFinish) and orphan
//     handling run exactly as before, so a job already in
//     flight settles its bookkeeping even if the lease is
//     lost mid-run — a row is never stranded by the lease.
//     If the lease write fails the cycle claims nothing
//     (fail closed; Supabase being unreachable already
//     blocks the queue reads, so this adds no new outage
//     class). Takeover is deliberate, never automatic: the
//     app's Extension page shows the lease state, and its
//     "Use this computer instead" button writes THIS
//     install's instance id (asked over the bridge —
//     AUTOLAUNCH_GET_INSTANCE_ID, app-origin senders only)
//     onto the row; the old holder sees a foreign lease on
//     its next cycle and stands down. Legacy builds know
//     nothing of the lease and ignore it — the lease
//     protects an account once its helpers run this build.
//
// 33. CARFAX REPORT LINE IN SHARE TEXT (v2.1.61 — CARFAX
//     phase 2, 2026-10-29; content.js header note 34
//     carries the composer's side): buildShareTextForCar
//     gains the identical conditional "CARFAX report:
//     <url>" line the composer gained, from the same input
//     (the claimed car row's carfax_url, which the
//     production scraper now keeps fresh from each VDP's
//     badge). The three builders stay byte-identical, so
//     a share's details text still equals the listing's
//     description exactly — with the link when the car
//     has one, and byte-identical to 2.1.60 when it
//     doesn't. Comment + one builder term; no other
//     worker behavior changes.
//
// 34. LISTING PRICE SYNC (v2.1.62 — Matthew, 2026-11-03;
//     content.js header note 35 carries the editor's side):
//     a Facebook listing keeps its post-time price forever,
//     while the dealer's price moves — so removals built at
//     the current price failed the strict title+price match
//     (the Nautilus: posted $14,530, price dropped to
//     $12,492, removal refused). Two foundations land here.
//     (a) POSTED-PRICE STAMP: applyPosted now also writes
//     scraped_inventory.marketplace_posted_price — the price
//     the post actually used, carried on the job from the
//     queue row — and applyDeleted clears it with the posted
//     stamp; producers build removals from it, so a removal
//     always matches the price the listing shows. (b) PRICE
//     UPDATE JOBS: the scraper queues action "update_price"
//     rows (price = the new price, update_from_price = the
//     price the listing still shows) when a live listing's
//     dealer price drifts. A price update is NOT a post —
//     Matthew's rule: it never counts toward the daily cap,
//     the usage counters, or post pacing, so checkQueue
//     claims it under the same exemptions "share" carries,
//     and its completion (applyPriceUpdated) advances ONLY
//     marketplace_posted_price — marketplace_posted_at is
//     never touched, so neither today's-posts count nor the
//     pacing anchor can move. Claim-time basis validation
//     (priceUpdateClaimGate) fails the row untouched when
//     the drift it was queued for is no longer the drift
//     that exists; the next sync re-queues the truth.
//
// 35. FOREGROUND FOR SCAN JOBS (v2.1.76 — Matthew,
//     2026-11-05; content.js header note 36 carries the
//     scan's side): Facebook only paginates the Selling
//     list on a page the browser is actually rendering —
//     a tab created active:false and never shown keeps
//     exactly its first chunk of cards (five, live
//     2026-11-05) no matter how long the settle scrolls,
//     so scan jobs (update_price, delete, share) died
//     listing_not_found on a list that was never loaded.
//     The worker now fronts a scan job's tab before its
//     flow begins: the tab the user was on in that window
//     is remembered on the job (restoreTabId) and the job
//     tab is activated; when the job ends — finish, fail,
//     exception, watchdog reconcile — the remembered tab
//     is re-activated. Tab activation only: the window is
//     never focused, and post jobs keep the v2.1.12
//     background rule untouched. A window that stays
//     minimized keeps its hidden page — the scan then
//     fails list_never_grew (content note 36), honestly.
//
// 37. SCAN JOBS LIVE IN A HELPER WINDOW (v2.1.77 —
//     Matthew, 2026-11-05; supersedes the same-window
//     half of note 35): the v2.1.76 fix itself was proven
//     live the morning it shipped — a fronted job tab's
//     match scan settled at the full census (cards:72,
//     vis:visible) after ~25 hidden-tab failures — but
//     fronting inside the USER's window switched the tab
//     out from under him while he was typing in another
//     one, and his ruling was plain: that can't happen.
//     Scan jobs now run in a dedicated Chrome window the
//     helper owns: created unfocused on first need, its
//     id kept in chrome.storage.local (al_helper_window),
//     reused across jobs, and recreated lazily when it is
//     gone (closed by hand, or forgotten at browser
//     startup, when a stored id could name a stranger's
//     window). The job tab is activated inside that
//     window only — being a window's active tab is what
//     makes the page render and paginate — no window is
//     ever focused, and no tab in the user's window is
//     ever activated for a scan. Note 35's borrowed-
//     foreground machinery (restoreTabId, and the
//     restore calls on the terminal paths) is removed:
//     there is no borrowed foreground left to give back.
//     If the helper window cannot be had, the scan job
//     fails honestly (helper_window_unavailable) rather
//     than fall back to the user's window. Post jobs are
//     untouched — inactive tabs in the user's window,
//     nothing to scan.
//
// 39. SEARCH-ASSIST, WORKER SIDE (v2.1.78 — Matthew,
//     2026-11-05; content.js header note 38 carries the
//     scan's side): notes 35 and 37's mechanisms are both
//     REMOVED. The helper window bought a rendered page at
//     the price of a second window the user's maximized
//     window then hid anyway (uniform cards:5 vis:hidden,
//     live 2026-11-05), and fronting in the user's window
//     (note 35) remains forbidden by his ruling. A scan no
//     longer needs its page rendered at all: the content
//     side renders the one target card through the Selling
//     list's own search (note 38) and reads it from the
//     DOM of an ordinary background tab. The claim site is
//     therefore back to a single creation path for every
//     job — chrome.tabs.create({ active: false }) in the
//     user's window, the v2.1.12 rule whole again: no tab
//     is activated for any job, no window is created or
//     focused, and the helper-window block and its
//     al_helper_window storage key are gone with the
//     mechanism. Post jobs were never touched by any of
//     this and are byte-identical.
//
// 40. VIN REELS PHASE 2 (v2.1.85 — Matthew, 2026-11-05):
//     the auto-post producer can queue a marketplace row
//     HELD (awaiting_reel=true) behind a poster VIN Reel.
//     Held rows are invisible to the claim fetch (one added
//     filter; the claim's shape and order are unchanged)
//     until the reels worker releases the hold — reel ready,
//     reel failed, or hold stale. At claim time a post looks
//     up the car's latest reel: a READY reel rides the job's
//     introVideo slot INSTEAD of the user's intro video (one
//     video slot; the reel carries the dealership branding),
//     so the content side's attach path is untouched. After
//     the post SUCCEEDS, a source='poster' reel is consumed:
//     its storage object is deleted and the row is marked
//     consumed — the Facebook post keeps its own copy. A
//     ready source='manual' reel attaches but is NEVER
//     consumed (cleanup may only ever touch poster reels).
//     No ready reel at claim time posts exactly as before:
//     nothing in this version can block a post on a video.
//
// 41. REEL ATTACH VERIFICATION (v2.1.86 — Matthew, 2026-11-06):
//     the 2.85 desk test posted three held cars; only one
//     listing actually carried its video, yet all three poster
//     reels were consumed — claim time had stamped the reel
//     "attached" on INTENT, and the finish believed the stamp.
//     Now the content side reports the attach verdict with the
//     posted message: it reads the composer's Videos counter
//     back after the attach (one retry on a miss, content.js
//     header note 41) and only a VERIFIED attach (counter
//     >= 1) lets a finish consume the poster reel. An
//     unverified attach leaves the reel ready, stamps the
//     queue row's completion reel_failed=true (the health
//     bar's "posted without video" chip finally tells the
//     truth both ways), and files the attach diagnostics in
//     the row's error_message in field_diag style — the post
//     itself still completes and stamps exactly as before.
//     A finish with no attach verdict on record (a recovery
//     scan settled the job) counts as unverified: consumption
//     requires proof, never a presumption.
//
// 42. REEL ATTACH: BINDING PRE-PUBLISH VERDICT (v2.1.87 —
//     Matthew, 2026-11-06): the consumption rule of note 41
//     is unchanged — the verdict it consumes is now the
//     content side's FINAL one, taken immediately before
//     Publish after a counter-required wait, a size-scaled
//     budget, and at most one repair attach (content.js
//     header note 42). The diag filed for an unverified
//     attach grows the self-diagnosing tail the Wrangler
//     run was missing: every attempt's verdict (with ever /
//     signature markers), the budget the size-scaled wait
//     used, the stage that produced the binding verdict,
//     and the compact Videos-counter trace — built purely
//     by reelAttachDiagFields so the harness exercises the
//     exact strings the row will carry.
// 43. EDIT-FLOW VIDEO ATTACH (v2.1.88 — Matthew, 2026-11-06):
//     the create-flow attach is structurally beaten — six
//     desk runs across file sizes, helper versions and
//     watched/unwatched tabs all ended the same way: the
//     clip attaches and verifies (a watched run read the
//     counter 1/1 in 7s, through the VIN auto-fill settle),
//     then Facebook's composer DROPS it at the "Next" step
//     transition, and the final step has no video input to
//     repair with. The EDIT surface is the proven one —
//     Matthew attached the Durango's reel by hand through
//     ⋯ → Edit listing and it stuck at once. So the attach
//     becomes a SECOND, queued job: when a post completes
//     with its poster reel still unconsumed (the note-41/42
//     verdict said unverified), the finish queues ONE
//     attach_video row for the car (dedupe-checked, strictly
//     fail-open), and a later claim runs it as a price
//     update's sibling: strict Selling-page match at the
//     POSTED price, the listing's own Edit form, the 2.87
//     attach machinery against that form, Save, then a
//     reopened editor as the post-save proof. Only a
//     verified post-save read consumes the reel, settles
//     the row "completed" and clears the parent post row's
//     reel_failed flag. The claim also gains its ACTION
//     ALLOWLIST in this version: a helper claims only
//     actions it knows (post/delete/share/update_price/
//     attach_video); an unknown action is never claimed as
//     a post. Blast radius, stated plainly: an attach_video
//     row can exist only in the queue of an account whose
//     own >= 2.88 helper created it at a post completion —
//     no producer writes one. An OLDER helper on that same
//     account claiming one as a "post" exits at the v2.52
//     claim-time stamp check (the car always carries
//     marketplace_posted_at — that is the attach premise):
//     the row settles "posted" without a tab ever opening,
//     no listing is created, the stamp is untouched and the
//     reel stays ready; the attach is simply lost. The one
//     residue: if the listing were deleted between queueing
//     and such a claim, the stamp check could not fire and
//     the legacy flow would re-post the car as it would any
//     queued post row — bounded to a downgrade window on an
//     account that ran 2.88, and accepted. Attach jobs are
//     not posts anywhere the worker counts: the daily cap
//     and usage count read inventory stamps (an attach
//     completion never stamps), pacing anchors on the same
//     stamp, and the claim treats the action with the
//     delete/share/update_price exemptions.
// 44. EDITOR ATTACH: CDP FILE INJECTION (v2.1.89 — Matthew,
//     2026-11-06): the 2.88 desk proof isolated the last
//     mechanism. In the listing's editor the DataTransfer-
//     set clip verified in the form (done/ever), Update was
//     clicked — and the reopened editor read the counter
//     at 0 (saved_unproven). The page-level set yields a
//     preview Facebook never binds to a durable upload;
//     Matthew's picker upload of the same file persisted
//     at once. The editor attach's file set is now picker-
//     equivalent: this worker saves the reel bytes to a
//     real on-disk path itself (chrome.downloads — the one
//     NEW permission in this build; "debugger" was already
//     carried for the note-9 trusted input) and, over the
//     note-9 CDP session, runs DOM.setFileInputFiles on
//     the exact input the content script marked. The
//     download record rides chrome.storage so the temp
//     file is cleaned up (removeFile + erase) when the
//     attach job settles — success in finishJobVideo-
//     Attached, failure in finishJobFailed — always fail-
//     open. Any failure in the download/CDP chain answers
//     a structured error and the content side falls back
//     to the DataTransfer set for that attempt; the
//     reel_attach diag states the mechanism that ran. The
//     create-flow attach keeps the DataTransfer set: this
//     build tests injection in the editor only.
// 45. CONTACT LINE + CARD-AS-LAST-PHOTO (v2.1.90 — Matthew,
//     2026-11-06): two surfaces for the rep's own "Call or
//     text {name} · {phone}" (user_settings rep_display_
//     name / rep_phone — both required, either blank and
//     every surface stays byte-identical to 2.89). (a) The
//     LISTING contact line: userSettings now reads the
//     pair and the job payload carries it exactly like the
//     dealership identity; both description composers —
//     the content side's buildDescription and this
//     worker's buildShareTextForCar, with the app's
//     buildShareDetailsText the third mirror — append it
//     as the closing line after the dealership block,
//     through the one pure formatter (repContactLine) so
//     the three can never drift. The voiceover never
//     speaks it (the generator asserts the same rule).
//     (b) The reel's end-card still rides the post as the
//     LAST photo: the generator uploads it beside the mp4
//     (qa.card_url on the reel row), the claim's reel
//     resolution carries the URL on the job, and the
//     content side attaches it after the dealer photos —
//     planPhotoAttach caps the dealer set at 19 when a
//     card rides, so the listing never passes Facebook's
//     20; under 20 it simply appends. The card never
//     counts toward any photo gate: the claim's no-photo
//     guard, the producer's minimum and the content
//     Photos verdict all keep reading dealer photos only.
//     Card download/attach failures are fail-open (the
//     post stands without the card), and consumption now
//     deletes the card object beside the mp4.

// 51. RICH DESCRIPTIONS (v2.1.98 — Matthew, 2026-11-10;
//     promoted from the rebuild, commit bde99546 —
//     content.js header note 51 carries the design):
//     worker side is carriage only. userSettings reads
//     user_settings.rich_descriptions (default OFF) beside
//     include_stock; the claim carries it on every job
//     payload as job.richDesc, exactly like includeStock;
//     buildShareTextForCar runs the same [PURE-RICHDESC]
//     renderer over the job's car row (the claim-time
//     inventory fetch is select-*, so vdp_features rides
//     the car row with no new fetch). The finish path's
//     auth-stash replay carries richDesc beside
//     includeStock and the shareCar snapshot now also
//     carries the payload inputs (vdp_features,
//     interior_color, body_type, price_status), so a
//     replayed share builds the identical rich text.
//     With the switch off — or no usable payload — every
//     surface is byte-identical to before this feature
//     existed.

const SUPABASE_URL = "https://tdsipiltwajwhzgjsupx.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_hkEU-TniEPk-ShSxBZQ-kQ_zGrDUC8w";
const POLL_ALARM = "autolaunch-queue-poll";
const POLL_MINUTES = 1;

class SbAuthError extends Error {
  constructor(status) {
    super(`Supabase rejected the session token (${status})`);
    this.status = status;
  }
}

async function storedAccessToken() {
  const { autolaunch_access_token: token } =
    await chrome.storage.local.get(["autolaunch_access_token"]);
  return token || null;
}

// Trial-abuse install identifier (v2.1.45). ONE random UUID per helper
// install, kept in chrome.storage.local under al_install_id: created
// lazily on first request, then stable across restarts, updates, and
// site-data clears. It identifies the INSTALL, never a person or an
// account — uninstall/reinstall or a fresh Chrome profile starts over,
// which is accepted: this is a fence against casual trial farming,
// not a device fingerprint. The only reader is the
// AUTOLAUNCH_GET_INSTALL_ID bridge answer below, which goes solely to
// the AutoLaunch app origin; the app sends it to trial-start when a
// trial begins, and the server stores only a salted hash of it.
async function getOrCreateInstallId() {
  const { al_install_id: existing } =
    await chrome.storage.local.get(["al_install_id"]);
  if (existing) return existing;
  let id = null;
  try { id = crypto.randomUUID(); } catch (e) { /* fall through */ }
  if (!id) {
    id = "al-" + Date.now().toString(36) + "-" +
      Math.random().toString(36).slice(2, 10) +
      Math.random().toString(36).slice(2, 10);
  }
  await chrome.storage.local.set({ al_install_id: id });
  return id;
}

// One-active-helper instance identity (v2.1.60, header note 32):
// ONE random UUID per helper install, kept in chrome.storage.local
// under al_instance_id — created lazily on first need, then stable
// across restarts and updates. It names the INSTALL for the helper
// lease only; it is deliberately NOT the trial-abuse al_install_id
// above (that fence has its own reader and lifecycle). The only
// outside reader is the AUTOLAUNCH_GET_INSTANCE_ID bridge answer,
// which goes solely to the AutoLaunch app origin so the Extension
// page's takeover button can write THIS install's id as the lease.
async function getOrCreateInstanceId() {
  const { al_instance_id: existing } =
    await chrome.storage.local.get(["al_instance_id"]);
  if (existing) return existing;
  let id = null;
  try { id = crypto.randomUUID(); } catch (e) { /* fall through */ }
  if (!id) {
    id = "al-inst-" + Date.now().toString(36) + "-" +
      Math.random().toString(36).slice(2, 10) +
      Math.random().toString(36).slice(2, 10);
  }
  await chrome.storage.local.set({ al_instance_id: id });
  return id;
}

// [PURE-LEASE-DECISION-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Lease decision (v2.1.60, header note 32): "take" when the lease
// is empty, expired, unreadable, or already mine — the caller
// renews and claims; "foreign" only when a DIFFERENT instance
// holds a lease whose expiry is still ahead — the caller stands
// down and claims nothing this cycle.
const HELPER_LEASE_TTL_MS = 10 * 60 * 1000;
function helperLeaseDecision(leaseId, leaseExpiresAt, myInstanceId, nowMs) {
  if (!leaseId || typeof leaseId !== "string") return "take";
  if (leaseId === myInstanceId) return "take";
  const exp = Date.parse(leaseExpiresAt || "");
  if (!isFinite(exp) || exp <= nowMs) return "take";
  return "foreign";
}
// [PURE-LEASE-DECISION-END]

async function sbHeaders(extra) {
  const token = await storedAccessToken();
  return Object.assign({
    "apikey": SUPABASE_ANON_KEY,
    "Authorization": `Bearer ${token || SUPABASE_ANON_KEY}`,
    "Content-Type": "application/json"
  }, extra || {});
}

// Record (once per expiry) that the stored token died, in the same
// autolaunch_last_error record the failure logger uses. Reason strings
// only — the token value itself never lands in storage logs or errors.
async function markSessionExpired() {
  const { autolaunch_session_expired: already } =
    await chrome.storage.local.get(["autolaunch_session_expired"]);
  if (already) return;
  await chrome.storage.local.set({
    autolaunch_session_expired: true,
    autolaunch_last_error: {
      queueId: null,
      reason: "session_expired — reopen the AutoLaunch tab",
      at: new Date().toISOString()
    }
  });
  console.warn("[AutoLaunch] Session token expired — reopen the AutoLaunch tab to reconnect the extension.");
}

async function noteWaitingForLogin() {
  const { autolaunch_last_error: last } =
    await chrome.storage.local.get(["autolaunch_last_error"]);
  if (last && last.reason === "waiting_for_login") return;
  await chrome.storage.local.set({
    autolaunch_last_error: {
      queueId: null,
      reason: "waiting_for_login",
      at: new Date().toISOString()
    }
  });
}

async function sbFetch(path, options) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, options);
  if (res.status === 401 || res.status === 403) {
    await markSessionExpired();
    throw new SbAuthError(res.status);
  }
  if (!res.ok) {
    throw new Error(`Supabase ${(options && options.method) || "GET"} ${path} -> ${res.status}`);
  }
  return res.json();
}

async function sbGet(path) {
  return sbFetch(path, { headers: await sbHeaders() });
}

async function sbPatch(path, body) {
  return sbFetch(path, {
    method: "PATCH",
    headers: await sbHeaders({ "Prefer": "return=representation" }),
    body: JSON.stringify(body)
  });
}

async function sbDelete(path) {
  return sbFetch(path, { method: "DELETE", headers: await sbHeaders({}) });
}

async function sbPost(path, body) {
  return sbFetch(path, {
    method: "POST",
    headers: await sbHeaders({ "Prefer": "return=representation" }),
    body: JSON.stringify(body)
  });
}

// Upsert with an explicit conflict target (v2.1.80, for the DWS
// helper-side sync's inventory push — mirrors the Python scraper's
// on_conflict="vin, user_id").
async function sbUpsert(path, rows) {
  return sbFetch(path, {
    method: "POST",
    headers: await sbHeaders({
      "Prefer": "resolution=merge-duplicates,return=representation"
    }),
    body: JSON.stringify(rows)
  });
}

// ---------------------------------------------------------------------
// AUTO-CREATE GATE (v2.1.46, header notes 22-23). Pure function:
// given an AUTO capture and the context handleCaptureChat assembled
// (the user's Marketplace-posted cars), decide whether the capture
// may CREATE a prospect. Manual captures never pass through here,
// and neither do captures for an already-known prospect (their
// message sync is not creation).
function autoCreateGate(capture, ctx) {
  var name = String((capture && capture.buyerName) || "").trim();
  // Hard rule: an unresolved participant name NEVER auto-creates —
  // the "Marketplace buyer" fallback card is exactly what this kills.
  if (!name) return { create: false, reason: "unresolved_name" };
  // Chrome placeholder names (v2.50, header note 24): "Facebook
  // user" and its furniture friends are what a half-rendered
  // thread shows INSTEAD of a participant — not a resolved name.
  if (/^(facebook user|compose|conversation with facebook user)$/i.test(name)) {
    return { create: false, reason: "unresolved_name" };
  }
  // Self test BY IDENTITY (v2.1.47, header note 23): block only when
  // the counterparty's Facebook identity PROVABLY equals the
  // signed-in account's — canonical tokens ("id:<digits>" /
  // "vanity:<name>") scraped by chat_capture.js. An id token never
  // equals a vanity token (unproven = not self), and a display-name
  // match is no signal at all: a second account under the same name
  // is a buyer, not the rep himself.
  var buyerId = String((capture && capture.buyerFbId) || "").trim();
  var selfId = String((capture && capture.selfFbId) || "").trim();
  if (buyerId && selfId && buyerId === selfId) {
    return { create: false, reason: "self_thread" };
  }
  var label = String((capture && capture.vehicleText) || "").trim();
  // Signal 1 — surface: the Marketplace inbox is commerce-only by
  // construction; a listing label must ride along so a bare system
  // row there still cannot create on surface alone.
  if (capture && capture.surface === "marketplace_inbox" && label) {
    return { create: true, signal: "marketplace_inbox" };
  }
  // Signal 2 — seller's thread: the open pane showed the seller's
  // own controls ("View buyer" renders only for the listing's
  // seller; a buyer-side thread shows "View seller" instead).
  if (capture && capture.sellerContext === true && label) {
    return { create: true, signal: "seller_thread" };
  }
  // Signal 3 — own listing: the label's year + make match one of
  // the user's own Marketplace-posted cars.
  if (label && labelMatchesPostedCar(label, (ctx && ctx.postedCars) || [])) {
    return { create: true, signal: "own_listing" };
  }
  return { create: false, reason: "no_seller_signal" };
}

// Does a listing label ("$26,159 - 2026 Volkswagen Jetta", "2026
// Volkswagen Jetta") name one of the user's posted cars? Token-based
// contains on year + make, so multi-word makes ("Land Rover") work
// the same way. postedCars rows come from scraped_inventory with
// marketplace_posted_at set — cars this user actually listed.
function labelMatchesPostedCar(label, postedCars) {
  var text = " " + String(label || "").toLowerCase()
    .replace(/[^a-z0-9]+/g, " ") + " ";
  for (var i = 0; i < postedCars.length; i++) {
    var car = postedCars[i] || {};
    var year = parseInt(car.year, 10);
    var make = String(car.make || "").trim().toLowerCase()
      .replace(/[^a-z0-9]+/g, " ").trim();
    if (!year || !make) continue;
    if (text.indexOf(" " + year + " ") === -1) continue;
    if (text.indexOf(" " + make + " ") !== -1) return true;
  }
  return false;
}

// Luca chat capture (Phase 2): a chat_capture.js scrape of an open
// Messenger/Marketplace thread lands here. Find-or-create the buyer as
// a Prospect, then store only the messages we don't already have.
// Runs on the rep's own stored session, so RLS keeps every row theirs.
async function handleCaptureChat(capture) {
  const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
  if (!userId) {
    const e = new Error("not_signed_in — open AutoLaunch and sign in first");
    e.code = "not_signed_in";
    throw e;
  }
  const norm = (s) => (s || "").trim().toLowerCase();
  const name = (capture.buyerName || "").trim() || "Marketplace buyer";
  const vehicleText = (capture.vehicleText || "").trim();
  const threadRef = (capture.threadUrl || "").slice(0, 300);
  // Tombstone key (v2.50, header note 24): the thread's numeric
  // /t/<id> when the ref carries one, else the normalized ref —
  // MUST stay in step with prospect_tombstone_key() in the
  // database, which keys the rows the delete trigger writes.
  const threadKey = (() => {
    const m = String(threadRef || "").match(/\/t\/(\d+)/);
    return m ? m[1] : norm(threadRef);
  })();

  // Match order (auto-capture, v2.1.31): the THREAD is the identity —
  // the same conversation must never become two prospects just because
  // a list-row name or a listing label scraped differently this time.
  // Name+label matching stays as the fallback for captures with no URL.
  const rows = await sbGet(`prospects?user_id=eq.${userId}&select=id,name,vehicle_label,thread_ref&order=created_at.desc&limit=200`);
  let prospect = null;
  if (threadRef) prospect = rows.find(r => r.thread_ref && norm(r.thread_ref) === norm(threadRef));
  if (!prospect) {
    prospect = rows.find(r => norm(r.name) === norm(name) && (!vehicleText || norm(r.vehicle_label) === norm(vehicleText)));
  }
  // Marketplace-only auto rule (Matthew, 2026-10-25; tightened
  // v2.1.46, header note 22): creating a prospect from an AUTO
  // capture requires a resolved participant name AND a positive
  // seller-side signal — see autoCreateGate. Merely opening a
  // Messenger chat must never create a prospect or save its
  // messages; the manual Capture button (no auto flag) is how a rep
  // adds anything else, and it never passes through the gate. Auto
  // updates to an already-known prospect's thread still flow.
  if (capture.auto && !prospect) {
    // Tombstone (v2.50, header note 24): a prospect the rep
    // deleted must STAY deleted — the thread still exists on
    // Facebook, so without this check the next pass re-creates
    // the card. Terminal: never created, never retried.
    if (threadKey) {
      try {
        const tombs = await sbGet(`prospect_tombstones?user_id=eq.${userId}&thread_ref=eq.${encodeURIComponent(threadKey)}&select=id&limit=1`);
        if (tombs && tombs.length) {
          return { prospectName: null, added: 0, skipped: "deleted_by_user" };
        }
      } catch (e) { /* read failed — the gate below still guards creation */ }
    }
    const gateCtx = { postedCars: [] };
    try {
      gateCtx.postedCars = await sbGet(
        `scraped_inventory?user_id=eq.${userId}` +
        `&marketplace_posted_at=not.is.null&select=year,make,model&limit=300`) || [];
    } catch (e) { /* no inventory signal this pass */ }
    const gate = autoCreateGate(capture, gateCtx);
    if (!gate.create) {
      return { prospectName: null, added: 0, skipped: gate.reason };
    }
  }
  // Manual Capture, no matched prospect, no resolvable participant
  // (v2.1.47): decline with a reason the button can name instead of
  // filing a nameless "Marketplace buyer" card. Auto captures never
  // reach here (the gate already decided), and a thread-matched
  // prospect captures fine without a name.
  if (!capture.auto && !prospect && !String(capture.buyerName || "").trim()) {
    const e = new Error("no_buyer — no buyer found in this chat");
    e.code = "no_buyer";
    throw e;
  }
  if (!prospect) {
    const created = await sbPost("prospects", {
      user_id: userId,
      name: name,
      vehicle_label: vehicleText || null,
      stage: "new",
      source: "marketplace",
      thread_ref: threadRef || null,
      notes: capture.stub
        ? "Found in your Messenger inbox by Luca auto-sync. Open the chat and Luca will capture the conversation."
        : "Captured from a Marketplace chat by Luca."
    });
    prospect = created[0];
    // Manual Capture of a previously deleted thread is an
    // explicit undelete (v2.50, header note 24): clear its
    // tombstone so the thread lives as a normal prospect again.
    if (!capture.auto && threadKey) {
      try { await sbDelete(`prospect_tombstones?user_id=eq.${userId}&thread_ref=eq.${encodeURIComponent(threadKey)}`); } catch (e) { /* cosmetic */ }
    }
  } else {
    // Self-heal older/rougher captures: backfill a placeholder name, a
    // missing label, or a missing thread link when this capture has
    // better data. Never overwrite good data with rougher data.
    const patch = {};
    if (norm(prospect.name) === "marketplace buyer" && norm(name) !== "marketplace buyer") patch.name = name;
    if (!prospect.vehicle_label && vehicleText) patch.vehicle_label = vehicleText;
    if (!prospect.thread_ref && threadRef) patch.thread_ref = threadRef;
    if (Object.keys(patch).length) {
      try { await sbPatch(`prospects?id=eq.${prospect.id}`, patch); Object.assign(prospect, patch); } catch (e) { /* cosmetic */ }
    }
  }

  const existing = await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospect.id}&select=id,body,direction&order=created_at.desc&limit=200`);
  const seen = new Set(existing.map(m => m.direction + "|" + m.body));
  // Cross-direction guard (v2.51, header note 25): a scrape that
  // misplaces a bubble files the SAME body under the opposite
  // direction, and the direction-keyed dedupe above waves it
  // through as new — that is how the rep's own delivered reply
  // ("I'll actually be here until 8 tonight…", already stored
  // out/rep) was re-filed as the buyer's on Matthew's shared-name
  // group thread. A long body already stored under the other
  // direction is the same message mis-read: drop the copy. Short
  // bodies are exempt — both sides genuinely say "Yes" / "Ok",
  // and dropping a real echo would lose a real message.
  const storedDirs = new Map();
  existing.forEach(m => {
    const b = norm(m.body);
    if (!storedDirs.has(b)) storedDirs.set(b, new Set());
    storedDirs.get(b).add(m.direction);
  });
  const fresh = (capture.messages || []).filter(m => {
    if (!m || !m.body) return false;
    if (seen.has(m.direction + "|" + m.body)) return false;
    if (String(m.body).trim().length >= 20) {
      const dirs = storedDirs.get(norm(m.body));
      if (dirs) {
        const mine = m.direction === "out" ? "out" : "in";
        const other = mine === "out" ? "in" : "out";
        if (dirs.has(other) && !dirs.has(mine)) return false;
      }
    }
    return true;
  });
  if (fresh.length) {
    // Sequential created_at stamps (v2.1.40): one bulk insert shares
    // a single transaction timestamp, which scrambled the thread
    // order in the conversation view (Matthew: "texts come in out
    // of order"). Stamping each row +1ms in scrape order makes
    // created_at a faithful chronology.
    const baseTs = Date.now();
    await sbPost("closer_messages", fresh.map((m, idx) => ({
      user_id: userId,
      prospect_id: prospect.id,
      thread_ref: (capture.threadUrl || "").slice(0, 300) || null,
      direction: m.direction === "out" ? "out" : "in",
      origin: m.direction === "out" ? "rep" : "buyer",
      body: String(m.body).slice(0, 2000),
      created_at: new Date(baseTs + idx).toISOString()
    })));
    // Snippet-partial cleanup (v2.1.33): a full capture supersedes the
    // truncated one-line rows the inbox-list snippet sync saved for the
    // same message. An existing row counts as a partial when a fresh
    // full body (same direction, longer) starts with its text.
    const partialIds = existing.filter(e => {
      const core = String(e.body || "").replace(/[…]+$/, "").replace(/\.\.\.$/, "");
      if (core.length >= 20 && fresh.some(f => f.direction === e.direction
        && String(f.body).length > core.length
        && String(f.body).indexOf(core.slice(0, 40)) === 0)) return true;
      // Composite rows (v2.1.41): a list-row snippet sometimes fuses
      // the listing label + sender name onto the message ("2026
      // Volkswagen Jetta Matthew: Hahahah shush"). When a fresh full
      // body matches the existing row's TAIL with a real prefix in
      // front of it, the fused row is the same message — drop it.
      const eBody = String(e.body || "");
      return fresh.some(f => f.direction === e.direction
        && String(f.body).length >= 3
        && eBody.length > String(f.body).length + 8
        && eBody.endsWith(String(f.body)));
    }).map(e => e.id).filter(Boolean);
    if (partialIds.length) {
      try { await sbDelete(`closer_messages?id=in.(${partialIds.join(",")})`); } catch (e) { /* cosmetic */ }
    }
  }
  return { prospectName: prospect.name || name, added: fresh.length };
}

// Snippet sync (v2.1.33): the inbox LIST only shows each conversation's
// newest line — but that line updates live when a buyer writes, with no
// click from anyone. chat_capture.js sends those lines here; a line is
// stored ONLY for a thread that already belongs to a known prospect
// (personal chats are never pulled in), and only when it is genuinely
// new against what we already hold for that prospect.
async function handleChatSnippets(snippets) {
  const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
  if (!userId || !Array.isArray(snippets) || !snippets.length) return { stored: 0 };
  const norm = (s) => (s || "").trim().toLowerCase();
  const rows = await sbGet(`prospects?user_id=eq.${userId}&select=id,thread_ref&order=created_at.desc&limit=200`);
  const byThread = new Map();
  rows.forEach(r => { if (r.thread_ref) byThread.set(norm(r.thread_ref), r); });
  let stored = 0;
  for (const sn of snippets.slice(0, 15)) {
    const prospect = byThread.get(norm(sn.threadRef || ""));
    const body = String(sn.snippet || "").trim();
    if (!prospect || body.length < 2) continue;
    const direction = sn.direction === "out" ? "out" : "in";
    const recent = await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospect.id}&select=body,direction&order=created_at.desc&limit=30`);
    const covered = recent.some(m => {
      const b = norm(m.body);
      const s = norm(body);
      return b === s || b.indexOf(s.slice(0, 30)) === 0 || s.indexOf(b.slice(0, 30)) === 0;
    });
    if (covered) continue;
    await sbPost("closer_messages", [{
      user_id: userId,
      prospect_id: prospect.id,
      thread_ref: (sn.threadRef || "").slice(0, 300) || null,
      direction,
      origin: direction === "out" ? "rep" : "buyer",
      body: body.slice(0, 500)
    }]);
    stored++;
  }
  return { stored };
}

// --- Outbound replies (Prospects inbox step 2, v2.1.32) -------------------
// The app queues a reply as a closer_messages row (status "queued").
// This engine claims one at a time, hands it to a Facebook tab via a
// storage pending-slot (the tab's chat_capture script does the typing
// and verification), and records the result. No Facebook tab open ->
// the reply simply stays queued (the hub rule). A delivery in flight
// for over 3 minutes is marked failed rather than retried blindly —
// a half-sent state must never resend itself.
let outboundBusy = false;
async function checkOutboundReplies() {
  if (outboundBusy) return;
  outboundBusy = true;
  try {
    const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
    if (!userId) return;
    const { luca_pending_delivery: pending } = await chrome.storage.local.get(["luca_pending_delivery"]);
    if (pending) {
      if (Date.now() - (pending.at || 0) > 3 * 60 * 1000) {
        try { await sbPatch(`closer_messages?id=eq.${pending.messageId}&status=eq.sending`, { status: "failed", delivery_error: "timeout_no_result" }); } catch (e) { /* best effort */ }
        await chrome.storage.local.remove(["luca_pending_delivery"]);
      }
      return; // one delivery at a time
    }
    const rows = await sbGet(`closer_messages?user_id=eq.${userId}&status=eq.queued&select=id,prospect_id,thread_ref,body&order=created_at.asc&limit=1`);
    const row = rows && rows[0];
    if (!row || !row.thread_ref) return;
    const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
    if (!tabs.length) return; // no hub tab — stays queued
    const key = (String(row.thread_ref).match(/\/t\/(\d+)/) || [])[1] || "";
    const tab = tabs.find(t => key && (t.url || "").includes("/t/" + key))
      || tabs.find(t => (t.url || "").includes("/messages"))
      || tabs.find(t => (t.url || "").includes("/marketplace"))
      || tabs[0];
    if (!tab || tab.id == null) return;
    const claimed = await sbPatch(`closer_messages?id=eq.${row.id}&status=eq.queued`, { status: "sending" });
    if (!claimed || !claimed.length) return; // someone else took it
    await chrome.storage.local.set({
      luca_pending_delivery: { messageId: row.id, threadRef: row.thread_ref, body: row.body, tabId: tab.id, at: Date.now() }
    });
    if (key && (tab.url || "").includes("/t/" + key)) {
      // Poke — but demand an ACK (v2.1.35). A tab whose capture script
      // died (the classic case: the helper was updated while the tab
      // sat open) never answers; reloading that tab re-injects the
      // current script, which picks the pending delivery up from
      // storage on load. Without this, a dead tab silently eats the
      // reply until the 3-minute timeout fails it (seen live
      // 2026-10-25 on the first reply attempt).
      const acked = await new Promise(resolve => {
        let done = false;
        const timer = setTimeout(() => { if (!done) { done = true; resolve(false); } }, 6000);
        try {
          chrome.tabs.sendMessage(tab.id, { type: "AUTOLAUNCH_DELIVER_NOW" }, resp => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            resolve(!chrome.runtime.lastError && !!(resp && resp.accepted));
          });
        } catch (e) {
          if (!done) { done = true; clearTimeout(timer); resolve(false); }
        }
      });
      if (!acked) {
        try { await chrome.tabs.reload(tab.id); } catch (e) { /* the timeout sweep fails it honestly */ }
      }
    } else {
      await chrome.tabs.update(tab.id, { url: row.thread_ref });
    }
  } catch (e) { /* next tick retries */ } finally {
    outboundBusy = false;
  }
}

async function finishOutboundReply(messageId, ok, error) {
  const { luca_pending_delivery: pending } = await chrome.storage.local.get(["luca_pending_delivery"]);
  if (!pending || pending.messageId !== messageId) return;
  try {
    await sbPatch(`closer_messages?id=eq.${messageId}`, {
      status: ok ? "sent" : "failed",
      delivery_error: ok ? null : String(error || "unknown").slice(0, 200)
    });
  } catch (e) { /* best effort */ }
  await chrome.storage.local.remove(["luca_pending_delivery"]);
  checkOutboundReplies(); // chain the next queued reply, if any
}

function startOfTodayISO() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

async function todaysPostCount(userId) {
  const rows = await sbGet(
    `scraped_inventory?user_id=eq.${userId}` +
    `&marketplace_posted_at=gte.${encodeURIComponent(startOfTodayISO())}` +
    `&select=vin`
  );
  return rows.length;
}

// One settings fetch per claim cycle (v2.1.4): the daily post
// limit AND the Full Auto switch both live on user_settings.
// v2.1.42: the same fetch also carries the post pacing delay
// (post_delay_minutes) and the dealership identity (name/address)
// for the description's closing block — see header note 19.
// v2.1.43: it also carries include_stock for the description's
// Stock # line — see header note 20.
// v2.1.53: it also carries the intro-video preference trio
// (enabled / mode / selected id) — see header note 27.
// v2.1.55: it also carries share_to_feed for the post-success
// feed share — see header note 29. Opt-in: anything but an
// explicit true reads as off.
// v2.1.60: it also carries the one-active-helper lease
// (helper_lease_id / helper_lease_expires_at) — see header
// note 32. The claim cycle's gate reads them from THIS fetch;
// no extra round trip.
// v2.1.90: it also carries rep_display_name / rep_phone —
// the description contact line's pair (header note 45).
async function userSettings(userId) {
  const rows = await sbGet(
    `user_settings?user_id=eq.${userId}&select=daily_post_limit,full_auto_enabled,post_delay_minutes,dealership_name,dealership_address,rep_display_name,rep_phone,include_stock,rich_descriptions,intro_video_enabled,intro_video_mode,intro_selected_video_id,share_to_feed,helper_lease_id,helper_lease_expires_at`);
  const row = (rows && rows.length) ? rows[0] : {};
  return {
    limit: typeof row.daily_post_limit === "number" ? row.daily_post_limit : 10,
    fullAuto: row.full_auto_enabled === true,
    delayMinutes: (typeof row.post_delay_minutes === "number" && row.post_delay_minutes > 0)
      ? row.post_delay_minutes : 0,
    dealershipName: typeof row.dealership_name === "string" ? row.dealership_name.trim() : "",
    dealershipAddress: typeof row.dealership_address === "string" ? row.dealership_address.trim() : "",
    repName: typeof row.rep_display_name === "string" ? row.rep_display_name.trim() : "",
    repPhone: typeof row.rep_phone === "string" ? row.rep_phone.trim() : "",
    includeStock: row.include_stock === true,
    richDesc: row.rich_descriptions === true,
    introEnabled: row.intro_video_enabled === true,
    introMode: typeof row.intro_video_mode === "string" ? row.intro_video_mode : "selected",
    introSelectedId: typeof row.intro_selected_video_id === "string" ? row.intro_selected_video_id : null,
    shareToFeed: row.share_to_feed === true,
    leaseId: (typeof row.helper_lease_id === "string" && row.helper_lease_id)
      ? row.helper_lease_id : null,
    leaseExpiresAt: typeof row.helper_lease_expires_at === "string"
      ? row.helper_lease_expires_at : null
  };
}

// [PURE-INTRO-RESOLVE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Intro-video claim-time resolution (v2.1.53, header note 27):
// decide, from the settings trio and the user's video rows,
// which single video (if any) rides this post. Every non-answer
// is a NAMED skip — the caller logs it and posts exactly as
// before this feature existed. rng is injectable so the harness
// can pin 'random' mode; production passes Math.random. Any
// mode other than 'random' follows the app's default semantics
// ('selected'), exactly as the app's own reader normalizes it.
function resolveIntroVideo(settings, rows, rng) {
  if (!settings || settings.introEnabled !== true) {
    return { skip: "intro_disabled" };
  }
  const list = (Array.isArray(rows) ? rows : []).filter(r =>
    r && typeof r.video_url === "string" && r.video_url.trim());
  if (!list.length) return { skip: "intro_library_empty" };
  if (settings.introMode === "random") {
    const roll = (typeof rng === "function" ? rng : Math.random)();
    const idx = Math.min(list.length - 1, Math.max(0, Math.floor(roll * list.length)));
    const pick = list[idx];
    return { url: pick.video_url, videoId: pick.id || null, mode: "random" };
  }
  const wanted = settings.introSelectedId;
  if (!wanted) return { skip: "intro_no_selection" };
  const hit = list.find(r => r.id === wanted);
  if (!hit) return { skip: "intro_selected_missing" };
  return { url: hit.video_url, videoId: hit.id || null, mode: "selected" };
}
// [PURE-INTRO-RESOLVE-END]

// Claim-time wrapper (v2.1.53): fetch the user's intro-video
// rows ONLY when the preference is on (everyone else's claim
// path is untouched), resolve, and log the outcome. Any failure
// resolves to a named skip — never a throw into the claim loop.
async function introVideoForJob(userId, settings) {
  if (!settings || settings.introEnabled !== true) return null;
  try {
    const rows = await sbGet(
      `user_intro_videos?user_id=eq.${userId}&select=id,video_url&order=created_at.asc`);
    const resolved = resolveIntroVideo(settings, rows, Math.random);
    if (resolved.skip) {
      console.log(`[AutoLaunch] Intro video skipped at claim (${resolved.skip}).`);
      return null;
    }
    console.log(`[AutoLaunch] Intro video resolved at claim (mode ${resolved.mode}, video ${resolved.videoId}).`);
    return { url: resolved.url, videoId: resolved.videoId };
  } catch (e) {
    console.log("[AutoLaunch] Intro video skipped at claim (intro_resolve_failed).");
    return null;
  }
}

// [PURE-REEL-DECIDE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// VIN Reel claim-time decisions (v2.1.85, header note 40).
// v2.1.86 (header note 41): consumption gated on the
// form-verified attach; decideReelCompletionFlag added.
// decideReelAttach: given the car's LATEST reel row (the
// claim-gate lookup: user + vin, newest first), decide whether
// a reel rides this post. Only a ready reel with a URL
// attaches; every other state is a plain no, and the post
// runs exactly as before VIN Reels existed.
function decideReelAttach(reelRow) {
  if (!reelRow || reelRow.status !== "ready") return { attach: false };
  if (typeof reelRow.video_url !== "string" || !reelRow.video_url.trim()) {
    return { attach: false };
  }
  // Card-as-last-photo (v2.1.90, header note 45): the
  // end-card still the generator uploaded beside the mp4
  // rides qa.card_url; it joins the resolution so the
  // content side can append it as the listing's last
  // photo. Absent (a reel rendered before cards existed,
  // or the fail-open card upload skipped) -> null, and
  // the post's photo set is exactly the dealer set.
  const qa = (reelRow.qa && typeof reelRow.qa === "object") ? reelRow.qa : null;
  const cardUrl = (qa && typeof qa.card_url === "string" && qa.card_url.trim())
    ? qa.card_url.trim() : null;
  return {
    attach: true,
    url: reelRow.video_url,
    reelId: reelRow.id || null,
    source: reelRow.source === "poster" ? "poster" : "manual",
    cardUrl
  };
}
// decideReelConsume: given the reel record a job carried
// ({ id, source, attached, attachVerified } — claim time
// stamped the first three, the finish folds in the content
// side's verified read-back), decide whether a SUCCESSFUL
// post consumes the reel. Only a poster reel whose attach
// the form itself confirmed is consumed (v2.1.86, header
// note 41) — a manual reel is the user's own artifact and
// is never deleted, and a post that attached nothing — or
// cannot prove it attached — consumes nothing.
function decideReelConsume(reel) {
  if (!reel || reel.attached !== true) {
    return { consume: false, reason: "not_attached" };
  }
  if (reel.source !== "poster") {
    return { consume: false, reason: "manual_reel" };
  }
  if (reel.attachVerified !== true) {
    return { consume: false, reason: "attach_unverified" };
  }
  if (!reel.id) return { consume: false, reason: "no_reel_id" };
  return { consume: true, reelId: reel.id };
}
// reelAttachDiagFields (v2.1.87, header note 42): the
// note/detail pair filed for an unverified attach. The
// note leads with the 2.86 shape (compactDiagError leaves
// notes untruncated) and appends the self-diagnosing tail:
// the binding stage, every attempt's verdict (R = the
// pre-Publish repair; /ever = the form showed the clip at
// some point in the attempt; /sig = the processed
// signature fired without the counter), and the compact
// counter trace. The detail keeps the 2.86 download facts
// and adds the processing budget the size-scaled wait
// used, in seconds.
function reelAttachDiagFields(a) {
  const att = a || {};
  const verdicts = (Array.isArray(att.attemptLog) ? att.attemptLog : [])
    .map(t => `${t && t.stage === "repair" ? "R" : ""}${(t && t.n) || "?"}:` +
      `${(t && t.verdict) || "?"}${t && t.everAttached ? "/ever" : ""}` +
      `${t && t.signature ? "/sig" : ""}`)
    .join(",");
  let note = `attach_unverified attempts:${att.attempts || 0}` +
    ` skip:${att.skip || "none"}`;
  if (att.finalStage) note += ` final:${att.finalStage}`;
  if (verdicts) note += ` verdicts:${verdicts}`;
  if (att.trace) note += ` trace:${att.trace}`;
  let detail = `downloaded:${att.downloaded === true}` +
    ` blob_bytes:${att.blobSize || 0}`;
  if (att.budgetMs) detail += ` budget_s:${Math.round(att.budgetMs / 1000)}`;
  return { note, detail };
}
// decideReelCompletionFlag (v2.1.86): the reel_failed value a
// posted completion writes. null = the job carried no reel —
// write nothing, the completion stays byte-identical to the
// pre-reel shape. A carried reel writes the truth: false when
// its attach verified on the form, true when it did not.
function decideReelCompletionFlag(reel) {
  if (!reel || reel.attached !== true) return null;
  return reel.attachVerified === true ? false : true;
}
// [PURE-REEL-DECIDE-END]

// Claim-time wrapper (v2.1.85): fetch the car's latest reel
// ONLY for posts (the caller gates that), resolve, and log.
// Any failure resolves to null — never a throw into the claim
// loop, and never a held post: the producer's hold is what
// waits for reels, not the claim.
async function reelForJob(userId, vin) {
  try {
    const rows = await sbGet(
      `vin_reels?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}` +
      `&order=created_at.desc&limit=1&select=id,status,source,video_url,qa`);
    const d = decideReelAttach(rows && rows.length ? rows[0] : null);
    if (!d.attach) return null;
    console.log(`[AutoLaunch] VIN reel resolved at claim (${d.source} reel ${d.reelId}).`);
    return {
      url: d.url,
      reel: { id: d.reelId, source: d.source, attached: true, cardUrl: d.cardUrl || null }
    };
  } catch (e) {
    console.log("[AutoLaunch] VIN reel skipped at claim (reel_resolve_failed).");
    return null;
  }
}

// Newest completed-post stamp for this user (v2.1.42): the pacing
// gate's anchor. applyPosted stamps scraped_inventory.marketplace_
// posted_at at the moment a post completes, so the newest non-null
// value IS the last completed post — no separate state to maintain.
// Returns epoch ms, or null when the user has never posted or the
// lookup failed; callers treat null as "no hold" (fail open), so a
// flaky read can never wedge the queue behind a phantom delay.
async function lastPostedAt(userId) {
  try {
    const rows = await sbGet(
      `scraped_inventory?user_id=eq.${userId}` +
      `&marketplace_posted_at=not.is.null` +
      `&order=marketplace_posted_at.desc&select=marketplace_posted_at&limit=1`
    );
    const ts = rows && rows.length ? Date.parse(rows[0].marketplace_posted_at || "") : NaN;
    return isFinite(ts) ? ts : null;
  } catch (e) {
    return null;
  }
}

// Stock number for the job payload (v2.1.44, header note 21): the
// queue row's stamped stock_num wins; when it is empty/null/
// whitespace, fall back to the inventory row's stock_number (the
// row checkQueue already fetched by the job's VIN). Returns the
// car row unchanged when it already carries a usable stock_num
// or when no source has one — the description then simply omits
// the Stock # line, exactly as before this fix.
function jobCarWithStock(carRow, queueItem) {
  if (!carRow) return carRow;
  const usable = v => (v != null && String(v).trim()) ? String(v).trim() : "";
  if (usable(carRow.stock_num)) return carRow;
  const stock = usable(queueItem && queueItem.stock_num) || usable(carRow.stock_number);
  if (!stock) return carRow;
  return Object.assign({}, carRow, { stock_num: stock });
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
const jitter = (min, max) => sleep(min + Math.random() * (max - min));

// Job-slot reconciliation (v2.1.8, header note 15). A claimed job
// may legitimately run long — confirm mode waits up to 10 minutes
// for a human Publish click, and the v2.1.7 post-publish
// verification adds up to ~4 minutes of Selling-page rescans —
// but no legitimate run approaches 45 minutes, so a "processing"
// row older than that has no living content script behind it.
const JOB_STALE_MS = 45 * 60 * 1000;
// Price updates are phase-bounded (120s editor watchdog plus
// bounded scans — well under 8 minutes end to end), so a
// processing update row older than this is wedged, not working:
// fail it early with the orphan diagnostics instead of holding
// the slot for the generic 45 minutes (live wedge 2026-11-03).
// attach_video does NOT belong to this class (v2.1.95): its
// editor flow legitimately runs long — the v2.1.94 ingest
// budget alone reaches 900s, plus the dwell and a possible
// second incarnation — so an attach shares the generic
// 45-minute limit with posts. The 8-minute class cost a live
// attach its row on 2026-11-09 (PT10582, orphaned at ~10 min
// while its editor was still working).
const UPDATE_JOB_STALE_MS = 8 * 60 * 1000;
// Orphan recovery (v2.52, header note 26): how long a stale POST
// row's recovery scan may run before the watchdog falls back to
// the blind fail. The scan's own budget is ~4 minutes of rescans
// (verifyPublished's wall-clock cap) plus render patience — six
// minutes leaves honest headroom without wedging the slot.
const ORPHAN_RECOVERY_TIMEOUT_MS = 6 * 60 * 1000;
const SELLING_PAGE_URL = "https://www.facebook.com/marketplace/you/selling";
const TERMINAL_ROW_STATUSES = ["posted", "failed", "completed"];

// Returns true when the stored job slot must be KEPT (a run is
// genuinely in flight, or this cycle could not verify either
// way), false when the slot was dead and has been cleared — the
// caller then falls through and claims fresh work in the same
// pass. Runs at most one lightweight queue-row read per cycle,
// and only when a slot is occupied.
// Arm a stale POST job for orphan-recovery verification and
// open the Selling tab that runs the scan (v2.52, header
// note 26). The stored job gains verifyPublished with
// orphanRecovery set — the content script's existing routing
// takes it from there — plus an orphanRecovery bookkeeping
// record the watchdog reads on later cycles. Returns false
// when the tab could not be opened; the caller then fails
// blind, exactly as before this fix.
async function startOrphanRecovery(job) {
  try {
    const nowIso = new Date().toISOString();
    const armed = Object.assign({}, job, {
      verifyPublished: { tries: 0, startedAt: nowIso, orphanRecovery: true },
      orphanRecovery: { requestedAt: nowIso, tabId: null }
    });
    await chrome.storage.local.set({ current_posting_job: armed });
    const tab = await chrome.tabs.create({ active: false, url: SELLING_PAGE_URL });
    if (!tab || tab.id == null) return false;
    try {
      await chrome.tabs.update(tab.id, { autoDiscardable: false });
    } catch (e) { /* non-fatal: the scan still runs, just unprotected */ }
    const { current_posting_job: cur } =
      await chrome.storage.local.get(["current_posting_job"]);
    if (cur && cur.queueId === job.queueId && cur.orphanRecovery) {
      cur.orphanRecovery.tabId = tab.id;
      await chrome.storage.local.set({ current_posting_job: cur });
    }
    console.log(`[AutoLaunch] Orphan recovery: verifying queue item ${job.queueId} on the Selling page before failing it.`);
    return true;
  } catch (e) {
    return false;
  }
}

// Job liveness (v2.54, header note 28): the content script
// asks, before filling, whether the job its tab loaded from
// storage is still this worker's live job. Definitive-only:
// "no" requires positive evidence — the slot holds a
// different job (or no job), the queue row is gone, or the
// row already sits in a state reconcileActiveJob would call
// dead (terminal, or pending again). A matching slot over a
// processing row is live, and ANY failure to check (storage
// or database) answers live too — uncertainty never blocks.
async function jobLivenessVerdict(queueId) {
  if (!queueId) return { live: true };
  let slot = null;
  try {
    const stored = await chrome.storage.local.get(["current_posting_job"]);
    slot = stored && stored.current_posting_job;
  } catch (e) {
    return { live: true };
  }
  if (!slot || slot.queueId !== queueId) {
    return { live: false, reason: "slot_moved_on" };
  }
  let rows;
  try {
    rows = await sbGet(`auto_posting_queue?id=eq.${queueId}&select=id,status`);
  } catch (e) {
    return { live: true };
  }
  const row = Array.isArray(rows) && rows.length ? rows[0] : null;
  if (!row) return { live: false, reason: "row_missing" };
  if (TERMINAL_ROW_STATUSES.includes(row.status)) {
    return { live: false, reason: "row_" + row.status };
  }
  if (row.status === "pending") {
    return { live: false, reason: "row_pending" };
  }
  return { live: true };
}

async function reconcileActiveJob(job) {
  const queueId = job && job.queueId;
  if (!queueId) {
    // A slot with no queue id can never be finished or verified —
    // it is dead by construction.
    await chrome.storage.local.remove(["current_posting_job"]);
    console.log("[AutoLaunch] Job slot cleared (slot carried no queue id).");
    return false;
  }
  let rows;
  try {
    rows = await sbGet(`auto_posting_queue?id=eq.${queueId}&select=id,status`);
  } catch (err) {
    // The lookup itself failed (network, or auth — sbFetch has
    // already recorded a session expiry if it was one). Believe
    // nothing, change nothing: keep the slot and let this cycle
    // skip, exactly as conservative as the rest of the worker.
    return true;
  }
  const row = Array.isArray(rows) && rows.length ? rows[0] : null;
  const clearSlot = async reason => {
    await chrome.storage.local.remove(["current_posting_job"]);
    console.log(`[AutoLaunch] Job slot cleared (${reason}) for queue item ${queueId}.`);
  };
  if (!row) {
    // The user cancelled the job in the app (the queue row is
    // deleted there) — the run it belonged to can never report
    // back, so the slot it wedged is dead.
    await clearSlot("queue row no longer exists");
    return false;
  }
  if (TERMINAL_ROW_STATUSES.includes(row.status)) {
    await clearSlot(`queue row already ${row.status}`);
    return false;
  }
  if (row.status === "pending") {
    // Re-queued externally (or the claim write never landed):
    // the stored run is dead either way. Clearing the slot lets
    // THIS cycle's claim pass pick the row up fresh below.
    await clearSlot("queue row is pending again");
    return false;
  }
  if (row.status === "processing") {
    const claimedAtMs = Date.parse(job.claimedAt || "");
    // A claim that cannot prove it is fresh (no readable
    // claimedAt) does not get to wedge the queue forever.
    // Phase watchdog for price updates (v2.1.73): the edit and
    // verify phases run inside a Facebook tab whose script can
    // stall without settling (soft-navigation handoff, frozen
    // timers — the 2026-11-03 E2E wedges). The phases stamp
    // stageAt when they start; if a phase runs past 150s (past
    // its own 120s watchdog) with the row still processing,
    // reload the job tab from OUTSIDE the page — a fresh script
    // boots and resumes from the stage marker. At most 2 reloads
    // per phase; beyond that the stale path below settles it.
    // v2.1.88: the same watchdog serves attach_video jobs,
    // whose stage marker rides job.attachVideo in the same
    // shape (stages "edit"/"verify").
    const phaseKey = job.action === "update_price" ? "priceUpdate"
      : job.action === "attach_video" ? "attachVideo" : null;
    const pu = phaseKey ? (job[phaseKey] || {}) : {};
    if (phaseKey &&
        (pu.stage === "edit" || pu.stage === "verify") &&
        job.tabId != null) {
      if (job.phaseReloadStage !== pu.stage) {
        job.phaseReloadStage = pu.stage;
        job.phaseReloads = 0;
      }
      const stageAgeMs = Date.now() - (Date.parse(pu.stageAt || "") || 0);
      if (isFinite(stageAgeMs) && stageAgeMs > 150 * 1000 &&
          (job.phaseReloads || 0) < 2) {
        try {
          job.phaseReloads = (job.phaseReloads || 0) + 1;
          job[phaseKey] = Object.assign({}, pu,
            { stageAt: new Date().toISOString() });
          await chrome.storage.local.set({ current_posting_job: job });
          await chrome.tabs.reload(job.tabId);
          console.warn("[AutoLaunch] " +
            (phaseKey === "priceUpdate" ? "Price-update" : "Video-attach") +
            " phase " + pu.stage +
            " stalled — reloaded the job tab (reload " +
            job.phaseReloads + " of 2).");
        } catch (e) { /* tab gone — the stale path settles it */ }
        return true;
      }
    }
    const ageMs = isFinite(claimedAtMs) ? Date.now() - claimedAtMs : Infinity;
    const staleLimitMs = job.action === "update_price"
      ? UPDATE_JOB_STALE_MS : JOB_STALE_MS;
    if (ageMs <= staleLimitMs) return true; // genuinely running
    // Orphan recovery (v2.52, header note 26): a stale POST row
    // is verified against Facebook BEFORE it may be failed —
    // the Prius lesson (2026-10-28) is that "processing" past
    // the watchdog can mean the Publish already landed and
    // only the bookkeeping died. The recovery scan settles the
    // row through the ordinary finish messages; while it is in
    // flight the slot is KEPT (returning true). Only a scan
    // that cannot start, or that produces no verdict within
    // ORPHAN_RECOVERY_TIMEOUT_MS, falls through to the blind
    // fail below — with the recovery outcome in its detail.
    let recoveryNote = "";
    if (job.action === "post") {
      const rec = job.orphanRecovery;
      if (!rec) {
        if (await startOrphanRecovery(job)) return true;
        recoveryNote = " Orphan recovery scan could not be started (no Selling tab) — failed blind.";
      } else {
        const recAgeMs = Date.now() - (Date.parse(rec.requestedAt || "") || 0);
        if (isFinite(recAgeMs) && recAgeMs <= ORPHAN_RECOVERY_TIMEOUT_MS) {
          return true; // scan in flight — its finish settles the row
        }
        recoveryNote = " Orphan recovery scan produced no verdict within 6 min — failed blind.";
      }
    }
    // Orphaned: still "processing" far beyond any legitimate
    // run, so the content script is certainly dead (its tab was
    // closed, or it crashed). Fail the row honestly — the
    // diagnostics ride error_message like every other failure —
    // clear the slot, and let the cycle continue to fresh work.
    console.warn(`[AutoLaunch] Job orphaned: queue item ${queueId} still processing ${Math.round(ageMs / 60000)} min after claim — failing it and clearing the slot.`);
    const errorMessage = compactDiagError([{
      field: "Job",
      note: "job_orphaned",
      detail: `claimed ${job.claimedAt || "unknown"}, still "processing" after 45+ min — content script presumed dead (tab closed or crashed).${recoveryNote}`
    }]);
    try {
      await applyFailed(queueId, errorMessage);
    } catch (err) {
      if (err instanceof SbAuthError) {
        // Same stash-and-replay as finishJobFailed, so the
        // failure lands when the next fresh token arrives instead
        // of being lost with the dead token.
        await chrome.storage.local.set({
          autolaunch_pending_finish: { outcome: "failed", queueId, errorMessage }
        });
      } else {
        throw err;
      }
    }
    await logFailure(queueId, "job_orphaned");
    await clearSlot("orphaned processing row failed");
    return false;
  }
  // A status vocabulary this build does not know: change nothing.
  return true;
}

let isChecking = false;

// [PURE-PRICE-UPDATE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Claim-time basis validation for a price-update job (v2.1.62,
// header note 34): the job was queued for ONE specific drift —
// the listing showed update_from_price, the dealer's price was
// the row's price. At claim time the inventory row is re-read,
// and the job may only run while that exact drift still exists:
// the car is still posted, the stamped posted price still
// equals the job's FROM price, and the current price still
// equals the job's TO price. Any mismatch means the world moved
// (a price update already landed, the listing came down, the
// dealer price moved again) — the row fails untouched with a
// named reason and the next sync's drift pass re-queues the
// truth. Pure: (queue item, inventory row) -> verdict.
function priceUpdateClaimGate(item, carRow) {
  if (!item || item.action !== "update_price") {
    return { ok: false, reason: "not_a_price_update" };
  }
  const fromPrice = Number(item.update_from_price);
  const toPrice = Number(item.price);
  if (!isFinite(fromPrice) || !isFinite(toPrice) ||
      fromPrice <= 0 || toPrice <= 0 || fromPrice === toPrice) {
    return { ok: false, reason: "price_update_payload_invalid" };
  }
  if (!carRow) {
    return { ok: false, reason: "inventory_row_missing" };
  }
  if (!carRow.marketplace_posted_at) {
    return { ok: false, reason: "listing_not_posted" };
  }
  if (Number(carRow.marketplace_posted_price) !== fromPrice) {
    return { ok: false, reason: "price_basis_changed" };
  }
  if (Number(carRow.price) !== toPrice) {
    return { ok: false, reason: "price_basis_changed" };
  }
  return { ok: true, fromPrice, toPrice };
}
// [PURE-PRICE-UPDATE-END]

// [PURE-CLAIM-BEGIN] — extracted and unit-exercised by the
// test harness; keep free of DOM/chrome references.
// The claim ACTION ALLOWLIST (v2.1.88, header note 43):
// the actions this build knows how to run. checkQueue
// selects work ONLY through claimActionOf: a row whose
// action is anything else — a future producer's new verb,
// a hand-written row — is NEVER claimed, and in particular
// never claimed as a post (the pre-2.88 selection treated
// every unrecognized action as a post). A row with no
// action (or an empty one) is a post: that is the queue's
// founding shape.
const CLAIM_KNOWN_ACTIONS = ["post", "delete", "share", "update_price", "attach_video"];
function claimActionOf(item) {
  const a = item && typeof item.action === "string" && item.action
    ? item.action : "post";
  return CLAIM_KNOWN_ACTIONS.indexOf(a) >= 0 ? a : null;
}
// [PURE-CLAIM-END]

// [PURE-ATTACH-VIDEO-BEGIN] — extracted and unit-exercised
// by the test harness; keep free of DOM/chrome references.
// Claim-time basis validation for an attach_video job
// (v2.1.88, header note 43), the price-update gate's twin:
// the job exists to put a video on ONE live listing — the
// car must still be posted, and its stamped posted price
// must still equal the price stamped on the row (the
// strict matcher's target). Any drift means the world
// moved — fail the row untouched with a named reason.
// Pure: (queue item, inventory row) -> verdict.
function attachVideoClaimGate(item, carRow) {
  if (!item || item.action !== "attach_video") {
    return { ok: false, reason: "not_an_attach_job" };
  }
  const postedPrice = Number(item.price);
  if (!isFinite(postedPrice) || postedPrice <= 0) {
    return { ok: false, reason: "attach_payload_invalid" };
  }
  if (!carRow) {
    return { ok: false, reason: "inventory_row_missing" };
  }
  if (!carRow.marketplace_posted_at) {
    return { ok: false, reason: "listing_not_posted" };
  }
  if (Number(carRow.marketplace_posted_price) !== postedPrice) {
    return { ok: false, reason: "attach_price_basis_changed" };
  }
  return { ok: true, postedPrice };
}
// decideAttachQueue (v2.1.88): given the reel record a
// POST completion folded (claim time stamped { id, source,
// attached }, the finish folded in attachVerified), decide
// whether the completion queues the edit-flow attach job.
// Exactly the completions whose poster reel was attached
// but NOT verified queue one — a verified attach consumed
// its reel (nothing left to attach), a manual reel is out
// of scope (never queued, never consumed), and a job that
// carried no reel has nothing to queue for.
function decideAttachQueue(reel) {
  if (!reel || reel.attached !== true) {
    return { queue: false, reason: "no_reel_attached" };
  }
  if (reel.source !== "poster") {
    return { queue: false, reason: "manual_reel" };
  }
  if (reel.attachVerified === true) {
    return { queue: false, reason: "attach_verified" };
  }
  return { queue: true };
}
// [PURE-ATTACH-VIDEO-END]

async function checkQueue() {
  if (isChecking) return;
  isChecking = true;
  try {
    const {
      autolaunch_user_id: userId,
      autolaunch_access_token: accessToken,
      autolaunch_session_expired: sessionExpired,
      current_posting_job: activeJob
    } = await chrome.storage.local.get([
      "autolaunch_user_id", "autolaunch_access_token",
      "autolaunch_session_expired", "current_posting_job"
    ]);
    if (!userId) return;               // not signed in to AutoLaunch yet
    if (sessionExpired) return;        // dead token — wait for a fresh one via the bridge
    if (!accessToken) {                // bridge hasn't delivered a session yet
      await noteWaitingForLogin();
      return;
    }
    if (activeJob) {
      // One car at a time, always — but verify the stored job is
      // still a live run before honouring the slot (v2.1.8): a
      // run stopped out-of-band (row cancelled in the app, tab
      // closed) never sends its finish, and an unreconciled slot
      // would wedge every future claim behind it, silently.
      const slotKept = await reconcileActiveJob(activeJob);
      if (slotKept) return;
      // The slot was dead and has been cleared — fall through and
      // claim fresh work in this same pass.
    }

    const settings = await userSettings(userId);

    // One-active-helper lease (v2.1.60, header note 32): only
    // ONE helper instance per account may claim. The lease rode
    // this cycle's settings fetch — no extra round trip. Foreign
    // + unexpired -> claim nothing and stay dormant (the cycle
    // keeps polling; the lease may expire or be yielded).
    // Otherwise renew — ONE PATCH, expiry now + TTL — and claim
    // as before. A failed renew throws into the cycle's catch:
    // no claim happens on an unproven lease (fail closed). The
    // gate sits AFTER job-slot reconciliation on purpose: the
    // lease gates NEW claims only, never the bookkeeping of a
    // job already in flight.
    const myInstanceId = await getOrCreateInstanceId();
    if (helperLeaseDecision(settings.leaseId, settings.leaseExpiresAt, myInstanceId, Date.now()) === "foreign") {
      console.log("[AutoLaunch] Another computer holds this account's helper lease — standing by, no claims this cycle.");
      return;
    }
    await sbPatch(`user_settings?user_id=eq.${userId}`, {
      helper_lease_id: myInstanceId,
      helper_lease_expires_at: new Date(Date.now() + HELPER_LEASE_TTL_MS).toISOString()
    });

    // The claim set (v2.1.4): Marketplace POST rows (target_channel
    // 'marketplace') and Facebook DELETE rows (target_channel
    // 'facebook', action 'delete') — the jobs this helper runs.
    // v2.1.55 adds Facebook SHARE rows (target_channel 'facebook',
    // action 'share') to the same set. v2.1.62 adds Facebook
    // PRICE UPDATE rows (action 'update_price') the same way.
    // Other channels' rows belong to other workers; never touch them.
    const queueItems = await sbGet(
      `auto_posting_queue?user_id=eq.${userId}&status=eq.pending` +
      `&awaiting_reel=eq.false` +
      `&target_channel=in.(marketplace,facebook)&order=created_at.asc&limit=5`
    );
    if (!queueItems.length) return;

    // Daily safety limit — enforced here too, not just in the UI,
    // and it gates POSTS only: a removal is not a post, and being at
    // the cap must never strand a listing the user asked to take down.
    let atLimit = false;
    if (settings.limit < 999) {
      const postedToday = await todaysPostCount(userId);
      atLimit = postedToday >= settings.limit;
      if (atLimit) {
        console.log(`[AutoLaunch] Daily limit reached (${postedToday}/${settings.limit}). Posts wait; deletes, shares and price updates still run.`);
      }
    }
    // Post pacing (v2.1.42, header note 19): post_delay_minutes is
    // the minimum gap between a COMPLETED post and claiming the
    // next POST row. Deletes are exempt, exactly like the daily
    // limit — pacing spaces posts, never removals. No configured
    // delay (0) means no gate; a missing last-post stamp (never
    // posted, or the lookup failed) also means no gate.
    // v2.1.88: the some() reads through the claim allowlist —
    // only a claimable POST can hold the cycle for pacing;
    // an unknown action never triggers the lookup.
    let pacingHeld = false;
    if (settings.delayMinutes > 0 && queueItems.some(q => claimActionOf(q) === "post")) {
      const lastPost = await lastPostedAt(userId);
      if (lastPost !== null) {
        const sinceMin = (Date.now() - lastPost) / 60000;
        if (sinceMin < settings.delayMinutes) {
          pacingHeld = true;
          console.log(`[AutoLaunch] Post pacing: last post ${Math.floor(sinceMin)} min ago; holding posts ~${Math.ceil(settings.delayMinutes - sinceMin)} more min (delay ${settings.delayMinutes} min). Deletes, shares and price updates still run.`);
        }
      }
    }
    let item = null;
    let itemAction = null;
    for (const q of queueItems) {
      // The claim ACTION ALLOWLIST (v2.1.88, header note 43):
      // only actions this build knows are selectable at all.
      // An unknown action is skipped — NEVER claimed as a
      // post — and the skip is logged so a future producer's
      // row is visible in the console instead of silently
      // becoming a listing.
      const a = claimActionOf(q);
      if (a === null) {
        console.warn(`[AutoLaunch] Queue row ${q.id} carries unknown action "${q.action}" — not claimed (allowlist).`);
        continue;
      }
      if (a !== "post") { item = q; itemAction = a; break; }
      if (!atLimit && !pacingHeld) { item = q; itemAction = "post"; break; }
    }
    if (!item) return; // only posts waiting, and the cap (or pacing) says wait
    const isDelete = itemAction === "delete";
    const isShare = itemAction === "share";
    // Price updates (v2.1.62, header note 34) ride the delete/share
    // exemptions everywhere below: not a post — never capped, never
    // paced, never photo-gated, never intro-video'd.
    const isUpdatePrice = itemAction === "update_price";
    // Edit-flow video attach (v2.1.88, header note 43): the
    // same exemptions, for the same reason — it edits a live
    // listing; it does not post one.
    const isAttachVideo = itemAction === "attach_video";

    const cars = await sbGet(
      `scraped_inventory?vin=eq.${encodeURIComponent(item.vin)}&user_id=eq.${userId}&limit=1`
    );
    let carRow = cars.length ? cars[0] : null;
    if (isUpdatePrice) {
      // Basis validation (v2.1.62, header note 34): the exact
      // drift this row was queued for must still exist — the car
      // still posted, its stamped posted price still the row's
      // FROM price, its current price still the row's TO price.
      // Anything else means the world moved; fail the row
      // untouched (the next sync re-queues the truth) rather
      // than editing a listing on stale instructions.
      const gate = priceUpdateClaimGate(item, carRow);
      if (!gate.ok) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, gate.reason);
        console.log(`[AutoLaunch] Price update for VIN ${item.vin} not claimed: ${gate.reason}.`);
        return;
      }
    }
    let attachReelHit = null;
    if (isAttachVideo) {
      // Basis validation (v2.1.88, header note 43), the price
      // gate's twin: the car still posted, its stamped posted
      // price still the row's price — and a ready POSTER reel
      // must still exist for the VIN (the completion that
      // queued this row left it ready; anything else means
      // the world moved). Fail the row untouched on any miss.
      const gate = attachVideoClaimGate(item, carRow);
      if (!gate.ok) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, gate.reason);
        console.log(`[AutoLaunch] Video attach for VIN ${item.vin} not claimed: ${gate.reason}.`);
        return;
      }
      const hit = await reelForJob(userId, item.vin);
      if (!hit || !hit.reel || hit.reel.source !== "poster") {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, "attach_reel_not_ready");
        console.log(`[AutoLaunch] Video attach for VIN ${item.vin} not claimed: no ready poster reel.`);
        return;
      }
      attachReelHit = hit;
    }
    if (!carRow && !isDelete && !isShare) {
      // Queue row points at a car that no longer exists: fail it loudly
      // instead of leaving it pending forever.
      await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
      await logFailure(item.id, "inventory_row_missing");
      return;
    }
    if (!carRow && (isDelete || isShare)) {
      // A delete can outlive its inventory row — by design: the
      // delete-job contract is producer-agnostic (the Remove button
      // today; an inventory-lifecycle auto-removal rule later, which
      // fires exactly when the car LEAVES inventory). The payload
      // therefore falls back to the queue row's own year/make/model
      // AND price, which producers stamp on the row at insert. Only a
      // row stamped without a price leaves the matcher nothing strict
      // to match — and then it refuses (listing_not_found) rather
      // than guessing at a twin.
      carRow = {
        vin: item.vin,
        year: item.year != null ? item.year : null,
        make: item.make || null,
        model: item.model || null,
        stock_num: item.stock_num || null,
        price: item.price != null ? Number(item.price) : null
      };
    }
    if (carRow && (isDelete || isShare) && carRow.price == null && item.price != null) {
      // Inventory row exists but carries no price; the row's stamped
      // price is the better evidence for the strict match.
      carRow = Object.assign({}, carRow, { price: Number(item.price) });
    }

    // NO-PHOTO RULE (mirrors hasRealPhoto in the web app): a vehicle with
    // no real photos is never posted — its photos may have vanished after
    // it was queued. Fail the row loudly, same as a missing car, instead
    // of handing a photo-less listing to Facebook. POSTS ONLY: a delete
    // removes a listing, and a car whose photos vanished is exactly the
    // car whose listing should come down.
    if (!isDelete && !isShare && !isUpdatePrice && !isAttachVideo) {
      // Fallback placeholders are never real photos: the old hotlinked
      // Unsplash URL (rows stored before 2.1.11 may still carry it), the
      // local fallback asset in both the absolute Pages form a stored
      // row could carry and the relative form the app now uses.
      const FALLBACK_PHOTOS = [
        "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800&auto=format&fit=crop&q=80",
        "https://mdemoss-bdc.github.io/AutoLaunch/luna-rebuild/assets/no-photo.png",
        "assets/no-photo.png"
      ];
      const usablePhoto = u => {
        if (!u || typeof u !== "string") return false;
        let s = u.trim();
        if (s.startsWith("//")) s = "https:" + s;
        return /^https?:\/\//i.test(s) && !s.includes("/static/") && !FALLBACK_PHOTOS.includes(s);
      };
      const hasPhoto = usablePhoto(carRow.image_url) ||
        (Array.isArray(carRow.custom_photo_urls) && carRow.custom_photo_urls.some(usablePhoto));
      if (!hasPhoto) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, "no_photos");
        return;
      }
    }

    // Conditional claim: only succeeds while the row is still pending.
    const claimed = await sbPatch(
      `auto_posting_queue?id=eq.${item.id}&status=eq.pending`,
      { status: "processing" }
    );
    if (!claimed.length) return; // someone/something else took it

    // Claim-time stamp check (v2.52, header note 26): the car
    // already carries marketplace_posted_at — an earlier run
    // reached Facebook and only its bookkeeping was lost (the
    // false-failure class behind the 2026-10-28 Passport
    // duplicates). Complete the row as posted WITHOUT storing
    // a job or opening a tab, and WITHOUT touching the stamp:
    // the existing value is the truth. The row's executed_at
    // fingerprints this path (applyPosted rows carry none).
    if (!isDelete && !isShare && !isUpdatePrice && !isAttachVideo && carRow.marketplace_posted_at) {
      await sbPatch(`auto_posting_queue?id=eq.${item.id}`,
        { status: "posted", executed_at: new Date().toISOString() });
      console.log(`[AutoLaunch] already_posted_at_claim: queue item ${item.id} (VIN ${item.vin}) already carries marketplace_posted_at ${carRow.marketplace_posted_at} — completed without posting.`);
      return;
    }

    const jobPayload = {
      queueId: item.id,
      userId,
      car: jobCarWithStock(carRow, item),
      action: isDelete ? "delete" : isShare ? "share" : isUpdatePrice ? "update_price" : isAttachVideo ? "attach_video" : "post",
      fullAuto: settings.fullAuto,
      dealershipName: settings.dealershipName,
      dealershipAddress: settings.dealershipAddress,
      // Rep contact pair (v2.1.90, header note 45): carried
      // exactly like the dealership identity; both composers
      // append the closing line only when both are present.
      repName: settings.repName,
      repPhone: settings.repPhone,
      includeStock: settings.includeStock,
      // Rich descriptions (v2.1.98, header note 51): the
      // account switch, carried exactly like includeStock.
      richDesc: settings.richDesc === true,
      shareToFeed: settings.shareToFeed === true,
      // Share details text (v2.1.56, header note 30): the row's
      // share_text rides SHARE jobs only; the content script
      // places it in the share composer before confirming.
      // Absent (a pre-column row) the job carries "" and the
      // share fails honestly rather than posting bare.
      shareText: isShare && typeof item.share_text === "string" ? item.share_text : "",
      // Price update (v2.1.62, header note 34): the FROM price
      // (what the listing still shows — the strict-match target
      // on the Selling page) and the TO price (what the editor
      // sets), carried only on update_price jobs; the basis gate
      // above has already proven both against the fresh
      // inventory row.
      updateFromPrice: isUpdatePrice ? Number(item.update_from_price) : null,
      updateToPrice: isUpdatePrice ? Number(item.price) : null,
      // The queue row's stamped price (v2.1.62): the price a post
      // publishes with, written to the inventory row as
      // marketplace_posted_price when the post completes.
      queuePrice: item.price != null ? Number(item.price) : null,
      // Edit-flow video attach (v2.1.88, header note 43): the
      // POSTED price (the strict matcher's target — the
      // inventory row's current price may already have moved)
      // and the resolved poster reel, carried only on
      // attach_video jobs; the claim gate above has already
      // proven both against the fresh rows.
      attachPostedPrice: isAttachVideo ? Number(item.price) : null,
      attachReel: attachReelHit
        ? { url: attachReelHit.url, reelId: attachReelHit.reel.id } : null,
      claimedAt: new Date().toISOString()
    };
    // Listing-ID memory (2.91 build): the stored Facebook
    // listing ID for this VIN rides update_price and
    // attach_video jobs only, so their listing phases can
    // navigate straight to the listing's editor when an
    // editor-URL pattern is known. Absent (never harvested,
    // or cleared after a failed attempt) the job runs
    // exactly as before.
    if (isUpdatePrice || isAttachVideo) {
      const listingMem = await listingIdMemoryFor(item.vin);
      if (listingMem) jobPayload.listingMemory = listingMem;
    }
    // Intro video (v2.1.53, header note 27): resolved at claim
    // time and carried on the job; posts only — a delete has no
    // composer to attach to. Absent = the post runs exactly as
    // before this version.
    if (!isDelete && !isShare && !isUpdatePrice && !isAttachVideo) {
      // VIN reel (v2.1.85, header note 40): a ready reel for
      // this car replaces the intro video for this post — it
      // rides the same job slot the content side already
      // attaches from. No ready reel: the intro resolution
      // runs exactly as before.
      const reelHit = await reelForJob(userId, item.vin);
      if (reelHit) {
        jobPayload.introVideo = { url: reelHit.url, videoId: null };
        jobPayload.reel = reelHit.reel;
      } else {
        const intro = await introVideoForJob(userId, settings);
        if (intro) jobPayload.introVideo = intro;
      }
    }
    await chrome.storage.local.set({ current_posting_job: jobPayload });

    await jitter(1500, 4000); // human pacing, never machine-gun tabs
    // Background-tab rule (v2.1.12, extended v2.1.13): EVERY job now
    // works in an inactive tab so the helper never pulls the user
    // away from what they are doing (and the user browsing elsewhere
    // can't disturb the form). v2.1.12 kept confirm-mode posts in
    // front because a human must click Publish; Matthew overruled
    // that after watching his son's test — the filled tab simply
    // waits in the background with its review banner, and the user
    // clicks over to it when they are ready to publish.
    // v2.1.76 fronted scan tabs in this window and v2.1.77
    // moved them to a helper window (header notes 35/37);
    // both mechanisms are REMOVED in v2.1.78 (header
    // note 39): a scan no longer needs its page rendered —
    // the content side renders the target card through the
    // Selling list's own search (content.js header note 38)
    // — so every job's tab is created the same plain way
    // again, scan jobs included.
    const jobUrl = (isDelete || isShare || isUpdatePrice || isAttachVideo)
      ? "https://www.facebook.com/marketplace/you/selling"
      : "https://www.facebook.com/marketplace/create/vehicle";
    const jobTab = await chrome.tabs.create({ active: false, url: jobUrl });
    if (jobTab && jobTab.id != null && chrome.tabs.update) {
      try {
        // A background tab must not be discarded by Memory Saver
        // while the content script is mid-run.
        await chrome.tabs.update(jobTab.id, { autoDiscardable: false });
      } catch (e) { /* non-fatal: the job still runs, just unprotected */ }
    }
    // Record the tab THIS worker opened for THIS job (note 14):
    // a successful finish closes exactly that tab ~4s after the
    // success banner lands. Written as a follow-up merge because
    // the job record was stored (and the pacing jitter spent)
    // before the tab existed.
    if (jobTab && jobTab.id != null) {
      const { current_posting_job: j } =
        await chrome.storage.local.get(["current_posting_job"]);
      if (j && j.queueId === item.id) {
        j.tabId = jobTab.id;
        await chrome.storage.local.set({ current_posting_job: j });
      }
    }
  } catch (err) {
    console.error("[AutoLaunch] Queue check error:", err);
  } finally {
    isChecking = false;
  }
}

// --- Photo relay --------------------------------------------------------
// The content script (on facebook.com) cannot fetch dealer photo URLs
// itself — page CORS. This worker can: extension fetches backed by host
// permissions are not page-CORS-bound. Returns the bytes base64-encoded
// (chunked conversion — String.fromCharCode on a whole 15MB buffer would
// blow the argument limit) with the content type; every failure is a
// structured { ok:false, error } so the content script can fall through
// to the photo-proxy and, failing that, the honest job failure.
const PHOTO_MAX_BYTES = 15 * 1024 * 1024; // ~15MB — dealer photos are ~50KB

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}

async function fetchPhotoForContent(url) {
  if (!url || typeof url !== "string" || !/^https?:\/\//i.test(url)) {
    return { ok: false, error: "photo_url_not_http" };
  }
  let res;
  try {
    res = await fetch(url);
  } catch (e) {
    return { ok: false, error: "photo_fetch_threw" };
  }
  if (!res.ok) return { ok: false, error: `photo_http_${res.status}` };
  const contentType = res.headers.get("content-type") || "";
  if (contentType && !contentType.toLowerCase().startsWith("image/")) {
    return { ok: false, error: "photo_not_an_image" };
  }
  const buffer = await res.arrayBuffer();
  if (!buffer.byteLength) return { ok: false, error: "photo_empty" };
  if (buffer.byteLength > PHOTO_MAX_BYTES) {
    return { ok: false, error: "photo_too_large" };
  }
  return {
    ok: true,
    base64: arrayBufferToBase64(buffer),
    contentType: contentType || "image/jpeg"
  };
}

// --- Video relay (v2.1.53, header note 27) ----------------------
// The intro-video twin of the photo relay above: the content
// script cannot fetch the storage URL itself (page CORS), this
// worker can. The app's own upload cap is 50 MB, so the relay
// cap matches it; anything larger is a structured refusal, and
// the content script skips the attach and posts without it.
const VIDEO_MAX_BYTES = 50 * 1024 * 1024; // the app's intro upload cap
const VIDEO_FETCH_TIMEOUT_MS = 30 * 1000; // abort budget (v2.54, note 28)

async function fetchVideoForContent(url) {
  if (!url || typeof url !== "string" || !/^https?:\/\//i.test(url)) {
    return { ok: false, error: "video_url_not_http" };
  }
  // Bounded (v2.54, header note 28): the fetch and the body
  // read share one 30s abort budget. In 2.53 this was a bare
  // fetch whose promise could hang unsettled forever — and
  // did, wedging a post behind the previous banner step. A
  // stall now answers the structured refusal below.
  const controller = new AbortController();
  const timer = setTimeout(() => {
    try { controller.abort(); } catch (e) { /* no-op */ }
  }, VIDEO_FETCH_TIMEOUT_MS);
  try {
    let res;
    try {
      res = await fetch(url, { signal: controller.signal });
    } catch (e) {
      if (controller.signal.aborted) {
        return { ok: false, error: "video_fetch_timeout" };
      }
      return { ok: false, error: "video_fetch_threw" };
    }
    if (!res.ok) return { ok: false, error: `video_http_${res.status}` };
    const contentType = res.headers.get("content-type") || "";
    const ct = contentType.toLowerCase();
    if (ct && !ct.startsWith("video/") && !ct.includes("octet-stream")) {
      return { ok: false, error: "video_not_a_video" };
    }
    let buffer;
    try {
      buffer = await res.arrayBuffer();
    } catch (e) {
      if (controller.signal.aborted) {
        return { ok: false, error: "video_fetch_timeout" };
      }
      throw e; // as before: the relay handler answers video_relay_failed
    }
    if (!buffer.byteLength) return { ok: false, error: "video_empty" };
    if (buffer.byteLength > VIDEO_MAX_BYTES) {
      return { ok: false, error: "video_too_large" };
    }
    return {
      ok: true,
      base64: arrayBufferToBase64(buffer),
      contentType: contentType || "video/mp4"
    };
  } finally {
    clearTimeout(timer);
  }
}


// --- CDP trusted input (filler v3) ---------------------------------------
// Minimal protocol the content script drives:
//   { type: "AUTOLAUNCH_CDP", action: "attach" }
//   { type: "AUTOLAUNCH_CDP", action: "click", x, y }
//   { type: "AUTOLAUNCH_CDP", action: "clickSeq", x, y }  (v2.1.9)
//   { type: "AUTOLAUNCH_CDP", action: "insertText", text }
//   { type: "AUTOLAUNCH_CDP", action: "key", key, code, text?, modifiers? }
//   { type: "AUTOLAUNCH_CDP", action: "setFile", url, filename, selector, queueId, vin }  (v2.1.89)
//   { type: "AUTOLAUNCH_CDP", action: "detach" }
// Every reply is { ok: true, ... } or { ok: false, error } — an attach
// failure (another debugger, e.g. the user's own DevTools, is attached)
// surfaces as an error, never a throw, so the caller's verify-or-report
// remains the arbiter. Sessions are tracked per tab; Chrome's own
// onDetach (tab closed, user cancels the infobar) cleans the map.
const cdpSessions = new Map(); // tabId -> protocol version

function cdpAttachOnce(tabId) {
  return new Promise(resolve => {
    chrome.debugger.attach({ tabId }, "1.3", () => {
      const err = chrome.runtime.lastError;
      if (err) {
        resolve({ ok: false, error: "cdp_attach_failed: " + (err.message || "unknown") });
        return;
      }
      cdpSessions.set(tabId, "1.3");
      resolve({ ok: true });
    });
  });
}

async function cdpAttach(tabId) {
  if (cdpSessions.has(tabId)) return { ok: true, already: true };
  let res = await cdpAttachOnce(tabId);
  // The classic refusal is the user having DevTools (or another
  // debugger) on the same tab. That can be transient — retry ONCE
  // after a pause before giving the rung up; the error string keeps
  // the browser's exact reason either way (v3.1).
  if (!res.ok && /another debugger is already attached/i.test(res.error || "")) {
    await sleep(3000);
    res = await cdpAttachOnce(tabId);
  }
  return res;
}

function cdpSendCommand(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, result => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message || "cdp_command_failed"));
      else resolve(result);
    });
  });
}

function cdpDetach(tabId) {
  if (!cdpSessions.has(tabId)) return Promise.resolve({ ok: true, already: false });
  return new Promise(resolve => {
    chrome.debugger.detach({ tabId }, () => {
      void chrome.runtime.lastError; // detaching a dead session is fine
      cdpSessions.delete(tabId);
      resolve({ ok: true });
    });
  });
}

async function handleCdp(message, tabId) {
  switch (message.action) {
    case "attach":
      return cdpAttach(tabId);
    case "detach":
      return cdpDetach(tabId);
    case "click": {
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      const x = Number(message.x), y = Number(message.y);
      if (!isFinite(x) || !isFinite(y)) return { ok: false, error: "cdp_bad_coordinates" };
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mousePressed", x, y, button: "left", clickCount: 1 });
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mouseReleased", x, y, button: "left", clickCount: 1 });
      return { ok: true };
    }
    case "clickSeq": {
      // v2.1.9 (header note 16): a full mouse SEQUENCE — move,
      // press, brief pause, release — for menus that arm on
      // hover/press timing and shrug off the instantaneous
      // press+release pair above.
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      const x = Number(message.x), y = Number(message.y);
      if (!isFinite(x) || !isFinite(y)) return { ok: false, error: "cdp_bad_coordinates" };
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mouseMoved", x, y });
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mousePressed", x, y, button: "left", clickCount: 1 });
      await sleep(90);
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mouseReleased", x, y, button: "left", clickCount: 1 });
      return { ok: true };
    }
    case "insertText": {
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      await cdpSendCommand(tabId, "Input.insertText", { text: String(message.text || "") });
      return { ok: true };
    }
    case "key": {
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      if (!message.key) return { ok: false, error: "cdp_key_missing" };
      const base = {
        key: String(message.key),
        code: String(message.code || message.key),
        modifiers: Number(message.modifiers) || 0
      };
      // `text` makes printable keys actually produce characters in
      // fields that read it from the key event (native selects do).
      if (message.text) base.text = String(message.text);
      await cdpSendCommand(tabId, "Input.dispatchKeyEvent",
        Object.assign({ type: "keyDown" }, base));
      await cdpSendCommand(tabId, "Input.dispatchKeyEvent",
        Object.assign({ type: "keyUp" }, base));
      return { ok: true };
    }
    case "setFile": {
      // v2.1.89 (header note 44): picker-equivalent file
      // injection for the editor attach — download the
      // reel to a real path, then DOM.setFileInputFiles
      // on the input the content script marked. Every
      // failure is the structured {ok:false, error} the
      // content side falls back on.
      return cdpSetFileInputFiles(tabId, message);
    }
    default:
      return { ok: false, error: "cdp_unknown_action" };
  }
}

chrome.debugger.onDetach.addListener(source => {
  if (source && source.tabId != null) cdpSessions.delete(source.tabId);
});
chrome.tabs.onRemoved.addListener(tabId => {
  cdpSessions.delete(tabId);
});

// --- CDP reel file injection (v2.1.89, header note 44) -------------------
// The editor attach's file set, picker-equivalent: the reel
// is saved to a real on-disk path by chrome.downloads, then
// DOM.setFileInputFiles hands that path to the editor's
// marked video input over the note-9 CDP session. The
// download record is kept in chrome.storage.local (key
// autolaunch_cdp_reel_file) so cleanup can find it even if
// this worker restarted between the set and the settle.

// [PURE-CDP-FILE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of chrome/fetch references.
// The setFile request's shape gate: an https reel URL and
// exactly the temp-file name shape the content side
// builds (reelTempFilename) — no paths, no traversal.
function cdpReelFileRequestGuard(message) {
  const url = message && typeof message.url === "string" ? message.url : "";
  const filename = message && typeof message.filename === "string"
    ? message.filename : "";
  if (!/^https:\/\//i.test(url)) {
    return { ok: false, error: "cdp_file_url_invalid" };
  }
  if (!/^autolaunch-reel-[A-Za-z0-9._-]+\.mp4$/.test(filename) ||
      filename.indexOf("..") >= 0 || filename.indexOf("/") >= 0 ||
      filename.indexOf("\\") >= 0) {
    return { ok: false, error: "cdp_file_name_invalid" };
  }
  return { ok: true, url, filename };
}
// Cleanup fires only for the attach job the record was
// written for — the queue id must match the settling job.
function decideCdpFileCleanup(record, job) {
  if (!record || !job) return false;
  if (job.action !== "attach_video") return false;
  return record.queueId != null && record.queueId === job.queueId;
}
// [PURE-CDP-FILE-END]

const CDP_REEL_DOWNLOAD_TIMEOUT_MS = 90 * 1000;

function waitForDownloadComplete(downloadId) {
  return new Promise(resolve => {
    let settled = false;
    const finish = v => {
      if (settled) return;
      settled = true;
      try { chrome.downloads.onChanged.removeListener(onChanged); } catch (e) {}
      resolve(v);
    };
    const onChanged = delta => {
      if (!delta || delta.id !== downloadId || !delta.state) return;
      if (delta.state.current === "complete") finish({ ok: true });
      else if (delta.state.current === "interrupted") {
        finish({ ok: false,
          error: "downloads_interrupted:" +
            ((delta.error && delta.error.current) || "unknown") });
      }
    };
    chrome.downloads.onChanged.addListener(onChanged);
    // The download may have finished before the listener
    // attached (a small reel on a fast disk) — check once.
    try {
      chrome.downloads.search({ id: downloadId }, items => {
        if (items && items[0] && items[0].state === "complete") {
          finish({ ok: true });
        } else if (items && items[0] && items[0].state === "interrupted") {
          finish({ ok: false,
            error: "downloads_interrupted:" + (items[0].error || "unknown") });
        }
      });
    } catch (e) { /* the listener + timeout still stand */ }
    setTimeout(() => finish({ ok: false, error: "downloads_timeout" }),
      CDP_REEL_DOWNLOAD_TIMEOUT_MS);
  });
}

// Ensure the reel sits at a real on-disk path: reuse the
// recorded download when it is this URL's and the file is
// still there (refreshing the record to the CURRENT job,
// so its settle cleans up); otherwise download it under
// the deterministic name and record it for cleanup.
async function ensureCdpReelFile(message) {
  const guard = cdpReelFileRequestGuard(message);
  if (!guard.ok) return guard;
  const stored = await chrome.storage.local.get(["autolaunch_cdp_reel_file"]);
  const prev = stored.autolaunch_cdp_reel_file;
  if (prev && prev.url === guard.url && prev.downloadId != null) {
    const items = await new Promise(resolve => {
      try { chrome.downloads.search({ id: prev.downloadId }, resolve); }
      catch (e) { resolve(null); }
    });
    if (items && items[0] && items[0].state === "complete" &&
        items[0].exists !== false && items[0].filename) {
      await chrome.storage.local.set({
        autolaunch_cdp_reel_file: Object.assign({}, prev, {
          queueId: message.queueId || null, vin: message.vin || null,
          at: new Date().toISOString()
        })
      });
      return { ok: true, path: items[0].filename, reused: true };
    }
  }
  const downloadId = await new Promise(resolve => {
    try {
      chrome.downloads.download(
        { url: guard.url, filename: guard.filename,
          conflictAction: "overwrite" },
        id => {
          const err = chrome.runtime.lastError;
          resolve(err || id == null ? null : id);
        });
    } catch (e) { resolve(null); }
  });
  if (downloadId == null) return { ok: false, error: "downloads_start_failed" };
  const done = await waitForDownloadComplete(downloadId);
  if (!done.ok) return done;
  const items = await new Promise(resolve => {
    try { chrome.downloads.search({ id: downloadId }, resolve); }
    catch (e) { resolve(null); }
  });
  const path = items && items[0] && items[0].filename;
  if (!path) return { ok: false, error: "downloads_path_unresolved" };
  await chrome.storage.local.set({
    autolaunch_cdp_reel_file: {
      downloadId, path, url: guard.url,
      queueId: message.queueId || null, vin: message.vin || null,
      at: new Date().toISOString()
    }
  });
  return { ok: true, path, reused: false };
}

// The injection itself: DOM.setFileInputFiles on the
// input the content script marked, over the note-9
// session (attached here when the rung-3 ladder has not
// already attached it).
async function cdpSetFileInputFiles(tabId, message) {
  const file = await ensureCdpReelFile(message);
  if (!file.ok) return file;
  const attach = await cdpAttach(tabId);
  if (!attach.ok) return attach;
  const selector = typeof message.selector === "string" && message.selector
    ? message.selector : 'input[data-autolaunch-cdp-target="1"]';
  try {
    await cdpSendCommand(tabId, "DOM.enable", {});
    const doc = await cdpSendCommand(tabId, "DOM.getDocument", { depth: -1 });
    const rootId = doc && doc.root && doc.root.nodeId;
    if (!rootId) return { ok: false, error: "cdp_no_document" };
    const found = await cdpSendCommand(tabId, "DOM.querySelector",
      { nodeId: rootId, selector });
    const nodeId = found && found.nodeId;
    if (!nodeId) return { ok: false, error: "cdp_node_not_found" };
    await cdpSendCommand(tabId, "DOM.setFileInputFiles",
      { nodeId, files: [file.path] });
    return { ok: true, path: file.path, reused: file.reused === true };
  } catch (e) {
    return { ok: false,
      error: "cdp_set_files_failed: " + ((e && e.message) || "unknown") };
  }
}

// Temp-file cleanup at the attach job's settle (success
// and failure alike, from the finish functions): erase
// the storage record first so a repeated call is a
// no-op, then remove the file and its download-history
// entry. Fail-open throughout — a leftover temp file is
// litter, never a wedge.
async function cleanupCdpReelFile(job) {
  try {
    const stored = await chrome.storage.local.get(["autolaunch_cdp_reel_file"]);
    const record = stored.autolaunch_cdp_reel_file;
    if (!decideCdpFileCleanup(record, job)) return;
    await chrome.storage.local.remove(["autolaunch_cdp_reel_file"]);
    if (record.downloadId != null) {
      await new Promise(resolve => {
        try {
          chrome.downloads.removeFile(record.downloadId,
            () => { void chrome.runtime.lastError; resolve(); });
        } catch (e) { resolve(); }
      });
      await new Promise(resolve => {
        try {
          chrome.downloads.erase({ id: record.downloadId },
            () => { void chrome.runtime.lastError; resolve(); });
        } catch (e) { resolve(); }
      });
    }
  } catch (e) { /* fail-open */ }
}

// Failure-log writes are serialized through this chain (v3.1): the
// get-modify-write cycle is not atomic, and near-simultaneous callers
// (four field diags landing alongside the job failure) could read the
// same base log and overwrite each other's entries.
let failureLogChain = Promise.resolve();
function logFailure(queueId, reason, extra) {
  const run = failureLogChain.then(() => logFailureNow(queueId, reason, extra));
  failureLogChain = run.catch(() => {});
  return run;
}

async function logFailureNow(queueId, reason, extra) {
  const { autolaunch_failure_log: log = [] } = await chrome.storage.local.get(["autolaunch_failure_log"]);
  const entry = Object.assign(
    { queueId, reason, at: new Date().toISOString() },
    extra || {}
  );
  log.unshift(entry);
  await chrome.storage.local.set({
    autolaunch_failure_log: log.slice(0, 25),
    autolaunch_last_error: { queueId, reason, at: entry.at }
  });
}

// [PURE-DIAG-BEGIN] — extracted and unit-exercised by the test harness;
// keep free of chrome/fetch references.
// Compact the content script's per-field forensic records into the
// JSON string stored in the queue row's error_message (diag-to-DB,
// v3.1; form map v3.2; step notes v2.1.3): per field {field, tag,
// type, role, ariaLabel, outerHTML (≤160 chars), rungsAttempted,
// readBack, cdpError, note, detail (≤200 chars)}, plus the form_map
// entry whose formMap lists the failing step's visible controls
// {tag, type, role, ariaLabel, containerLabel (≤120 chars)}. The
// whole string is capped at 6000 chars — shed formMap entries first
// (halve, then drop), then outerHTML, then readBack + detail, then
// hard-truncate, so the field names + rungs + cdpError + notes
// survive.
function compactDiagError(diags) {
  if (!Array.isArray(diags) || !diags.length) return null;
  const fields = diags.map(d => {
    const el = (d && d.element) || {};
    return {
      field: (d && d.field) || null,
      tag: el.tag || null,
      type: el.type || null,
      role: el.role || null,
      ariaLabel: el.ariaLabel || null,
      outerHTML: el.outerHTML ? String(el.outerHTML).slice(0, 160) : null,
      rungsAttempted: (d && Array.isArray(d.rungsAttempted)) ? d.rungsAttempted.slice() : [],
      readBack: (d && d.readBack != null) ? String(d.readBack).slice(0, 120) : null,
      cdpError: (d && d.cdpError) || null,
      note: (d && d.note) || null,
      detail: (d && d.detail != null) ? String(d.detail).slice(0, 200) : null,
      formMap: (d && Array.isArray(d.formMap))
        ? d.formMap.slice(0, 12).map(m => ({
            tag: (m && m.tag) || null,
            type: (m && m.type) || null,
            role: (m && m.role) || null,
            ariaLabel: (m && m.ariaLabel) || null,
            containerLabel: (m && m.containerLabel != null)
              ? String(m.containerLabel).slice(0, 120) : null
          }))
        : null
    };
  });
  let out = JSON.stringify({ field_diag: fields });
  if (out.length > 6000) {
    fields.forEach(f => { if (Array.isArray(f.formMap)) f.formMap = f.formMap.slice(0, 6); });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) {
    fields.forEach(f => { f.formMap = null; });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) {
    fields.forEach(f => { f.outerHTML = null; });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) {
    fields.forEach(f => { f.readBack = null; f.detail = null; });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) out = out.slice(0, 6000);
  return out;
}
// [PURE-DIAG-END]

// The DB writes that end a job, split out so a finish that collides with
// a dead token can be stashed and replayed when a fresh token arrives
// (see autolaunch_pending_finish below) instead of being lost.
async function applyPosted(queueId, vin, userId, postedPrice, reel) {
  // v2.1.86: a job that carried a reel also writes the
  // completion's reel_failed truth (decideReelCompletionFlag);
  // no reel -> the patch is exactly the pre-2.86 shape.
  const completion = { status: "posted" };
  const reelFlag = decideReelCompletionFlag(reel);
  if (reelFlag !== null) completion.reel_failed = reelFlag;
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`, completion);
  // Posted-price stamp (v2.1.62, header note 34): alongside the
  // posted-at stamp, record the price the post actually used —
  // the queue row's stamped price, carried on the job — as
  // marketplace_posted_price. It is the price the live listing
  // carries: removals match against it, and the drift pass diffs
  // the dealer's current price against it. A missing/invalid
  // price leaves the column untouched (null = fall back to the
  // current price, the pre-feature behavior).
  const stamp = { marketplace_posted_at: new Date().toISOString() };
  const pp = Number(postedPrice);
  if (isFinite(pp) && pp > 0) stamp.marketplace_posted_price = Math.round(pp);
  await sbPatch(
    `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}`,
    stamp
  );
}

// VIN reel attach diagnostics (v2.1.86, header note 41): an
// unverified attach files its forensics in the queue row's
// error_message, in the field_diag shape the failure path
// uses (compactDiagError) — the app never renders a posted
// row's error_message; the record exists for the database.
// STRICTLY FAIL-OPEN: a diag write may never fail a post
// whose listing is already live.
async function writeReelAttachDiag(queueId, errorMessage) {
  if (!errorMessage) return;
  try {
    await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
      { error_message: errorMessage });
  } catch (e) { /* the post stands; the console keeps the story */ }
}

// VIN Reel consumption (v2.1.85, header note 40; since
// v2.1.86 the attach must be form-verified, note 41): after a post
// SUCCEEDS with a poster reel attached, the reel's job is done
// — delete its storage object and mark the row consumed (the
// Facebook post keeps its own copy; the app already ignores
// consumed rows). STRICTLY FAIL-OPEN: the post is confirmed
// before this runs, and nothing here may ever surface as a
// post failure. Delete-then-mark, the README's order: if the
// mark fails the row stays ready over a dead URL (the next
// claim's attach would fail honestly and post without it);
// if the delete fails the object lingers unviewed.
async function consumeJobReel(userId, vin, reel) {
  try {
    const d = decideReelConsume(reel);
    if (!d.consume) {
      if (reel && reel.attached === true && reel.source !== "poster") {
        console.log("[AutoLaunch] VIN reel attached was a manual reel — left in place (never consumed).");
      }
      return;
    }
    try {
      // v2.1.90 (header note 45): the end-card still beside
      // the mp4 is the reel's second object — it is deleted
      // in the same call, so a consumed reel leaves nothing
      // behind. A reel rendered before cards existed simply
      // has no second prefix hit; the delete is unaffected.
      const res = await fetch(`${SUPABASE_URL}/storage/v1/object/vin-reels`, {
        method: "DELETE",
        headers: await sbHeaders(),
        body: JSON.stringify({ prefixes: [`${userId}/${vin}.mp4`, `${userId}/${vin}-card.jpg`] })
      });
      if (!res.ok) {
        console.warn(`[AutoLaunch] VIN reel storage delete returned ${res.status}; marking consumed anyway.`);
      }
    } catch (e) {
      console.warn("[AutoLaunch] VIN reel storage delete failed; marking consumed anyway.");
    }
    await sbPatch(`vin_reels?id=eq.${d.reelId}`, {
      status: "consumed",
      consumed_at: new Date().toISOString()
    });
    console.log(`[AutoLaunch] VIN reel ${d.reelId} consumed (poster reel for VIN ${vin}).`);
  } catch (e) {
    console.warn("[AutoLaunch] VIN reel consumption failed (non-fatal; the post stands).");
  }
}

// Delete completion (v2.1.4): the queue row ends "completed" —
// there is no check constraint on status (verified against the live
// schema), and the app's queue view renders the value — with
// executed_at stamped, and the car's marketplace_posted_at cleared.
// That column is the app's ONLY derivation of "Posted", so clearing
// it is what truthfully returns the car to unposted once the listing
// is verifiably gone from Facebook.
async function applyDeleted(queueId, vin, userId) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
  await sbPatch(
    `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}`,
    // The posted price clears with the posted stamp (v2.1.62):
    // no live listing, no posted price — the invariant the
    // drift pass and the removal matcher both rely on.
    { marketplace_posted_at: null, marketplace_posted_price: null }
  );
}

// Share completion (v2.1.55, header note 29): the queue row ends
// "completed" with executed_at stamped — and NOTHING else. A
// share never touches scraped_inventory: the listing stays
// posted and marketplace_posted_at keeps its value.
async function applyShared(queueId) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
}

// Price-update completion (v2.1.62, header note 34): the queue
// row ends "completed" with executed_at stamped, and the car's
// marketplace_posted_price advances to the price the listing now
// shows. marketplace_posted_at is NEVER touched here — a price
// update is not a post, and that stamp feeds both the
// today's-posts count and the pacing anchor.
async function applyPriceUpdated(queueId, vin, userId, newPrice) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
  const np = Number(newPrice);
  if (isFinite(np) && np > 0) {
    await sbPatch(
      `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}`,
      { marketplace_posted_price: Math.round(np) }
    );
  }
}

// Edit-flow attach completion (v2.1.88, header note 43):
// the queue row ends "completed" with executed_at stamped —
// the price-update completion's exact semantics, since an
// attach is not a post: scraped_inventory's posted stamps
// are NEVER touched here (the daily count and the pacing
// anchor read them). The parent post row's reel_failed flag
// then clears — the car is no longer "posted without
// video". The parent is matched by user + VIN among posted
// rows still carrying the flag; a swept parent (the app
// ages finished rows out) matches nothing and the clear is
// skipped silently. The clear is fail-open: the attach DID
// land, and its own row already says so.
async function applyVideoAttached(queueId, vin, userId) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
  try {
    await sbPatch(
      `auto_posting_queue?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}&status=eq.posted&reel_failed=eq.true`,
      { reel_failed: false }
    );
  } catch (e) { /* the attach stands; the flag clear is bookkeeping */ }
}

// [PURE-RICHDESC-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Rich listing descriptions (2026-11-10 — Matthew's
// build, promoted from the rebuild (bde99546) as
// v2.1.98; header note 51 in the content script and
// the worker): the emoji format the competitor posters use, fed
// ONLY by the car's scraped VDP payload (scraped_inventory
// .vdp_features — highlights, factory packages, exact-phrase
// claims, and the most specific engine/transmission strings,
// captured by the rebuild scraper from the dealer's own
// vehicle page). GROUNDING RULE: nothing renders that is not
// in the payload — no invented features, no inferred claims,
// no fact-asserting blurbs; the feature names print plain.
// When the account's rich_descriptions setting is off the
// composers never call this; when it is on but the car
// carries no usable payload, buildRichDescription returns ""
// and every composer falls back to the plain template
// BYTE-IDENTICAL to before this feature existed. PRICE
// RULE: package dollar values are factory OPTION prices,
// not the car's price — a package prints as its name only
// (richPackageName strips the value tail), and a final guard
// refuses the rich text outright when any $ figure other
// than the advertised price line survives. The one exception
// is the composer's own facts block: the advertised "Price:"
// line, which the guard counts exactly.
// Category map: the Highlighted Features shortlist is sorted
// by keyword, tested in the order safety → capability →
// tech → comfort (first match wins), so "Adaptive Cruise
// Control" lands in safety (adaptive cruise beats the plain
// cruise-control comfort term) and heated tech never
// outranks a safety term. Unmatched items are still real
// scraped features — they print under MORE FEATURES, capped
// like every section (section cap 6, package cap 8) so the
// post stays readable.
const RICH_SECTION_CAP = 6;
const RICH_PACKAGE_CAP = 8;
const RICH_FEATURE_CATEGORIES = [
  { key: "safety", re: /\b(blind spot|lane|collision|brake assist|emergency brak|automatic braking|backup camera|back-up camera|rear view camera|rearview camera|parking sensor|park assist|parking assist|cross traffic|pedestrian|airbags?|air bags?|traction control|stability control|tire pressure|tpms|anti-lock|antilock|abs|adaptive cruise|hill hold|hill descent|daytime running)\b/ },
  { key: "capability", re: /\b(4wd|awd|4x4|four-wheel|all-wheel|front-wheel drive|rear-wheel drive|tow|towing|hitch|trailer|payload|bed liner|tonneau|skid plate|off-road|off road|differential|transfer case|axle ratio|ground clearance|fox racing|roof rack|running boards?|side steps?|locking hubs?|sway control)\b/ },
  { key: "tech", re: /\b(bluetooth|carplay|android auto|navigation|wi-fi|wifi|hotspot|usb|touchscreen|touch screen|infotainment|satellite radio|siriusxm|hd radio|speakers?|sound system|audio system|wireless charging|aux input|voice recognition|voice control|sync|uconnect|onstar|telematics|hands-free|hands free)\b/ },
  { key: "comfort", re: /\b(heated|cooled|ventilated|leather|seats?|seating|sunroof|moonroof|climate|air conditioning|a\/c|remote start|remote engine start|keyless|cruise control|lumbar|armrest|steering wheel|memory|dual-zone|tri-zone|floor mats|all-weather)\b/ }
];
function richFeatureCategory(name) {
  const t = String(name == null ? "" : name).toLowerCase();
  for (let i = 0; i < RICH_FEATURE_CATEGORIES.length; i++) {
    if (RICH_FEATURE_CATEGORIES[i].re.test(t)) {
      return RICH_FEATURE_CATEGORIES[i].key;
    }
  }
  return "other";
}
function richPackageName(pkg) {
  // "Spray-In Bed Liner ($595 value)" → "Spray-In Bed
  // Liner": only a parenthetical carrying a $ figure is
  // stripped, so a real name parenthetical survives.
  return String(pkg == null ? "" : pkg)
    .replace(/\s*\([^)]*\$[^)]*\)\s*$/, "")
    .trim();
}
function richTrimDisplay(car) {
  // The stored trim is slug-corrupted on most rows — the
  // VDP URL slug glued to the VIN ("SE-1FADP3KE3GL273598",
  // "HYBRID-RX-350h-LUXURY-AWD-<VIN>"). Repair ONLY that
  // exact shape: strip the "-<VIN>" tail and un-slug the
  // remainder ("Black-Edition" → "Black Edition"). A clean
  // stored trim passes through untouched.
  let t = String((car && car.trim) || "").trim();
  const vin = String((car && car.vin) || "").trim();
  if (t && vin &&
      t.toUpperCase().endsWith("-" + vin.toUpperCase())) {
    t = t.slice(0, t.length - vin.length - 1)
      .replace(/-/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }
  return t;
}
function buildRichDescription(car, settings) {
  const vf = (car && typeof car.vdp_features === "object" &&
    car.vdp_features) ? car.vdp_features : null;
  if (!vf) return "";
  const s = settings || {};
  const highlights = (Array.isArray(vf.highlights)
    ? vf.highlights : [])
    .map(x => String(x == null ? "" : x).trim())
    .filter(x => x);
  const claims = (vf.claims && typeof vf.claims === "object")
    ? vf.claims : {};
  const packages = (Array.isArray(vf.packages) ? vf.packages : [])
    .map(richPackageName)
    .filter(x => x);
  const anyClaim = claims.one_owner === true ||
    claims.no_accidents === true;
  if (!highlights.length && !packages.length && !anyClaim) {
    return "";
  }
  // Mileage posture: the composer's rules exactly (stored
  // >= 300 wins; an exact stored 1,000 on a New car is the
  // new-car default; below 300 / absent = unproven → the
  // 1,000 working figure with the default disclosure).
  const stored = (car.mileage != null && car.mileage !== "")
    ? Number(car.mileage) : null;
  const isNew = /^new$/i.test(String(car.condition || "").trim());
  const lm = (stored !== null && stored >= 300)
    ? { miles: stored, defaulted: isNew && stored === 1000 }
    : { miles: 1000, defaulted: true };
  const title = (`${car.year || ""} ${car.make || ""} ` +
    `${car.model || "Vehicle"} ${richTrimDisplay(car)}`)
    .trim().replace(/\s+/g, " ");
  const stockRaw = (car.stock_num != null &&
    String(car.stock_num).trim())
    ? car.stock_num : car.stock_number;
  const stock = stockRaw != null ? String(stockRaw).trim() : "";
  const carfax = car.carfax_url != null
    ? String(car.carfax_url).trim() : "";
  const engine = typeof vf.engine_detail === "string"
    ? vf.engine_detail.trim() : "";
  const trans = typeof vf.transmission_detail === "string"
    ? vf.transmission_detail.trim() : "";
  // The facts block: the composer's lines, in the
  // composer's order, under the emoji header — Price
  // (omitted when there is no usable advertised price: the
  // scraper's call/none states, or a non-positive stored
  // price), then VIN, Stock # (setting-gated), the CARFAX
  // line, and the mileage-default disclosure verbatim.
  const lines = [];
  lines.push(`🔥 ${title} 🔥`);
  if (car.color &&
      String(car.color).trim().toLowerCase() !== "standard") {
    lines.push(`🎨 Color: ${car.color}`);
  }
  if (car.interior_color &&
      String(car.interior_color).trim().toLowerCase() !== "standard") {
    lines.push(`🪑 Interior: ${car.interior_color}`);
  }
  if (lm.miles != null) {
    lines.push(`🛣️ Miles: ${lm.miles.toLocaleString()}`);
  }
  const engParts = [];
  if (engine) engParts.push(`Engine: ${engine}`);
  if (trans) engParts.push(`Transmission: ${trans}`);
  if (engParts.length) {
    lines.push(`⚙️ ${engParts.join(" | ⚙️ ")}`);
  }
  const priceStatus = String(car.price_status || "")
    .trim().toLowerCase();
  const priceNum = car.price != null ? Number(car.price) : 0;
  const hasPrice = priceStatus !== "call" &&
    priceStatus !== "none" && priceNum > 0;
  if (hasPrice) {
    lines.push(`Price: $${priceNum.toLocaleString()}`);
  }
  if (car.vin) lines.push(`VIN: ${car.vin}`);
  if (s.includeStock === true && stock) {
    lines.push(`Stock #: ${stock}`);
  }
  if (carfax) lines.push(`CARFAX report: ${carfax}`);
  if (lm.defaulted) {
    lines.push(isNew
      ? "Brand new vehicle — the mileage shown is a listing default; actual miles may be less."
      : "Mileage shown is a listing default — exact miles were not published for this vehicle; ask us for the current odometer reading.");
  }
  // Intro: real attributes only — the body word comes from
  // the car's own scraped body_type, the rest is generic
  // connective phrasing that asserts nothing.
  const bt = String(car.body_type || "").trim().toLowerCase();
  const bodyWord = bt.includes("truck") ? "truck"
    : bt.includes("suv") ? "SUV"
    : bt.includes("van") ? "van"
    : bt.includes("coupe") ? "coupe"
    : bt.includes("convertible") ? "convertible"
    : bt.includes("hatchback") ? "hatchback"
    : bt.includes("sedan") ? "sedan" : "vehicle";
  lines.push("");
  lines.push(`Looking for your next ${bodyWord}? This ${title} is on the lot and ready to go — here's what it brings:`);
  // HIGHLIGHTS: the scraped claims first (exact-phrase
  // flags only — never inferred), then the factory
  // packages by NAME.
  const hl = [];
  if (claims.one_owner === true) hl.push("✅ ONE OWNER! 👤");
  if (claims.no_accidents === true) hl.push("✅ NO ACCIDENTS!");
  if (packages.length) {
    hl.push("✅ Factory packages:");
    for (const p of packages.slice(0, RICH_PACKAGE_CAP)) {
      hl.push(`• ${p}`);
    }
  }
  // Categorized sections from the highlights shortlist.
  const buckets = { comfort: [], tech: [], safety: [], capability: [], other: [] };
  const seenH = new Set();
  for (const h of highlights) {
    const k = h.toLowerCase();
    if (seenH.has(k)) continue;
    seenH.add(k);
    buckets[richFeatureCategory(h)].push(h);
  }
  const SECTION_ORDER = [
    ["comfort", "👑 COMFORT & CONVENIENCE 👑"],
    ["tech", "📶 TECH & CONNECTIVITY 📶"],
    ["safety", "🛡️ SAFETY & DRIVER ASSIST 🛡️"],
    ["capability", "⚡ CAPABILITY ⚡"],
    ["other", "🔹 MORE FEATURES 🔹"]
  ];
  const sections = [];
  if (hl.length) {
    sections.push("✨ VEHICLE HIGHLIGHTS ✨\n" + hl.join("\n"));
  }
  for (const [key, head] of SECTION_ORDER) {
    const items = buckets[key].slice(0, RICH_SECTION_CAP);
    if (items.length) {
      sections.push(head + "\n" +
        items.map(i => `• ${i}`).join("\n"));
    }
  }
  if (!sections.length) return "";
  let desc = lines.join("\n") + "\n\n" + sections.join("\n\n");
  // Closing: the existing tagline, dealer block, and rep
  // contact line — the composer's elements, unchanged (the
  // contact pair through the same both-required rule as
  // repContactLine in the helper composers; the app mirror
  // inlines the pair the same way its plain path does).
  desc += "\n\nInspected and frontline ready. Message to set up a test drive!";
  const dealerLines = [s.dealershipName, s.dealershipAddress]
    .map(x => typeof x === "string" ? x.trim() : "")
    .filter(x => x);
  if (dealerLines.length) desc += `\n\n${dealerLines.join("\n")}`;
  const rn = typeof s.repName === "string" ? s.repName.trim() : "";
  const rp = typeof s.repPhone === "string" ? s.repPhone.trim() : "";
  if (rn && rp) desc += `\n\nCall or text ${rn} · ${rp}`;
  // PRICE GUARD: every $ in the text must be the advertised
  // price itself; anything else refuses the rich text and
  // the composer falls back to the plain template.
  const dollarCount = (desc.match(/\$/g) || []).length;
  const priceCount = hasPrice
    ? desc.split(`$${priceNum.toLocaleString()}`).length - 1
    : 0;
  if (dollarCount !== priceCount) return "";
  return desc;
}
// [PURE-RICHDESC-END]

// [PURE-CONTACT-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// The rep contact line (v2.1.90, header note 45): the ONE
// formatter behind all three description mirrors (the
// listing buildDescription, the worker's
// buildShareTextForCar, the app's buildShareDetailsText)
// and the reel end card's text. BOTH values required —
// either blank (or not a string at all) and the answer is
// the empty string, which every composer appends as
// nothing: the description stays byte-identical to before
// the feature existed.
function repContactLine(name, phone) {
  const n = typeof name === "string" ? name.trim() : "";
  const p = typeof phone === "string" ? phone.trim() : "";
  if (!n || !p) return "";
  return `Call or text ${n} · ${p}`;
}
// [PURE-CONTACT-END]

// The share row's details text (v2.1.56, header note 30): a
// worker-side rebuild of the listing description from the same
// inputs the posting composer's buildDescription uses — the
// description TEXT itself is built in the content script at
// post time and never reported back to the worker, so the
// worker reconstructs it from the job's car row and the
// claim-time settings riding the job (dealership identity,
// include_stock). Mirrors buildDescription + listingMileage
// line for line; the app carries the third copy of this
// builder (buildShareDetailsText) — keep all three in step.
function buildShareTextForCar(car, job) {
  if (!car) return "";
  // Rich descriptions (v2.1.98, header note 51): mirror
  // of the composer's branch — the job carries richDesc
  // from the same claim-time settings read; ON + a usable
  // payload and the share text IS the rich listing text,
  // byte for byte.
  if (job && job.richDesc === true) {
    const rich = buildRichDescription(car, {
      includeStock: job.includeStock === true,
      dealershipName: job.dealershipName,
      dealershipAddress: job.dealershipAddress,
      repName: job.repName,
      repPhone: job.repPhone
    });
    if (rich) return rich;
  }
  const norm = v => String(v == null ? "" : v).trim().toLowerCase().replace(/\s+/g, " ");
  const stored = car.mileage != null && car.mileage !== "" ? Number(car.mileage) : null;
  const isNew = /^new$/i.test(String(car.condition || "").trim());
  const lm = (stored !== null && stored >= 300)
    ? { miles: stored, defaulted: isNew && stored === 1000, isNew }
    : { miles: 1000, defaulted: true, isNew };
  const title = `${car.year || ""} ${car.make || ""} ${car.model || "Vehicle"} ${car.trim || ""}`.trim();
  const stockRaw = (car.stock_num != null && String(car.stock_num).trim())
    ? car.stock_num : car.stock_number;
  const stock = stockRaw != null ? String(stockRaw).trim() : "";
  // CARFAX report line (v2.1.61, header note 33): mirrors the
  // composer exactly — the car's stored carfax_url (scraper-
  // captured from its VDP badge) joins the facts block under the
  // stock line; absent or blank, the text is byte-identical to
  // 2.1.60. The claim-time car fetch is select-*, so the field
  // rides the job's car row with no new plumbing.
  const carfax = car.carfax_url != null ? String(car.carfax_url).trim() : "";
  let desc =
    `${title}\n` +
    `Price: $${(car.price || 0).toLocaleString()}\n` +
    (lm.miles != null ? `Mileage: ${lm.miles.toLocaleString()} miles\n` : "") +
    (car.color && norm(car.color) !== "standard" ? `Exterior: ${car.color}\n` : "") +
    (car.transmission ? `Transmission: ${car.transmission}\n` : "") +
    (car.vin ? `VIN: ${car.vin}\n` : "") +
    (job && job.includeStock === true && stock ? `Stock #: ${stock}\n` : "") +
    (carfax ? `CARFAX report: ${carfax}\n` : "") +
    (lm.defaulted
      ? (lm.isNew
        ? `\nBrand new vehicle — the mileage shown is a listing default; actual miles may be less.`
        : `\nMileage shown is a listing default — exact miles were not published for this vehicle; ask us for the current odometer reading.`)
      : "") +
    `\nInspected and frontline ready. Message to set up a test drive!`;
  const dealerLines = [
    job && typeof job.dealershipName === "string" ? job.dealershipName.trim() : "",
    job && typeof job.dealershipAddress === "string" ? job.dealershipAddress.trim() : ""
  ].filter(s => s);
  if (dealerLines.length) desc += `\n\n${dealerLines.join("\n")}`;
  // Rep contact line (v2.1.90, header note 45): the closing
  // line, after the dealership block — the third mirror
  // agrees byte for byte through repContactLine.
  const contact = repContactLine(job && job.repName, job && job.repPhone);
  if (contact) desc += `\n\n${contact}`;
  return desc;
}

// Post-success feed share (v2.1.55, header note 29): when the
// job's claim-time settings carried shareToFeed, queue ONE share
// row for the just-posted car — the producer contract the app's
// "Share to my feed" button writes (target_channel 'facebook',
// action 'share', the car's year/make/model/stock/price stamped
// on the row for the strict matcher). Dedupe-checked against
// live share rows for the VIN first, exactly like the app's
// producer. STRICTLY FAIL-OPEN: called only after the post is
// already final, wrapped so nothing it does can throw into,
// fail, or delay the completed post — worst case the share is
// skipped and the skip is logged.
async function maybeQueueFeedShare(job) {
  try {
    if (!job || job.shareToFeed !== true || !job.car || !job.car.vin || !job.userId) return;
    const car = job.car;
    const existing = await sbGet(
      `auto_posting_queue?user_id=eq.${job.userId}&vin=eq.${encodeURIComponent(car.vin)}&action=eq.share&status=in.(pending,processing)&select=id&limit=1`);
    if (existing && existing.length) {
      console.log(`[AutoLaunch] share_to_feed: a share for VIN ${car.vin} is already queued — not queueing another.`);
      return;
    }
    await sbPost("auto_posting_queue", {
      user_id: job.userId,
      vin: car.vin,
      target_channel: "facebook",
      action: "share",
      status: "pending",
      year: car.year != null ? car.year : null,
      make: car.make || null,
      model: car.model || null,
      stock_num: car.stock_num || car.stock_number || null,
      price: car.price != null ? Number(car.price) : null,
      // The details text (v2.1.56, header note 30) rides the
      // row so the share can carry the listing's description
      // into the feed post.
      share_text: buildShareTextForCar(car, job) || null,
      created_at: new Date().toISOString()
    });
    console.log(`[AutoLaunch] share_to_feed: queued a feed share for VIN ${car.vin} (posted car, toggle on).`);
  } catch (e) {
    console.warn("[AutoLaunch] share_to_feed: queueing the feed share failed and was skipped — the post itself is unaffected.", e && e.message || e);
  }
}

// Post-completion edit-flow attach queueing (v2.1.88,
// header note 43): when a post's poster reel was attached
// but NOT verified (decideAttachQueue), queue ONE
// attach_video row so a later claim can put the video on
// the live listing through its Edit form — the surface
// that keeps it. The row carries the producer shape the
// strict matcher needs: the car's year/make/model/stock
// and the POSTED price. Dedupe-checked against live attach
// rows for the VIN first, exactly like the feed share.
// STRICTLY FAIL-OPEN: called only after the post is
// already final; worst case the attach is skipped and the
// reel simply stays ready.
async function maybeQueueAttachVideo(userId, vin, carLike, postedPrice, reel) {
  try {
    const d = decideAttachQueue(reel);
    if (!d.queue) return;
    if (!userId || !vin || !carLike) return;
    const pp = Number(postedPrice);
    if (!isFinite(pp) || pp <= 0) return;
    const existing = await sbGet(
      `auto_posting_queue?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}&action=eq.attach_video&status=in.(pending,processing)&select=id&limit=1`);
    if (existing && existing.length) {
      console.log(`[AutoLaunch] edit-flow attach: an attach for VIN ${vin} is already queued — not queueing another.`);
      return;
    }
    await sbPost("auto_posting_queue", {
      user_id: userId,
      vin,
      target_channel: "facebook",
      action: "attach_video",
      status: "pending",
      year: carLike.year != null ? carLike.year : null,
      make: carLike.make || null,
      model: carLike.model || null,
      stock_num: carLike.stock_num || carLike.stock_number || null,
      price: Math.round(pp),
      created_at: new Date().toISOString()
    });
    console.log(`[AutoLaunch] edit-flow attach: queued a video attach for VIN ${vin} (create-flow attach unverified).`);
  } catch (e) {
    console.warn("[AutoLaunch] edit-flow attach: queueing failed and was skipped — the post itself is unaffected.", e && e.message || e);
  }
}

async function applyFailed(queueId, errorMessage) {
  if (errorMessage) {
    try {
      await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
        { status: "failed", error_message: errorMessage });
      return;
    } catch (err) {
      // An auth failure would doom the retry too — rethrow so the
      // caller stashes the finish for the next token. Any other
      // rejection (e.g. the diagnostics write itself) must NOT cost
      // the failure state: fall through to the status-only write.
      if (err instanceof SbAuthError) throw err;
      console.warn("[AutoLaunch] error_message write rejected; failing the row without diagnostics.");
    }
  }
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`, { status: "failed" });
}

async function flushPendingFinish() {
  const { autolaunch_pending_finish: pending } =
    await chrome.storage.local.get(["autolaunch_pending_finish"]);
  if (!pending) return;
  try {
    if (pending.outcome === "posted") {
      await applyPosted(pending.queueId, pending.vin, pending.userId, pending.postedPrice, pending.reel);
      // v2.1.86: file the attach diagnostics the original
      // finish captured, if any.
      if (pending.reelDiag) await writeReelAttachDiag(pending.queueId, pending.reelDiag);
      // v2.1.85: consume the reel the original job attached
      // (v2.1.86: only on its verified attach — the stashed
      // reel record carries the verdict).
      await consumeJobReel(pending.userId, pending.vin, pending.reel);
      // v2.1.88: the replayed finish queues the edit-flow
      // attach backstop exactly like the direct one.
      await maybeQueueAttachVideo(pending.userId, pending.vin, pending.shareCar, pending.postedPrice, pending.reel);
      // The share the post earned rides the stash (v2.1.55):
      // queued on replay, still fail-open.
      await maybeQueueFeedShare({ userId: pending.userId, shareToFeed: pending.shareToFeed, car: pending.shareCar, includeStock: pending.includeStock === true, richDesc: pending.richDesc === true, dealershipName: pending.dealershipName || "", dealershipAddress: pending.dealershipAddress || "", repName: pending.repName || "", repPhone: pending.repPhone || "" });
    } else if (pending.outcome === "shared") {
      await applyShared(pending.queueId);
    } else if (pending.outcome === "price_updated") {
      await applyPriceUpdated(pending.queueId, pending.vin, pending.userId, pending.price);
    } else if (pending.outcome === "video_attached") {
      await applyVideoAttached(pending.queueId, pending.vin, pending.userId);
      // v2.1.88: consume the reel on the verified post-save
      // read that settled this finish, exactly like the
      // direct path.
      await consumeJobReel(pending.userId, pending.vin,
        { id: pending.reelId || null, source: "poster", attached: true, attachVerified: true });
    } else if (pending.outcome === "deleted") {
      await applyDeleted(pending.queueId, pending.vin, pending.userId);
    } else {
      await applyFailed(pending.queueId, pending.errorMessage || null);
    }
    await chrome.storage.local.remove(["autolaunch_pending_finish"]);
    console.log("[AutoLaunch] Replayed a job finish that was waiting on a fresh session token.");
  } catch (e) {
    // Still can't write — sbFetch already marked the session expired if
    // that's the cause. Leave the record; the next new token retries it.
  }
}


// Tab auto-close (v2.1.7, header note 14): ~4s after a finish —
// long enough for a success banner to be read — close the tab
// this worker opened for the job. Called from every finish,
// success or failure. Before 2.92, finishJobFailed never called
// it (a failed job's tab stayed open as evidence); Matthew
// retired that policy on 2026-11-09 — the diagnostics ride the
// job's DB record, and one leftover tab per failed job littered
// the user's browser across a batch. A tab the user already
// closed is a silent no-op.
function scheduleJobTabClose(job) {
  if (!chrome.tabs || typeof chrome.tabs.remove !== "function") return;
  // The job's own tab, plus the orphan-recovery tab when this
  // finish came from a recovery scan (v2.52, header note 26).
  const ids = [];
  if (job && job.tabId != null) ids.push(job.tabId);
  if (job && job.orphanRecovery && job.orphanRecovery.tabId != null &&
      !ids.includes(job.orphanRecovery.tabId)) {
    ids.push(job.orphanRecovery.tabId);
  }
  if (!ids.length) return;
  setTimeout(() => {
    for (const tabId of ids) {
      try {
        const p = chrome.tabs.remove(tabId);
        if (p && typeof p.catch === "function") p.catch(() => {});
      } catch (e) { /* the tab is already gone — nothing to do */ }
    }
  }, 4000);
}

// The ONLY two ways a job ends. Called by the content script via message.
async function finishJobPosted(queueId, listingUrl, reelAttach) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  // VIN reel attach verdict (v2.1.86, header note 41): the
  // content side's read-back rides the posted message; fold
  // it into the reel record the finish acts on. No verdict
  // on record (a recovery scan settled this job) leaves
  // attachVerified unset — consumption reads that as
  // unverified and keeps the reel. (v2.1.87, header note
  // 42: the verdict riding the message is now the BINDING
  // pre-Publish one, and the diag's note/detail are built
  // by reelAttachDiagFields — per-attempt verdicts, the
  // budget, the compact counter trace.)
  const reel = job.reel
    ? { ...job.reel, attachVerified: !!(reelAttach && reelAttach.verified === true) }
    : null;
  const reelDiag = (reel && reel.attachVerified !== true && reelAttach)
    ? compactDiagError([{
        field: "reel_attach",
        rungsAttempted: [],
        readBack: reelAttach.readBack != null ? String(reelAttach.readBack) : null,
        ...reelAttachDiagFields(reelAttach)
      }])
    : null;
  try {
    await applyPosted(queueId, job.car.vin, job.userId,
      job.queuePrice != null ? job.queuePrice : job.car.price, reel);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The listing really is live; only the bookkeeping failed. Stash
      // the finish and replay it on the next token rather than losing
      // the confirmation (or wedging every future check behind a job
      // whose browser-side work is already done).
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "posted", queueId,
          vin: job.car.vin, userId: job.userId,
          // v2.1.62: the posted price rides the stash so a
          // replayed finish stamps marketplace_posted_price
          // exactly like the direct one.
          postedPrice: job.queuePrice != null ? job.queuePrice
            : (job.car.price != null ? Number(job.car.price) : null),
          listingUrl: listingUrl || null,
          // v2.1.85: the reel the job attached rides the stash,
          // so a replayed finish consumes it exactly like the
          // direct one.
          reel,
          // v2.1.86: the attach diagnostics ride the stash, so
          // a replayed finish files them exactly like the
          // direct one.
          reelDiag,
          shareToFeed: job.shareToFeed === true,
          // v2.1.56: the settings the share text is built from
          // ride the stash too, so a replayed share row is
          // identical to the direct one.
          includeStock: job.includeStock === true,
          // Rich descriptions (v2.1.98, header note 51):
          // the switch rides the stash beside include_stock.
          richDesc: job.richDesc === true,
          dealershipName: job.dealershipName || "",
          dealershipAddress: job.dealershipAddress || "",
          // v2.1.90: the contact pair rides the stash too, so
          // a replayed finish builds the identical share text.
          repName: job.repName || "",
          repPhone: job.repPhone || "",
          shareCar: {
            vin: job.car.vin,
            year: job.car.year != null ? job.car.year : null,
            make: job.car.make || null,
            model: job.car.model || null,
            stock_num: job.car.stock_num || job.car.stock_number || null,
            price: job.car.price != null ? Number(job.car.price) : null,
            // v2.1.56: the remaining buildShareTextForCar
            // inputs, so the replay builds the same text.
            trim: job.car.trim || null,
            mileage: job.car.mileage != null ? job.car.mileage : null,
            color: job.car.color || null,
            transmission: job.car.transmission || null,
            condition: job.car.condition || null,
            // Rich descriptions (v2.1.98, header note 51):
            // the rich renderer's remaining inputs, so the
            // replayed share is identical to the direct one.
            vdp_features: job.car.vdp_features || null,
            interior_color: job.car.interior_color || null,
            body_type: job.car.body_type || null,
            price_status: job.car.price_status || null
          }
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Posted confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  if (reelDiag) await writeReelAttachDiag(queueId, reelDiag);
  // VIN reel consumption (v2.1.85; verified gate v2.1.86):
  // the post is confirmed — consume the poster reel it
  // carried, but only on a form-verified attach. Fail-open.
  await consumeJobReel(job.userId, job.car.vin, reel);
  // Edit-flow attach backstop (v2.1.88, header note 43):
  // an unverified poster attach queues its second chance
  // through the listing's Edit form. Fail-open.
  await maybeQueueAttachVideo(job.userId, job.car.vin, job.car,
    job.queuePrice != null ? job.queuePrice : job.car.price, reel);
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Posted confirmed for queue item", queueId, listingUrl || "");
  scheduleJobTabClose(job);
  // Feed share (v2.1.55, header note 29): the post is final —
  // queue the share its toggle earned. Never throws.
  await maybeQueueFeedShare(job);
}

// The delete counterpart of finishJobPosted (v2.1.4). Called by the
// content script ONLY after it verified the listing card is gone
// from the selling page — never on a click alone.
async function finishJobDeleted(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  try {
    await applyDeleted(queueId, job.car.vin, job.userId);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The listing really is deleted; only the bookkeeping failed.
      // Stash + replay on the next fresh token, like the posted path.
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "deleted", queueId,
          vin: job.car.vin, userId: job.userId
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Delete confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Delete confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// The share counterpart of finishJobDeleted (v2.1.55, header
// note 29). Called by the content script ONLY after the share
// dialog completed — never on a click alone. Settles the row
// "completed"; the car's posted stamp is untouched.
async function finishJobShared(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  try {
    await applyShared(queueId);
  } catch (err) {
    if (err instanceof SbAuthError) {
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "shared", queueId,
          vin: job.car.vin, userId: job.userId
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Share confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Share confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// The price-update counterpart of finishJobDeleted (v2.1.62,
// header note 34). Called by the content script ONLY after its
// fresh Selling-page scan proved the listing now shows the new
// price — never on the editor's Save click alone. Settles the
// row "completed" and advances the car's posted price; the
// posted-at stamp is never touched.
async function finishJobPriceUpdated(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  try {
    await applyPriceUpdated(queueId, job.car.vin, job.userId, job.updateToPrice);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The listing really does show the new price; only the
      // bookkeeping failed. Stash + replay on the next fresh
      // token, like the other finishes.
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "price_updated", queueId,
          vin: job.car.vin, userId: job.userId,
          price: job.updateToPrice != null ? job.updateToPrice : null
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Price update confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Price update confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// The edit-flow attach counterpart of finishJobPriceUpdated
// (v2.1.88, header note 43). Called by the content script
// ONLY after its reopened editor read the Videos counter
// back at >= 1 post-save — never on the Save click alone.
// Settles the row "completed", consumes the poster reel on
// that verified read, and clears the parent post row's
// reel_failed flag (inside applyVideoAttached).
async function finishJobVideoAttached(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  const reelId = job.attachReel && job.attachReel.reelId ? job.attachReel.reelId : null;
  try {
    await applyVideoAttached(queueId, job.car.vin, job.userId);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The video really is on the listing; only the
      // bookkeeping failed. Stash + replay on the next
      // fresh token, like the other finishes.
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "video_attached", queueId,
          vin: job.car.vin, userId: job.userId, reelId
        }
      });
      await cleanupCdpReelFile(job);
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Video attach confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  // The reel's job is done — consume it on the verified
  // post-save read (the note-41 rule, fed a verified
  // record). Fail-open, exactly like the post path's.
  await consumeJobReel(job.userId, job.car.vin,
    { id: reelId, source: "poster", attached: true, attachVerified: true });
  // v2.1.89: the attach job is settled — the CDP temp
  // file goes away with it (fail-open).
  await cleanupCdpReelFile(job);
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Video attach confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

async function finishJobFailed(queueId, reason, diags) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  // Diag-to-DB (v3.1): the content script's forensic records arrive in
  // this message; for a fields_unfilled failure they are compacted
  // into the row's error_message in the same write that fails it.
  // Delete jobs (v2.1.4) compact too — there the records are the
  // delete step notes (match scan, outcome), the evidence that says
  // WHY nothing was deleted. A publish_unverified failure (v2.1.7)
  // compacts as well: its records are the Selling-page verify scans,
  // the evidence that the listing truly was not there. v2.52:
  // duplicate_rejected and job_orphaned (the orphan-recovery
  // verdicts) compact too — the same scan records are the evidence
  // for those honest failures.
  const errorMessage =
    ((typeof reason === "string" && reason.startsWith("fields_unfilled")) ||
     reason === "publish_unverified" ||
     reason === "publish_button_not_found" ||
     reason === "duplicate_rejected" ||
     reason === "job_orphaned" ||
     (job && (job.action === "delete" || job.action === "share" ||
              job.action === "update_price" || job.action === "attach_video")))
      ? compactDiagError(diags)
      : null;
  try {
    await applyFailed(queueId, errorMessage);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // Same stash-and-replay as the posted path, so the row doesn't
      // sit in "processing" forever behind a dead token. The compacted
      // diagnostics ride the stash so the replay keeps them.
      await chrome.storage.local.set({
        autolaunch_pending_finish: { outcome: "failed", queueId, errorMessage }
      });
    } else {
      throw err; // the finally below still logs + clears, as before
    }
  } finally {
    await logFailure(queueId, reason || "unknown");
    // v2.1.89: a failed attach job settles too — clean up
    // its CDP temp file (the pure gate no-ops for any
    // other action and for a missing record).
    await cleanupCdpReelFile(job);
    // 2.92 (Matthew, 2026-11-09): close the failed job's tab too.
    // The compacted diagnostics were written to the job's DB
    // record by applyFailed above, so the tab is no longer the
    // evidence — leaving it open just littered the browser.
    scheduleJobTabClose(job);
    await chrome.storage.local.remove(["current_posting_job"]);
    console.warn("[AutoLaunch] Job failed:", queueId, reason);
  }
}

// --- DealerCenter DWS helper-side sync (v2.1.80; fetch shape 2.81; postpass wiring 2.82) ----
// dws_sync.js (importScripts at the top of this file) crawls
// Cloudflare-blocked DealerCenter sites from THIS browser over
// plain fetch and lands the cars itself. Background fetch only:
// no tab is created, navigated, or focused for a sync — the user
// keeps working wherever they are. The deps below hand the sync
// this worker's own Supabase plumbing and lease machinery; the
// sync path honors the lease exactly like the posting claims do.
async function dwsFetchText(url, opts) {
  const init = {};
  if (opts && opts.method) init.method = opts.method;
  // 2.81: ride the browser's own cookies for the dealer site
  // (including any Cloudflare clearance it earned by browsing), so
  // a sync request is server-visibly the dealer's own browser —
  // the premise of the whole feature. The 2.80 wrapper sent no
  // cookies, the one remaining difference from the site's own
  // same-origin requests; its page 2-4 fragment POSTs came back
  // as HTTP-200 bodies with no cards in them on the live run.
  init.credentials = (opts && opts.credentials) || "include";
  if (opts && opts.form) {
    init.headers = { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" };
    init.body = new URLSearchParams(opts.form).toString();
  }
  if (opts && opts.headers) {
    init.headers = { ...(init.headers || {}), ...opts.headers };
  }
  const res = await fetch(url, init);
  return { status: res.status, text: await res.text() };
}

function checkDwsSyncSafe() {
  if (typeof AutoLaunchDwsSync === "undefined" ||
      !AutoLaunchDwsSync || !AutoLaunchDwsSync.checkDwsSync) return;
  AutoLaunchDwsSync.checkDwsSync({
    storageGet: (keys) => chrome.storage.local.get(keys),
    storageSet: (obj) => chrome.storage.local.set(obj),
    sbGet: sbGet,
    sbPatch: sbPatch,
    sbPost: sbPost,
    sbUpsert: sbUpsert,
    getInstanceId: getOrCreateInstanceId,
    leaseDecision: helperLeaseDecision,
    leaseTtlMs: HELPER_LEASE_TTL_MS,
    fetchText: dwsFetchText,
    now: () => Date.now(),
    log: (...args) => console.log(...args)
  }).catch(err => console.warn("[AutoLaunch] DWS sync cycle failed:", err));
}

// --- Wiring ---------------------------------------------------------------

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(POLL_ALARM, { periodInMinutes: POLL_MINUTES });
  checkQueue();
  checkDwsSyncSafe();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(POLL_ALARM, { periodInMinutes: POLL_MINUTES });
  checkQueue();
  checkDwsSyncSafe();
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === POLL_ALARM) { checkQueue(); checkOutboundReplies(); checkDwsSyncSafe(); }
});

// The app is served from two first-party origins: the custom domain
// and the GitHub Pages mirror (the rebuild preview rides the mirror).
// The bridge handshake is accepted from either, and from nowhere else.
// v2.1.49: autolaunch.org added — before this the worker trusted only
// the mirror, so on the custom domain the app could never hand over
// the session token and the queue poller stayed parked.
function isAppUrl(url) {
  const u = url || "";
  return u.startsWith("https://autolaunch.org/") ||
         u.startsWith("https://mdemoss-bdc.github.io/");
}

// ---- listing-ID memory (2.91 build) --------------------------------
// VIN -> { listingId, editorUrlPattern }: the Facebook listing
// ID for a car this helper has provably stood in front of —
// harvested by the content script at the post flow's Selling-
// page verify (the strictly matched card's own link) and at
// the top of the update_price / attach_video editor phases
// (the editor URL the tab actually landed on, its ID replaced
// by "{id}" so the pattern can be re-aimed). The worker owns
// the map (chrome.storage.local) and rides the entry on
// update_price / attach_video job payloads at claim time, so
// those listing phases can navigate straight to the editor
// instead of coaxing the virtualized Selling list into
// rendering the card from a background tab. The editor
// phases' identity gates remain the only authority on
// whether the landed editor is really this car's listing; a
// failed memory-nav attempt clears the entry (the content
// side asks via AUTOLAUNCH_LISTING_ID_CLEAR) and falls back
// to the ordinary search-assist scan, once.
const LISTING_ID_MAP_KEY = "listing_id_by_vin";
async function listingIdMemoryFor(vin) {
  if (!vin) return null;
  try {
    const got = await chrome.storage.local.get([LISTING_ID_MAP_KEY]);
    const map = got && got[LISTING_ID_MAP_KEY];
    const entry = map && typeof map === "object" ? map[vin] : null;
    if (entry && typeof entry.listingId === "string" && entry.listingId) {
      return {
        listingId: entry.listingId,
        editorUrlPattern: typeof entry.editorUrlPattern === "string" && entry.editorUrlPattern
          ? entry.editorUrlPattern : null
      };
    }
  } catch (e) { /* memory is an optimization, never a gate */ }
  return null;
}
async function recordListingIdMemory(vin, listingId, editorUrlPattern) {
  if (!vin || !listingId) return;
  try {
    const got = await chrome.storage.local.get([LISTING_ID_MAP_KEY]);
    const map = (got && got[LISTING_ID_MAP_KEY] && typeof got[LISTING_ID_MAP_KEY] === "object")
      ? got[LISTING_ID_MAP_KEY] : {};
    const prev = map[vin] && typeof map[vin] === "object" ? map[vin] : {};
    map[vin] = {
      listingId: String(listingId),
      // A harvest that saw no editor URL (the post-verify
      // card link) must not erase a pattern an editor
      // landing already taught us.
      editorUrlPattern: editorUrlPattern || prev.editorUrlPattern || null,
      updatedAt: new Date().toISOString()
    };
    await chrome.storage.local.set({ [LISTING_ID_MAP_KEY]: map });
  } catch (e) { /* fail-open: the scan path still stands */ }
}
async function clearListingIdMemory(vin) {
  if (!vin) return;
  try {
    const got = await chrome.storage.local.get([LISTING_ID_MAP_KEY]);
    const map = got && got[LISTING_ID_MAP_KEY];
    if (map && typeof map === "object" && vin in map) {
      delete map[vin];
      await chrome.storage.local.set({ [LISTING_ID_MAP_KEY]: map });
    }
  } catch (e) { /* fail-open */ }
}

// Handshake path 1 (the real one): bridge.js on the AutoLaunch origin.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  if (message.type === "AUTOLAUNCH_PING") {
    // Setup-page liveness/readiness ping (header note 17). Only the
    // bridge on the AutoLaunch origin may ask — same sender discipline
    // as the login handoff below — and the answer is a boolean about
    // the stored session token, never the token itself.
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const token = await storedAccessToken();
      // v2.1.24: report our own version so the setup page can say
      // "out of date" instead of a bare "ready" for an old helper.
      let version = null;
      try { version = chrome.runtime.getManifest().version || null; } catch (e) { /* keep null */ }
      sendResponse({ hasToken: !!token, version });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_GET_INSTALL_ID") {
    // Trial-abuse install id (v2.1.45): only the bridge on the
    // AutoLaunch origin may ask — same sender discipline as the ping
    // above. The answer is the install UUID itself (never a user id,
    // never the session token).
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const installId = await getOrCreateInstallId();
      sendResponse({ installId });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_GET_INSTANCE_ID") {
    // One-active-helper instance id (v2.1.60, header note 32):
    // only the bridge on the AutoLaunch origin may ask — same
    // sender discipline as the install id above. The Extension
    // page's takeover button writes this id onto the user's own
    // settings row as the lease holder; the answer is the
    // instance UUID itself (never a user id, never the token).
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const instanceId = await getOrCreateInstanceId();
      sendResponse({ instanceId });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_CAPTURE_CHAT" && message.capture) {
    // Only the capture script on facebook.com may hand us a chat —
    // same sender discipline as the ping above.
    const fromFb = (sender.tab && sender.tab.url || "").startsWith("https://www.facebook.com/");
    if (!fromFb) return;
    (async () => {
      try {
        const result = await handleCaptureChat(message.capture);
        sendResponse(Object.assign({ ok: true }, result));
      } catch (err) {
        console.warn("[AutoLaunch] chat capture failed:", err && err.message ? err.message : err);
        sendResponse({ ok: false, error: (err && err.code) || "save_failed" });
      }
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_CHAT_SNIPPETS" && Array.isArray(message.snippets)) {
    const fromFbSnip = (sender.tab && sender.tab.url || "").startsWith("https://www.facebook.com/");
    if (!fromFbSnip) return;
    (async () => {
      try { await handleChatSnippets(message.snippets); } catch (e) { /* next pass retries */ }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_REPLY_RESULT" && message.messageId) {
    // Only a Facebook tab may report a delivery (same discipline as
    // the job-finish messages). The result flips the queued reply's
    // status in the database — that status is the rep's receipt.
    const senderUrl = (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    (async () => {
      await finishOutboundReply(message.messageId, !!message.ok, message.error || null);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_SET_USER_ID" && message.userId) {
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const updates = { autolaunch_user_id: message.userId };
      let freshToken = false;
      if (message.accessToken) {
        const { autolaunch_access_token: oldToken } =
          await chrome.storage.local.get(["autolaunch_access_token"]);
        if (message.accessToken !== oldToken) {
          // A NEW token revives an expired session: store it, clear the
          // expired stop, and (below) replay any stashed job finish
          // before resuming claims. The token value is never logged.
          updates.autolaunch_access_token = message.accessToken;
          updates.autolaunch_session_expired = false;
          freshToken = true;
        }
      }
      await chrome.storage.local.set(updates);
      sendResponse({ status: "connected" });
      if (freshToken) await flushPendingFinish();
      checkQueue();
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_SYNC_REQUEST") {
    // App-driven inbound sync (v2.1.38): the Prospects screen asks for
    // a capture pass NOW because the Facebook tab's own timers are
    // throttled while it sits in the background. Only the bridge on
    // the AutoLaunch origin may ask. We drive the best Facebook tab's
    // capture script and answer only when it confirms the writes.
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      let synced = false;
      try {
        const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
        // Ask EVERY Facebook tab (v2.1.39): each one captures what
        // IT can see — a list tab contributes snippets, the thread's
        // own tab the full conversation. The first version stopped at
        // the first tab that answered, which starved the thread tab
        // whenever another tab replied first.
        const attempts = tabs.slice(0, 3).map(t => new Promise(resolve => {
          let done = false;
          const timer = setTimeout(() => { if (!done) { done = true; resolve(false); } }, 8000);
          try {
            chrome.tabs.sendMessage(t.id, { type: "AUTOLAUNCH_SYNC_NOW" }, resp => {
              if (done) return;
              done = true;
              clearTimeout(timer);
              resolve(!chrome.runtime.lastError && !!(resp && resp.ok));
            });
          } catch (e) {
            if (!done) { done = true; clearTimeout(timer); resolve(false); }
          }
        }));
        const results = await Promise.all(attempts);
        synced = results.some(Boolean);
      } catch (e) { /* answer what we have */ }
      sendResponse({ ok: synced });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_NUDGE_OUTBOUND") {
    // Only the bridge on the AutoLaunch origin may nudge (same sender
    // discipline as the login handoff). Runs the outbound claim
    // immediately — the 1-minute alarm stays as the safety net.
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    checkOutboundReplies();
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "AUTOLAUNCH_FETCH_PHOTO") {
    // Only the Facebook content script may use the relay (it is the one
    // CORS-blocked from dealer photo servers), and only real URLs — the
    // http(s) check lives in fetchPhotoForContent.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    fetchPhotoForContent(message.url)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ ok: false, error: "photo_relay_failed" }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_FETCH_VIDEO") {
    // Intro-video relay (v2.1.53, header note 27): same sender
    // discipline as the photo relay — only the Facebook content
    // script may use it, and only real URLs (the http(s) check
    // lives in fetchVideoForContent).
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    fetchVideoForContent(message.url)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ ok: false, error: "video_relay_failed" }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_LIVENESS") {
    // Job liveness (v2.54, header note 28): same sender
    // discipline as the relays above — only the Facebook
    // content script may ask. The verdict is definitive-only
    // (jobLivenessVerdict); even a handler-level failure
    // answers live, never an abort.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    jobLivenessVerdict(message.queueId)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ live: true }));
    return true;
  }


  if (message.type === "AUTOLAUNCH_CDP") {
    // Only the Facebook content script may drive trusted input, and only
    // on its own tab (sender.tab is authoritative — content scripts
    // cannot spoof another tab's id).
    const tabId = sender && sender.tab && sender.tab.id;
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (tabId == null || !senderUrl.startsWith("https://www.facebook.com/")) return;
    handleCdp(message, tabId)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: "cdp_error: " + (err && err.message || "unknown") }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_FIELD_DIAG") {
    // A required field defeated every fill rung. Record the forensics
    // (element identity, rungs attempted, value read back) in the same
    // failure log the job reasons land in, so the NEXT failure is never
    // a guessing game. Reason strings + element metadata only.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    const diag = message.diag || {};
    logFailure(message.queueId || null, "field_diag:" + (diag.field || "unknown"), {
      field: diag.field || null,
      element: diag.element || null,
      rungsAttempted: Array.isArray(diag.rungsAttempted) ? diag.rungsAttempted : [],
      readBack: diag.readBack != null ? String(diag.readBack) : null,
      expected: diag.expected != null ? String(diag.expected) : null,
      cdpError: diag.cdpError || null,
      note: diag.note || null,
      detail: diag.detail != null ? String(diag.detail) : null
    })
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_LISTING_ID" && message.vin && message.listingId) {
    // Listing-ID harvest (2.91 build): only the Facebook
    // content script may teach the memory — same sender
    // discipline as the job-finish messages below.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    recordListingIdMemory(message.vin, message.listingId,
      typeof message.editorUrlPattern === "string" && message.editorUrlPattern
        ? message.editorUrlPattern : null)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_LISTING_ID_CLEAR" && message.vin) {
    // A memory-nav attempt failed (2.91 build): the stored
    // ID is suspect, so the entry dies and the next job for
    // this car scans the ordinary way (and re-harvests on
    // its next proven landing).
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    clearListingIdMemory(message.vin)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_POSTED") {
    finishJobPosted(message.queueId, message.listingUrl, message.reelAttach || null)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_DELETED") {
    // Only the Facebook content script reports deletes (same sender
    // discipline as the other job-finish messages' storage contract —
    // finishJobDeleted additionally requires the id to match the
    // currently claimed job).
    // v2.1.16 second witness: a delete may only be CLAIMED from the
    // Selling page. Facebook's SPA can drift the job tab elsewhere
    // (Friend Requests, 2026-10-23) without a reload, and a report
    // from any other page is a scan of the wrong room — refuse it
    // and fail the job honestly instead of clearing the stamp.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/you\/(selling|dashboard)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "delete_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobDeleted(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_SHARED") {
    // Same Selling-page sender discipline as AUTOLAUNCH_JOB_DELETED
    // (v2.1.55): a share may only be CLAIMED from the Selling page —
    // a report from anywhere else is a scan of the wrong room.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/you\/(selling|dashboard)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "share_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobShared(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_PRICE_UPDATED") {
    // Same Selling-page sender discipline as AUTOLAUNCH_JOB_DELETED
    // (v2.1.62): a price update may only be CLAIMED from the
    // Selling page, where the content script's verifying scan ran —
    // a report from anywhere else is a scan of the wrong room.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/you\/(selling|dashboard)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "price_update_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobPriceUpdated(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_VIDEO_ATTACHED") {
    // Sender discipline (v2.1.88, header note 43): an attach
    // is claimed from the Selling page OR the listing's edit
    // surface — the verdict evidence is the editor's own
    // Videos counter, read in a reopened editor after Save,
    // and the flow reports from whichever of those rooms the
    // reopened editor lives in. A report from anywhere else
    // is a read of the wrong room — refuse and fail honestly.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/(you\/(selling|dashboard)|edit)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "attach_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobVideoAttached(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_FAILED") {
    finishJobFailed(message.queueId, message.reason, message.diags)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});

// Handshake path 2 (legacy, kept for compatibility): a page that knows the
// extension id can still set the user id externally. manifest.json limits
// this to the AutoLaunch origin via externally_connectable.
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message && message.type === "SET_USER_ID" && message.userId) {
    chrome.storage.local.set({ autolaunch_user_id: message.userId }, () => {
      sendResponse({ status: "connected" });
      checkQueue();
    });
    return true;
  }
});
