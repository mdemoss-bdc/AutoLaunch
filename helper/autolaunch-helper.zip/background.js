importScripts("dws_sync.js");

// AutoLaunch Vehicle Assistant — background service worker (v2)
//
// Phase 2 changes vs the original:
//  1. HANDSHAKE: the user id now arrives from bridge.js, a content script
//     on the AutoLaunch origin that forwards the app's
//     AUTOLAUNCH_EXT_LOGIN window message. (The old code waited for
//     onMessageExternal "SET_USER_ID", which the app never sent and could
//     not send — a web page cannot message an extension it cannot name.)
//     The external listener is kept as a secondary path.
//  2. POLLING: chrome.alarms instead of setInterval. MV3 service workers
//     are killed when idle, which silently killed the 20s interval.
//  3. STATUS VOCABULARY: one vocabulary everywhere, matching the web UI —
//     pending -> processing -> posted / failed. The old code wrote
//     "completed", which the UI does not know.
//  4. CLAIMING: a queue row is claimed with a conditional PATCH
//     (status must still be pending) so two polls can never take the
//     same car twice.
//  5. DAILY LIMIT: before claiming, count today's posts from
//     scraped_inventory.marketplace_posted_at against the user's saved
//     daily_post_limit (user_settings). At the cap, nothing is claimed.
//  6. POSTED MEANS POSTED: this worker never marks a row posted. Only the
//     content script can do that, and only after it has detected a real
//     publish success on Facebook. Unconfirmed = failed, with a reason.
//  7. SESSION TOKEN: the queue / settings / inventory tables are
//     RLS-locked to the `authenticated` role with auth.uid() owner
//     policies, so the publishable key alone can see and claim NOTHING.
//     The app now sends the signed-in user's Supabase access token
//     through the bridge with the user id; the worker stores it in
//     chrome.storage.local and sends it as Authorization: Bearer on
//     every REST call. A 401/403 marks the session expired and stops
//     claiming until a NEW token arrives — no retry hammering. The
//     token is never logged and never written into any error record.
//  8. PHOTO RELAY: the content script runs on facebook.com, so its direct
//     fetch of a dealer photo URL is page-CORS-bound — and dealer photo
//     servers (mosescars.com proven) send no Access-Control-Allow-Origin,
//     so the fetch dies and the job fails with photo_download_failed.
//     Fetches from this worker are extension fetches: with host
//     permission for the origin they are NOT page-CORS-bound. The
//     content script now asks the worker for the bytes
//     (AUTOLAUNCH_FETCH_PHOTO) and rebuilds the File itself; its
//     fallback is the photo-proxy Edge Function, and only if both fail
//     does the job fail honestly — a photoless car is never posted.
//  9. CDP TRUSTED INPUT (filler v3): Year/Make/Model/Price resisted two
//     generations of DOM fills — Facebook commits those fields only
//     through its suggestion-listbox selection / trusted input pipeline,
//     and React resets values set any other way. The content script's
//     last-resort rung now asks this worker to drive REAL input through
//     the DevTools protocol (AUTOLAUNCH_CDP: attach / click /
//     insertText / key / detach via chrome.debugger on the Facebook
//     tab). While attached Chrome shows a "…is debugging this browser"
//     infobar; it disappears on detach, which happens when the fill
//     sequence ends or the job finishes/fails. An attach failure (e.g.
//     the user has DevTools open on the tab) is a structured error, and
//     the content script's verify-or-report still decides the outcome.
//     Field diagnostics (AUTOLAUNCH_FIELD_DIAG) ride the same path into
//     autolaunch_failure_log when a field defeats every rung.
// 10. DIAG-TO-DB (v3.1, fourth live test): run 4's installed build WAS
//     2.1.0 (card verified) and both attempts failed honestly with
//     fields_unfilled:Year,Make,Model,Price — but the field_diag
//     forensics NEVER appeared in autolaunch_failure_log: Matthew pulled
//     exactly two bare {at, queueId, reason} entries. The separate
//     diag-message → storage path could not be trusted, so the records
//     now ride the AUTOLAUNCH_JOB_FAILED message itself, and this
//     worker compacts them into the queue row's error_message column
//     in the same PATCH that marks the row failed (outerHTML ≤160
//     chars per field, whole string ≤3500) — the evidence lives in the
//     database, readable with a plain SELECT, no console archaeology.
//     If the error_message write is rejected, the row still ends
//     failed via a status-only PATCH. logFailure's storage writes are
//     also serialized through a promise chain now: the old
//     get-modify-write cycles from near-simultaneous callers (four
//     field diags + the job failure) could overwrite each other. And a
//     CDP attach refused with "Another debugger is already attached"
//     is retried ONCE after 3s before the reason is recorded — a
//     transient DevTools attach shouldn't cost the rung.
// 11. FORM MAP RIDES ALONG (v3.2, fifth live test): run 5's
//     error_message stayed NULL under a working diag-to-DB — the
//     content script's jobDiags was empty because the four fields
//     were never LOCATED, so the ladder (and its diagnostics) never
//     ran for them. Location is fixed content-side (container label
//     text); here, compactDiagError now also preserves each record's
//     `note` and the one-per-job `formMap` entry (the failing step's
//     visible controls with their computed container labels), and
//     the cap rises to 6000 chars — formMap entries are shed first,
//     so the field records always survive.
// 12. STEP NOTES RIDE ALONG (v2.1.3, filler v3.3): the first
//     successful post still needed Matthew's hands for the step-2
//     color dropdowns and the clean-title box — best-effort fields
//     whose misses were silent. The content script now records a
//     non-fatal "step note" for each step-2 outcome (color requested
//     -> option chosen -> read-back; clean-title click path) on the
//     same diagnostic channels. Here, compactDiagError also
//     preserves each record's `detail` string (shed with readBack
//     under cap pressure), and the FIELD_DIAG handler stores `note`
//     + `detail` in autolaunch_failure_log alongside the forensics.
// 13. FULL AUTO + DELETE JOBS (v2.1.4): the claim loop now serves
//     the queue's `action` column. (a) FULL AUTO: user_settings is
//     fetched once per cycle (daily_post_limit + the new
//     full_auto_enabled); the flag rides the job payload
//     (current_posting_job.fullAuto) so the content script can turn
//     confirm mode off and click Publish itself. (b) DELETE JOBS
//     (action='delete', target_channel='facebook', queued by the
//     app's "Remove from Facebook"): claimed under the same
//     conditional-claim + session-token rules, but the daily POST
//     limit never blocks them (the limit counts posts, not
//     removals), the no-photo rule does not apply (a car whose
//     photos vanished is exactly the car you remove), and the tab
//     opened is the selling page, not the create form. A delete
//     whose inventory row is gone is still claimed — the payload
//     falls back to the queue row's own stamped year/make/model and
//     price (producers stamp all four at insert; the contract is
//     producer-agnostic, since an inventory-lifecycle auto-removal
//     rule will create these rows when a car leaves inventory).
//     Only a row stamped without a price leaves the strict matcher
//     nothing to match — and then it refuses (listing_not_found)
//     rather than guessing. Completion is a
//     third finish path (AUTOLAUNCH_JOB_DELETED ->
//     finishJobDeleted): the queue row ends "completed" (the table
//     has no status check constraint; the app's queue view renders
//     it) with executed_at set, and the car's
//     marketplace_posted_at is cleared — the same column the app
//     derives "Posted" from, so the car truthfully returns to
//     unposted. A mid-finish token death stashes outcome "deleted"
//     alongside "posted"/"failed". Delete failures compact their
//     diagnostics into error_message too, not just fields_unfilled
//     ones — the delete step notes are the evidence there.
// 14. VERIFY FAILURES + TAB AUTO-CLOSE (v2.1.7): (a) a post that
//     ends publish_unverified (the content script clicked Publish,
//     then could not find the listing on the Selling page after
//     repeated strict-match scans) compacts its diagnostics into
//     error_message too — the records are the verify scans, the
//     evidence the listing truly was not there. (b) TAB AUTO-CLOSE:
//     every job used to leave its Facebook tab behind, and they
//     piled up across a testing session. The claim now records the
//     opened tab's id on the job (current_posting_job.tabId), and
//     the two SUCCESS finishes (posted, deleted — including a
//     delete that finished goal-achieved) schedule that tab's
//     closure ~4s later, once the success banner has been readable.
//     Failures NEVER close — the tab is the user's evidence — and
//     neither does a token-stash replay (flushPendingFinish calls
//     the apply* writes directly; by replay time the moment has
//     passed). Only the exact tab this worker opened is ever
//     closed; a tab the user already closed is a no-op.
// 15. JOB-SLOT RECONCILIATION (v2.1.8): the current_posting_job
//     slot used to be cleared ONLY by a finish message from the
//     job's own content script. Stop a run any other way — cancel
//     the queue row in the app, close the job's tab — and the
//     finish never arrives: the slot stays occupied forever and
//     every claim cycle silently returns at `if (activeJob)`, with
//     a healthy awake worker, a valid token, and a pending row
//     nobody will ever claim. Proven live 2026-10-22 ~19:46 EDT:
//     storage held a job claimed at 23:14:48Z whose queue row the
//     user had deleted; a fresh pending row sat unclaimed 15+
//     minutes. claimedAt was written at claim time but never read.
//     checkQueue now reconciles the slot against its queue row
//     before honouring it (one lightweight read, only when a slot
//     is occupied): row gone, terminal (posted/failed/completed),
//     or pending again -> the run it belonged to is dead; clear
//     the slot and fall through to claim fresh work in the SAME
//     pass. Row still "processing" -> the slot is kept, UNLESS
//     claimedAt is older than 45 minutes — past every legitimate
//     run (the 10-minute confirm watch + the ~4-minute
//     verification cap, with generous margin) — in which case the
//     content script is certainly dead, so the row is failed
//     honestly as job_orphaned (diagnostics compacted into
//     error_message, token-death stash behaviour as in the other
//     finishes), the slot cleared, and the cycle continues. A
//     lookup that itself errors (network/auth) changes NOTHING:
//     the slot is kept and the cycle skips, so a transient failure
//     can never free a live job's slot or fail its row; auth
//     errors keep the session-expired semantics sbFetch already
//     records. Every reconciliation action is logged — the old
//     failure was invisible precisely because the skip was silent.
// 16. DELETE CLICK LADDER — CDP MOUSE SEQUENCE (v2.1.9): the
//     delete flow's menu-opening ladder gains a third rung above
//     the instantaneous press+release "click": action "clickSeq"
//     dispatches Input.dispatchMouseEvent mouseMoved, then
//     mousePressed, a brief pause, then mouseReleased at the
//     content-supplied coordinates — the hover/press timing some
//     Facebook menus arm on. Same contract as every CDP action:
//     {ok:true} / {ok:false, error}, and the cdp_not_attached
//     guard applies unchanged. Purely additive: claim logic, the
//     finish paths and every other action are untouched, and the
//     delete stage notes the content script records ride the
//     existing FIELD_DIAG / diag-compaction channels — no worker
//     change was needed for them (delete failures already compact
//     diagnostics into error_message, note 13).
// 17. SETUP-PAGE PING (v2.1.10): the app's Chrome Extension page asks,
//     through bridge.js, whether this worker is present and ready.
//     {type:"AUTOLAUNCH_PING"} is answered {hasToken} — true exactly
//     when a session token is currently stored under
//     autolaunch_access_token in chrome.storage.local (the key the
//     login handoff writes; read via storedAccessToken()). The token
//     value itself is never returned, logged, or otherwise exposed —
//     only the boolean. Purely additive: no claim, finish, CDP, photo
//     or diag behaviour changes.
// 18. BACKGROUND JOB TABS (v2.1.12, Matthew's request): navigating the
//     helper's Facebook tab away mid-fill destroys that attempt's page
//     and everything typed into it. Fully automated work therefore no
//     longer steals the user's place: Full Auto posts and all delete
//     jobs open with active:false, so the user can keep working in
//     their current tab while the helper works in its own background
//     tab, and the job tab is marked autoDiscardable:false so Chrome's
//     memory saver cannot discard it mid-run. Confirm-mode posts were
//     the deliberate exception in 2.1.12 (they opened in front because
//     the user personally has to click Publish there) — Matthew
//     overruled that on 2026-10-23 after his son's cross-account
//     test, so v2.1.13 opens EVERY job tab in the background; a
//     confirm-mode form waits, filled and bannered, until the user
//     clicks over to review and publish.
// 19. POST PACING + DEALER BLOCK (v2.1.42): two settings that live in
//     user_settings — and are promised by the app's UI copy — but
//     that no code ever read. (a) PACING: the claim cycle runs on a
//     1-minute alarm and used to claim the next POST the moment the
//     previous job's slot cleared, so a queued batch drained
//     back-to-back (proven live 2026-10-26: a post completed at
//     09:31 EDT and the next car was processing by 09:33, despite
//     post_delay_minutes = 15). userSettings now also reads
//     post_delay_minutes, and checkQueue refuses to claim a POST
//     until that many minutes have passed since the newest
//     scraped_inventory.marketplace_posted_at stamp — the stamp
//     applyPosted writes at completion, so the gap anchors on the
//     COMPLETED post, survives worker restarts, and needs no new
//     state. Deletes are NOT paced (a removal is not a post, the
//     same exemption the daily limit uses). An absent/zero delay
//     means no gate, and a failed last-post lookup fails OPEN (no
//     hold) — a flaky read must never wedge the queue. (b) DEALER
//     BLOCK: userSettings also reads dealership_name /
//     dealership_address, carried on the job payload like fullAuto,
//     so the content script can close the Marketplace description
//     with the dealership's name and address (Matthew's request,
//     2026-10-26). Either may be empty; the description appends
//     whatever exists and never blocks on a missing identity.
// 20. STOCK NUMBER IN DESCRIPTION (v2.1.43): the app's Posting
//     preferences have always saved an include_stock checkbox to
//     user_settings, but no code ever read it — the switch changed
//     nothing. userSettings now also reads include_stock and it
//     rides the job payload like the dealership identity, so the
//     content script can put a "Stock #:" line under the VIN in the
//     Marketplace description (Matthew's request, 2026-10-26).
//     Fail-open both ways: the preference off, or a car with no
//     stock number, leaves the description exactly as it was.
// 21. STOCK FALLBACK FROM INVENTORY (v2.1.44): 2.1.43 read the
//     stock number off the QUEUE row (stock_num) — but the app's
//     single-car enqueue never stamped it, so a hand-queued car's
//     queue row carried NULL and its listing shipped with no
//     Stock # line even though scraped_inventory knew the number
//     (proven live 2026-10-26: the Yukon VT60164B posted with the
//     dealership block but no stock line). The claim path already
//     holds the inventory row it fetched by VIN: jobCarWithStock
//     now stamps the payload car's stock_num from the queue row
//     first, then the inventory row's stock_number, so the content
//     script always sees the best-known value. Fail-open: no
//     stock anywhere still means no line, exactly as before.
// 22. AUTO-CREATE GATE (v2.1.46): the old Marketplace-only auto rule
//     keyed creation on the mere PRESENCE of a listing label — and
//     labels leak: a plain 1:1 Messenger chat about tires scraped
//     one, and a thread whose counterparty is the rep himself (a
//     Marketplace system/self thread) matched his own car's label.
//     On 2026-10-26 both became junk prospects on Matthew's account
//     the moment the app synced. Creation now runs through
//     autoCreateGate: a resolved participant name is mandatory (an
//     unresolved name NEVER auto-creates), a counterparty resolving
//     to the rep himself never creates, and at least one positive
//     seller-side signal must fire — the Marketplace inbox surface,
//     the seller's own thread controls ("View buyer"), or a label
//     matching one of the user's own posted cars. Snippet sync and
//     updates to known prospects are untouched: the gate decides
//     CREATION only, and it fails closed.
// 23. SELF BY IDENTITY + CAPTURE REASONS (v2.1.47): note 22's self
//     test matched the counterparty's NAME against the rep's —
//     but Matthew tests Marketplace chats from a second Facebook
//     account under the same display name ("Matthew DeMoss"), so
//     the name test blocked his own alt-account buyer threads, and
//     would block any real buyer who shares his name. The gate now
//     blocks as self ONLY on a proven Facebook-identity match: the
//     capture carries canonical identity tokens (buyerFbId /
//     selfFbId, scraped from profile links and the c_user cookie),
//     and a name match alone is no signal at all. Same release:
//     manual Capture stopped failing silently — the worker returns
//     a short error code (not_signed_in / no_buyer / save_failed)
//     and the button names the cause ("reload this Facebook tab"
//     for an orphaned script after a helper update, the bare
//     "Capture failed" case Matthew hit on 2026-10-26), and a
//     manual capture with no matched prospect and no resolvable
//     participant declines as no_buyer instead of filing a
//     nameless "Marketplace buyer" card.
// 24. SYNC REPAIR (v2.50): three fixes from Matthew's live
//     session, 2026-10-27. (a) CHROME NAMES: a half-rendered
//     thread paints the generic participant placeholder
//     "Facebook user" (plus "Compose" / "Conversation with
//     Facebook user" furniture); those strings were saved as
//     messages and even filed as a prospect NAME. chat_capture.js
//     now filters them everywhere, and autoCreateGate below
//     treats them as an unresolved name. (b) RENDER-SKIP RETRY:
//     gate skips for render-dependent reasons (unresolved_name /
//     no_seller_signal) are no longer final — chat_capture.js
//     tracks the worker's skip response per thread and re-sends
//     on later passes, bounded per page session. (c) TOMBSTONES:
//     deleting a prospect used to be undone by the next
//     auto-sync pass — the Facebook thread still exists, so
//     find-or-create simply re-created the card. A trigger now
//     records every deleted prospect's thread key in
//     prospect_tombstones; the auto path below checks it before
//     creating (skip reason deleted_by_user — terminal, never
//     retried) and a MANUAL Capture of the same thread removes
//     the tombstone (explicit undelete).
// 25. CAPTURE HYGIENE (v2.51): four fixes from Matthew's live
//     group thread, 2026-10-27. (a) GROUP CHROME: Marketplace
//     threads are group chats — Facebook's own narration ("…
//     named the group …", "… changed the group photo."), the
//     buyer card (participant's full name, ratings lines), the
//     listing label line and bare sender captions were all
//     stored as buyer messages; chat_capture.js now patterns
//     the whole family, not just yesterday's strings. (b)
//     DIRECTION: the scrape placed bubbles by center-vs-pane-
//     midpoint, but the pane spans nav + thread + info rail, so
//     a long rep bubble's center fell on the "buyer" side — the
//     rep's own delivered reply was re-filed as the buyer's.
//     The scrape now classifies by edge-hugging against the
//     bubble column itself and skips what it cannot place; and
//     handleCaptureChat refuses a long body already stored
//     under the OPPOSITE direction (same text, other side = the
//     same message mis-read; short echoes like "Yes" exempt —
//     both sides really say those). (c) TRANSIENT STATES:
//     "Sending" / "Delivered" / "Seen" / "Edited" / "You sent"
//     are delivery furniture, never message bodies, on every
//     storage path. (d) AUTO-PASS SILENCE: the content script
//     marked a thread's content hash before the worker
//     answered, so an errored pass (e.g. not_signed_in during a
//     session handover) silenced that thread until its text
//     changed; the hash now survives only a confirmed outcome.
// 26. OUTCOME TRUTH (v2.52 — the 2026-10-28 Passport incident;
//     content.js header note 26 carries the scan side): the
//     worker half of the same repairs. (a) CLAIM-TIME STAMP
//     CHECK: a POST row whose inventory record already carries
//     marketplace_posted_at is completed as posted at claim —
//     no tab, no second post; the existing stamp is the truth
//     and is left untouched, and the row's executed_at
//     fingerprints the path (applyPosted rows carry none).
//     (b) ORPHAN RECOVERY: a stale (>45 min) processing POST
//     row is no longer failed blind — the worker first arms
//     the stored job for Selling-page verification
//     (verifyPublished with orphanRecovery) and opens a
//     Selling tab to run the status-aware scan; the scan's
//     ordinary finish settles the row (live → posted, shells
//     → duplicate_rejected, nothing → job_orphaned). Only
//     when the scan cannot start, or produces no verdict
//     within 6 minutes, does the old blind fail land — with
//     the recovery outcome named in its diagnostics. Delete
//     rows keep the blind fail exactly as before. (c)
//     finishJobFailed now compacts diagnostics for
//     duplicate_rejected and job_orphaned too, so the scan
//     evidence rides error_message like every other honest
//     failure.

// 27. INTRO VIDEO ON MARKETPLACE (v2.1.53 — Intro Video Phase 4;
//     content.js header note 27 carries the composer side): the
//     composer test on Matthew's account (2026-10-28) proved the
//     vehicle composer takes ONE video (60 seconds max) through
//     a dedicated control alongside the photos, so Marketplace
//     is IN. userSettings now also reads intro_video_enabled /
//     intro_video_mode / intro_selected_video_id, and checkQueue
//     resolves the clip AT CLAIM TIME (resolveIntroVideo,
//     [PURE-INTRO-RESOLVE]): 'selected' uses the pinned row,
//     'random' picks one of the user's rows per post. The
//     resolved { url, videoId } rides the stored job only —
//     nothing is added to queue rows, per the spec's lookup-at-
//     use design — so the toggle and Delete take effect from
//     the very next post. STRICTLY FAIL-OPEN (spec invariant
//     2): disabled, an empty library, a vanished selection, or
//     a failed lookup each resolve to a named skip and the post
//     proceeds exactly as before this version. The worker also
//     relays the clip bytes to the content script (the AUTO
//     LAUNCH_FETCH_VIDEO message), mirroring the photo relay:
//     the page cannot fetch cross-origin itself.
// 28. BOUNDED VIDEO FETCH + JOB LIVENESS (v2.54 — the
//     2026-10-28 Accord wedge; content.js header note 28
//     carries the composer side): the relay fetcher below ran
//     a bare fetch + arrayBuffer() with no time limit, so a
//     stalled download never settled, the content script's
//     relay wait never answered, and the post wedged silently
//     behind the previous banner step. fetchVideoForContent
//     now aborts its fetch at 30s and answers the structured
//     refusal video_fetch_timeout; the content side races the
//     relay answer and bounds its own fallback, so a dead
//     download becomes the ordinary intro_video_download_
//     failed skip and the post proceeds without the clip.
//     The worker also answers AUTOLAUNCH_JOB_LIVENESS: the
//     content script asks, before filling, whether its stored
//     job is still the live slot — the same incident's second
//     half was a surviving tab re-driving a fill for a row
//     this worker had already settled. The verdict is
//     definitive-only: the slot holding a different job (or
//     no job), a missing queue row, or a row already in a
//     terminal state (or pending again, per reconcileActive
//     Job's reading) answers { live: false }; a matching slot
//     with a processing row answers { live: true }; and any
//     lookup failure answers { live: true } too — uncertainty
//     never blocks a fill.
// 29. SHARE TO FEED (v2.1.55 — Matthew's spec, 2026-10-29;
//     content.js header note 29 carries the Selling-page side):
//     two entry points, ONE mechanism. (a) The app's "Share to
//     my feed" button inserts an auto_posting_queue row with
//     action 'share' — the worker claims it exactly like a
//     delete (same Selling-page tab, same pacing/limit
//     exemption class, same missing-inventory-row fallback to
//     the row's stamped fields, same conditional claim), and
//     the content script shares the strictly matched listing
//     to the user's personal feed. A share NEVER touches
//     scraped_inventory.marketplace_posted_at: the listing
//     stays posted; the row settles 'completed'. (b) The
//     settings toggle (user_settings.share_to_feed, read at
//     claim time by userSettings exactly like the intro trio)
//     rides POST jobs as job.shareToFeed; when a post job
//     finalizes SUCCESSFULLY, finishJobPosted queues ONE share
//     row for the just-posted car through maybeQueueFeedShare
//     (dedupe-checked against live share rows for the VIN).
//     STRICTLY FAIL-OPEN, mirroring the intro-video skip
//     contract: the share insert is wrapped so it can never
//     throw into, fail, or delay the completed post — the post
//     is already final when it runs — and the share job itself
//     is an ordinary queue row whose own failure settles
//     'failed' with field_diag evidence, exactly like a delete.
//     Post failure never reaches finishJobPosted, so a failed
//     post never queues a share; toggle off queues nothing.
// 30. SHARE HARDENING (v2.1.56 — content.js header note 30
//     carries the incident and the two gates): share rows now
//     carry the listing's description text in the new
//     auto_posting_queue.share_text column, and the worker
//     carries it on share jobs as job.shareText for the
//     content script's composer placement. The worker-side
//     producer (maybeQueueFeedShare) stamps it with
//     buildShareTextForCar — a rebuild of the listing
//     description from the same inputs the posting composer
//     uses: the description TEXT is built in the content
//     script at post time and never reported back to the
//     worker, so the worker reconstructs it from the job's
//     car row plus the claim-time settings (dealership
//     identity + include_stock ride every job payload). The
//     auth-stash replay builds the same text: the stash's
//     shareCar now also carries trim / mileage / color /
//     transmission / condition and the stash carries the
//     identity + stock settings, so a replayed insert is
//     identical to the direct one. A claimed share whose row
//     predates the column simply carries shareText "" and the
//     content side fails it share_text_unplaced — a bare
//     share is never an acceptable outcome.
//
// 31. DEALERSHIP TAG ON FEED SHARES (v2.1.59 — content.js
//     header note 33 carries the design): the content
//     script now appends a best-effort Facebook @mention
//     of the dealership Page to the share composer's
//     details text. NO worker change was needed: the
//     dealership name has ridden every claimed job since
//     the description's closing block existed —
//     jobPayload sets dealershipName from the claim-time
//     settings (user_settings.dealership_name, read with
//     the settings block at claim) unconditionally, share
//     rows included, and the content script already binds
//     it at the top of every job. Both share producers
//     (app button + auto-share) claim through the same
//     path, so both arrive tagged-capable. This note is
//     the whole worker-side delta: comment only.
//
// 32. ONE ACTIVE HELPER — THE LEASE (v2.1.60 — Matthew's
//     spec, 2026-10-29; proven necessary the same night):
//     two helper workers holding the same user's session
//     raced one queue — an old pre-share build on Matthew's
//     home PC kept claiming rows, and its claim-time
//     already-posted shortcut closed SHARE rows "posted"
//     without ever opening Facebook (three shares eaten;
//     caught live by watching a row flip pending -> posted
//     in 5 seconds with the desk helper switched OFF).
//     Rule from this build: only ONE helper instance per
//     account may CLAIM queue jobs. The lease lives on the
//     user's own user_settings row (helper_lease_id /
//     helper_lease_expires_at — two nullable columns; the
//     own-row RLS policies already cover them). Each
//     instance owns a random UUID (al_instance_id in
//     chrome.storage.local, created on first need, stable
//     for the install — deliberately distinct from the
//     trial-abuse al_install_id). checkQueue reads the
//     lease with the claim cycle's existing settings fetch
//     (no extra round trip): empty, expired, or MINE ->
//     renew (one PATCH, expiry now + 10 min) and claim as
//     before; FOREIGN and unexpired -> claim NOTHING this
//     cycle and keep cycling (dormant) — the lease may
//     expire or be yielded. The lease gates NEW claims
//     only: job-slot reconciliation, every finish function,
//     the auth-stash replay (flushPendingFinish) and orphan
//     handling run exactly as before, so a job already in
//     flight settles its bookkeeping even if the lease is
//     lost mid-run — a row is never stranded by the lease.
//     If the lease write fails the cycle claims nothing
//     (fail closed; Supabase being unreachable already
//     blocks the queue reads, so this adds no new outage
//     class). Takeover is deliberate, never automatic: the
//     app's Extension page shows the lease state, and its
//     "Use this computer instead" button writes THIS
//     install's instance id (asked over the bridge —
//     AUTOLAUNCH_GET_INSTANCE_ID, app-origin senders only)
//     onto the row; the old holder sees a foreign lease on
//     its next cycle and stands down. Legacy builds know
//     nothing of the lease and ignore it — the lease
//     protects an account once its helpers run this build.
//
// 33. CARFAX REPORT LINE IN SHARE TEXT (v2.1.61 — CARFAX
//     phase 2, 2026-10-29; content.js header note 34
//     carries the composer's side): buildShareTextForCar
//     gains the identical conditional "CARFAX report:
//     <url>" line the composer gained, from the same input
//     (the claimed car row's carfax_url, which the
//     production scraper now keeps fresh from each VDP's
//     badge). The three builders stay byte-identical, so
//     a share's details text still equals the listing's
//     description exactly — with the link when the car
//     has one, and byte-identical to 2.1.60 when it
//     doesn't. Comment + one builder term; no other
//     worker behavior changes.
//
// 34. LISTING PRICE SYNC (v2.1.62 — Matthew, 2026-11-03;
//     content.js header note 35 carries the editor's side):
//     a Facebook listing keeps its post-time price forever,
//     while the dealer's price moves — so removals built at
//     the current price failed the strict title+price match
//     (the Nautilus: posted $14,530, price dropped to
//     $12,492, removal refused). Two foundations land here.
//     (a) POSTED-PRICE STAMP: applyPosted now also writes
//     scraped_inventory.marketplace_posted_price — the price
//     the post actually used, carried on the job from the
//     queue row — and applyDeleted clears it with the posted
//     stamp; producers build removals from it, so a removal
//     always matches the price the listing shows. (b) PRICE
//     UPDATE JOBS: the scraper queues action "update_price"
//     rows (price = the new price, update_from_price = the
//     price the listing still shows) when a live listing's
//     dealer price drifts. A price update is NOT a post —
//     Matthew's rule: it never counts toward the daily cap,
//     the usage counters, or post pacing, so checkQueue
//     claims it under the same exemptions "share" carries,
//     and its completion (applyPriceUpdated) advances ONLY
//     marketplace_posted_price — marketplace_posted_at is
//     never touched, so neither today's-posts count nor the
//     pacing anchor can move. Claim-time basis validation
//     (priceUpdateClaimGate) fails the row untouched when
//     the drift it was queued for is no longer the drift
//     that exists; the next sync re-queues the truth.
//
// 35. FOREGROUND FOR SCAN JOBS (v2.1.76 — Matthew,
//     2026-11-05; content.js header note 36 carries the
//     scan's side): Facebook only paginates the Selling
//     list on a page the browser is actually rendering —
//     a tab created active:false and never shown keeps
//     exactly its first chunk of cards (five, live
//     2026-11-05) no matter how long the settle scrolls,
//     so scan jobs (update_price, delete, share) died
//     listing_not_found on a list that was never loaded.
//     The worker now fronts a scan job's tab before its
//     flow begins: the tab the user was on in that window
//     is remembered on the job (restoreTabId) and the job
//     tab is activated; when the job ends — finish, fail,
//     exception, watchdog reconcile — the remembered tab
//     is re-activated. Tab activation only: the window is
//     never focused, and post jobs keep the v2.1.12
//     background rule untouched. A window that stays
//     minimized keeps its hidden page — the scan then
//     fails list_never_grew (content note 36), honestly.
//
// 37. SCAN JOBS LIVE IN A HELPER WINDOW (v2.1.77 —
//     Matthew, 2026-11-05; supersedes the same-window
//     half of note 35): the v2.1.76 fix itself was proven
//     live the morning it shipped — a fronted job tab's
//     match scan settled at the full census (cards:72,
//     vis:visible) after ~25 hidden-tab failures — but
//     fronting inside the USER's window switched the tab
//     out from under him while he was typing in another
//     one, and his ruling was plain: that can't happen.
//     Scan jobs now run in a dedicated Chrome window the
//     helper owns: created unfocused on first need, its
//     id kept in chrome.storage.local (al_helper_window),
//     reused across jobs, and recreated lazily when it is
//     gone (closed by hand, or forgotten at browser
//     startup, when a stored id could name a stranger's
//     window). The job tab is activated inside that
//     window only — being a window's active tab is what
//     makes the page render and paginate — no window is
//     ever focused, and no tab in the user's window is
//     ever activated for a scan. Note 35's borrowed-
//     foreground machinery (restoreTabId, and the
//     restore calls on the terminal paths) is removed:
//     there is no borrowed foreground left to give back.
//     If the helper window cannot be had, the scan job
//     fails honestly (helper_window_unavailable) rather
//     than fall back to the user's window. Post jobs are
//     untouched — inactive tabs in the user's window,
//     nothing to scan.
//
// 39. SEARCH-ASSIST, WORKER SIDE (v2.1.78 — Matthew,
//     2026-11-05; content.js header note 38 carries the
//     scan's side): notes 35 and 37's mechanisms are both
//     REMOVED. The helper window bought a rendered page at
//     the price of a second window the user's maximized
//     window then hid anyway (uniform cards:5 vis:hidden,
//     live 2026-11-05), and fronting in the user's window
//     (note 35) remains forbidden by his ruling. A scan no
//     longer needs its page rendered at all: the content
//     side renders the one target card through the Selling
//     list's own search (note 38) and reads it from the
//     DOM of an ordinary background tab. The claim site is
//     therefore back to a single creation path for every
//     job — chrome.tabs.create({ active: false }) in the
//     user's window, the v2.1.12 rule whole again: no tab
//     is activated for any job, no window is created or
//     focused, and the helper-window block and its
//     al_helper_window storage key are gone with the
//     mechanism. Post jobs were never touched by any of
//     this and are byte-identical.
//
// 40. VIN REELS PHASE 2 (v2.1.85 — Matthew, 2026-11-05):
//     the auto-post producer can queue a marketplace row
//     HELD (awaiting_reel=true) behind a poster VIN Reel.
//     Held rows are invisible to the claim fetch (one added
//     filter; the claim's shape and order are unchanged)
//     until the reels worker releases the hold — reel ready,
//     reel failed, or hold stale. At claim time a post looks
//     up the car's latest reel: a READY reel rides the job's
//     introVideo slot INSTEAD of the user's intro video (one
//     video slot; the reel carries the dealership branding),
//     so the content side's attach path is untouched. After
//     the post SUCCEEDS, a source='poster' reel is consumed:
//     its storage object is deleted and the row is marked
//     consumed — the Facebook post keeps its own copy. A
//     ready source='manual' reel attaches but is NEVER
//     consumed (cleanup may only ever touch poster reels).
//     No ready reel at claim time posts exactly as before:
//     nothing in this version can block a post on a video.
//
// 41. REEL ATTACH VERIFICATION (v2.1.86 — Matthew, 2026-11-06):
//     the 2.85 desk test posted three held cars; only one
//     listing actually carried its video, yet all three poster
//     reels were consumed — claim time had stamped the reel
//     "attached" on INTENT, and the finish believed the stamp.
//     Now the content side reports the attach verdict with the
//     posted message: it reads the composer's Videos counter
//     back after the attach (one retry on a miss, content.js
//     header note 41) and only a VERIFIED attach (counter
//     >= 1) lets a finish consume the poster reel. An
//     unverified attach leaves the reel ready, stamps the
//     queue row's completion reel_failed=true (the health
//     bar's "posted without video" chip finally tells the
//     truth both ways), and files the attach diagnostics in
//     the row's error_message in field_diag style — the post
//     itself still completes and stamps exactly as before.
//     A finish with no attach verdict on record (a recovery
//     scan settled the job) counts as unverified: consumption
//     requires proof, never a presumption.
//
// 42. REEL ATTACH: BINDING PRE-PUBLISH VERDICT (v2.1.87 —
//     Matthew, 2026-11-06): the consumption rule of note 41
//     is unchanged — the verdict it consumes is now the
//     content side's FINAL one, taken immediately before
//     Publish after a counter-required wait, a size-scaled
//     budget, and at most one repair attach (content.js
//     header note 42). The diag filed for an unverified
//     attach grows the self-diagnosing tail the Wrangler
//     run was missing: every attempt's verdict (with ever /
//     signature markers), the budget the size-scaled wait
//     used, the stage that produced the binding verdict,
//     and the compact Videos-counter trace — built purely
//     by reelAttachDiagFields so the harness exercises the
//     exact strings the row will carry.
// 43. EDIT-FLOW VIDEO ATTACH (v2.1.88 — Matthew, 2026-11-06):
//     the create-flow attach is structurally beaten — six
//     desk runs across file sizes, helper versions and
//     watched/unwatched tabs all ended the same way: the
//     clip attaches and verifies (a watched run read the
//     counter 1/1 in 7s, through the VIN auto-fill settle),
//     then Facebook's composer DROPS it at the "Next" step
//     transition, and the final step has no video input to
//     repair with. The EDIT surface is the proven one —
//     Matthew attached the Durango's reel by hand through
//     ⋯ → Edit listing and it stuck at once. So the attach
//     becomes a SECOND, queued job: when a post completes
//     with its poster reel still unconsumed (the note-41/42
//     verdict said unverified), the finish queues ONE
//     attach_video row for the car (dedupe-checked, strictly
//     fail-open), and a later claim runs it as a price
//     update's sibling: strict Selling-page match at the
//     POSTED price, the listing's own Edit form, the 2.87
//     attach machinery against that form, Save, then a
//     reopened editor as the post-save proof. Only a
//     verified post-save read consumes the reel, settles
//     the row "completed" and clears the parent post row's
//     reel_failed flag. The claim also gains its ACTION
//     ALLOWLIST in this version: a helper claims only
//     actions it knows (post/delete/share/update_price/
//     attach_video); an unknown action is never claimed as
//     a post. Blast radius, stated plainly: an attach_video
//     row can exist only in the queue of an account whose
//     own >= 2.88 helper created it at a post completion —
//     no producer writes one. An OLDER helper on that same
//     account claiming one as a "post" exits at the v2.52
//     claim-time stamp check (the car always carries
//     marketplace_posted_at — that is the attach premise):
//     the row settles "posted" without a tab ever opening,
//     no listing is created, the stamp is untouched and the
//     reel stays ready; the attach is simply lost. The one
//     residue: if the listing were deleted between queueing
//     and such a claim, the stamp check could not fire and
//     the legacy flow would re-post the car as it would any
//     queued post row — bounded to a downgrade window on an
//     account that ran 2.88, and accepted. Attach jobs are
//     not posts anywhere the worker counts: the daily cap
//     and usage count read inventory stamps (an attach
//     completion never stamps), pacing anchors on the same
//     stamp, and the claim treats the action with the
//     delete/share/update_price exemptions.
// 44. EDITOR ATTACH: CDP FILE INJECTION (v2.1.89 — Matthew,
//     2026-11-06): the 2.88 desk proof isolated the last
//     mechanism. In the listing's editor the DataTransfer-
//     set clip verified in the form (done/ever), Update was
//     clicked — and the reopened editor read the counter
//     at 0 (saved_unproven). The page-level set yields a
//     preview Facebook never binds to a durable upload;
//     Matthew's picker upload of the same file persisted
//     at once. The editor attach's file set is now picker-
//     equivalent: this worker saves the reel bytes to a
//     real on-disk path itself (chrome.downloads — the one
//     NEW permission in this build; "debugger" was already
//     carried for the note-9 trusted input) and, over the
//     note-9 CDP session, runs DOM.setFileInputFiles on
//     the exact input the content script marked. The
//     download record rides chrome.storage so the temp
//     file is cleaned up (removeFile + erase) when the
//     attach job settles — success in finishJobVideo-
//     Attached, failure in finishJobFailed — always fail-
//     open. Any failure in the download/CDP chain answers
//     a structured error and the content side falls back
//     to the DataTransfer set for that attempt; the
//     reel_attach diag states the mechanism that ran. The
//     create-flow attach keeps the DataTransfer set: this
//     build tests injection in the editor only.
// 45. CONTACT LINE + CARD-AS-LAST-PHOTO (v2.1.90 — Matthew,
//     2026-11-06): two surfaces for the rep's own "Call or
//     text {name} · {phone}" (user_settings rep_display_
//     name / rep_phone — both required, either blank and
//     every surface stays byte-identical to 2.89). (a) The
//     LISTING contact line: userSettings now reads the
//     pair and the job payload carries it exactly like the
//     dealership identity; both description composers —
//     the content side's buildDescription and this
//     worker's buildShareTextForCar, with the app's
//     buildShareDetailsText the third mirror — append it
//     as the closing line after the dealership block,
//     through the one pure formatter (repContactLine) so
//     the three can never drift. The voiceover never
//     speaks it (the generator asserts the same rule).
//     (b) The reel's end-card still rides the post as the
//     LAST photo: the generator uploads it beside the mp4
//     (qa.card_url on the reel row), the claim's reel
//     resolution carries the URL on the job, and the
//     content side attaches it after the dealer photos —
//     planPhotoAttach caps the dealer set at 19 when a
//     card rides, so the listing never passes Facebook's
//     20; under 20 it simply appends. The card never
//     counts toward any photo gate: the claim's no-photo
//     guard, the producer's minimum and the content
//     Photos verdict all keep reading dealer photos only.
//     Card download/attach failures are fail-open (the
//     post stands without the card), and consumption now
//     deletes the card object beside the mp4.

// 51. RICH DESCRIPTIONS (v2.1.98 — Matthew, 2026-11-10;
//     promoted from the rebuild, commit bde99546 —
//     content.js header note 51 carries the design):
//     worker side is carriage only. userSettings reads
//     user_settings.rich_descriptions (default OFF) beside
//     include_stock; the claim carries it on every job
//     payload as job.richDesc, exactly like includeStock;
//     buildShareTextForCar runs the same [PURE-RICHDESC]
//     renderer over the job's car row (the claim-time
//     inventory fetch is select-*, so vdp_features rides
//     the car row with no new fetch). The finish path's
//     auth-stash replay carries richDesc beside
//     includeStock and the shareCar snapshot now also
//     carries the payload inputs (vdp_features,
//     interior_color, body_type, price_status), so a
//     replayed share builds the identical rich text.
//     With the switch off — or no usable payload — every
//     surface is byte-identical to before this feature
//     existed.

// 57. HANDS-FREE WORKER HEALTH + FAILURE RECOVERY
//     (v2.1.104 — Matthew's hands-free principle,
//     2026-11-12; the top-5 helper bundle): four changes.
//     (1) KEEP-AWAKE: while work is pending the worker
//     holds chrome.power.requestKeepAwake("system"), so
//     the desk PC no longer needs a keep-awake script
//     babysitting it; the hold releases after a full
//     claim cycle with an empty queue and nothing in
//     flight. "Work pending" is decided from the claim
//     cycle's own state: a job in flight (the reconciled
//     slot kept, a claim just made, or rows waiting on
//     the cap / pacing), a non-empty claim fetch, or
//     auto-reply hub duty (the availability toggle ON —
//     pending auto-sends live in the hub runtime, not
//     the queue). Fail-safe: a power-API error is logged
//     and never blocks a claim, and the hold also
//     releases on worker suspension. The manifest gains
//     exactly ONE permission for this: "power".
//     (2) ORPHAN VERIFICATION GENERALIZED: the pre-fail
//     Selling-page verification that covered orphaned
//     posts now covers orphaned update_price and delete
//     jobs too — content.js runOrphanVerify runs the
//     same settled scan, and the row settles completed
//     only on the verified report (the price stamp
//     advances only then); unverified orphans fail
//     exactly as before. And a list_never_grew scan
//     failure returns the job to pending ONCE (a retry
//     marker rides its diagnostics); a second occurrence
//     fails terminally. (3) PERMISSION SELF-CHECK: on
//     install/startup and at the top of every claim
//     cycle the manifest's permissions are verified;
//     a missing one is written as a NAMED structured
//     last-error (missing_permissions: [...]) and rides
//     the ping reply as permissions_ok — detection
//     only, claiming is unchanged. (4) SESSION-EXPIRED
//     SURFACING: a 401 now also sets the persistent
//     al_session_expired state, cleared by the next
//     successful authenticated call or a fresh token;
//     it rides the ping reply as session_expired, so
//     the app can show why a helper went quiet instead
//     of the flag sitting unread.

// 58. HUB SURFACE RULE (v2.1.105): the auto-reply hub requirement
// is a tab on /marketplace/inbox SPECIFICALLY. Before this build
// any tab matching facebook.com/(messages|marketplace/inbox)
// counted as "an inbox surface exists", so a rep's bare
// /messages/ tab suppressed the hub forever — and on the
// /messages/ start page Marketplace threads live inside the
// unopened "Marketplace" folder row: no thread anchor renders,
// all harvesting is anchor-based, so no stub, snippet or
// nomination ever fired there (Matthew's 2.104 desk proof,
// 2026-11-12: the Mustang thread sat eight minutes with the
// helper alive, lease renewing, and the chain never started).
// A /messages/ tab no longer satisfies the rule; a tab already
// on /marketplace/inbox — the tracked hub or the rep's own —
// still does, so the hub is never duplicated.
// MANUAL-LANE MERGE GUARD (v2.1.105): the 3.03 id-less guard and
// the auto-create gate are AUTO-only, so the floating Capture
// button's UNtagged send sailed past both: pressed on a list
// page it filed the whole page as one prospect keyed to the
// bare page URL (live instances 2026-11-03 and 2026-11-12, the
// latter named "Notifications" off the page heading, with a
// fused banner label and zero messages). handleCaptureChat now
// drops ANY capture — tagged or not — whose threadRef lacks
// /t/<digits> AND which carries no messages, before any read or
// write. Manual captures WITH messages keep the exact prior
// behavior: the popup lane keys its captures to the page URL
// and always carries messages, so it is untouched.
// SNIPPET-LINK REPAIR (v2.1.105): the 2.104 salvage test proved
// the snippet-to-nomination link dead in production. (1)
// handleChatSnippets stored each snippet as a closer_messages
// row BEFORE nominating, and lucaAutoReplyThreadState counts a
// stored snippet row as a captured message — so the nominator's
// own gate (real > 0) rejected the very thread the snippet was
// meant to nominate, on the first pass and every later one; it
// now nominates BEFORE the store loop; the evaluate hook
// that ran on stored snippets is removed for the same
// reason — it wrote terminal decisions from the preview
// text itself, barring the real capture from ever
// deciding — and the capture merge strips a fused
// sender-name prefix when retiring snippet partials, so
// a verified capture is not blocked by its own preview
// row; and snippet rows are stored only for threads that
// already hold captured messages — a stub thread's
// preview row was indistinguishable from a capture to
// every downstream gate (the candidate processor read
// it as a landed capture and skipped the verification
// open entirely). (2) The canned set
// carried hi/hello/hey greetings but no good morning /
// afternoon / evening forms, so "Good evening, is this still
// available?" — availability-only, fused "Name:" prefix and
// all — could never nominate or decide; the three greeting
// forms join the set on the same terms as hi/hello/hey.
// (3) chat_capture's snippet walk needs a separate preview
// segment after the buyer name; rows whose text never
// separates (the /messages/ folder renders some rows fused)
// yielded a stub but no snippet, forever, so the snippet pass
// there falls back to the text after the listing label.
// "Notifications", "Messenger" and "Chats" also join
// FB_CHROME_LABELS in chat_capture.js: they are Facebook page
// headings, never buyer names, and the bare-/messages/ junk
// prospect took its name from exactly such a heading —
// so the name scrape rejects them outright.

// 59. FIRST-CONTACT SYSTEM LINE (v2.1.106): on the
// /marketplace/inbox surface a FIRST listing inquiry shows
// no buyer words at all — the row preview is Facebook's own
// sentence: "<Name> sent you a message about your listing:
// <title>" (Matthew's 2.105 desk proof, 2026-11-12: the hub
// tab existed, the Mustang row sat at the top of the Selling
// list unread, and the chain never started, because the
// snippet nominator matches buyer availability text and the
// preview held none; the same thread's row on /messages
// showed the buyer's real words — the surfaces differ). The
// nominator now also accepts that exact signature, anchored
// at the start of the snippet: one to four capitalized name
// tokens, the exact phrase with its colon, then listing
// text. It NOMINATES ONLY, on the same gates as a textual
// snippet — the verification open re-reads the thread and
// the decider judges the buyer's real first message, so a
// look-alike line can never produce a send. The line is
// Facebook chrome, not a message: the snippet store loop
// skips it explicitly, so it is never stored and never
// reaches the decider as text.
// 60. INBOX BUTTON-ROW HARVEST (v2.1.108): the root cause of
// the 2.104/2.105/2.106 hub failures, proven 2026-11-13 by
// read-only DOM inspection of facebook.com/marketplace/inbox
// in a signed-in browser: the page contains ZERO anchors
// matching a[href*="/messages/t/"]. Every conversation row
// is a <button> (role="button") with no href and no
// contained <a>; rows are siblings inside <main> alongside
// the Selling/Buying/Jobs tabs. collectThreadSnippets and
// collectThreadStubs hook ONLY anchors, so the hub surface
// never harvested anything under any build (the 3.07
// diagnostic trace confirmed the worker side was healthy
// throughout: toggle read true, hub exists, processor
// ticking, zero snippets ever delivered). chat_capture now
// also harvests the button rows on /marketplace/inbox:
// header ("<Name> · <Label>", label may be absent), preview
// line, unread if an aria marker says so, plus a
// best-effort thread id scanned from the row's React props
// (never a click, never a read mark). Records ride the
// snippet channel with rowKind "inbox_button". Worker
// side: a record WITH a resolved threadRef is treated
// exactly like an anchor snippet; a record WITHOUT one
// nominates only through an EXACTLY-ONE prospect match on
// (buyer name, clean vehicle label) — zero or multiple
// matches nominate nothing. Signatures that nominate:
// the availability canned/truncated tests, the
// first-contact system line (note 59), and FB's
// "<Name> is waiting for your response." nudge. A preview
// matching the rep's own availability template never
// nominates. Button records are never stored and never
// create prospects; every nomination lands on a concrete
// /t/<id> ref (resolved or uniquely matched) or does not
// happen, and from nomination onward the processor,
// verification open, capture and decider are unchanged.
// Documented limitation: an unknown buyer with no
// prospect and no props-resolvable id is missed until
// another surface stubs them.
// 61. BUTTON-ROW HARVEST REPAIR + HUB SELF-REFRESH
// (v2.1.110): the 3.09 desk trace named the 3.08 silence
// exactly, on three consecutive passes. The live inbox
// has NO <main> element (hasMainTag false) — the
// button-row collector gated on
// document.querySelector("main"), got null, and returned
// empty at its second line, every pass; all 15 rows live
// inside the single [role="main"] container instead.
// The same trace showed the row header renders SPLIT:
// the buyer's name on one line, "· <Label>" on its own
// line (an nbsp-only line between them), so the parser
// produced a name with NO label and the unique
// (name, label) match could never fire. Two confined
// repairs in chat_capture: the collector falls back to
// [role="main"] when no <main> tag exists, and the
// parser rejoins a line beginning with "·" onto the
// previous line before parsing. Third: Chrome orphans
// every open tab's content scripts on an extension
// update, and the hub tab is the worker's OWN tab — its
// freshness is the worker's job. At boot the worker
// compares a stored version marker with the running
// version; on any difference it records the new version
// first, then reloads the hub tab (if one exists)
// exactly once. No other tab is ever touched, and the
// housekeeping is fail-silent throughout. The 3.09
// trace code does NOT ride along: this build starts
// from the 3.08 tree, trace-free.
// 62. CAPTURE HYGIENE: THE WAITING BANNER + THE HEADER NAME
// (v2.1.111). The 3.10 chain FIRED LIVE on Matthew's desk
// (2026-11-13 16:36:47 UTC): the button harvest nominated
// the Mustang prospect, the verification open captured the
// thread, and a decision was written — but the decision was
// skip / has_rep_reply, because the full-thread capture
// stored TWO pieces of thread chrome as messages first:
// (a) origin "rep", body "Matthew is waiting for your
// response." — Facebook's awaiting-reply BANNER rendered
// inside the thread view, scraped as if the rep had sent
// it; the fake rep reply tripped the has_rep_reply gate.
// (b) origin "buyer", body "Matthew DeMoss" — the thread
// header's name element, scraped as a buyer message ahead
// of the real first message ("Good evening, is this still
// available?"); a bare name as messages[0] would also
// poison first-message accounting once (a) is fixed. Why
// (b) survived the participant-name filter: that filter
// keys on the titled label's name form ("Matthew", from
// "Conversation titled Matthew \u00B7 <Listing>"), while the
// header element renders the buyer's full name ("Matthew
// DeMoss") — a different string. FIX, narrow and
// whole-text only, cut at BOTH layers (the 3.03 precedent):
// (1) NUDGE-AS-CHROME — a candidate whose ENTIRE text
// matches /^.+ is waiting for your response\.?$/ is UI
// chrome, never a message: chat_capture cuts it inside
// findMessages AFTER direction assignment (the banner's
// wide bubble helps define the column the direction pass
// measures against — cutting it in the candidate loop
// shrinks the column and can orphan the buyer's real
// message; proven in the 3.11 harness), and the worker
// ingest belt drops a captured message whose whole body
// matches, on every capture path. A real message merely containing those
// words mid-text is untouched. (2) HEADER-NAME-AS-MESSAGE
// — chat_capture drops a scraped candidate that is the
// FIRST candidate, whose entire text equals a buyer name
// the scrape itself resolved (the titled-label name, the
// header's visible title text, or the header heading), and
// is followed by at least one more candidate; the worker
// belt drops the batch's first buyer message when its
// whole body is the buyer's resolved name (the
// capture-resolved name or the prospect's stored name)
// AND a second buyer message follows it. A buyer genuinely
// writing their own name anywhere else, or as their only
// message, is untouched. Nothing else changes: harvest,
// nomination, processor, decider, send path, self-refresh
// — byte-identical behavior. The header can never be a
// message, and the banner can never wear a rep's name again.

// 64. THE NOMINATION DEADLOCK: CAPTURED-BUT-UNDECIDED
// THREADS (v2.1.113). The 3.11 desk re-proof went silent
// (2026-11-13): under 3.10 the Mustang chain had FIRED —
// nomination, verification open, capture, decision
// skip / has_rep_reply (the banner wart 3.11 fixed). For
// the re-proof the decision row and the two bogus rows
// were deleted, leaving the thread captured but UNDECIDED:
// one stored buyer message, no decision. Under 3.11
// nothing ever picked it up again — worker alive, toggle
// on, the inbox row identical, the hub refreshed — because
// BOTH doors were shut by design: the nominator's state
// gate queued only message-less threads ("known threads
// with messages belong to the existing hooks"), and the
// one hook it deferred to — handleCaptureChat's
// evaluate-on-insert — fires only when a capture inserts
// FRESH rows; a re-capture of an already-stored thread
// inserts none. 3.12-DIAG's step-0 read named the gate
// (suspect N5) and its E2E reproduced the refusal on
// 3.11's own code (queue_push refused /
// state_has_messages, real 1, decided false). FIX, one
// gate: the state gate in lucaAutoReplyNoteCandidates —
// the single loop every nomination route shares (anchor
// snippets, button rows with a ref, ref-less rows via
// the unique match; the ref-only loop queues
// prospect-less refs, where no thread state can exist) —
// now refuses only DECIDED threads. A
// captured-but-undecided thread queues, and the
// processor's existing pop branch (real > 0 && !decided)
// evaluates it directly from the stored rows: no
// verification open, no open record, no open pacing
// consumed. WHY THIS IS SAFE: nomination only earns a
// thread an EVALUATION — the decider re-verifies
// everything at evaluation time (the toggle,
// first-message-only, rep replies, the already-decided
// re-check, inventory freshness, sold state, send pacing
// and caps), so the worst case of queuing is a correct
// skip decision — which also permanently unsticks the
// thread. Queue volume stays bounded by the hub
// harvest's own textual gates (system line / waiting
// nudge / canned availability / rep-template veto, all
// unchanged). Decided threads stay refused: one
// auto-reply decision per thread, ever, enforced by the
// decision row's existence — that side of the gate is
// untouched, as are the capture hook, the pop branch,
// the queue shape, the decider, the templates, pacing
// and caps.

// 66. DELIVERY FIX (v2.1.115). The 3.14-DIAG desk
// trace (2026-11-14, the Mustang group thread) caught
// the false-sent in the act, both halves: (1) CDP
// Input.insertText reported success (attachOk,
// insertOk) while the composer read back EMPTY
// (dlv_type textAfter "") — the text never commits
// into this Messenger composer, so Enter was pressed
// on an empty box; (2) verification stamped the row
// "sent" anyway (dlv_outcome basis reply_result_ok)
// after three dlv_verify attempts all reported
// threadHasBody false — verify rule (b), "composer
// empty + 1.5 s", blessed a send that never happened.
// THE FIX, all inside chat_capture's deliverPending
// (the [DLVFIX315] span): a COMMIT GATE — after each
// typing path (CDP insertText, then the execCommand
// fallback, then a NEW third rung: CDP trusted
// per-character key dispatch, the note-63 price-edit
// input family) the composer is RE-READ, and delivery
// proceeds to submit ONLY when the re-read shows the
// body in the box (the rule-(a)-shaped compare). No
// path commits -> NO submit, and the row settles
// failed with delivery_error text_not_committed —
// loud, never "sent". VERIFY: rule (b) is DELETED;
// "sent" is written only when the thread re-read
// (findMessages) finds an OUT bubble matching the
// body inside the existing 12 s / 600 ms window; on
// timeout the row settles failed
// (not_verified_in_thread). The worker settle is
// unchanged — it still trusts the content verdict,
// but the verdict can now only be earned two honest
// ways. The dlv_* trace from 3.14-DIAG is KEPT
// (retagged 315; dlv_type extended with per-path
// attempt results and the composer re-read values)
// so the desk proof of this fix reads the same way.
// Everything outside the delivery path is untouched.

// [REEL318-NOTE-BEGIN]
// 69. VIN REELS REVAMP — CREATE-TIME ATTACH, READY-ONLY
//     GATE (v2.1.118 — Matthew, 2026-11-14): the poster
//     revamp moves the reel's attach decisively into the
//     create flow (where the Nov 14 live probe watched a
//     real reel register cleanly in the composer's
//     dedicated video slot) and retires the post-hoc
//     editor attach for poster reels — and Matthew's
//     ready-only rule replaces the fail-open semantics
//     for FLAGGED cars: a reel-flagged post fires ONLY
//     with its video ready and included, never bare.
//     (a) CLAIM: a flagged post (the row's reel_requested_
//     at marker, or the account's vin_reel_before_post —
//     read by userSettings from this build) whose latest
//     reel is not ready is NOT posted: the row returns to
//     held (awaiting_reel=true) with the reason on its
//     record, no job is stored, no tab opens. The pure
//     decision is decideReelGateClaim; an account flag
//     alone with no reel ever requested for the car does
//     not hold (the producer's hold IS the request), and
//     a reel row the app marked "waived" (the manual
//     post-without-video override) posts ungated. A ready
//     poster reel on a flagged job rides as before, plus
//     job.reelGate=true on the payload. (b) CONTENT: a
//     gated job whose clip never registers aborts BEFORE
//     submit (decideReelGateContinue judges the unchanged
//     attach outcome), and the binding pre-Publish verdict
//     gates Publish in both modes — unverified aborts
//     instead of posting bare. (c) FINISH: a reel_gate_
//     abort is not terminal: settleReelGateAbort returns
//     the row to held with the abort count carried in its
//     error_message marker (the note-57 row-marker
//     pattern); the third abort settles it FAILED under a
//     leading reel_needs_attention: record. (d) ATTACH
//     RETIREMENT: attach_video rows are never claimed in
//     this build and no new ones are queued for poster
//     reels — the editor machinery stays in place,
//     dormant. Everything else is 2.1.117 exactly: the
//     claim fetch is byte-untouched, photos and the video
//     mechanism are byte-untouched, intro videos and
//     manual reels keep their fail-open semantics.
// [REEL318-NOTE-END]

// [REEL319-NOTE-BEGIN]
// 70. READY-ONLY GATE — MANUAL-ROW FIX (v2.1.119 —
//     Matthew, 2026-11-14): the 3.18 desk proof found
//     the hole note 69's carve-out left: a MANUAL queue
//     row carries no reel_requested_at marker, and an
//     account flag alone with no reel row posted BARE
//     (a Morgantown Silverado went up with no video
//     before the tab could be closed; the listing was
//     deleted by hand). The producer's hold was the
//     only request mechanism, and manual rows never
//     pass through it. 3.19 closes the gate helper-
//     side, at claim, for every post row on a flagged
//     account — who queued the row no longer matters:
//     (a) no reel row at all, or only a consumed one:
//     the helper queues the render ITSELF — the same
//     insert the producer makes (poster source, live-
//     state dedupe re-read first, the partial unique
//     index arbitrates races) — and holds the row.
//     (b) a failed render earns exactly ONE automatic
//     restart, counted in the row's own error_message
//     marker (reel_render_restarts:N, the note-57
//     pattern); with the restart spent the row holds
//     under a leading reel_needs_attention: record for
//     a human — it is never posted bare and never
//     re-rendered in a loop. (c) a claim hold stamps
//     reel_requested_at when the row never carried
//     one, so a helper-held manual row is downstream-
//     identical to a producer hold. (d) a row that was
//     held and later proceeds sheds the hold prose at
//     claim (the counters ride on) — the record stops
//     shouting "held" once the car is posting. (e) a
//     producer row the OLD fail-open release lets go
//     after a failed render is re-held here: ready-
//     only supersedes that release at claim. The
//     worker/app release policy itself is unchanged
//     (the 3.18 companion spec still owns it). Flag
//     OFF: no read, no branch, no insert — behaviour
//     is 3.18 exactly.
// [REEL319-NOTE-END]

// [REEL320-NOTE-BEGIN]
// 71. CREATE-FLOW ATTACH CASCADE + ABORT FORENSICS
//     (v2.1.120 — Matthew, 2026-11-14): the 3.19 desk
//     proof's gated Bronco post aborted no_register
//     three times on Matt's work account, while the
//     same clip, delivered minutes later through the
//     browser's native file pipeline in a live census
//     of that account's create/vehicle flow, flipped
//     the Videos counter instantly — and a manual
//     attach on the main account that morning had
//     done the same. Verdict of the diagnosis
//     (helper319-work/NO-REGISTER-DIAGNOSIS.md) plus
//     the census: in-page DataTransfer injection for
//     VIDEO is 0-for-3 on real composers; native-
//     pipeline delivery is 2-for-2 on two accounts.
//     The mechanism, not the account, was the
//     failure. 3.20 rebuilds the CREATE-flow attach
//     as a cascade (content.js): every plausible
//     video input, ordered by association with the
//     "Add video" tile rather than document order
//     alone; per candidate, one QUICK DataTransfer
//     set (tile-armed first; input + change events),
//     then the trusted CDP DOM.setFileInputFiles
//     set the editor flow has used since 2.89, on
//     the same candidate; a step that registers
//     hands over to the unchanged processing poll.
//     Registration witnesses widen (a blob media
//     element, the rendered file name, the census's
//     "Loading video..." phase), and a media-only
//     registration folds into the outcome as
//     attached-evidence for the gate's deferral.
//     no_register is now earned: it classifies only
//     after the full cascade runs silent inside the
//     attempt. The gate's semantics do not move —
//     decideReelGateContinue, the 3-abort budget,
//     the markers; aborts still count once per
//     claim, never per candidate. And the aborts
//     now keep their evidence: the settle appends
//     the content side's compacted field_diag to
//     the gate record (3.18 dropped it), so the
//     next failure can be diagnosed from the row
//     instead of a closed tab. The gate records
//     also name the running build (2.1.120); the
//     stale 2.1.118 string the aborts carried is
//     retired. Editor attach, claim fetch, photo
//     attach: untouched.
// [REEL320-NOTE-END]
// [REEL321-NOTE-BEGIN]
// 72. POST-THEN-ATTACH (v2.1.121, 3.21): the Nov 14
//     publish test proved Facebook DROPS a video attached
//     in the create flow — it registers on step 1
//     (Videos 1/1) yet the published vehicle listing
//     carries no video at all (manual native-picker
//     attach, listing inspected live: photos only). The
//     create-flow cascade (note 71) registers reliably
//     and the gate's prepublish aborts were correct
//     detections of a real loss — but that road can never
//     reach a live listing. Gated (poster, flagged) posts
//     therefore no longer attach at creation: the post
//     runs exactly as an unflagged post, the completion
//     queues the editor attach (the note-43 backstop,
//     revived for gated posters only), the attach claims
//     under a chain record this worker keeps
//     (al_gate_chain_v1, keyed by VIN), and its verdict is
//     read on the LIVE LISTING page — a fresh load of
//     /marketplace/item/<id>, never the editor's saved
//     state. Attach or listing-verify failure queues a
//     delete of the bare listing; the delete's confirmed
//     completion clears the posted stamp (applyDeleted)
//     and only then does the parent post row settle as a
//     gate abort (editor_attach_failed /
//     listing_verify_failed, the same 3-abort budget).
//     A delete that itself fails settles the parent
//     needs-attention IMMEDIATELY — its text says a
//     listing may be LIVE WITHOUT its video and names
//     the listing when the memory knows it. Ungated
//     posts, manual reels and legacy attach rows are
//     untouched: legacy attach claims stay dormant
//     (only a live chain record makes an attach row
//     claimable), and the create-flow attach still runs
//     for every ungated job exactly as in 3.20.
// [REEL321-NOTE-END]
// [REEL322-NOTE-BEGIN]
// 73. PATIENT LISTING VERIFY (v2.1.122, the 3.22 build):
// the 3.21 desk proof's chained delete fired ~1 min
// after the editor save on a reopened-editor counter
// that read 0 — and the live-listing verify behind it
// never ran. A lab test the same day proved a
// synthetically delivered editor attach DOES reach the
// live listing (video item present at +3 min on fresh
// loads): Facebook's post-save reads are stale and a
// video materializes over minutes. So for a chained
// attach the editor counter is now a diagnostic only —
// the reopened-editor verify is never run — and the
// verdict is a PATIENT read of the live listing: fresh
// loads of /marketplace/item/<id> at +2 and +5 minutes
// after the save (Matt's cap; the +5 read is final).
// Presence of the video ITEM is the verdict; playback
// state is recorded in the trace at each read and never
// gates. All reads negative -> the chain's delete path,
// exactly as 3.21, but the settle text now says the
// post DID go live and the listing was deleted. The
// read sequence rides the chain record into the
// parent's settle diag. State lives on the stored
// job's attachVideo marker (saveAt + reads) — the same
// stash the phases use — so every incarnation
// recomputes from the save; the stage marker refreshes
// at arm, at every read, and before every reload, and
// the attach-class stale limit (45 min) never comes
// close. Standalone attach jobs keep the 3.21 verify
// byte-for-byte; nothing else moves.
// [REEL322-NOTE-END]
// [REEL323-NOTE-BEGIN]
// 74. PRE-SAVE ID CAPTURE (v2.1.123, the 3.23 build):
// the 3.22 desk proof failed end-to-end while the
// video demonstrably reached the live listing. After
// the editor save, the chained arm read the listing
// ID from window.location.href only AFTER the
// leave-the-editor wait loop — and a successful save
// navigates the tab back to the Selling page, where
// the URL carries no ID. The arm never fired, the
// verify phase fell into the 3.21 card recovery, the
// card carried no item link (url:no), and the attach
// failed ~90s in; the chain's delete then failed on
// its own ambiguity guard and the user stopped it by
// hand with the video already playing on the listing.
// The fix is content-side only: a chained job now
// captures the listing ID from the editor URL BEFORE
// the Save click (the last moment the URL is
// certainly the editor's) and the arm prefers that
// capture, falling back to the post-save parse for
// saves that do not navigate. The arm also records a
// step note naming the ID and its source, so a desk
// trace shows the arm firing without inference.
// Nothing else changes: the patient schedule, the
// verdict, the delete path, and every settle text
// are 3.22's, byte for byte apart from the version
// these records name.
// [REEL323-NOTE-END]
// [REEL324-NOTE-BEGIN]
// 75. AIM SEEDING (v2.1.124, the 3.24 build): the 3.23
// desk proof attached the video and STILL failed —
// the failure-log ring read at the desk showed the
// editor phase completing cleanly and NO "armed id:"
// entry anywhere after it: the pre-save arm never
// fired (its parse missed, or a watchdog split took
// the sibling path the capture was never added to),
// the verify tab sat for ~95s with nothing to aim at,
// and the recovery's card scan failed matches:3. The
// round-2 diagnosis named the mechanism: the chained
// verify's aim existed only as a side effect inside
// the editor incarnation, while the post finish —
// which HELD the live listing URL — wrote it nowhere
// the attach could inherit. 3.24 moves the aim to
// where the knowledge is: finishJobPosted's listing
// URL (the listing-ID memory as fallback) is resolved
// at queue time and written onto the chain record;
// the claim payload seeds it into the attach job
// itself (jobPayload.attachVideo), so the job STARTS
// aimed. The editor arms may confirm the seed but
// never replace it; an editor whose own URL names a
// different listing is a hard stop — the parent
// settles needs-attention (chain_aim_attention) and
// NOTHING is deleted on a corrupted aim. A pending
// check with a durable aim re-navigates to the item
// URL (bounded, 2 per read cycle) instead of scanning
// cards; the card recovery remains for the no-aim case
// only, and its failure text says the address was
// never there. The attach editor phase also gains the
// price flow's crossPhaseDiags stash (2.91), so its
// evidence survives the incarnation boundary, and
// every chained-attach incarnation records a
// breadcrumb (page kind, stage, check, aim) at entry.
// [REEL324-NOTE-END]
// [REEL325-NOTE-BEGIN]
// 76. AIM HARVEST (v2.1.125, the 3.25 build): 3.24's
// seeding read the listing-ID memory as its fallback,
// and the memory is written at editor-enter — so in
// BOTH Nov 14 desk runs the seeded aim was exactly one
// attach BEHIND: run 1 aimed at the previous session's
// listing (1153553967168243; the editor found the true
// new 4651417945133889), run 2 at run 1's listing
// (4651417945133889; the editor found 1145475834543400).
// The finish URL the Selling-page confirmation supplies
// carries no parseable id, so the fallback fired every
// time and the contradiction gate — working exactly as
// designed — stopped both attaches. 3.25 removes the
// poison at the source. (a) The content side harvests
// the id from the MATCHED CARD's own item link at the
// Selling-page confirmation (the one card the strict
// scan proved is this post) and sends it on the posted
// message as the finish's authoritative listingId; a
// card with no item link sends NO id — no other source
// is ever substituted. (b) The seeding path reads NO
// memory: precedence is the confirmation id, then a
// parse of the finish URL; neither yields an id and
// NOTHING is seeded (the chain record carries no aim,
// the claim payload carries no aim, the aim_seeded
// breadcrumb fires id:none). (c) An unseeded chained
// attach ADOPTS the editor id its strict scan opened —
// persisted on the stored job at editor-enter through
// the same stage write + cross-phase stash the notes
// parity uses, so successor incarnations inherit it —
// and the patient verify runs against the adopted id
// exactly as the seeded path runs against a seeded id
// (trace src:scan_editor). (d) The contradiction
// hard-stop fires ONLY against a seeded aim from this
// post's confirmation; an adopted target can never
// contradict. The memory itself is untouched: Design A
// navigation reads it exactly as before. Patient
// schedule, delete rule, abort budget, settle texts:
// unchanged.
// [REEL325-NOTE-END]
// [REEL326-NOTE-BEGIN]
// 77. NO-TAKE FORENSICS (v2.1.126, the 3.26 build —
// DIAGNOSTIC + best-supported fix, staging only):
// the Nov 15 FT60621 desk run proved 3.25's aim fix
// (the attach adopted the fresh listing from its own
// scan) and then failed pure delivery: the CDP set
// returned ok, the DataTransfer re-inject fired, and
// no witness ever moved (count/remove/loading 0 for
// two full no-take windows). Full diagnosis:
// helper326-work/DIAGNOSIS.md. The best-supported
// causes, and what this build does about each:
// (a) the editor set landed before the uploader was
// wired, or its media tray re-rendered after the set
// and discarded it — the scan -> menu -> Edit route
// is an SPA transition whose attach can start the
// moment a price field + an input exist. FIX: the
// attempt opens with an input stability gate (the
// SAME connected node across two samples, <=9s,
// fail-open) before the first set. (b) the no-take
// re-inject wrote to the node captured at attempt
// start — a detached black hole if the tray had
// replaced it. FIX: the input is re-resolved at the
// re-injection. (c) the editor's DataTransfer set
// fired change only; the create flow's set has
// fired input then change since 3.20, whose
// diagnosis named change-only as a silent shape.
// FIX: parity. And because 3.25's evidence could
// not convict any single cause, three witness lanes
// ride the existing field_diag channel on failure:
// a per-rung witness (the chosen input's accept, a
// stamped node marker, connectedness, whether a
// fresh lookup still returns the same node, the
// events fired), a MutationObserver tray watch per
// rung (did the tray change AT ALL; did the input
// node survive), and a NETWORK witness — the
// background enables the CDP Network domain on the
// editor tab for the delivery window only (attach
// start -> verdict) and records method/host/path
// (query stripped; no headers, no bodies), response
// statuses and loadingFailed errorTexts, classified
// for media-upload traffic: upload_posts:0 after a
// set means the editor never began ingestion
// (client-side no-take); an upload POST that fails
// carries its exact net::ERR text. The witness
// session drops at stop (or tab detach); recorded
// requests cap at 200. Everything else — aim
// seeding/adoption, the contradiction gate, the
// patient verify, settle texts apart from the
// version string — is byte-identical to 3.25.
// [REEL326-NOTE-END]
// [REEL327-NOTE-BEGIN]
// 78. VERIFY FALSE-FAIL + SETTLE DELAY (v2.1.127,
// the 3.27 build — staging only): the Nov 15
// WT60434B desk run delivered PERFECTLY under 3.26 —
// video registered in the editor, saved, PLAYING on
// the live listing — and the chain still failed the
// attach and queued the listing's delete at +3m23s
// with a NULL error_message. Full diagnosis:
// helper327-work/DIAGNOSIS.md. The mechanism: the
// patient runner marks the stored job's
// listingCheck "passed" when its read finds the
// video, THEN reports AUTOLAUNCH_JOB_VIDEO_ATTACHED
// from the item page — but the background's
// item-page admission (3.21) accepts that report
// only while the stored job says "pending", so the
// success was refused as a wrong-room report, the
// refusal failed the job with a hardcoded EMPTY
// diags array (compactDiagError([]) is null — the
// NULL row), and failure propagation queued the
// delete on the refusal's reason. Three fixes and
// one addition. (a) THE GATE ADMITS THE PASSED
// STATE: the item-page admission accepts
// listingCheck "pending" OR "passed" — "passed" is
// the runner's own completion marker, written
// exactly before the report it gates. (b) NO SILENT
// CHAIN FAILS: finishJobFailed synthesizes a
// compact trace (gateChainFailDiag327: the failing
// path, the arm state, the verify state, every
// read with its timestamp) from the stored job
// whenever a chained attach fails with no
// diagnostics — a chained attach can no longer
// fail with a NULL error_message. (c) THE DELETE
// IS EARNED, NOT DEFAULT: the delete hop now
// requires decideGateChainDelete327's proof. From
// the moment a save landed (the verify phase was
// entered), ONLY a completed patient verify — the
// listing-verify verdict reason AND both patient
// reads recorded, genuinely empty, at the +2/+5
// offsets — earns it; every other verify-phase
// shape (arm missing, recovery collapse, incarnation
// death, a refused report, a stale or never-run
// read) settles the parent needs-attention under
// the new chain_verify_attention text — stamp
// standing, NO delete queued. A failure BEFORE any
// save (editor/listing phase: the attach
// demonstrably never landed) keeps the 3.21 rule
// exactly — the listing is bare by the attach's own
// evidence. (d) SETTLE
// DELAY (Matt's call, Nov 15): after a chained post
// finishes, its tab closes and the chain used to
// open the attach tab INSTANTLY — onto a listing
// whose save/video binding is still settling.
// Chain records written at post finish now carry
// attachNotBefore327 (+60s) and the claim loop
// honors it (gateChainAttachDelay327): the chained
// attach cannot be claimed — its tab cannot open —
// until the minute has passed. The stamp lives on
// the chain record in chrome.storage, so the hold
// survives worker restarts and spans the
// incarnation boundary by construction; standalone
// attaches have no chain record and never wait.
// Everything else — aim seeding/adoption, delivery,
// the patient schedule, settle texts apart from
// the version string and the one new kind — is
// byte-identical to 3.26. content.js is untouched.
// [REEL327-NOTE-END]
// [REEL328-NOTE-BEGIN]
// 79. SETTLE DELAY RELOCATED (v2.1.128, the 3.28
// build — staging only): the 3.27 build put Matt's
// settle minute in the wrong gap. Watching the
// Nov 15 OW26681 desk proof run clean end to end
// under v2.1.127, Matt corrected the placement:
// the minute belongs AFTER the video-add (editor)
// page closes — after the attach's editor SAVE
// lands — and before the patient verify opens or
// reads the live listing, because Facebook's
// ingest/bind of the video needs its settle time
// AFTER the upload, not before the editor opens.
// The 3.27 admission fix, the no-silent-fails
// trace, the hardened delete gate, the delivery
// path and the aim logic are unchanged; ONLY the
// delay moves — one minute, relocated, never two.
// Background side: the v2.1.127 mechanism is
// removed whole — chain records no longer carry
// attachNotBefore327, the claim loop no longer
// gates chained attaches, and the pure
// gateChainAttachDelay327 is gone (a tombstone
// comment marks the spot). Records written by
// v2.1.127 keep an inert attachNotBefore327 field
// that nothing reads; a rollback to v2.1.127
// re-arms its gate from that same field, and a
// record written by v2.1.128 (no field) reads
// fail-open there — no shape breaks in either
// direction. Content side (the save/arm moment
// lives there, so the relocation does too): the
// editor save's arm now stamps verifyNotBefore328
// (saveAt + 60s) onto the persisted listingVerify
// state; every verify-phase navigation to the
// listing — the save path's own, the pending-check
// router's, the card arm's, the divert's — first
// sits out the stamp in the runner's chunked-sleep
// pattern (waitForGateVerifyOpen328), and the
// verify plan takes each read at the first fresh
// load at/after the later of its +2/+5 target and
// the stamp, so no read can execute early either.
// Anchoring: saveAt stays the save click; the
// +2/+5 targets stay anchored to it; the stamp
// (save + 60s) sits below both targets, so in the
// standard shape the read schedule and the
// recorded offsets are exactly v2.1.127's — the
// delete gate's offset proofs (>=100s / >=280s,
// both reads, all "none") hold with the same
// margins. A state with no stamp (armed before
// 3.28, or synthesized on a fallback path) behaves
// exactly as v2.1.127. background.js +
// content.js + manifest.json; bridge /
// chat_capture / dws_sync untouched.
// [REEL328-NOTE-END]
// [REEL329-NOTE-BEGIN]
// 80. EARLY-SUCCESS VERIFY EXIT + IDENTITY-GATE
// STABILITY (v2.1.129, the 3.29 build — staging
// only): two small fixes on the v2.1.128 base;
// nothing else moves.
// (1) EARLY-SUCCESS EXIT (Matt's request, Nov 15):
// the patient verify always ran BOTH fresh-load
// reads (+2 and +5 minutes from the editor save)
// even when the first read already found the
// video. Now the SUCCESS path can settle on the
// first read: a non-final read settles only when
// the video is present AND playback is confirmed
// (gateVerifyPlaybackConfirmed329 /
// decideGateVerifyReadSettles329, content-side
// PURE-REEL-VERIFY-C) — "playing@Ns", or a player
// carrying the file's real duration ("dur:Ns",
// N > 0: loaded and playable; a listing video at
// rest is paused, not absent). Present but NOT
// confirmed (spinner, ready without a duration,
// or label-only evidence with no player element)
// still runs the +5 read as tiebreaker. The
// final read settles on presence exactly as
// before — presence persisted across two fresh
// loads minutes apart is the proof this verify
// has always accepted. The exit is recorded:
// the read's own step note stands, an
// "early_success" step note names the skipped
// read(s), and the persisted verify state
// carries earlySuccess329 {atRead, skippedReads}.
// The DELETE path is untouched, byte for byte:
// decideGateChainDelete327 still demands a
// completed verify — both reads recorded, every
// verdict "none", offsets >=100s / >=280s — so
// an early success can never shorten the road
// to a delete; it only shortens the road to a
// confirmed attach (~3 minutes a car, and the
// helper is serial).
// (2) IDENTITY-GATE STABILITY + EVIDENCE (the
// ZT7042A attempt-1 lesson, Nov 15): the editor
// hunt judged the FIRST price candidate it
// found. Attempt 1 claimed the same second its
// post finished, landed on the Selling search
// page, and the hunt read the SEARCH BOX ("2027
// Chevrolet Equinox" — moneyNumber strips it to
// a phantom 2027) as the editor's price field:
// attach_wrong_listing in ~21s against the
// right car at the right price ($30,563; Matt's
// screenshot showed exactly one Equinox).
// Attempt 2, whose scan sat ~90s, passed the
// same gate on the same car. The hunt now acts
// on a verdict — either way — only once the
// SAME candidate value has been shown stable
// for the stability window (1500ms —
// GATE_IDENTITY_STABLE_MS329 — sampled on the
// hunt's existing 400ms poll) and only when the
// value is money-shaped (decideGateIdentity-
// Action329 / gateIdentityValueShape329,
// content-side PURE-ATTACH-FLOW): a price field
// shows a price, and a value carrying letters
// is some other control — never judged at all.
// The hunt's existing 25s deadline remains the
// bound: a candidate that never stabilizes is
// never judged, and the hunt ends unproven
// exactly as before — never attach on doubt.
// Evidence: the wrong-listing note now records
// the extracted price verbatim ("shown <value>
// price:<n> | expect <posted>"), and a candidate
// from which no price can be extracted leaves
// one note per distinct value with its text
// snippet and "price:none", so any future trip
// is diagnosable from the row alone. The
// verify-editor twin deliberately does NOT gain
// the wait (chained jobs never reopen the
// editor; out of scope). background.js (this
// note + the gate settle texts' version) +
// content.js + manifest.json; bridge /
// chat_capture / dws_sync untouched.
// [REEL329-NOTE-END]

// 81. §4E IDENTITY FOR PRICE + DELETE (v2.1.130, the
// 3.30 build — Matthew, 2026-11-16; failure-recovery
// spec §4E, decided 2026-11-15): a listing is this
// car when its VIN (or, failing that, its stock
// number) says so — the price it shows is never
// identity. Worker side, this file: (1)
// priceUpdateClaimGate drops the FROM half of the
// basis check — the job runs while the car is
// posted and the dealer's current price still
// equals the job's TO price; the stamped posted
// price may read anything (a moved price is the
// job's reason to exist, and the old
// stamp-equals-FROM rule false-failed every drift
// that had already moved). (2) Delete jobs now
// carry listingMemory like price/attach jobs: the
// stored listing ID is the delete flow's identity
// anchor for telling twins apart. Content side:
// header note 54 there. Attach, post, share
// unchanged.

const SUPABASE_URL = "https://tdsipiltwajwhzgjsupx.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_hkEU-TniEPk-ShSxBZQ-kQ_zGrDUC8w";
const POLL_ALARM = "autolaunch-queue-poll";
const POLL_MINUTES = 1;

class SbAuthError extends Error {
  constructor(status) {
    super(`Supabase rejected the session token (${status})`);
    this.status = status;
  }
}

async function storedAccessToken() {
  const { autolaunch_access_token: token } =
    await chrome.storage.local.get(["autolaunch_access_token"]);
  return token || null;
}

// Trial-abuse install identifier (v2.1.45). ONE random UUID per helper
// install, kept in chrome.storage.local under al_install_id: created
// lazily on first request, then stable across restarts, updates, and
// site-data clears. It identifies the INSTALL, never a person or an
// account — uninstall/reinstall or a fresh Chrome profile starts over,
// which is accepted: this is a fence against casual trial farming,
// not a device fingerprint. The only reader is the
// AUTOLAUNCH_GET_INSTALL_ID bridge answer below, which goes solely to
// the AutoLaunch app origin; the app sends it to trial-start when a
// trial begins, and the server stores only a salted hash of it.
async function getOrCreateInstallId() {
  const { al_install_id: existing } =
    await chrome.storage.local.get(["al_install_id"]);
  if (existing) return existing;
  let id = null;
  try { id = crypto.randomUUID(); } catch (e) { /* fall through */ }
  if (!id) {
    id = "al-" + Date.now().toString(36) + "-" +
      Math.random().toString(36).slice(2, 10) +
      Math.random().toString(36).slice(2, 10);
  }
  await chrome.storage.local.set({ al_install_id: id });
  return id;
}

// One-active-helper instance identity (v2.1.60, header note 32):
// ONE random UUID per helper install, kept in chrome.storage.local
// under al_instance_id — created lazily on first need, then stable
// across restarts and updates. It names the INSTALL for the helper
// lease only; it is deliberately NOT the trial-abuse al_install_id
// above (that fence has its own reader and lifecycle). The only
// outside reader is the AUTOLAUNCH_GET_INSTANCE_ID bridge answer,
// which goes solely to the AutoLaunch app origin so the Extension
// page's takeover button can write THIS install's id as the lease.
async function getOrCreateInstanceId() {
  const { al_instance_id: existing } =
    await chrome.storage.local.get(["al_instance_id"]);
  if (existing) return existing;
  let id = null;
  try { id = crypto.randomUUID(); } catch (e) { /* fall through */ }
  if (!id) {
    id = "al-inst-" + Date.now().toString(36) + "-" +
      Math.random().toString(36).slice(2, 10) +
      Math.random().toString(36).slice(2, 10);
  }
  await chrome.storage.local.set({ al_instance_id: id });
  return id;
}

// [PURE-LEASE-DECISION-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Lease decision (v2.1.60, header note 32): "take" when the lease
// is empty, expired, unreadable, or already mine — the caller
// renews and claims; "foreign" only when a DIFFERENT instance
// holds a lease whose expiry is still ahead — the caller stands
// down and claims nothing this cycle.
const HELPER_LEASE_TTL_MS = 10 * 60 * 1000;
function helperLeaseDecision(leaseId, leaseExpiresAt, myInstanceId, nowMs) {
  if (!leaseId || typeof leaseId !== "string") return "take";
  if (leaseId === myInstanceId) return "take";
  const exp = Date.parse(leaseExpiresAt || "");
  if (!isFinite(exp) || exp <= nowMs) return "take";
  return "foreign";
}
// [PURE-LEASE-DECISION-END]

// [PURE-AUTOREPLY-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Luca availability-only auto-reply (v2.1.101, header note
// 54): the ONE exception to draft-only, amended by Matthew
// 2026-11-12. A fixed template answers a thread's FIRST
// buyer message when — and only when — that message is
// nothing but a canned availability question and every
// guard below passes. Any guard failing means NO send:
// the buyer message stays in the normal draft flow and
// the skip reason is logged on the prospect.
const LUCA_AUTOREPLY_CAP_PER_DAY = 20;
const LUCA_AUTOREPLY_START_HOUR = 7;
const LUCA_AUTOREPLY_END_HOUR = 22;
const LUCA_AUTOREPLY_FRESH_MS = 26 * 60 * 60 * 1000;
const LUCA_AUTOREPLY_DELAY_MIN_MS = 60 * 1000;
const LUCA_AUTOREPLY_DELAY_SPAN_MS = 120 * 1000;
const LUCA_AUTOREPLY_CANNED = new Set([
  "is this available",
  "is this still available",
  "is this available please",
  "is this still available please",
  "hi is this available",
  "hello is this available",
  "hey is this available",
  "hi is this still available",
  "hello is this still available",
  "hey is this still available",
  "is it available",
  "is it still available",
  "hi is it available",
  "hello is it still available",
  "hey is it still available",
  "hello is it available",
  "hey is it available",
  "is the car available",
  "is this car available",
  "is the vehicle available",
  "is this vehicle available",
  "is this one available",
  "good morning is this available",
  "good morning is this still available",
  "good morning is it available",
  "good morning is it still available",
  "good afternoon is this available",
  "good afternoon is this still available",
  "good afternoon is it available",
  "good afternoon is it still available",
  "good evening is this available",
  "good evening is this still available",
  "good evening is it available",
  "good evening is it still available",
  "still available"
]);
const LUCA_AUTOREPLY_JUNK_NAMES = new Set([
  "marketplace", "buyer", "customer", "facebook", "user",
  "unknown", "guest", "seller", "someone", "friend"
]);
function lucaAutoReplyNormalize(text) {
  return String(text || "")
    .toLowerCase()

    .replace(/[^a-z0-9\s']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
function lucaAutoReplyIsCanned(text) {
  return LUCA_AUTOREPLY_CANNED.has(lucaAutoReplyNormalize(text));
}
function lucaAutoReplyFirstName(name) {
  const first = String(name || "").trim().split(/\s+/)[0] || "";
  if (first.length < 2 || first.length > 20) return null;
  if (!/^[A-Za-z][A-Za-z'’-]*$/.test(first)) return null;
  if (LUCA_AUTOREPLY_JUNK_NAMES.has(first.toLowerCase())) return null;
  return first.charAt(0).toUpperCase() + first.slice(1);
}
function lucaAutoReplyMoney(n) {
  const v = Number(n);
  if (!isFinite(v)) return "";
  return "$" + Math.round(v).toLocaleString("en-US");
}
function lucaAutoReplyRenderAvailable(f) {
  const greet = f.name ? `Hi ${f.name}, yes` : "Yes";
  return `${greet} — it's still available! ${f.year} ${f.make} ${f.model}, ${lucaAutoReplyMoney(f.price)}. You can see it here: ${f.link}. Are you okay with that price? And when would you want to come look at it, test drive it, and possibly take it home?`;
}
function lucaAutoReplyRenderUnavailable(f) {
  const greet = f.name ? `Hi ${f.name}, sorry` : "Sorry";
  return `${greet} — that ${f.year} ${f.make} ${f.model} has sold / is no longer available.`;
}
// Decision table. ctx (all fields required):
//   enabled, alreadyDecided, inboundCount, outboundCount,
//   priorAutoCount, firstBody, match ("one"|"none"|"ambiguous"),
//   carState ("available"|"gone"|"unknown"), priceOk, hasLink,
//   carFresh, acctFresh, hour (0-23 local), sentToday, cap,
//   fields {name, year, make, model, price, link}
// Returns {action: "send"|"skip"|"hold", branch, reason, body?}.
function lucaAutoReplyDecide(ctx) {
  const skip = (reason) => ({ action: "skip", branch: null, reason });
  if (!ctx.enabled) return skip("toggle_off");
  if (ctx.alreadyDecided) return skip("already_decided");
  if ((ctx.priorAutoCount || 0) > 0) return skip("prior_auto_reply");
  if ((ctx.outboundCount || 0) > 0) return skip("has_rep_reply");
  if (ctx.inboundCount !== 1) return skip("not_first_message");
  if (!lucaAutoReplyIsCanned(ctx.firstBody)) return skip("not_availability_only");
  if (ctx.labelTrusted === false) return skip("label_untrusted");
  if (ctx.match === "none") return skip("car_unresolved");
  if (ctx.match === "ambiguous") return skip("car_ambiguous");
  if (ctx.match !== "one") return skip("car_unresolved");
  if (!ctx.carFresh || !ctx.acctFresh) return skip("stale_inventory");
  if (typeof ctx.hour !== "number" || ctx.hour < LUCA_AUTOREPLY_START_HOUR || ctx.hour >= LUCA_AUTOREPLY_END_HOUR) {
    return { action: "hold", branch: null, reason: "outside_hours" };
  }
  if ((ctx.sentToday || 0) >= (ctx.cap || LUCA_AUTOREPLY_CAP_PER_DAY)) return skip("cap_reached");
  if (ctx.carState === "gone") {
    return { action: "send", branch: "unavailable", reason: "confirmed_gone", body: lucaAutoReplyRenderUnavailable(ctx.fields || {}) };
  }
  if (ctx.carState !== "available") return skip("availability_unknown");
  if (!ctx.priceOk) return skip("no_price");
  if (!ctx.hasLink) return skip("missing_link");
  return { action: "send", branch: "available", reason: "ok", body: lucaAutoReplyRenderAvailable(ctx.fields || {}) };
}
// Label trust (v2.1.102, header note 55): the resolver may
// only read year/make/model from a CLEAN listing label. An
// inbox list row can fuse banner text, a NEIGHBOR listing's
// title, and a row timestamp into one string — Matthew's
// 2026-11-12 desk test stored "UnreadLet people know if
// you've sold your item: 2018 Honda Ridgeline.6h" for a
// thread about a 2027 Sentra, and the fused title resolved
// to a REAL Ridgeline VIN. Artifact-bearing labels are
// untrusted: decision label_untrusted, never a best-effort
// match. An absent label is weak, not dirty (the resolver
// reports car_unresolved for it).
const LUCA_AUTOREPLY_LABEL_ARTIFACTS = [
  /unread/i,
  /let people know if you/i,
  /sold your item/i,
  /mark as sold/i,
  /view similar items/i,
  /see details/i,
  /more options/i
];
function lucaAutoReplyLabelTrusted(label) {
  const t = String(label || "").trim();
  if (!t) return true;
  for (let i = 0; i < LUCA_AUTOREPLY_LABEL_ARTIFACTS.length; i++) {
    if (LUCA_AUTOREPLY_LABEL_ARTIFACTS[i].test(t)) return false;
  }
  if (/\.\d{1,2}\s*[mhd]\b/i.test(t)) return false; // fused row timestamp: ".6h", ".2m", ".3d"
  if (/\b\d{1,2}:\d{2}\s?(am|pm)\b/i.test(t)) return false; // fused clock text: "4:32 PM"
  const years = t.match(/\b(?:19|20)\d{2}\b/g) || [];
  if (years.length > 1) return false; // two listing titles fused into one label
  return true;
}
// [PURE-AUTOREPLY-END]
// [PURE-AUTOREPLY2-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Luca Phase 2 auto-reply classes (v2.1.146, spec
// 2026-11-17 Track B; trade_link added by Matthew the same
// evening): three more FIXED-template intents beside phase
// 1's availability, each behind its OWN per-account toggle
// (user_settings.luca_autoreply_hours_location /
// luca_autoreply_visit / luca_autoreply_trade_link, all
// default OFF). Same discipline as phase 1: a message
// matches a class only when — after normalization — it is
// EXACTLY one of the class's canned phrases (an optional
// greeting / "please" around a listed base phrase). Any
// extra clause breaks the match by construction; the
// exclusion screen below is a second gate for value /
// payment / financing territory, which is NEVER auto —
// the moment a trade mention pairs with worth, price or
// payments, nothing matches and the thread stays
// draft-only. Templates are built ONLY from verified data:
// account settings (store hours, dealership name/address,
// rep name, the account's own trade link) and, for
// visit_invite, the same one-car resolution + freshness
// gates phase 1 uses. No number is ever computed here.
const LUCA2_HOURS_THREAD_CAP_MS = 24 * 60 * 60 * 1000;
const LUCA2_CLASSES = ["hours_location", "visit_invite", "trade_link"];
function luca2CannedSet(bases) {
  const GREET = ["", "hi ", "hello ", "hey ", "good morning ", "good afternoon ", "good evening "];
  const SUF = ["", " please"];
  const s = new Set();
  for (const b of bases) for (const g of GREET) for (const suf of SUF) s.add(g + b + suf);
  return s;
}
const LUCA2_HOURS_CANNED = luca2CannedSet([
  "what are your hours",
  "what are your hours today",
  "what are your business hours",
  "what are your store hours",
  "when do you close",
  "when do you open",
  "when do you guys close",
  "when do you guys open",
  "what time do you close",
  "what time do you open",
  "what time do you guys close",
  "are you open today",
  "are you open now",
  "are you open tomorrow",
  "are you guys open today",
  "are you open on saturday",
  "are you open on sunday",
  "are you open on sundays",
  "are you open sundays",
  "where are you located",
  "where are you guys located",
  "where are you",
  "where are you at",
  "where you located",
  "where you guys located",
  "where is the dealership",
  "where is your dealership",
  "where is your lot",
  "what is your address",
  "what's your address",
  "whats your address",
  "what is the address",
  "what's the address",
  "whats the address"
]);
const LUCA2_VISIT_CANNED = luca2CannedSet([
  "can i come see it",
  "can i come see the car",
  "can i come look at it",
  "can i come look at the car",
  "can i come by to see it",
  "can i come by and see it",
  "can i come by today",
  "can i come see it today",
  "can i come see it tomorrow",
  "can i come look at it today",
  "can i see it today",
  "can i see it tomorrow",
  "can i test drive it",
  "can i test drive the car",
  "can i test drive it today",
  "can i test drive it tomorrow",
  "can i come test drive it",
  "can i take it for a test drive",
  "when can i come see it",
  "when can i come look at it",
  "when can i come by",
  "when can i test drive it",
  "can we come see it",
  "can we come look at it",
  "can we test drive it",
  "i want to come see it",
  "i want to come look at it",
  "i want to test drive it",
  "i'd like to come see it",
  "id like to come see it",
  "i'd like to test drive it",
  "id like to test drive it"
]);
const LUCA2_TRADE_CANNED = luca2CannedSet([
  "i have a trade",
  "i have a trade in",
  "i have a tradein",
  "i have a car to trade",
  "i have a truck to trade",
  "i have a vehicle to trade",
  "i have something to trade",
  "i have a trade for it",
  "do you take trades",
  "do you take trade ins",
  "do you take tradeins",
  "do you accept trades",
  "do you accept trade ins",
  "do you guys take trades",
  "do you guys take trade ins",
  "you take trade ins",
  "you guys take trade ins",
  "i need to trade my car",
  "i need to trade my truck",
  "i need to trade in my car",
  "i want to trade my car",
  "i want to trade my truck",
  "i want to trade in my car",
  "can i trade my car",
  "can i trade my truck",
  "can i trade in my car",
  "can i trade in my truck",
  "i'm trading my car",
  "im trading my car"
]);
// Value / money territory: if any of these appear, NO class
// may match — the message is multi-clause or value-seeking
// by definition here, and stays with the human.
const LUCA2_EXCLUSIONS = [
  /\bworth\b/, /\bvalue\b/, /\bhow much\b/, /\bbest price\b/,
  /\blowest price\b/, /\bbottom line\b/, /\bmonthly\b/,
  /\bpayments?\b/, /\bfinanc(e|ing)\b/, /\bcredit\b/, /\bapr\b/,
  /\bdown payment\b/, /\bfees?\b/, /\btax(es)?\b/, /\bwarranty\b/,
  /\bnegotiable\b/, /\bdiscount\b/, /\bloan\b/, /\bowe\b/,
  /\binterest rate\b/, /\bprice\b/
];
function lucaAutoReply2Match(text) {
  const raw = String(text || "");
  if ((raw.match(/\?/g) || []).length > 1) return null; // two questions = multi-clause
  const t = lucaAutoReplyNormalize(raw);
  if (!t) return null;
  for (const re of LUCA2_EXCLUSIONS) if (re.test(t)) return null;
  if (LUCA2_TRADE_CANNED.has(t)) return "trade_link";
  if (LUCA2_VISIT_CANNED.has(t)) return "visit_invite";
  if (LUCA2_HOURS_CANNED.has(t)) return "hours_location";
  return null;
}
// "9:00" -> "9 AM", "20:00" -> "8 PM", "13:30" -> "1:30 PM"
function luca2TimeLabel(hhmm) {
  const parts = String(hhmm || "").split(":").map(Number);
  let h = parts[0];
  const min = parts[1] || 0;
  if (!isFinite(h)) return "";
  const suffix = h >= 12 ? "PM" : "AM";
  h = h % 12; if (h === 0) h = 12;
  return min ? `${h}:${String(min).padStart(2, "0")} ${suffix}` : `${h} ${suffix}`;
}
const LUCA2_DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const LUCA2_DAY_SHORT = { mon: "Mon", tue: "Tue", wed: "Wed", thu: "Thu", fri: "Fri", sat: "Sat", sun: "Sun" };
// Store hours line from the closer profile's store_schedule
// (the app's shape: {day: {open, start, end}}). Mirrors the
// app's own defaults when unset: Mon-Sat 09:00-20:00 open,
// Sunday closed. Consecutive days with identical hours are
// grouped ("Mon-Fri 9 AM-8 PM, Sat 9 AM-6 PM, Sun closed").
function luca2StoreHoursLine(storeSchedule) {
  const sched = {};
  for (const d of LUCA2_DAY_KEYS) {
    const e = (storeSchedule && storeSchedule[d]) || null;
    if (e) sched[d] = { open: !!e.open, start: e.start || "09:00", end: e.end || "20:00" };
    else sched[d] = { open: d !== "sun", start: "09:00", end: "20:00" };
  }
  const runs = [];
  for (const d of LUCA2_DAY_KEYS) {
    const cur = sched[d];
    const key = cur.open ? `${cur.start}-${cur.end}` : "closed";
    const last = runs[runs.length - 1];
    if (last && last.key === key) last.days.push(d);
    else runs.push({ key, days: [d], cur });
  }
  return runs.map(r => {
    const first = LUCA2_DAY_SHORT[r.days[0]];
    const lastD = LUCA2_DAY_SHORT[r.days[r.days.length - 1]];
    const label = r.days.length > 1 ? `${first}-${lastD}` : first;
    if (!r.cur.open) return `${label} closed`;
    return `${label} ${luca2TimeLabel(r.cur.start)}-${luca2TimeLabel(r.cur.end)}`;
  }).join(", ");
}
// The rep's work-day line for visit_invite, from the closer
// profile's per-day schedule (falling back to the legacy
// work_days range like the app does). "" when the profile
// carries no schedule at all — the template then omits the
// sentence rather than inventing availability.
function luca2RepDaysLine(profile) {
  const p = profile || {};
  const hasPerDay = !!(p.schedule && typeof p.schedule === "object");
  const hasLegacy = Array.isArray(p.work_days) && p.work_days.length > 0;
  if (!hasPerDay && !hasLegacy) return "";
  const sched = {};
  for (const d of LUCA2_DAY_KEYS) {
    const e = (p.schedule && p.schedule[d]) || null;
    if (e) sched[d] = { on: !!e.on, start: e.start || "09:00", end: e.end || "19:00" };
    else sched[d] = { on: hasLegacy ? p.work_days.includes(d) : false, start: p.work_start || "09:00", end: p.work_end || "19:00" };
  }
  const on = LUCA2_DAY_KEYS.filter(d => sched[d].on);
  if (!on.length) return "";
  const parts = on.map(d => `${LUCA2_DAY_SHORT[d]} ${luca2TimeLabel(sched[d].start)}-${luca2TimeLabel(sched[d].end)}`);
  return `I'm at the store ${parts.join(", ")}.`;
}
function lucaAutoReply2RenderHours(f) {
  const greet = f.name ? `Hi ${f.name}, thanks for asking! ` : "Thanks for asking! ";
  let out = `${greet}We're ${f.dealerName} at ${f.dealerAddress}. Our hours are ${f.hoursLine}.`;
  if (f.repName) out += ` Ask for ${f.repName} when you come in.`;
  return out;
}
function lucaAutoReply2RenderVisit(f) {
  const greet = f.name ? `Hi ${f.name}, yes` : "Yes";
  let out = `${greet} — you can come see it! ${f.year} ${f.make} ${f.model}, ${lucaAutoReplyMoney(f.price)}. You can see it here: ${f.link}.`;
  if (f.daysLine) out += ` ${f.daysLine}`;
  out += " What time works for you?";
  return out;
}
function lucaAutoReply2RenderTrade(f) {
  const greet = f.name ? `Hi ${f.name}, yes` : "Yes";
  return `${greet} — we take trades! You can send me your trade info here: ${f.tradeLink} — it takes about 2 minutes: a few photos, the mileage, and the condition. Once it's in, I can take a look.`;
}
// Decision table for the phase-2 classes. ctx:
//   cls, enabled, matched (bool — the runtime only calls
//   decide for the matched class), repAnsweredAfter,
//   priorClassSends, lastClassSendAt (ms epoch|null), nowMs,
//   hour (0-23 local), sentToday, cap,
//   car-bound (visit_invite): labelTrusted, match, carState,
//   priceOk, hasLink, carFresh, acctFresh,
//   fields per class (see the renderers).
// Returns {action: "send"|"skip"|"hold", branch: cls,
// reason, body?} — branch is the intent class on EVERY
// phase-2 decision (the per-class record the caps and the
// app's decision log read); the JSON keys are phase 1's.
function lucaAutoReply2Decide(ctx) {
  const cls = ctx.cls;
  const skip = (reason) => ({ action: "skip", branch: cls, reason });
  if (!LUCA2_CLASSES.includes(cls)) return { action: "skip", branch: null, reason: "unknown_class" };
  if (!ctx.enabled) return skip("toggle_off");
  if (!ctx.matched) return skip("not_matched");
  if (ctx.repAnsweredAfter) return skip("has_rep_reply");
  if (cls === "hours_location") {
    if ((ctx.priorClassSends || 0) > 0 &&
        (ctx.lastClassSendAt == null || (ctx.nowMs - ctx.lastClassSendAt) < LUCA2_HOURS_THREAD_CAP_MS)) {
      return skip("thread_cap");
    }
  } else if ((ctx.priorClassSends || 0) > 0) {
    return skip("thread_cap"); // visit_invite + trade_link: once per thread, ever
  }
  if (cls === "visit_invite") {
    if (ctx.labelTrusted === false) return skip("label_untrusted");
    if (ctx.match === "none") return skip("car_unresolved");
    if (ctx.match === "ambiguous") return skip("car_ambiguous");
    if (ctx.match !== "one") return skip("car_unresolved");
    if (!ctx.carFresh || !ctx.acctFresh) return skip("stale_inventory");
    if (ctx.carState === "gone") return skip("confirmed_gone");
    if (ctx.carState !== "available") return skip("availability_unknown");
    if (!ctx.priceOk) return skip("no_price");
    if (!ctx.hasLink) return skip("missing_link");
  }
  if (typeof ctx.hour !== "number" || ctx.hour < LUCA_AUTOREPLY_START_HOUR || ctx.hour >= LUCA_AUTOREPLY_END_HOUR) {
    return { action: "hold", branch: cls, reason: "outside_hours" };
  }
  if ((ctx.sentToday || 0) >= (ctx.cap || LUCA_AUTOREPLY_CAP_PER_DAY)) return skip("cap_reached");
  const f = ctx.fields || {};
  if (cls === "hours_location") {
    if (!f.hoursLine || !f.dealerName || !f.dealerAddress) return skip("missing_settings");
    return { action: "send", branch: cls, reason: "ok", body: lucaAutoReply2RenderHours(f) };
  }
  if (cls === "visit_invite") {
    return { action: "send", branch: cls, reason: "ok", body: lucaAutoReply2RenderVisit(f) };
  }
  if (!f.tradeLink) return skip("missing_trade_link");
  return { action: "send", branch: cls, reason: "ok", body: lucaAutoReply2RenderTrade(f) };
}
// [PURE-AUTOREPLY2-END]

// [PURE-AUTOREPLY-TRIGGER-BEGIN] — extracted and unit-exercised
// by the test harness; keep free of DOM/chrome references.
// Inbox-auto trigger (v2.1.102, header note 55): an inbox list
// snippet may NOMINATE a thread for a worker verification
// open — it never decides anything. The nomination test is
// deliberately looser than the send test (a truncated snippet
// can nominate), because the real first message is re-read
// from the captured thread and judged by lucaAutoReplyDecide
// before anything can send.
const LUCA_AUTOREPLY_OPEN_GAP_MS = 30 * 1000;
const LUCA_AUTOREPLY_OPEN_PER_HOUR = 10;
const LUCA_AUTOREPLY_OPEN_TIMEOUT_MS = 150 * 1000;
const LUCA_AUTOREPLY_OPEN_MAX_ATTEMPTS = 2;
const LUCA_AUTOREPLY_OPEN_RETRY_MS = 60 * 1000;
// Facebook fuses the sender's name onto their latest line in
// list rows ("Matthew: Hello, is this still availab…"). Strip
// one leading "Name:" prefix so the text underneath can be
// compared with the canned openers.
function lucaAutoReplySnippetText(raw) {
  let t = String(raw || "").trim();
  const m = t.match(/^[A-Za-z][A-Za-z .'-]{0,24}:\s+/);
  if (m) t = t.slice(m[0].length);
  return t.trim();
}

// Facebook's first-contact system line (v2.1.106, note
// 59): the /marketplace/inbox preview of a first listing
// inquiry is FB's own sentence, not the buyer's words —
// "<Name> sent you a message about your listing: <title>".
// Anchored at the very start of the (prefix-stripped)
// snippet: one to four capitalized name tokens (letters,
// apostrophes, hyphens, dots), then the exact phrase with
// its colon, then at least one character of listing text.
// A buyer-typed line matches only by reproducing that
// exact shape from its first character — and even then it
// merely nominates (see lucaAutoReplySnippetCandidate).
const LUCA_AUTOREPLY_SYSTEM_LINE_RE =
  /^[A-Z][A-Za-z'’.-]{0,29}(?: [A-Z][A-Za-z'’.-]{0,29}){0,3} sent you a message about your listing: +\S/;
function lucaAutoReplyIsSystemLine(text) {
  return LUCA_AUTOREPLY_SYSTEM_LINE_RE.test(String(text || "").trim());
}
// snippet: {direction, snippet} as the worker's snippet sync
// delivers them; prospect: {hasMessages} — a thread that
// already holds captured messages belongs to the existing
// capture/snippet hooks and is never a candidate.
function lucaAutoReplySnippetCandidate(snippet, prospect) {
  if (!snippet || snippet.direction !== "in") return false;
  if (!prospect || prospect.hasMessages) return false;
  const body = lucaAutoReplySnippetText(snippet.snippet);
  // v2.1.106 (note 59): FB's first-contact system line
  // nominates on the same terms — it carries no buyer
  // words, so the canned test below can never see it.
  if (lucaAutoReplyIsSystemLine(body)) return true;
  const truncated = /[…]\s*$|\.\.\.\s*$/.test(body);
  const core = body.replace(/[…]+$|\.\.\.$/, "").trim();
  const norm = lucaAutoReplyNormalize(core);
  if (!norm) return false;
  if (LUCA_AUTOREPLY_CANNED.has(norm)) return true;
  if (!truncated || norm.length < 10) return false;
  for (const entry of LUCA_AUTOREPLY_CANNED) {
    if (entry.indexOf(norm) === 0) return true;
  }
  return false;
}
// v2.1.108 (note 60): the inbox BUTTON-row signatures. A
// button record nominates ONLY — exactly like a snippet —
// and only through these shapes: the availability
// canned/truncated tests (the same tests the anchor
// candidate runs), the first-contact system line, or FB's
// awaiting-reply nudge ("<Name> is waiting for your
// response."). The nudge is an inbound-first-contact
// shape by construction — FB shows it only while the
// thread's first buyer message awaits the rep's first
// reply. The no-captured-messages gate is NOT repeated
// here; it is applied by the caller's candidate and
// thread-state checks, as for every signature.
const LUCA_AUTOREPLY_WAITING_NUDGE_RE = /^.+ is waiting for your response\.?$/;
function lucaAutoReplyIsWaitingNudge(text) {
  return LUCA_AUTOREPLY_WAITING_NUDGE_RE.test(lucaAutoReplySnippetText(text));
}
// The rep's OWN availability template, as it renders in an
// inbox preview after a send: the inbox carries no "You:"
// direction marker, so a row previewing the template text
// must never nominate. Fragment tests on the rendered
// templates' distinctive clauses (a preview is truncated,
// so match the clauses, not the whole string).
function lucaAutoReplyIsRepTemplateText(text) {
  const body = lucaAutoReplyNormalize(text);
  if (!body) return false;
  if (body.includes("are you okay with that price")) return true;
  if (body.includes("has sold / is no longer available")) return true;
  if (body.includes("come look at it test drive it")) return true;
  if (/^(hi|hello|hey) .{1,40} yes/.test(body) && body.includes("still available")) return true;
  return false;
}
function lucaAutoReplyButtonCandidate(rec) {
  const body = lucaAutoReplySnippetText(String((rec && rec.snippet) || ""));
  if (!body) return false;
  if (lucaAutoReplyIsSystemLine(body)) return true;
  if (lucaAutoReplyIsRepTemplateText(body)) return false;
  if (lucaAutoReplyIsWaitingNudge(body)) return true;
  const truncated = /[…]\s*$|\.\.\.\s*$/.test(body);
  const core = body.replace(/[…]+$|\.\.\.$/, "").trim();
  const norm = lucaAutoReplyNormalize(core);
  if (!norm) return false;
  if (LUCA_AUTOREPLY_CANNED.has(norm)) return true;
  if (!truncated || norm.length < 10) return false;
  for (const entry of LUCA_AUTOREPLY_CANNED) {
    if (entry.indexOf(norm) === 0) return true;
  }
  return false;
}
// Match keys for the no-threadRef route: name + clean
// label, both normalized (the label key strips the
// scraper's "$X - " price prefix and punctuation noise).
function lucaAutoReplyNameKey(name) {
  return String(name || "").toLowerCase().replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ").trim();
}
function lucaAutoReplyLabelKey(label) {
  let s = String(label || "");
  const cut = s.indexOf(" - ");
  if (cut > 0 && /\$/.test(s.slice(0, cut))) s = s.slice(cut + 3);
  return s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ").trim();
}
// EXACTLY ONE prospect whose name + label keys match the
// row's, or null (zero or multiple matches never guess).
// A row with no label cannot match: there is nothing to
// bind the label half of the pair to.
function lucaAutoReplyUniqueProspectMatch(rows, buyerName, vehicleLabel) {
  const nk = lucaAutoReplyNameKey(buyerName);
  const lk = lucaAutoReplyLabelKey(vehicleLabel);
  if (!nk || !lk) return null;
  const hits = (rows || []).filter((p) => p &&
    lucaAutoReplyNameKey(p.name) === nk &&
    lucaAutoReplyLabelKey(p.vehicle_label) === lk);
  return hits.length === 1 ? hits[0] : null;
}
// [PURE-AUTOREPLY-TRIGGER-END]

async function sbHeaders(extra) {
  const token = await storedAccessToken();
  return Object.assign({
    "apikey": SUPABASE_ANON_KEY,
    "Authorization": `Bearer ${token || SUPABASE_ANON_KEY}`,
    "Content-Type": "application/json"
  }, extra || {});
}

// Record (once per expiry) that the stored token died, in the same
// autolaunch_last_error record the failure logger uses. Reason strings
// only — the token value itself never lands in storage logs or errors.
async function markSessionExpired() {
  alSessionExpiredKnown = true;
  const { autolaunch_session_expired: already } =
    await chrome.storage.local.get(["autolaunch_session_expired"]);
  if (already) return;
  await chrome.storage.local.set({
    autolaunch_session_expired: true,
    al_session_expired: true,
    autolaunch_last_error: {
      queueId: null,
      reason: "session_expired — reopen the AutoLaunch tab",
      at: new Date().toISOString()
    }
  });
  console.warn("[AutoLaunch] Session token expired — reopen the AutoLaunch tab to reconnect the extension.");
}

async function noteWaitingForLogin() {
  const { autolaunch_last_error: last } =
    await chrome.storage.local.get(["autolaunch_last_error"]);
  if (last && last.reason === "waiting_for_login") return;
  await chrome.storage.local.set({
    autolaunch_last_error: {
      queueId: null,
      reason: "waiting_for_login",
      at: new Date().toISOString()
    }
  });
}

async function sbFetch(path, options) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, options);
  if (res.status === 401 || res.status === 403) {
    // [SESS356] session self-healing (spec H1): the
    // first auth failure of an episode asks the app
    // for a fresh token before anything may latch;
    // with the kill switch off this is .155 exactly.
    if (SESSION_SELF_HEAL) await alSessHeal356OnAuthFailure();
    else await markSessionExpired();
    throw new SbAuthError(res.status);
  }
  if (!res.ok) {
    throw new Error(`Supabase ${(options && options.method) || "GET"} ${path} -> ${res.status}`);
  }
  // Session-expired surfacing (v2.1.104, note 57): a call
  // that carried the user's token and SUCCEEDED revives
  // the session — clear the surfaced state.
  await alNoteAuthenticatedSuccess(options && options.headers);
  await alSessHeal356NoteSuccess(options && options.headers);
  return res.json();
}

async function sbGet(path) {
  return sbFetch(path, { headers: await sbHeaders() });
}

async function sbPatch(path, body) {
  return sbFetch(path, {
    method: "PATCH",
    headers: await sbHeaders({ "Prefer": "return=representation" }),
    body: JSON.stringify(body)
  });
}

async function sbDelete(path) {
  return sbFetch(path, { method: "DELETE", headers: await sbHeaders({}) });
}

async function sbPost(path, body) {
  return sbFetch(path, {
    method: "POST",
    headers: await sbHeaders({ "Prefer": "return=representation" }),
    body: JSON.stringify(body)
  });
}

// Upsert with an explicit conflict target (v2.1.80, for the DWS
// helper-side sync's inventory push — mirrors the Python scraper's
// on_conflict="vin, user_id").
async function sbUpsert(path, rows) {
  return sbFetch(path, {
    method: "POST",
    headers: await sbHeaders({
      "Prefer": "resolution=merge-duplicates,return=representation"
    }),
    body: JSON.stringify(rows)
  });
}

// ---------------------------------------------------------------------
// AUTO-CREATE GATE (v2.1.46, header notes 22-23). Pure function:
// given an AUTO capture and the context handleCaptureChat assembled
// (the user's Marketplace-posted cars), decide whether the capture
// may CREATE a prospect. Manual captures never pass through here,
// and neither do captures for an already-known prospect (their
// message sync is not creation).
function autoCreateGate(capture, ctx) {
  var name = String((capture && capture.buyerName) || "").trim();
  // Hard rule: an unresolved participant name NEVER auto-creates —
  // the "Marketplace buyer" fallback card is exactly what this kills.
  if (!name) return { create: false, reason: "unresolved_name" };
  // Chrome placeholder names (v2.50, header note 24): "Facebook
  // user" and its furniture friends are what a half-rendered
  // thread shows INSTEAD of a participant — not a resolved name.
  if (/^(facebook user|compose|conversation with facebook user)$/i.test(name)) {
    return { create: false, reason: "unresolved_name" };
  }
  // Self test BY IDENTITY (v2.1.47, header note 23): block only when
  // the counterparty's Facebook identity PROVABLY equals the
  // signed-in account's — canonical tokens ("id:<digits>" /
  // "vanity:<name>") scraped by chat_capture.js. An id token never
  // equals a vanity token (unproven = not self), and a display-name
  // match is no signal at all: a second account under the same name
  // is a buyer, not the rep himself.
  var buyerId = String((capture && capture.buyerFbId) || "").trim();
  var selfId = String((capture && capture.selfFbId) || "").trim();
  if (buyerId && selfId && buyerId === selfId) {
    return { create: false, reason: "self_thread" };
  }
  var label = String((capture && capture.vehicleText) || "").trim();
  // Signal 1 — surface: the Marketplace inbox is commerce-only by
  // construction; a listing label must ride along so a bare system
  // row there still cannot create on surface alone.
  if (capture && capture.surface === "marketplace_inbox" && label) {
    return { create: true, signal: "marketplace_inbox" };
  }
  // Signal 2 — seller's thread: the open pane showed the seller's
  // own controls ("View buyer" renders only for the listing's
  // seller; a buyer-side thread shows "View seller" instead).
  if (capture && capture.sellerContext === true && label) {
    return { create: true, signal: "seller_thread" };
  }
  // Signal 3 — own listing: the label's year + make match one of
  // the user's own Marketplace-posted cars.
  if (label && labelMatchesPostedCar(label, (ctx && ctx.postedCars) || [])) {
    return { create: true, signal: "own_listing" };
  }
  return { create: false, reason: "no_seller_signal" };
}

// Does a listing label ("$26,159 - 2026 Volkswagen Jetta", "2026
// Volkswagen Jetta") name one of the user's posted cars? Token-based
// contains on year + make, so multi-word makes ("Land Rover") work
// the same way. postedCars rows come from scraped_inventory with
// marketplace_posted_at set — cars this user actually listed.
function labelMatchesPostedCar(label, postedCars) {
  var text = " " + String(label || "").toLowerCase()
    .replace(/[^a-z0-9]+/g, " ") + " ";
  for (var i = 0; i < postedCars.length; i++) {
    var car = postedCars[i] || {};
    var year = parseInt(car.year, 10);
    var make = String(car.make || "").trim().toLowerCase()
      .replace(/[^a-z0-9]+/g, " ").trim();
    if (!year || !make) continue;
    if (text.indexOf(" " + year + " ") === -1) continue;
    if (text.indexOf(" " + make + " ") !== -1) return true;
  }
  return false;
}

// Luca chat capture (Phase 2): a chat_capture.js scrape of an open
// Messenger/Marketplace thread lands here. Find-or-create the buyer as
// a Prospect, then store only the messages we don't already have.
// Runs on the rep's own stored session, so RLS keeps every row theirs.
async function handleCaptureChat(capture, opts) {
  const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
  if (!userId) {
    const e = new Error("not_signed_in — open AutoLaunch and sign in first");
    e.code = "not_signed_in";
    throw e;
  }
  const norm = (s) => (s || "").trim().toLowerCase();
  const name = (capture.buyerName || "").trim() || "Marketplace buyer";
  const vehicleText = (capture.vehicleText || "").trim();
  const threadRef = (capture.threadUrl || "").slice(0, 300);
  // Tombstone key (v2.50, header note 24): the thread's numeric
  // /t/<id> when the ref carries one, else the normalized ref —
  // MUST stay in step with prospect_tombstone_key() in the
  // database, which keys the rows the delete trigger writes.
  const threadKey = (() => {
    const m = String(threadRef || "").match(/\/t\/(\d+)/);
    return m ? m[1] : norm(threadRef);
  })();

  // CAPTURE-MERGE GUARD (v2.1.103, note 56): an AUTO capture is
  // filed under its thread only when the ref carries a real
  // thread id. The full-thread scrape keys its harvest to the
  // page URL, so on a LIST surface (the Marketplace inbox with
  // no single thread open) the capture arrives keyed to the
  // list page itself — and 3.02's worker-owned hub tab lives on
  // that page permanently, which is how the 2026-11-12 desk
  // proof grew a prospect whose "thread" was the inbox, its
  // "messages" the list rows and nav items of every thread on
  // it (the same defect as Rachel's merged prospect, diagnosed
  // 2026-10-28). An id-less AUTO capture therefore never
  // creates a prospect and never matches one — it is dropped
  // here, before any read. A capture from the worker's own hub
  // tab is list surface by definition: a FULL capture from it
  // is dropped the same way even if its URL claims a thread,
  // while its stub captures (real /t/ refs, no messages) still
  // flow. Manual captures pass through untouched — the Capture
  // button is the rep's explicit act.
  const fromHubTab = !!(opts && opts.fromHubTab);
  if (capture.auto && !/\/t\/\d+/.test(threadRef)) {
    return { prospectName: null, added: 0, skipped: "no_thread_id" };
  }
  if (capture.auto && fromHubTab && !capture.stub) {
    return { prospectName: null, added: 0, skipped: "hub_list_surface" };
  }

  // MANUAL-LANE MERGE GUARD (v2.1.105, note 58): the
  // guards above are AUTO-only — the floating Capture
  // button's send is untagged, so a list-page scrape
  // filed through the manual lane reached the create
  // path unguarded (805886ae, keyed to the bare
  // /messages/ URL, page-heading name, fused banner
  // label, zero messages). The junk invariant: an
  // id-less thread ref AND no messages at all. A manual
  // capture WITH messages keeps today's behavior
  // byte-for-byte — the popup lane (v2.1.28) keys
  // threadUrl to the page URL and always carries the
  // conversation — and stubs carry real /t/ refs by
  // construction, so neither is touched.
  if (!/\/t\/\d+/.test(threadRef) && !(capture.messages && capture.messages.length)) {
    return { prospectName: null, added: 0, skipped: "no_thread_id" };
  }

  // Match order (auto-capture, v2.1.31): the THREAD is the identity —
  // the same conversation must never become two prospects just because
  // a list-row name or a listing label scraped differently this time.
  // Name+label matching stays as the fallback for captures with no URL.
  const rows = await sbGet(`prospects?user_id=eq.${userId}&select=id,name,vehicle_label,thread_ref&order=created_at.desc&limit=200`);
  let prospect = null;
  if (threadRef) prospect = rows.find(r => r.thread_ref && norm(r.thread_ref) === norm(threadRef));
  // Tombstone BEFORE the fallback (v2.1.103, note 56): the
  // name+label fallback below can match a DIFFERENT live
  // prospect, and a deleted thread's capture must not be
  // swallowed into it — so for auto captures the deletion
  // check runs before the fallback, not only after both
  // matches fail (2026-10-28 diagnosis, part 3). The create
  // path further down re-checks before creating, unchanged.
  if (!prospect && capture.auto && threadKey) {
    try {
      const tombsEarly = await sbGet(`prospect_tombstones?user_id=eq.${userId}&thread_ref=eq.${encodeURIComponent(threadKey)}&select=id&limit=1`);
      if (tombsEarly && tombsEarly.length) {
        return { prospectName: null, added: 0, skipped: "deleted_by_user" };
      }
    } catch (e) { /* read failed — the create-path check below still guards */ }
  }
  if (!prospect) {
    prospect = rows.find(r => norm(r.name) === norm(name) && (!vehicleText || norm(r.vehicle_label) === norm(vehicleText)));
  }
  // Marketplace-only auto rule (Matthew, 2026-10-25; tightened
  // v2.1.46, header note 22): creating a prospect from an AUTO
  // capture requires a resolved participant name AND a positive
  // seller-side signal — see autoCreateGate. Merely opening a
  // Messenger chat must never create a prospect or save its
  // messages; the manual Capture button (no auto flag) is how a rep
  // adds anything else, and it never passes through the gate. Auto
  // updates to an already-known prospect's thread still flow.
  if (capture.auto && !prospect) {
    // Tombstone (v2.50, header note 24): a prospect the rep
    // deleted must STAY deleted — the thread still exists on
    // Facebook, so without this check the next pass re-creates
    // the card. Terminal: never created, never retried.
    if (threadKey) {
      try {
        const tombs = await sbGet(`prospect_tombstones?user_id=eq.${userId}&thread_ref=eq.${encodeURIComponent(threadKey)}&select=id&limit=1`);
        if (tombs && tombs.length) {
          return { prospectName: null, added: 0, skipped: "deleted_by_user" };
        }
      } catch (e) { /* read failed — the gate below still guards creation */ }
    }
    const gateCtx = { postedCars: [] };
    try {
      gateCtx.postedCars = await sbGet(
        `scraped_inventory?user_id=eq.${userId}` +
        `&marketplace_posted_at=not.is.null&select=year,make,model&limit=300`) || [];
    } catch (e) { /* no inventory signal this pass */ }
    const gate = autoCreateGate(capture, gateCtx);
    if (!gate.create) {
      return { prospectName: null, added: 0, skipped: gate.reason };
    }
  }
  // Manual Capture, no matched prospect, no resolvable participant
  // (v2.1.47): decline with a reason the button can name instead of
  // filing a nameless "Marketplace buyer" card. Auto captures never
  // reach here (the gate already decided), and a thread-matched
  // prospect captures fine without a name.
  if (!capture.auto && !prospect && !String(capture.buyerName || "").trim()) {
    const e = new Error("no_buyer — no buyer found in this chat");
    e.code = "no_buyer";
    throw e;
  }
  if (!prospect) {
    const created = await sbPost("prospects", {
      user_id: userId,
      name: name,
      vehicle_label: vehicleText || null,
      stage: "new",
      source: "marketplace",
      thread_ref: threadRef || null,
      notes: capture.stub
        ? "Found in your Messenger inbox by Luca auto-sync. Open the chat and Luca will capture the conversation."
        : "Captured from a Marketplace chat by Luca."
    });
    prospect = created[0];
    // Manual Capture of a previously deleted thread is an
    // explicit undelete (v2.50, header note 24): clear its
    // tombstone so the thread lives as a normal prospect again.
    if (!capture.auto && threadKey) {
      try { await sbDelete(`prospect_tombstones?user_id=eq.${userId}&thread_ref=eq.${encodeURIComponent(threadKey)}`); } catch (e) { /* cosmetic */ }
    }
  } else {
    // Self-heal older/rougher captures: backfill a placeholder name, a
    // missing label, or a missing thread link when this capture has
    // better data. Never overwrite good data with rougher data.
    const patch = {};
    if (norm(prospect.name) === "marketplace buyer" && norm(name) !== "marketplace buyer") patch.name = name;
    if (!prospect.vehicle_label && vehicleText) patch.vehicle_label = vehicleText;
    const healedLabel = lucaAutoReplyLabelHeal(prospect.vehicle_label, vehicleText);
    if (healedLabel) patch.vehicle_label = healedLabel;
    if (!prospect.thread_ref && threadRef) patch.thread_ref = threadRef;
    if (Object.keys(patch).length) {
      try { await sbPatch(`prospects?id=eq.${prospect.id}`, patch); Object.assign(prospect, patch); } catch (e) { /* cosmetic */ }
    }
  }

  const existing = await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospect.id}&select=id,body,direction&order=created_at.desc&limit=200`);
  const seen = new Set(existing.map(m => m.direction + "|" + m.body));
  // Cross-direction guard (v2.51, header note 25): a scrape that
  // misplaces a bubble files the SAME body under the opposite
  // direction, and the direction-keyed dedupe above waves it
  // through as new — that is how the rep's own delivered reply
  // ("I'll actually be here until 8 tonight…", already stored
  // out/rep) was re-filed as the buyer's on Matthew's shared-name
  // group thread. A long body already stored under the other
  // direction is the same message mis-read: drop the copy. Short
  // bodies are exempt — both sides genuinely say "Yes" / "Ok",
  // and dropping a real echo would lose a real message.
  const storedDirs = new Map();
  existing.forEach(m => {
    const b = norm(m.body);
    if (!storedDirs.has(b)) storedDirs.set(b, new Set());
    storedDirs.get(b).add(m.direction);
  });
  // Capture hygiene belt (v2.1.111, note 62): the desk
  // capture of 2026-11-13 stored two pieces of thread
  // chrome as messages — FB's awaiting-reply banner as a
  // REP message (it tripped has_rep_reply) and the thread
  // header's name line as the first BUYER message (it
  // poisons first-message accounting). chat_capture cuts
  // both at the scrape; this belt is the second net, on
  // every capture path (the 3.03 precedent): whole-text
  // cuts only, on the batch before storage. (1) A message
  // whose WHOLE body is the waiting banner is dropped,
  // either direction. (2) The batch's first buyer message
  // is dropped when its whole body is the buyer's resolved
  // name — the name this capture resolved, or the
  // prospect's stored name — AND another buyer message
  // follows it in the batch. A name written anywhere else,
  // or as the only buyer message, is kept.
  const captureMessages311 = (capture.messages || []).filter(m =>
    !(m && typeof m.body === "string" && /^.+ is waiting for your response\.?$/.test(m.body.trim())));
  const firstBuyer311 = captureMessages311.findIndex(m => m && m.direction !== "out");
  if (firstBuyer311 >= 0) {
    const buyerCount311 = captureMessages311.filter(m => m && m.direction !== "out").length;
    const firstBody311 = norm(captureMessages311[firstBuyer311].body);
    if (buyerCount311 >= 2 && firstBody311 &&
        (firstBody311 === norm(name) || firstBody311 === norm(prospect.name || ""))) {
      captureMessages311.splice(firstBuyer311, 1);
    }
  }
  const fresh = (captureMessages311 || []).filter(m => {
    if (!m || !m.body) return false;
    if (seen.has(m.direction + "|" + m.body)) return false;
    if (String(m.body).trim().length >= 20) {
      const dirs = storedDirs.get(norm(m.body));
      if (dirs) {
        const mine = m.direction === "out" ? "out" : "in";
        const other = mine === "out" ? "in" : "out";
        if (dirs.has(other) && !dirs.has(mine)) return false;
      }
    }
    return true;
  });
  if (fresh.length) {
    // Sequential created_at stamps (v2.1.40): one bulk insert shares
    // a single transaction timestamp, which scrambled the thread
    // order in the conversation view (Matthew: "texts come in out
    // of order"). Stamping each row +1ms in scrape order makes
    // created_at a faithful chronology.
    const baseTs = Date.now();
    await sbPost("closer_messages", fresh.map((m, idx) => ({
      user_id: userId,
      prospect_id: prospect.id,
      thread_ref: (capture.threadUrl || "").slice(0, 300) || null,
      direction: m.direction === "out" ? "out" : "in",
      origin: m.direction === "out" ? "rep" : "buyer",
      body: String(m.body).slice(0, 2000),
      created_at: new Date(baseTs + idx).toISOString()
    })));
    // Snippet-partial cleanup (v2.1.33): a full capture supersedes the
    // truncated one-line rows the inbox-list snippet sync saved for the
    // same message. An existing row counts as a partial when a fresh
    // full body (same direction, longer) starts with its text.
    const partialIds = existing.filter(e => {
      const core = lucaAutoReplySnippetText(String(e.body || "")).replace(/[…]+$/, "").replace(/\.\.\.$/, "");
      if (core.length >= 20 && fresh.some(f => f.direction === e.direction
        && String(f.body).length > core.length
        && String(f.body).indexOf(core.slice(0, 40)) === 0)) return true;
      // Composite rows (v2.1.41): a list-row snippet sometimes fuses
      // the listing label + sender name onto the message ("2026
      // Volkswagen Jetta Matthew: Hahahah shush"). When a fresh full
      // body matches the existing row's TAIL with a real prefix in
      // front of it, the fused row is the same message — drop it.
      const eBody = String(e.body || "");
      return fresh.some(f => f.direction === e.direction
        && String(f.body).length >= 3
        && eBody.length > String(f.body).length + 8
        && eBody.endsWith(String(f.body)));
    }).map(e => e.id).filter(Boolean);
    if (partialIds.length) {
      try { await sbDelete(`closer_messages?id=in.(${partialIds.join(",")})`); } catch (e) { /* cosmetic */ }
    }
  }
  if (fresh.length) { try { await lucaAutoReplyEvaluate(userId, prospect); } catch (e) { /* auto-reply is fail-open */ } }
  if (fresh.length) { try { await lucaAutoReply2Evaluate(userId, prospect); } catch (e) { /* auto-reply 2 is fail-open */ } } /*LUCA2*/
  return { prospectName: prospect.name || name, added: fresh.length };
}

// Snippet sync (v2.1.33): the inbox LIST only shows each conversation's
// newest line — but that line updates live when a buyer writes, with no
// click from anyone. chat_capture.js sends those lines here; a line is
// stored ONLY for a thread that already belongs to a known prospect
// (personal chats are never pulled in), and only when it is genuinely
// new against what we already hold for that prospect.
async function handleChatSnippets(snippets) {
  const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
  if (!userId || !Array.isArray(snippets) || !snippets.length) return { stored: 0 };
  const norm = (s) => (s || "").trim().toLowerCase();
  const rows = await sbGet(`prospects?user_id=eq.${userId}&select=id,thread_ref&order=created_at.desc&limit=200`);
  const byThread = new Map();
  rows.forEach(r => { if (r.thread_ref) byThread.set(norm(r.thread_ref), r); });
  // v2.1.105 (note 58): nominate BEFORE the store loop below.
  // A stored snippet is itself a closer_messages row and the
  // nominator's thread-state gate counts stored rows as
  // captured messages — stored first, the snippet permanently
  // disqualified its own thread (the 2.104 salvage incident).
  // Nominating first sees the thread as it is: a known
  // prospect with nothing captured yet. The evaluate hook
  // that used to run on `stored` is GONE for the same reason:
  // it decided threads on the snippet text itself — a
  // truncated, name-fused preview is not the buyer's words,
  // and one terminal skip on it barred the real capture
  // from ever deciding (also the salvage chain).
  // A snippet nominates; it never decides.
  try { await lucaAutoReplyNoteCandidates(userId, snippets); } catch (e) { /* auto-reply trigger is fail-open */ }
  let stored = 0;
  for (const sn of snippets.slice(0, 15)) {
    // v2.1.108 (note 60): button records are never stored.
    if (sn && sn.rowKind === "inbox_button") continue;
    const prospect = byThread.get(norm(sn.threadRef || ""));
    const body = String(sn.snippet || "").trim();
    if (!prospect || body.length < 2) continue;
    // v2.1.106 (note 59): FB's first-contact system line is a
    // nomination signal, never a message — it is never stored.
    if (lucaAutoReplyIsSystemLine(lucaAutoReplySnippetText(body))) continue;
    // v2.1.134 (note 84): a snippet that is ONLY a relative time
    // label (".5m", "5m", "2h") is the row's timestamp segment,
    // never a message — the segment filter upstream misses the
    // leading-dot form, and the label changes every pass, so it
    // was stored as a fresh buyer message on every hub cycle
    // (Valerie's thread, 2026-11-16). Same class as note 83,
    // which guards the thread-scrape path; this is the snippet
    // path's choke point.
    if (/^[.·]?\s*\d{1,3}\s*[mhdw]$/i.test(body)) continue;
    const direction = sn.direction === "out" ? "out" : "in";
    const recent = await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospect.id}&select=body,direction&order=created_at.desc&limit=30`);
    if (!recent.length) continue; // v2.1.105 (note 58): no captured messages yet — the nomination above owns this thread; a stored preview would be mistaken for a capture downstream.
    const covered = recent.some(m => {
      const b = norm(m.body);
      const s = norm(body);
      return b === s || b.indexOf(s.slice(0, 30)) === 0 || s.indexOf(b.slice(0, 30)) === 0;
    });
    if (covered) continue;
    await sbPost("closer_messages", [{
      user_id: userId,
      prospect_id: prospect.id,
      thread_ref: (sn.threadRef || "").slice(0, 300) || null,
      direction,
      origin: direction === "out" ? "rep" : "buyer",
      body: body.slice(0, 500)
    }]);
    stored++;
  }
  return { stored };
}


// [DLVTRACE315-BEGIN]
// Delivery-trace sink (v2.1.115, header note 66).
// Guarded, fail-silent, behavior-neutral; carried from
// 3.14-DIAG, where one desk run named the lying rungs.
// Content scripts reach it through the AUTOLAUNCH_TRACE
// route (alTraceIngest passes dlv_* stages through
// verbatim); rows land in public.helper_trace.
const AL_TRACE_FLUSH_MS = 20000;
const AL_TRACE_BUFFER_MAX = 200;
const AL_TRACE_FLUSH_MAX = 50;
const AL_TRACE_TEXT_MAX = 80;
const AL_TRACE_IMPORTANT = { dlv_schedule: 1, dlv_outcome: 1, dlv_error: 1 };
let alTraceBuf = [];
let alTraceSeq = 0;
let alTraceDropped = 0;
let alTraceLastFlushAt = 0;
function alTraceText(s) { return String(s == null ? "" : s).slice(0, AL_TRACE_TEXT_MAX); }
function alTraceThreadKey(ref) {
  const m = String(ref || "").match(/\/t\/(\d+)/);
  if (!m) return null;
  return m[1].slice(-8);
}
function alTraceSanitize(v, depth) {
  if (v == null || typeof v === "number" || typeof v === "boolean") return v;
  if (typeof v === "string") {
    let s = v;
    s = s.replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)?/g, "[redacted]");
    s = s.replace(/Bearer\s+\S+/gi, "Bearer [redacted]");
    s = s.replace(/[A-Za-z0-9_-]{40,}/g, "[redacted]");
    return s.slice(0, 200);
  }
  if (Array.isArray(v)) {
    if (depth > 4) return [];
    return v.slice(0, 24).map(x => alTraceSanitize(x, depth + 1));
  }
  if (typeof v === "object") {
    if (depth > 4) return {};
    const out = {};
    let n = 0;
    for (const k of Object.keys(v)) {
      if (n++ >= 24) break;
      try { out[k] = alTraceSanitize(v[k], depth + 1); } catch (e) { out[k] = null; }
    }
    return out;
  }
  return null;
}
function alTrace(stage, threadRef, detail) {
  try {
    let d = alTraceSanitize(detail || {}, 0) || {};
    if (typeof d !== "object" || Array.isArray(d)) d = { value: d };
    d.seq = ++alTraceSeq;
    if (alTraceDropped) { d.trace_dropped = alTraceDropped; alTraceDropped = 0; }
    const row = { stage: String(stage || "?"), thread_key: alTraceThreadKey(threadRef), detail: d };
    if (JSON.stringify(row).length > 1400) row.detail = { note: "detail_truncated", seq: d.seq };
    alTraceBuf.push(row);
    if (alTraceBuf.length > AL_TRACE_BUFFER_MAX) { const drop = alTraceBuf.length - AL_TRACE_BUFFER_MAX; alTraceBuf.splice(0, drop); alTraceDropped += drop; }
    if (AL_TRACE_IMPORTANT[stage]) alTraceFlush();
    else alTraceFlushTick();
  } catch (e) { /* tracing must never break the flow */ }
}
function alTraceFlushTick() {
  try {
    if (!alTraceBuf.length) return;
    if ((Date.now() - alTraceLastFlushAt) < AL_TRACE_FLUSH_MS && alTraceBuf.length < 25) return;
    alTraceFlush();
  } catch (e) { /* fail-silent */ }
}
async function alTraceFlush() {
  try {
    alTraceLastFlushAt = Date.now();
    const rows0 = alTraceBuf.splice(0, alTraceBuf.length);
    if (!rows0.length) return;
    const st = await chrome.storage.local.get(["autolaunch_user_id"]);
    const userId = st && st.autolaunch_user_id;
    if (!userId) return; // no signed-in user: drop quietly
    const rows = rows0.map(r => ({ user_id: userId, stage: r.stage, thread_key: r.thread_key, detail: r.detail }));
    for (let i = 0; i < rows.length; i += AL_TRACE_FLUSH_MAX) {
      await sbPost("helper_trace", rows.slice(i, i + AL_TRACE_FLUSH_MAX));
    }
  } catch (e) { /* fail-silent: a dead sink drops the batch, never the flow */ }
}
function alDlvErr(step, e) {
  try { alTrace("dlv_error", null, { step: String(step || "?"), name: (e && e.name) || "Error", message: String((e && e.message) || e || "").slice(0, 160) }); } catch (e2) { /* fail-silent */ }
}
function alTraceIngest(message) {
  try {
    if (!message || typeof message !== "object") return;
    let stage = String(message.stage || "?");
    if (stage.indexOf("dlv_") !== 0 && stage.indexOf("cc_") !== 0) stage = "cc_" + stage;
    const detail = (message.detail && typeof message.detail === "object" && !Array.isArray(message.detail)) ? message.detail : {};
    alTrace(stage, message.threadRef || null, detail);
  } catch (e) { /* fail-silent */ }
}
// [DLVTRACE315-END]

// --- Luca availability-only auto-reply (v2.1.101, header note 54) --------
// Runtime half of the [PURE-AUTOREPLY] decision block. Evaluated
// when a capture lands new messages on a Marketplace prospect.
// Design notes:
//  * The decision is taken ONCE per thread, ever, and written
//    to closer_messages as an origin:'ai', status:'auto_decision'
//    row whose body is a small JSON record — the rep-visible
//    decision log (the app renders these in the prospect's
//    conversation view; origin 'ai' keeps them out of the real
//    message counts/bubbles by the app's existing filter).
//  * A send NEVER enters the status:'queued' outbound pool —
//    queued rows are claimable by EVERY helper version, so an
//    auto-reply sitting there could be sent by an old helper
//    that knows nothing about these guards. Instead the send
//    waits in chrome.storage (luca_auto_reply_pending) until
//    its randomized delay passes, is then inserted directly
//    at status:'sending' and delivered through the EXACT
//    luca_pending_delivery slot the human reply path uses
//    (chat_capture types it, finishOutboundReply settles it).
//    Only this helper version contains this code, so only it
//    can ever perform an auto-send.
//  * luca_autoreply_dry_run (chrome.storage, set only by the
//    test harness — no UI) makes the pending processor settle
//    the row as sent with delivery_error 'dry_run_no_send'
//    without touching Facebook.
async function lucaAutoReplyWriteDecision(userId, prospect, decision, vin, trigger) {
  try {
    await sbPost("closer_messages", [{
      user_id: userId,
      prospect_id: prospect.id,
      thread_ref: prospect.thread_ref || null,
      direction: "out",
      origin: "ai",
      auto_reply: true,
      status: "auto_decision",
      body: JSON.stringify({
        v: 1,
        action: decision.action,
        branch: decision.branch || null,
        reason: decision.reason,
        vin: vin || null,
        trigger: trigger || undefined,
        at: new Date().toISOString()
      }).slice(0, 500)
    }]);
  } catch (e) { /* the decision still stands in memory; logging is best-effort */ }
}

async function lucaAutoReplyEvaluate(userId, prospect) {
  if (!userId || !prospect || !prospect.id) return;
  // Belt-and-braces (v2.1.103, note 56): never decide on —
  // and never send to — a prospect whose ref carries no real
  // thread id. Such a row is a list-surface artifact, not a
  // conversation (see the capture-merge guard in
  // handleCaptureChat).
  if (!/\/t\/\d+/.test(String(prospect.thread_ref || ""))) return;
  const settingsRows = await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_availability,last_synced_at`);
  const settings = settingsRows && settingsRows[0];
  if (!settings || settings.luca_autoreply_availability !== true) return; // toggle off: dormant, no log spam
  const msgs = (await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospect.id}&select=id,direction,body,status,auto_reply,created_at&order=created_at.asc&limit=200`)) || [];
  if (msgs.some(m => m.status === "auto_decision")) return; // one decision per thread, ever
  const real = msgs.filter(m => m.status !== "auto_decision");
  const inbound = real.filter(m => m.direction === "in");
  if (!inbound.length) return; // nothing to decide yet (e.g. a bare thread stub)
  const outbound = real.filter(m => m.direction === "out");
  const priorAuto = msgs.filter(m => m.auto_reply && (m.status === "sent" || m.status === "sending")).length;

  // Resolve the prospect's vehicle to exactly one posted car.
  // prospects.vehicle_id is unused in practice, so resolution
  // goes through vehicle_label (year + make + model), the same
  // signal autoCreateGate trusts. The label is the listing
  // title the app itself composed from the car's data.
  const label = String(prospect.vehicle_label || "");
  const labelTrusted = lucaAutoReplyLabelTrusted(label);
  const yearM = labelTrusted ? label.match(/\b(?:19|20)\d{2}\b/) : null;
  let match = "none", car = null;
  if (yearM) {
    const inv = (await sbGet(`scraped_inventory?user_id=eq.${userId}&marketplace_posted_at=not.is.null&select=vin,year,make,model,price,status,is_active,detail_url,last_updated&limit=1000`)) || [];
    const ln = " " + label.toLowerCase().replace(/[^a-z0-9]+/g, " ") + " ";
    const lnFlat = ln.replace(/ /g, "");
    const cands = inv.filter(c => {
      if (c.year !== Number(yearM[0])) return false;
      const mk = " " + String(c.make || "").toLowerCase().trim() + " ";
      if (!mk.trim() || !ln.includes(mk)) return false;
      const md = String(c.model || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
      return md.length >= 2 && lnFlat.includes(md);
    });
    const vins = [...new Set(cands.map(c => c.vin))];
    if (vins.length === 1) { match = "one"; car = cands[0]; }
    else if (vins.length > 1) match = "ambiguous";
  }

  const now = Date.now();
  const fresh = (ts) => {
    const t = Date.parse(ts || "");
    return isFinite(t) && (now - t) <= LUCA_AUTOREPLY_FRESH_MS && (now - t) > -5 * 60 * 1000;
  };
  const sold = car ? String(car.status || "").toLowerCase() === "sold" : false;
  const carState = !car ? "unknown" : (sold || car.is_active !== true) ? "gone" : "available";
  const sentRows = (await sbGet(`closer_messages?user_id=eq.${userId}&auto_reply=eq.true&status=in.(sent,sending)&created_at=gte.${encodeURIComponent(startOfTodayISO())}&select=id`)) || [];
  const syncAt = await lucaAutoReplyLastSyncAt(userId, settings);
  const acctFresh = fresh(syncAt);
  const decision = lucaAutoReplyDecide({
    enabled: true,
    alreadyDecided: false,
    inboundCount: inbound.length,
    outboundCount: outbound.length,
    priorAutoCount: priorAuto,
    firstBody: inbound[0].body || "",
    labelTrusted,
    match,
    carState,
    priceOk: !!(car && Number(car.price) > 0),
    hasLink: !!(car && car.detail_url),
    carFresh: !!car && acctFresh,
    acctFresh: acctFresh,
    hour: new Date().getHours(),
    sentToday: sentRows.length,
    cap: LUCA_AUTOREPLY_CAP_PER_DAY,
    fields: car ? {
      name: lucaAutoReplyFirstName(prospect.name),
      year: car.year, make: car.make, model: car.model,
      price: car.price, link: car.detail_url || ""
    } : {}
  });
  const trigger = await lucaAutoReplyTriggerFor(prospect.id, prospect.thread_ref);
  await lucaAutoReplyWriteDecision(userId, prospect, decision, car ? car.vin : null, trigger);
  if (decision.action !== "send") return;
  const store = await chrome.storage.local.get(["luca_auto_reply_pending"]);
  const list = Array.isArray(store.luca_auto_reply_pending) ? store.luca_auto_reply_pending : [];
  list.push({
    prospectId: prospect.id,
    threadRef: prospect.thread_ref || null,
    body: decision.body,
    vin: car ? car.vin : null,
    dueAt: Date.now() + LUCA_AUTOREPLY_DELAY_MIN_MS + Math.floor(Math.random() * LUCA_AUTOREPLY_DELAY_SPAN_MS)
  });
  await chrome.storage.local.set({ luca_auto_reply_pending: list });
}

async function lucaAutoReplyEvaluateThreads(userId, snippets) {
  if (!userId || !Array.isArray(snippets) || !snippets.length) return;
  const norm = (s) => (s || "").trim().toLowerCase();
  const want = new Set(snippets.map(sn => norm(sn.threadRef || "")).filter(Boolean));
  if (!want.size) return;
  const rows = (await sbGet(`prospects?user_id=eq.${userId}&select=id,name,vehicle_label,thread_ref&order=created_at.desc&limit=200`)) || [];
  const seen = new Set();
  for (const p of rows) {
    if (!p.thread_ref || !/\/t\/\d+/.test(p.thread_ref) || !want.has(norm(p.thread_ref)) || seen.has(p.id)) continue;
    seen.add(p.id);
    try { await lucaAutoReplyEvaluate(userId, p); } catch (e) { /* per-thread fail-open */ }
    try { await lucaAutoReply2Evaluate(userId, p); } catch (e) { /* per-thread fail-open */ } /*LUCA2*/
  }
}

// [AUTOREPLY2-RUNTIME-BEGIN] (v2.1.146, Luca Phase 2)
// Phase-2 auto-reply runtime. Deliberately separate from
// the phase-1 path above (which stays byte-untouched and
// always evaluates FIRST at every call site): a phase-2
// decision row can therefore never eat a thread's phase-1
// availability decision — and this reader ignores phase-1
// rows by filtering on the three phase-2 branches.
// Judging: the thread's LATEST inbound message is matched
// against the three canned classes; each class judges a
// given message at most once (a prior decision row for
// that branch at/after the message means it was judged).
// Sends go through a separate pending list whose processor
// mirrors phase 1's (consume-before-insert, shared
// luca_pending_delivery slot + poke/finish plumbing), with
// two deliberate differences: the send-time kill-switch
// recheck reads the item's OWN class toggle (phase 1 only
// re-checks availability), and the human-reply cancel check
// is scoped to human replies at/after the buyer's message
// (phase 2 classes may fire mid-thread, after older rep
// replies; Luca's own auto rows never cancel).
let lucaAuto2Busy = false;
const LUCA2_TOGGLE_COL = {
  hours_location: "luca_autoreply_hours_location",
  visit_invite: "luca_autoreply_visit",
  trade_link: "luca_autoreply_trade_link"
};
async function lucaAutoReply2Evaluate(userId, prospect) {
  if (!userId || !prospect || !prospect.id) return;
  if (!/\/t\/\d+/.test(String(prospect.thread_ref || ""))) return;
  const settingsRows = await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_hours_location,luca_autoreply_visit,luca_autoreply_trade_link,last_synced_at,trade_code,trade_token,dealership_name,dealership_address,rep_display_name`);
  const settings = settingsRows && settingsRows[0];
  if (!settings) return;
  if (!settings.luca_autoreply_hours_location && !settings.luca_autoreply_visit && !settings.luca_autoreply_trade_link) return; // all off: dormant, no log spam
  const msgs = (await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospect.id}&select=id,direction,body,status,auto_reply,created_at&order=created_at.asc&limit=200`)) || [];
  const real = msgs.filter(m => m.status !== "auto_decision");
  const inbound = real.filter(m => m.direction === "in");
  if (!inbound.length) return;
  const target = inbound[inbound.length - 1];
  const cls = lucaAutoReply2Match(target.body);
  if (!cls) return;
  const decisions = [];
  for (const m of msgs) {
    if (m.status !== "auto_decision" || !m.body) continue;
    try { const d = JSON.parse(m.body); if (d && LUCA2_CLASSES.includes(d.branch)) decisions.push({ ...d, createdMs: Date.parse(m.created_at) || 0 }); } catch (e) { /* not a phase-2 decision row */ }
  }
  const tMs = Date.parse(target.created_at) || 0;
  if (decisions.some(d => d.branch === cls && d.createdMs >= tMs)) return; // this message already judged for this class
  const classRows = decisions.filter(d => d.branch === cls && d.action === "send");
  const priorClassSends = classRows.length;
  const lastClassSendAt = priorClassSends ? Math.max(...classRows.map(d => Date.parse(d.at) || d.createdMs || 0)) : null;
  const targetIdx = real.indexOf(target);
  const repAnsweredAfter = real.slice(targetIdx + 1).some(m => m.direction === "out" && !m.auto_reply);
  const now = Date.now();
  const sentRows = (await sbGet(`closer_messages?user_id=eq.${userId}&auto_reply=eq.true&status=in.(sent,sending)&created_at=gte.${encodeURIComponent(startOfTodayISO())}&select=id`)) || [];
  const ctx = {
    cls, enabled: !!settings[LUCA2_TOGGLE_COL[cls]], matched: true,
    repAnsweredAfter, priorClassSends, lastClassSendAt,
    nowMs: now, hour: new Date().getHours(),
    sentToday: sentRows.length, cap: LUCA_AUTOREPLY_CAP_PER_DAY,
    fields: { name: lucaAutoReplyFirstName(prospect.name) }
  };
  if (cls === "visit_invite") {
    // Car resolution mirrors phase 1 exactly: the prospect's
    // label (trusted only when the extractor composed it from
    // a real listing) + a year/make/model scan of the posted
    // inventory; freshness is the account-sync gate, and a
    // car's state is sold-status / is_active, as in phase 1.
    const label = String(prospect.vehicle_label || "");
    const labelTrusted = lucaAutoReplyLabelTrusted(label);
    const yearM = labelTrusted ? label.match(/\b(?:19|20)\d{2}\b/) : null;
    let match = "none", car = null;
    if (yearM) {
      const inv = (await sbGet(`scraped_inventory?user_id=eq.${userId}&marketplace_posted_at=not.is.null&select=vin,year,make,model,price,status,is_active,detail_url,last_updated&limit=1000`)) || [];
      const ln = " " + label.toLowerCase().replace(/[^a-z0-9]+/g, " ") + " ";
      const lnFlat = ln.replace(/ /g, "");
      const cands = inv.filter(c => {
        if (c.year !== Number(yearM[0])) return false;
        const mk = " " + String(c.make || "").toLowerCase().trim() + " ";
        if (!mk.trim() || !ln.includes(mk)) return false;
        const md = String(c.model || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
        return md.length >= 2 && lnFlat.includes(md);
      });
      const vins = [...new Set(cands.map(c => c.vin))];
      if (vins.length === 1) { match = "one"; car = cands[0]; }
      else if (vins.length > 1) match = "ambiguous";
    }
    const fresh = (ts) => {
      const t = Date.parse(ts || "");
      return isFinite(t) && (now - t) <= LUCA_AUTOREPLY_FRESH_MS && (now - t) > -5 * 60 * 1000;
    };
    const sold = car ? String(car.status || "").toLowerCase() === "sold" : false;
    ctx.labelTrusted = labelTrusted;
    ctx.match = match;
    ctx.carState = !car ? "unknown" : (sold || car.is_active !== true) ? "gone" : "available";
    const syncAt = await lucaAutoReplyLastSyncAt(userId, settings);
    ctx.acctFresh = fresh(syncAt);
    ctx.carFresh = !!car && ctx.acctFresh;
    ctx.priceOk = !!(car && Number(car.price) > 0);
    ctx.hasLink = !!(car && car.detail_url);
    ctx.vin = car ? car.vin : null;
    if (car) { ctx.fields.year = car.year; ctx.fields.make = car.make; ctx.fields.model = car.model; ctx.fields.price = car.price; ctx.fields.link = car.detail_url || ""; }
  }
  if (cls === "hours_location" || cls === "visit_invite") {
    let profile = {};
    try {
      const prow = (await sbGet(`closer_profiles?user_id=eq.${userId}&select=profile`))[0];
      if (prow && prow.profile) profile = prow.profile;
    } catch (e) { /* profile is optional — hours fall back to the app defaults */ }
    if (cls === "hours_location") {
      ctx.fields.hoursLine = luca2StoreHoursLine(profile.store_schedule);
      ctx.fields.dealerName = settings.dealership_name || "";
      ctx.fields.dealerAddress = settings.dealership_address || "";
      ctx.fields.repName = profile.rep_name || settings.rep_display_name || "";
    } else {
      ctx.fields.daysLine = luca2RepDaysLine(profile);
    }
  }
  if (cls === "trade_link") {
    const code = settings.trade_code || settings.trade_token || "";
    ctx.fields.tradeLink = code ? `https://autolaunch.org/trade.html?t=${code}` : "";
  }
  const decision = lucaAutoReply2Decide(ctx);
  const trigger = await lucaAutoReplyTriggerFor(prospect.id, prospect.thread_ref);
  await lucaAutoReplyWriteDecision(userId, prospect, decision, ctx.vin || null, trigger);
  if (decision.action !== "send") return;
  const store = await chrome.storage.local.get(["luca_auto_reply2_pending"]);
  const pending = Array.isArray(store.luca_auto_reply2_pending) ? store.luca_auto_reply2_pending : [];
  pending.push({
    prospectId: prospect.id, threadRef: prospect.thread_ref || null, body: decision.body,
    vin: ctx.vin || null, branch: cls, targetAt: target.created_at || null,
    dueAt: Date.now() + LUCA_AUTOREPLY_DELAY_MIN_MS + Math.floor(Math.random() * LUCA_AUTOREPLY_DELAY_SPAN_MS)
  });
  await chrome.storage.local.set({ luca_auto_reply2_pending: pending });
}
async function lucaAutoReply2ProcessPending() {
  if (lucaAuto2Busy) return;
  const store = await chrome.storage.local.get(["luca_auto_reply2_pending", "luca_pending_delivery", "luca_autoreply_dry_run"]);
  const pending = Array.isArray(store.luca_auto_reply2_pending) ? store.luca_auto_reply2_pending : [];
  if (!pending.length || store.luca_pending_delivery) return;
  const now = Date.now();
  const due = pending.filter(p => (p.dueAt || 0) <= now).sort((a, b) => (a.dueAt || 0) - (b.dueAt || 0));
  if (!due.length) return;
  const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
  if (!userId) return;
  lucaAuto2Busy = true;
  try {
    for (const item of due) {
      const rest = pending.filter(p => p !== item);
      // Kill-switch recheck against the item's OWN class toggle.
      const settings = (await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_hours_location,luca_autoreply_visit,luca_autoreply_trade_link`))[0];
      const col = LUCA2_TOGGLE_COL[item.branch];
      if (!settings || !col || !settings[col]) { await chrome.storage.local.set({ luca_auto_reply2_pending: rest }); return; }
      // A human reply at/after the buyer's message cancels the send.
      const outs = (await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${item.prospectId}&direction=eq.out&status=neq.auto_decision&auto_reply=eq.false&created_at=gte.${encodeURIComponent(item.targetAt || "")}&select=id&limit=1`)) || [];
      if (outs.length) { await chrome.storage.local.set({ luca_auto_reply2_pending: rest }); return; }
      const dryRun = !!store.luca_autoreply_dry_run;
      const ins = await sbPost("closer_messages", {
        user_id: userId, prospect_id: item.prospectId, thread_ref: item.threadRef,
        direction: "out", origin: "rep", body: item.body,
        auto_reply: true, status: dryRun ? "sent" : "sending"
      });
      const rowId = ins && ins[0] && ins[0].id;
      await chrome.storage.local.set({ luca_auto_reply2_pending: rest }); // consumed either way
      if (dryRun) {
        console.log(`[autolaunch] luca auto-reply2 DRY-RUN (${item.branch}) for prospect ${item.prospectId} — logged, not delivered`);
        return;
      }
      if (!rowId) return;
      const key = "lucaDeliver:" + rowId;
      await chrome.storage.local.set({
        luca_pending_delivery: {
          rowId, key, prospectId: item.prospectId, threadRef: item.threadRef,
          body: item.body, vin: item.vin || null, startedAt: Date.now()
        }
      });
      let tab = null;
      try {
        const tabs = await chrome.tabs.query({ url: ["https://www.messenger.com/*", "https://www.facebook.com/*"] });
        tab = tabs.find(t => t.active) || tabs[0] || null;
      } catch (e) { /* no tab to poke — the inbox watcher can still pick it up */ }
      const poke346 = tab ? await lucaAutoReplyPokeTab(tab, key, item.threadRef) : null;
      if (poke346 && poke346.load !== "complete") {
        // Same rule as phase 1: never finish (never type) into
        // a tab whose document has not finished loading.
        finishOutboundReply(rowId, false, "auto_reply_tab_still_loading");
      }
      return;
    }
  } catch (e) {
    console.warn("[autolaunch] luca auto-reply2 process failed:", e && e.message || e);
  } finally {
    lucaAuto2Busy = false;
  }
}
// [AUTOREPLY2-RUNTIME-END]

// [NAV317-BEGIN] FRESH NAVIGATION (v2.1.117, note 68):
// the 3.16 desk proof typed into a composer on a
// LONG-LIVED thread tab, and the trace showed why
// that page could not take text: the found box was
// a zero-width ghost ({w: 0, h: 20, x: -26, y: 18})
// and document focus never landed. The fix is
// Matt's own: the lead REMEMBERS its address
// (prospects.thread_ref), so delivery goes back to
// that address FRESH instead of trusting whatever
// state the reused tab has been sitting in. The
// poke below navigates the matched tab to the
// stored thread URL (chrome.tabs.update — the tab
// is NEVER activated and the user's visible tab
// does not change), waits for the load to complete
// at the thread URL, and lets the page settle
// before the DELIVER_NOW poke. A matched tab that
// will not load fresh is a LOUD failure — the
// caller settles the row failed
// (navigation_failed); nothing pokes the ghost.
async function lucaAutoReplyNavigateFresh317(tabId, threadRef) {
  const out = { navigated: false, url: String(threadRef || ""), load: "error" };
  try {
    await chrome.tabs.update(tabId, { url: threadRef });
    out.navigated = true;
    const key = (String(threadRef || "").match(/\/t\/(\d+)/) || [])[1] || "";
    const deadline = Date.now() + 20000;
    let complete = false;
    while (Date.now() < deadline) {
      await sleep(400);
      let t = null;
      try { t = await chrome.tabs.get(tabId); } catch (e) { t = null; }
      if (t && t.status === "complete" && (!key || (t.url || "").includes("/t/" + key))) { complete = true; break; }
    }
    out.load = complete ? "complete" : "timeout";
    if (complete) await sleep(1200);
  } catch (e) { alDlvErr("nav317", e); out.load = "error"; }
  return out;
}
// [NAV317-END]

async function lucaAutoReplyPokeTab(tab, key, threadRef) {
  if (key && (tab.url || "").includes("/t/" + key)) {
    // [NAV317-POKE-BEGIN] (v2.1.117, note 68): go
    // back to the remembered address FRESH before
    // poking (the helper above) — the 3.16 desk run
    // typed into the stale tab's ghost composer.
    // Navigation only; the tab is never activated.
    // The outcome returns to the caller, which
    // fails the row loud when the load did not
    // complete.
    const nav317 = await lucaAutoReplyNavigateFresh317(tab.id, threadRef);
    if (typeof alTrace === "function") alTrace("dlv_tab", threadRef || null, { action: "navigated", navigated: nav317.navigated, url: nav317.url, load: nav317.load, tabId: tab.id }); /*D317*/
    if (nav317.load !== "complete") return nav317;
    // [NAV317-POKE-END]
    const acked = await new Promise(resolve => {
      let done = false;
      const timer = setTimeout(() => { if (!done) { done = true; resolve(false); } }, 6000);
      try {
        chrome.tabs.sendMessage(tab.id, { type: "AUTOLAUNCH_DELIVER_NOW" }, resp => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          resolve(!chrome.runtime.lastError && !!(resp && resp.accepted));
        });
      } catch (e) {
        if (!done) { done = true; clearTimeout(timer); resolve(false); }
      }
    });
    if (!acked) {
      try { await chrome.tabs.reload(tab.id); } catch (e) { alDlvErr("poke_reload", e); /* the delivery timeout sweep settles it */ } /*D315R*/
    }
  } else {
    try { await chrome.tabs.update(tab.id, { url: threadRef }); } catch (e) { alDlvErr("poke_navigate", e); /* same */ } /*D315R*/
  }
}

let lucaAutoBusy = false;
async function lucaAutoReplyProcessPending() {
  if (lucaAutoBusy) return;
  lucaAutoBusy = true;
  try {
    const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
    if (!userId) return;
    const store = await chrome.storage.local.get(["luca_auto_reply_pending", "luca_pending_delivery", "luca_autoreply_dry_run"]);
    const list = Array.isArray(store.luca_auto_reply_pending) ? store.luca_auto_reply_pending : [];
    if (!list.length) return;
    const item = list.find(i => i && (i.dueAt || 0) <= Date.now());
    if (!item) return;
    if (store.luca_pending_delivery) return; // one delivery at a time — next tick
    // Re-verify at send time: toggle still on, and no human
    // reply has landed in the delay window (a human reply
    // always stands the auto-reply down).
    const settingsRows = await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_availability`);
    if (!settingsRows || !settingsRows[0] || settingsRows[0].luca_autoreply_availability !== true) {
      await chrome.storage.local.set({ luca_auto_reply_pending: list.filter(i => i !== item) });
      return;
    }
    const outs = await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${item.prospectId}&direction=eq.out&status=neq.auto_decision&select=id&limit=1`);
    if (outs && outs.length) {
      await chrome.storage.local.set({ luca_auto_reply_pending: list.filter(i => i !== item) });
      return;
    }
    const dryRun = store.luca_autoreply_dry_run === true;
    let tab = null, key = "";
    if (!dryRun) {
      const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
      if (!tabs.length) return; // no hub tab — retry next tick
      key = (String(item.threadRef || "").match(/\/t\/(\d+)/) || [])[1] || "";
      tab = tabs.find(t => key && (t.url || "").includes("/t/" + key))
        || tabs.find(t => (t.url || "").includes("/messages"))
        || tabs.find(t => (t.url || "").includes("/marketplace"))
        || tabs[0];
      if (!tab || tab.id == null) return;
    }
    // Consume the pending item BEFORE inserting the send row,
    // so a crash mid-delivery can never re-send it (the row's
    // own 3-minute timeout sweep settles a half-sent state).
    await chrome.storage.local.set({ luca_auto_reply_pending: list.filter(i => i !== item) });
    const inserted = await sbPost("closer_messages", [{
      user_id: userId,
      prospect_id: item.prospectId,
      thread_ref: item.threadRef || null,
      direction: "out",
      origin: "rep",
      auto_reply: true,
      status: dryRun ? "sent" : "sending",
      delivery_error: dryRun ? "dry_run_no_send" : null,
      body: item.body
    }]);
    const row = inserted && inserted[0];
    if (!row || dryRun) return;
    await chrome.storage.local.set({
      luca_pending_delivery: { messageId: row.id, threadRef: item.threadRef, body: item.body, tabId: tab.id, at: Date.now() }
    });
    if (typeof alTrace === "function") alTrace("dlv_schedule", item.threadRef || null, { prospectId: item.prospectId, bodyLen: String(item.body || "").length, messageId: row.id }); /*D315*/
    if (typeof alTrace === "function") alTrace("dlv_tab", item.threadRef || null, { action: "reused", matched: !!(key && (tab.url || "").includes("/t/" + key)), url: String(tab.url || "").slice(0, 160), tabId: tab.id }); /*D315*/
    const poke317 = await lucaAutoReplyPokeTab(tab, key, item.threadRef);
    // [NAV317-GATE] (v2.1.117, note 68): a matched
    // tab that would not load fresh settles the row
    // FAILED here — never a poke into the stale
    // ghost page, never a silent timeout.
    if (poke317 && poke317.load !== "complete") { await finishOutboundReply(row.id, false, "navigation_failed"); } /*D317*/
  } catch (e) { alDlvErr("process_pending", e); /* next tick retries */ } finally { /*D315R*/
    lucaAutoBusy = false;
  }
}

// --- Inbox-auto trigger runtime (v2.1.102, header note 55) ----
// Matthew's desk test (2026-11-12) proved the 3.01 hooks are
// not enough: they evaluate only when a capture lands, and a
// BRAND-NEW thread is captured in full only when the rep opens
// it — but the auto-reply exists for the moments the rep does
// NOT open the message ("its not gonna help if the user has to
// go into the message though"). So the worker nominates
// candidate threads from the inbox LIST itself (the snippet a
// row already shows), then opens the thread in its OWN
// background tab — the posting-job tab pattern, active:false,
// never the user's tab, never focused — purely so the existing
// full capture runs. Every send decision is still taken by the
// 3.01 decision path on the captured messages; a snippet never
// decides anything, and nothing can send out of this section.
//
// Hands-free hub (Matthew's standing rule, 2026-11-12): the
// list pass needs an inbox surface open in Chrome. While the
// toggle is on and NO inbox surface exists, the worker keeps
// ONE of its own background tabs on the Marketplace inbox —
// the PC-hub basics (PC awake, Chrome open, signed in) are
// all the rep provides. The tab is tracked in storage
// (luca_auto_reply_hub); the worker only ever touches tabs it
// created itself, and a signed-out session just backs it off.
const LUCA_AUTOREPLY_HUB_URL = "https://www.facebook.com/marketplace/inbox";
const LUCA_AUTOREPLY_HUB_BACKOFF_MS = 6 * 60 * 60 * 1000;

// Freshest trustworthy account-sync evidence (FIX 2 — the
// 3.01 brief's car-level bound was wrong: scraped_inventory
// .last_updated moves only when a car's data CHANGES, and
// zero of Matthew's posted cars had it within 26 h, so the
// 3.01 rule could never send). The signal: the latest
// completed sync_summaries run — lot-scale runs only, so a
// single-car repair pass cannot refresh the whole lot's
// clock — else user_settings.last_synced_at (written by
// helper-side syncs; NULL on scraper-only accounts like
// Matthew's, where sync_summaries carries the truth).
// scraped_inventory has no per-car last-seen column
// (first_seen / last_updated are all it carries), so the
// account sync + is_active at decision time IS the last-seen
// evidence: a car the latest lot sync still lists active was
// seen by that sync, and one it exited is is_active=false.
async function lucaAutoReplyLastSyncAt(userId, settings) {
  let best = Date.parse((settings && settings.last_synced_at) || "") || 0;
  try {
    const sums = (await sbGet(`sync_summaries?user_id=eq.${userId}&run_finished_at=not.is.null&select=run_finished_at,vehicles_checked&order=run_finished_at.desc&limit=5`)) || [];
    for (const s of sums) {
      if (s.vehicles_checked != null && Number(s.vehicles_checked) < 20) continue;
      const t = Date.parse(s.run_finished_at || "") || 0;
      if (t > best) best = t;
      break;
    }
  } catch (e) { /* the settings timestamp still counts */ }
  return best ? new Date(best).toISOString() : null;
}

// Label self-heal (FIX 1): a full capture reads the thread's
// OWN listing title from the thread page. When the stored
// label is dirty (fused inbox-row text) and the captured
// title is clean, the clean title replaces it — called from
// handleCaptureChat's patch step, so the heal lands before
// the capture hook evaluates. A clean stored label is never
// overwritten; an absent one is the existing patch line's job.
function lucaAutoReplyLabelHeal(storedLabel, captureLabel) {
  const incoming = String(captureLabel || "").trim();
  if (!incoming || !lucaAutoReplyLabelTrusted(incoming)) return null;
  const stored = String(storedLabel || "").trim();
  if (!stored || lucaAutoReplyLabelTrusted(stored)) return null;
  if (stored === incoming) return null;
  return incoming;
}

// Which trigger owns an evaluation: while a verification open
// is in flight for a prospect, decisions for it are recorded
// with trigger "inbox_auto" in the decision JSON.
async function lucaAutoReplyTriggerFor(prospectId, threadRef) {
  try {
    const store = await chrome.storage.local.get(["luca_auto_reply_open_for"]);
    const f = store.luca_auto_reply_open_for;
    if (f && (Date.now() - (f.at || 0)) < 10 * 60 * 1000) {
      if (prospectId && f.prospectId === prospectId) return "inbox_auto";
      // v2.1.108 (note 60): a ref-only open carries no
      // prospectId (the prospect is born during the open);
      // the thread ref is the same thread either way.
      const nf = String(f.threadRef || "").trim().toLowerCase();
      const nt = String(threadRef || "").trim().toLowerCase();
      if (nf && nt && nf === nt) return "inbox_auto";
    }
  } catch (e) { /* labeling is best-effort */ }
  return null;
}

async function lucaAutoReplyThreadState(userId, prospectId) {
  const msgs = (await sbGet(`closer_messages?user_id=eq.${userId}&prospect_id=eq.${prospectId}&select=id,status&limit=50`)) || [];
  return {
    real: msgs.filter(m => m.status !== "auto_decision").length,
    decided: msgs.some(m => m.status === "auto_decision")
  };
}

// v2.1.108 (note 60): resolve a prospect by its thread
// ref (normalized compare, the same equality the
// nominator's want-set uses). Used to adopt ref-only
// button-row candidates once a prospect exists for the
// ref — nominated before any prospect existed, or born
// as a stub during the verification open itself.
async function lucaAutoReplyProspectByRef(userId, threadRef) {
  const nt = String(threadRef || "").trim().toLowerCase();
  if (!nt) return null;
  const rows = (await sbGet(`prospects?user_id=eq.${userId}&select=id,name,vehicle_label,thread_ref&limit=200`)) || [];
  return rows.find(r => r.thread_ref && String(r.thread_ref).trim().toLowerCase() === nt) || null;
}

// Fail-safe record: a candidate whose verification open never
// produced a capture is logged unverified and STOPPED — one
// decision row, terminal, and no send can come out of it.
async function lucaAutoReplyWriteUnverified(userId, prospectId) {
  const rows = (await sbGet(`prospects?user_id=eq.${userId}&id=eq.${prospectId}&select=id,name,vehicle_label,thread_ref`)) || [];
  if (!rows[0]) return;
  if (!/\/t\/\d+/.test(String(rows[0].thread_ref || ""))) return; // note 56: no decisions for id-less rows
  const st = await lucaAutoReplyThreadState(userId, prospectId);
  if (st.real > 0 || st.decided) return; // raced — the normal path owns it now
  await lucaAutoReplyWriteDecision(userId, rows[0],
    { action: "skip", branch: null, reason: "unverified_open" }, null, "inbox_auto");
}

// Nomination: the worker's snippet sync hands us the inbox
// list's newest lines. A line nominates its thread only when
// the thread is a known prospect with NO decision yet and
// the pure test likes the text. (v2.1.113, note 64: threads
// WITH captured messages queue too — the capture hook
// evaluates only on a fresh insert, so a captured-but-
// undecided thread was reached by neither path and
// deadlocked; the processor's pop branch decides it from
// the stored rows.) The queue lives in chrome.storage,
// deduped by thread.
async function lucaAutoReplyNoteCandidates(userId, snippets) {
  if (!userId || !Array.isArray(snippets) || !snippets.length) return;
  // v2.1.108 (note 60): inbox button records route through
  // their own candidate test and resolution; anchor
  // snippets keep the exact path they have always had.
  const textual = snippets.filter(sn => sn && sn.rowKind !== "inbox_button" && lucaAutoReplySnippetCandidate(sn, { hasMessages: false }));
  const btnTextual = snippets.filter(sn => sn && sn.rowKind === "inbox_button" && lucaAutoReplyButtonCandidate(sn));
  if (!textual.length && !btnTextual.length) return;
  const settingsRows = await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_availability`);
  if (!settingsRows || !settingsRows[0] || settingsRows[0].luca_autoreply_availability !== true) return;
  const norm = (s) => (s || "").trim().toLowerCase();
  const want = new Set(textual.map(sn => norm(sn.threadRef || "")).filter(Boolean));
  // v2.1.108 (note 60): button records may resolve without
  // any ref at all (the unique-match route below), so an
  // empty want-set no longer ends the pass by itself.
  if (!want.size && !btnTextual.length) return;
  const rows = (await sbGet(`prospects?user_id=eq.${userId}&select=id,name,vehicle_label,thread_ref&order=created_at.desc&limit=200`)) || [];
  // v2.1.108 (note 60): button records WITH a resolved ref
  // join the same want-set; records WITHOUT one nominate
  // only through an exactly-one (name, clean label) match.
  for (const sn of btnTextual) {
    if (sn.threadRef) want.add(norm(sn.threadRef));
  }
  const matchedIds = new Set();
  for (const sn of btnTextual) {
    if (sn.threadRef) continue;
    const hit = lucaAutoReplyUniqueProspectMatch(rows, sn.buyerName, sn.vehicleLabel);
    if (hit) matchedIds.add(hit.id);
  }
  const store = await chrome.storage.local.get(["luca_auto_reply_candidates", "luca_auto_reply_open"]);
  const queue = Array.isArray(store.luca_auto_reply_candidates) ? store.luca_auto_reply_candidates.slice() : [];
  const busy = new Set(queue.map(c => norm((c && c.threadRef) || "")));
  if (store.luca_auto_reply_open && store.luca_auto_reply_open.threadRef) busy.add(norm(store.luca_auto_reply_open.threadRef));
  let changed = false;
  for (const p of rows) {
    if (!p.thread_ref || !/\/t\/\d+/.test(p.thread_ref) || (!want.has(norm(p.thread_ref)) && !matchedIds.has(p.id)) || busy.has(norm(p.thread_ref))) continue;
    const st = await lucaAutoReplyThreadState(userId, p.id);
    if (st.decided) continue; // note 64: captured-but-undecided threads queue too — the pop branch decides them from the stored rows
    queue.push({ threadRef: p.thread_ref, prospectId: p.id, queuedAt: Date.now(), tries: 0, notBefore: 0 });
    busy.add(norm(p.thread_ref));
    changed = true;
  }
  // v2.1.108 (note 60): a button record whose resolved ref
  // belongs to NO prospect row still nominates — keyed by
  // the ref alone. The verification open's capture
  // auto-create gate births the prospect on the thread
  // page, and the processor adopts it by ref. A ref that
  // matches a row was handled by the loop above (queued,
  // or state-gated off) and is never double-queued here.
  const rowRefs = new Set(rows.map(p => norm(p.thread_ref || "")).filter(Boolean));
  for (const sn of btnTextual) {
    const ref = norm(sn.threadRef || "");
    if (!ref || !/\/t\/\d+/.test(sn.threadRef || "")) continue;
    if (rowRefs.has(ref) || busy.has(ref)) continue;
    queue.push({ threadRef: sn.threadRef, prospectId: null, queuedAt: Date.now(), tries: 0, notBefore: 0 });
    busy.add(ref);
    changed = true;
  }
  if (changed) await chrome.storage.local.set({ luca_auto_reply_candidates: queue });
}

// [HUB-SELF-REFRESH-310-BEGIN]
// Hub self-refresh on version change (v2.1.110, note 61):
// Chrome orphans every open tab's content scripts when the
// extension updates, so a hub tab left over from the
// previous build runs a dead script and the inbox harvest
// silently stops — the desk symptom behind three silent
// proofs. The hub is the worker's OWN tab, so its
// freshness is the worker's job: at boot, compare the
// stored version marker with the running version; on any
// difference (or no marker yet), record the running
// version FIRST, then reload the hub tab — the
// /marketplace/inbox tab, whichever owner created it —
// exactly once. No other tab is ever touched, and the
// housekeeping is fail-silent: a storage or tabs error
// must never break boot.
async function alHubSelfRefreshOnVersionChange() {
  try {
    let version = null;
    try { version = chrome.runtime.getManifest().version || null; } catch (e) { /* keep null */ }
    if (!version) return;
    const store = await chrome.storage.local.get(["al_helper_version_seen"]);
    if (store && store.al_helper_version_seen === version) return;
    await chrome.storage.local.set({ al_helper_version_seen: version });
    const isInbox = (u) => /facebook\.com\/marketplace\/inbox/.test(u || "");
    const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
    const hub = (tabs || []).find(t => isInbox(t.url));
    if (hub && hub.id != null) {
      try { await chrome.tabs.reload(hub.id); } catch (e) { /* the next boot retries */ }
    }
  } catch (e) { /* housekeeping is fail-silent */ }
}
// [HUB-SELF-REFRESH-310-END]

// Hub-tab maintenance: keep ONE worker-owned background tab
// on the Marketplace inbox while the toggle is on, so the
// list pass (and therefore this trigger) works with zero rep
// action. Never activates a tab, never touches a tab the
// worker did not create.
async function lucaAutoReplyEnsureHubTab() {
  const store = await chrome.storage.local.get(["luca_auto_reply_hub"]);
  const hub = store.luca_auto_reply_hub || {};
  const now = Date.now();
  if (hub.backoffUntil && hub.backoffUntil > now) return;
  // v2.1.105 (note 58): the hub requirement is a tab on
  // /marketplace/inbox SPECIFICALLY — a bare /messages/
  // tab does NOT satisfy it (its Marketplace threads sit
  // inside the unopened folder row, invisible to the
  // anchor-based harvest). Any owner's inbox tab counts.
  const isInbox = (u) => /facebook\.com\/marketplace\/inbox/.test(u || "");
  const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
  if (tabs.some(t => isInbox(t.url))) {
    if (hub.tabId != null && !tabs.some(t => t.id === hub.tabId)) {
      hub.tabId = null;
      await chrome.storage.local.set({ luca_auto_reply_hub: hub });
    }
    return;
  }
  if (hub.tabId != null) {
    const ours = tabs.find(t => t.id === hub.tabId);
    if (ours) {
      if ((ours.url || "").indexOf("/login") !== -1) {
        // Signed out: a tab cannot fix that. Close ours,
        // back off for hours, stay silent.
        try { await chrome.tabs.remove(ours.id); } catch (e) { /* already gone */ }
        hub.tabId = null;
        hub.backoffUntil = now + LUCA_AUTOREPLY_HUB_BACKOFF_MS;
        await chrome.storage.local.set({ luca_auto_reply_hub: hub });
        return;
      }
      if ((ours.url || "").indexOf("facebook.com") !== -1) {
        // Our tab wandered within Facebook — steer it home.
        try { await chrome.tabs.update(ours.id, { url: LUCA_AUTOREPLY_HUB_URL }); } catch (e) { /* next tick */ }
        return;
      }
      hub.tabId = null; // the user took our tab off Facebook — it is theirs now
    } else {
      hub.tabId = null; // our tab is gone — recreate below
    }
  }
  const tab = await chrome.tabs.create({ active: false, url: LUCA_AUTOREPLY_HUB_URL });
  if (tab && tab.id != null) {
    try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* non-fatal */ }
    hub.tabId = tab.id;
    await chrome.storage.local.set({ luca_auto_reply_hub: hub });
  }
}

let lucaAutoCandBusy = false;
async function lucaAutoReplyProcessCandidates() {
  if (lucaAutoCandBusy) return;
  lucaAutoCandBusy = true;
  try {
    const base = await chrome.storage.local.get(["autolaunch_user_id", "luca_autoreply_dry_run"]);
    const userId = base.autolaunch_user_id;
    if (!userId) return;
    const dryRun = base.luca_autoreply_dry_run === true;
    const settingsRows = await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_availability`);
    if (!settingsRows || !settingsRows[0] || settingsRows[0].luca_autoreply_availability !== true) {
      // Toggle off: the trigger is dormant and its queue drains.
      const st = await chrome.storage.local.get(["luca_auto_reply_candidates"]);
      if (Array.isArray(st.luca_auto_reply_candidates) && st.luca_auto_reply_candidates.length) {
        await chrome.storage.local.set({ luca_auto_reply_candidates: [] });
      }
      return;
    }
    if (!dryRun) { try { await lucaAutoReplyEnsureHubTab(); } catch (e) { /* the hub is best-effort */ } }
    const store = await chrome.storage.local.get([
      "luca_auto_reply_candidates", "luca_auto_reply_open", "luca_auto_reply_cand_pace"]);
    const queue = Array.isArray(store.luca_auto_reply_candidates) ? store.luca_auto_reply_candidates.slice() : [];
    const pace = store.luca_auto_reply_cand_pace || { lastOpenAt: 0, hourKey: "", hourCount: 0 };
    const now = Date.now();

    // -- settle an in-flight verification open ---------------
    const open = store.luca_auto_reply_open || null;
    if (open) {
      // v2.1.108 (note 60): a ref-only open carries no
      // prospectId; adopt the prospect for its ref as soon
      // as one exists (the capture usually births it during
      // the open itself).
      let openPid = open.prospectId || null;
      if (!openPid) {
        const byRef = await lucaAutoReplyProspectByRef(userId, open.threadRef);
        if (byRef) openPid = byRef.id;
      }
      const st = openPid
        ? await lucaAutoReplyThreadState(userId, openPid)
        : { real: 0, decided: false };
      if (st.real > 0) {
        // The capture landed. The capture hook evaluates on
        // insert; the nudge below covers a raced decision
        // write, after a short grace so a hook evaluation
        // already in flight finishes first (one decision per
        // thread is the invariant).
        if (!st.decided && !dryRun && (now - (open.openedAt || 0)) < 20000) return;
        if (!st.decided) {
          const rows = (await sbGet(`prospects?user_id=eq.${userId}&id=eq.${openPid}&select=id,name,vehicle_label,thread_ref`)) || [];
          if (rows[0]) { try { await lucaAutoReplyEvaluate(userId, rows[0]); } catch (e) { /* fail-open */ } }
          if (rows[0]) { try { await lucaAutoReply2Evaluate(userId, rows[0]); } catch (e) { /* fail-open */ } } /*LUCA2*/
        }
        if (!dryRun && open.tabId != null) { try { await chrome.tabs.remove(open.tabId); } catch (e) { /* already gone */ } }
        await chrome.storage.local.set({ luca_auto_reply_open: null, luca_auto_reply_open_for: null });
        return;
      }
      let failed = dryRun; // dry-run has no tab to wait on
      if (!dryRun) {
        const alive = open.tabId != null &&
          await chrome.tabs.get(open.tabId).then(() => true).catch(() => false);
        if (!alive) failed = true;
        else if (now - (open.openedAt || 0) >= LUCA_AUTOREPLY_OPEN_TIMEOUT_MS) failed = true;
      }
      if (!failed) return; // still waiting on the capture
      if (!dryRun && open.tabId != null) { try { await chrome.tabs.remove(open.tabId); } catch (e) { /* already gone */ } }
      await chrome.storage.local.set({ luca_auto_reply_open: null, luca_auto_reply_open_for: null });
      if (!dryRun && (open.tries || 1) < LUCA_AUTOREPLY_OPEN_MAX_ATTEMPTS) {
        // ONE bounded retry, after a stated delay — never a loop.
        queue.push({ threadRef: open.threadRef, prospectId: openPid, queuedAt: now, tries: open.tries || 1, notBefore: now + LUCA_AUTOREPLY_OPEN_RETRY_MS });
        await chrome.storage.local.set({ luca_auto_reply_candidates: queue });
      } else {
        // v2.1.108 (note 60): an unverified record needs a
        // prospect row; a still-prospectless ref just ends.
        if (openPid) { try { await lucaAutoReplyWriteUnverified(userId, openPid); } catch (e) { /* logging is best-effort */ } }
      }
      return;
    }

    // -- open the next due candidate -------------------------
    const hourKey = new Date().toISOString().slice(0, 13);
    if (pace.hourKey !== hourKey) { pace.hourKey = hourKey; pace.hourCount = 0; }
    if (pace.hourCount >= LUCA_AUTOREPLY_OPEN_PER_HOUR) {
      await chrome.storage.local.set({ luca_auto_reply_cand_pace: pace });
      return;
    }
    if (now - (pace.lastOpenAt || 0) < LUCA_AUTOREPLY_OPEN_GAP_MS) return;
    const idx = queue.findIndex(c => c && (c.notBefore || 0) <= now);
    if (idx < 0) return;
    const cand = queue[idx];
    // v2.1.108 (note 60): a ref-only button-row candidate
    // adopts its prospect if one exists by now (matched
    // since nomination, or stub-born on an earlier pass).
    if (!cand.prospectId && cand.threadRef) {
      const byRef = await lucaAutoReplyProspectByRef(userId, cand.threadRef);
      if (byRef) cand.prospectId = byRef.id;
    }
    if (!cand.prospectId && !/\/t\/\d+/.test(cand.threadRef || "")) {
      // Neither a prospect nor a resolvable ref: the
      // nomination cannot land anywhere concrete. Drop it.
      queue.splice(idx, 1);
      await chrome.storage.local.set({ luca_auto_reply_candidates: queue });
      return;
    }
    if (cand.prospectId) {
      const chk = await lucaAutoReplyThreadState(userId, cand.prospectId);
      if (chk.real > 0 || chk.decided) {
        queue.splice(idx, 1);
        await chrome.storage.local.set({ luca_auto_reply_candidates: queue });
        if (chk.real > 0 && !chk.decided) {
          // The trigger still owns this evaluation — the
          // nomination is what surfaced the thread — so the
          // decision is labeled inbox_auto like an opened one.
          await chrome.storage.local.set({ luca_auto_reply_open_for: { prospectId: cand.prospectId, threadRef: cand.threadRef, at: now } });
          const rows = (await sbGet(`prospects?user_id=eq.${userId}&id=eq.${cand.prospectId}&select=id,name,vehicle_label,thread_ref`)) || [];
          if (rows[0]) { try { await lucaAutoReplyEvaluate(userId, rows[0]); } catch (e) { /* fail-open */ } }
          if (rows[0]) { try { await lucaAutoReply2Evaluate(userId, rows[0]); } catch (e) { /* fail-open */ } } /*LUCA2*/
        }
        return;
      }
      const prows = (await sbGet(`prospects?user_id=eq.${userId}&id=eq.${cand.prospectId}&select=id,thread_ref`)) || [];
      if (!prows[0] || !/\/t\/\d+/.test(prows[0].thread_ref || "")) {
        queue.splice(idx, 1);
        await chrome.storage.local.set({ luca_auto_reply_candidates: queue });
        return;
      }
    }
    queue.splice(idx, 1);
    pace.lastOpenAt = now;
    pace.hourCount += 1;
    await chrome.storage.local.set({
      luca_auto_reply_candidates: queue,
      luca_auto_reply_cand_pace: pace,
      luca_auto_reply_open_for: { prospectId: cand.prospectId, threadRef: cand.threadRef, at: now }
    });
    let tabId = null;
    if (!dryRun) {
      try {
        const tab = await chrome.tabs.create({ active: false, url: cand.threadRef });
        tabId = tab && tab.id != null ? tab.id : null;
        if (tabId != null) { try { await chrome.tabs.update(tabId, { autoDiscardable: false }); } catch (e) { /* non-fatal */ } }
      } catch (e) { tabId = null; }
    }
    // A null tabId outside dry-run means the open itself
    // failed outright; the settle pass treats the missing tab
    // as a failed attempt (bounded retry, then unverified).
    await chrome.storage.local.set({
      luca_auto_reply_open: { tabId, prospectId: cand.prospectId, threadRef: cand.threadRef, openedAt: now, tries: (cand.tries || 0) + 1 }
    });
  } catch (e) { /* next tick retries */ } finally {
    lucaAutoCandBusy = false;
  }
}

// --- Outbound replies (Prospects inbox step 2, v2.1.32) -------------------
// The app queues a reply as a closer_messages row (status "queued").
// This engine claims one at a time, hands it to a Facebook tab via a
// storage pending-slot (the tab's chat_capture script does the typing
// and verification), and records the result. No Facebook tab open ->
// the reply simply stays queued (the hub rule). A delivery in flight
// for over 3 minutes is marked failed rather than retried blindly —
// a half-sent state must never resend itself.
let outboundBusy = false;
async function checkOutboundReplies() {
  if (outboundBusy) return;
  outboundBusy = true;
  try {
    const { autolaunch_user_id: userId } = await chrome.storage.local.get(["autolaunch_user_id"]);
    if (!userId) return;
    const { luca_pending_delivery: pending } = await chrome.storage.local.get(["luca_pending_delivery"]);
    if (pending) {
      if (Date.now() - (pending.at || 0) > 3 * 60 * 1000) {
        try { await sbPatch(`closer_messages?id=eq.${pending.messageId}&status=eq.sending`, { status: "failed", delivery_error: "timeout_no_result" }); } catch (e) { /* best effort */ }
        if (typeof alTrace === "function") alTrace("dlv_outcome", pending.threadRef || null, { written: "failed", basis: "timeout_no_result", messageId: pending.messageId }); /*D315*/
        await chrome.storage.local.remove(["luca_pending_delivery"]);
      }
      return; // one delivery at a time
    }
    const rows = await sbGet(`closer_messages?user_id=eq.${userId}&status=eq.queued&select=id,prospect_id,thread_ref,body&order=created_at.asc&limit=1`);
    const row = rows && rows[0];
    if (!row || !row.thread_ref) return;
    const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
    if (!tabs.length) return; // no hub tab — stays queued
    const key = (String(row.thread_ref).match(/\/t\/(\d+)/) || [])[1] || "";
    const tab = tabs.find(t => key && (t.url || "").includes("/t/" + key))
      || tabs.find(t => (t.url || "").includes("/messages"))
      || tabs.find(t => (t.url || "").includes("/marketplace"))
      || tabs[0];
    if (!tab || tab.id == null) return;
    const claimed = await sbPatch(`closer_messages?id=eq.${row.id}&status=eq.queued`, { status: "sending" });
    if (!claimed || !claimed.length) return; // someone else took it
    await chrome.storage.local.set({
      luca_pending_delivery: { messageId: row.id, threadRef: row.thread_ref, body: row.body, tabId: tab.id, at: Date.now() }
    });
    if (key && (tab.url || "").includes("/t/" + key)) {
      // Poke — but demand an ACK (v2.1.35). A tab whose capture script
      // died (the classic case: the helper was updated while the tab
      // sat open) never answers; reloading that tab re-injects the
      // current script, which picks the pending delivery up from
      // storage on load. Without this, a dead tab silently eats the
      // reply until the 3-minute timeout fails it (seen live
      // 2026-10-25 on the first reply attempt).
      const acked = await new Promise(resolve => {
        let done = false;
        const timer = setTimeout(() => { if (!done) { done = true; resolve(false); } }, 6000);
        try {
          chrome.tabs.sendMessage(tab.id, { type: "AUTOLAUNCH_DELIVER_NOW" }, resp => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            resolve(!chrome.runtime.lastError && !!(resp && resp.accepted));
          });
        } catch (e) {
          if (!done) { done = true; clearTimeout(timer); resolve(false); }
        }
      });
      if (!acked) {
        try { await chrome.tabs.reload(tab.id); } catch (e) { /* the timeout sweep fails it honestly */ }
      }
    } else {
      await chrome.tabs.update(tab.id, { url: row.thread_ref });
    }
  } catch (e) { /* next tick retries */ } finally {
    outboundBusy = false;
  }
}

async function finishOutboundReply(messageId, ok, error) {
  const { luca_pending_delivery: pending } = await chrome.storage.local.get(["luca_pending_delivery"]);
  if (!pending || pending.messageId !== messageId) return;
  try {
    await sbPatch(`closer_messages?id=eq.${messageId}`, {
      status: ok ? "sent" : "failed",
      delivery_error: ok ? null : String(error || "unknown").slice(0, 200)
    });
  } catch (e) { alDlvErr("finish_patch", e); /* best effort */ } /*D315R*/
  if (typeof alTrace === "function") alTrace("dlv_outcome", pending.threadRef || null, { written: ok ? "sent" : "failed", basis: ok ? "reply_result_ok" : String(error || "unknown").slice(0, 120), messageId: messageId }); /*D315*/
  await chrome.storage.local.remove(["luca_pending_delivery"]);
  checkOutboundReplies(); // chain the next queued reply, if any
}

function startOfTodayISO() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

async function todaysPostCount(userId) {
  const rows = await sbGet(
    `scraped_inventory?user_id=eq.${userId}` +
    `&marketplace_posted_at=gte.${encodeURIComponent(startOfTodayISO())}` +
    `&select=vin`
  );
  return rows.length;
}

// One settings fetch per claim cycle (v2.1.4): the daily post
// limit AND the Full Auto switch both live on user_settings.
// v2.1.42: the same fetch also carries the post pacing delay
// (post_delay_minutes) and the dealership identity (name/address)
// for the description's closing block — see header note 19.
// v2.1.43: it also carries include_stock for the description's
// Stock # line — see header note 20.
// v2.1.53: it also carries the intro-video preference trio
// (enabled / mode / selected id) — see header note 27.
// v2.1.55: it also carries share_to_feed for the post-success
// feed share — see header note 29. Opt-in: anything but an
// explicit true reads as off.
// v2.1.60: it also carries the one-active-helper lease
// (helper_lease_id / helper_lease_expires_at) — see header
// note 32. The claim cycle's gate reads them from THIS fetch;
// no extra round trip.
// v2.1.90: it also carries rep_display_name / rep_phone —
// the description contact line's pair (header note 45).
async function userSettings(userId) {
  const rows = await sbGet(
    `user_settings?user_id=eq.${userId}&select=daily_post_limit,full_auto_enabled,post_delay_minutes,dealership_name,dealership_address,rep_display_name,rep_phone,include_stock,rich_descriptions,intro_video_enabled,intro_video_mode,intro_selected_video_id,share_to_feed,vin_reel_before_post,helper_lease_id,helper_lease_expires_at`);
  const row = (rows && rows.length) ? rows[0] : {};
  return {
    limit: typeof row.daily_post_limit === "number" ? row.daily_post_limit : 10,
    fullAuto: row.full_auto_enabled === true,
    delayMinutes: (typeof row.post_delay_minutes === "number" && row.post_delay_minutes > 0)
      ? row.post_delay_minutes : 0,
    dealershipName: typeof row.dealership_name === "string" ? row.dealership_name.trim() : "",
    dealershipAddress: typeof row.dealership_address === "string" ? row.dealership_address.trim() : "",
    repName: typeof row.rep_display_name === "string" ? row.rep_display_name.trim() : "",
    repPhone: typeof row.rep_phone === "string" ? row.rep_phone.trim() : "",
    includeStock: row.include_stock === true,
    richDesc: row.rich_descriptions === true,
    vinReelBeforePost: row.vin_reel_before_post === true,
    introEnabled: row.intro_video_enabled === true,
    introMode: typeof row.intro_video_mode === "string" ? row.intro_video_mode : "selected",
    introSelectedId: typeof row.intro_selected_video_id === "string" ? row.intro_selected_video_id : null,
    shareToFeed: row.share_to_feed === true,
    leaseId: (typeof row.helper_lease_id === "string" && row.helper_lease_id)
      ? row.helper_lease_id : null,
    leaseExpiresAt: typeof row.helper_lease_expires_at === "string"
      ? row.helper_lease_expires_at : null
  };
}

// [PURE-INTRO-RESOLVE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Intro-video claim-time resolution (v2.1.53, header note 27):
// decide, from the settings trio and the user's video rows,
// which single video (if any) rides this post. Every non-answer
// is a NAMED skip — the caller logs it and posts exactly as
// before this feature existed. rng is injectable so the harness
// can pin 'random' mode; production passes Math.random. Any
// mode other than 'random' follows the app's default semantics
// ('selected'), exactly as the app's own reader normalizes it.
function resolveIntroVideo(settings, rows, rng) {
  if (!settings || settings.introEnabled !== true) {
    return { skip: "intro_disabled" };
  }
  const list = (Array.isArray(rows) ? rows : []).filter(r =>
    r && typeof r.video_url === "string" && r.video_url.trim());
  if (!list.length) return { skip: "intro_library_empty" };
  if (settings.introMode === "random") {
    const roll = (typeof rng === "function" ? rng : Math.random)();
    const idx = Math.min(list.length - 1, Math.max(0, Math.floor(roll * list.length)));
    const pick = list[idx];
    return { url: pick.video_url, videoId: pick.id || null, mode: "random" };
  }
  const wanted = settings.introSelectedId;
  if (!wanted) return { skip: "intro_no_selection" };
  const hit = list.find(r => r.id === wanted);
  if (!hit) return { skip: "intro_selected_missing" };
  return { url: hit.video_url, videoId: hit.id || null, mode: "selected" };
}
// [PURE-INTRO-RESOLVE-END]

// Claim-time wrapper (v2.1.53): fetch the user's intro-video
// rows ONLY when the preference is on (everyone else's claim
// path is untouched), resolve, and log the outcome. Any failure
// resolves to a named skip — never a throw into the claim loop.
async function introVideoForJob(userId, settings) {
  if (!settings || settings.introEnabled !== true) return null;
  try {
    const rows = await sbGet(
      `user_intro_videos?user_id=eq.${userId}&select=id,video_url&order=created_at.asc`);
    const resolved = resolveIntroVideo(settings, rows, Math.random);
    if (resolved.skip) {
      console.log(`[AutoLaunch] Intro video skipped at claim (${resolved.skip}).`);
      return null;
    }
    console.log(`[AutoLaunch] Intro video resolved at claim (mode ${resolved.mode}, video ${resolved.videoId}).`);
    return { url: resolved.url, videoId: resolved.videoId };
  } catch (e) {
    console.log("[AutoLaunch] Intro video skipped at claim (intro_resolve_failed).");
    return null;
  }
}

// [PURE-REEL-DECIDE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// VIN Reel claim-time decisions (v2.1.85, header note 40).
// v2.1.86 (header note 41): consumption gated on the
// form-verified attach; decideReelCompletionFlag added.
// [CONSUME-355-BEGIN] — a worker-rendered reel
// is a worker-rendered reel, whatever its row
// is labeled (v2.1.155, header note 96). The
// vin_reels source column is written "poster"
// only by the scraper's auto-post producer; a
// render requested any other way (the app's
// Create-reel insert writes no source, so the
// column default "manual" lands) renders
// through the same worker to the same
// deterministic object — vin-reels/<userId>/
// <VIN>.mp4 — yet the finish read the label
// and refused to consume it as a manual reel,
// so on 2026-11-18 six proven posts left
// their reels "ready" with both storage
// objects undeleted. The manual protection
// exists for a user's OWN artifact; a file
// the worker itself rendered into the
// vin-reels bucket is never that. This pure
// classifier reads the file's address, not
// its label: the public vin-reels object path
// of a VIN-named mp4. decideReelAttach stamps
// it on the resolution, the claim carries it
// onto the job, and the finish's consume
// decider honors it; every other reader of
// source (the gate, the chain) is untouched.
function reelWorkerFile355(url) {
  if (typeof url !== "string") return false;
  return /\/vin-reels\/[^/]+\/[^/]+\.mp4(?:[?#].*)?$/i
    .test(url.trim());
}
// [CONSUME-355-END]
// decideReelAttach: given the car's LATEST reel row (the
// claim-gate lookup: user + vin, newest first), decide whether
// a reel rides this post. Only a ready reel with a URL
// attaches; every other state is a plain no, and the post
// runs exactly as before VIN Reels existed.
function decideReelAttach(reelRow) {
  if (!reelRow || reelRow.status !== "ready") return { attach: false };
  if (typeof reelRow.video_url !== "string" || !reelRow.video_url.trim()) {
    return { attach: false };
  }
  // Card-as-last-photo (v2.1.90, header note 45): the
  // end-card still the generator uploaded beside the mp4
  // rides qa.card_url; it joins the resolution so the
  // content side can append it as the listing's last
  // photo. Absent (a reel rendered before cards existed,
  // or the fail-open card upload skipped) -> null, and
  // the post's photo set is exactly the dealer set.
  const qa = (reelRow.qa && typeof reelRow.qa === "object") ? reelRow.qa : null;
  const cardUrl = (qa && typeof qa.card_url === "string" && qa.card_url.trim())
    ? qa.card_url.trim() : null;
  return {
    attach: true,
    url: reelRow.video_url,
    reelId: reelRow.id || null,
    source: reelRow.source === "poster" ? "poster" : "manual",
    workerFile: reelWorkerFile355(reelRow.video_url),
    cardUrl
  };
}
// decideReelConsume: given the reel record a job carried
// ({ id, source, attached, attachVerified } — claim time
// stamped the first three, the finish folds in the content
// side's verified read-back), decide whether a SUCCESSFUL
// post consumes the reel. Only a poster reel whose attach
// the form itself confirmed is consumed (v2.1.86, header
// note 41) — a manual reel is the user's own artifact and
// is never deleted, and a post that attached nothing — or
// cannot prove it attached — consumes nothing.
function decideReelConsume(reel) {
  if (!reel || reel.attached !== true) {
    return { consume: false, reason: "not_attached" };
  }
  // [CONSUME-355] a worker-rendered file consumes
  // on the poster proof whatever its row was
  // labeled (see reelWorkerFile355); only a file
  // that is neither poster-labeled nor the
  // worker's own keeps the manual protection.
  if (reel.source !== "poster" && reel.workerFile !== true) {
    return { consume: false, reason: "manual_reel" };
  }
  if (reel.attachVerified !== true) {
    return { consume: false, reason: "attach_unverified" };
  }
  if (!reel.id) return { consume: false, reason: "no_reel_id" };
  return { consume: true, reelId: reel.id };
}
// reelAttachDiagFields (v2.1.87, header note 42): the
// note/detail pair filed for an unverified attach. The
// note leads with the 2.86 shape (compactDiagError leaves
// notes untruncated) and appends the self-diagnosing tail:
// the binding stage, every attempt's verdict (R = the
// pre-Publish repair; /ever = the form showed the clip at
// some point in the attempt; /sig = the processed
// signature fired without the counter), and the compact
// counter trace. The detail keeps the 2.86 download facts
// and adds the processing budget the size-scaled wait
// used, in seconds.
function reelAttachDiagFields(a) {
  const att = a || {};
  const verdicts = (Array.isArray(att.attemptLog) ? att.attemptLog : [])
    .map(t => `${t && t.stage === "repair" ? "R" : ""}${(t && t.n) || "?"}:` +
      `${(t && t.verdict) || "?"}${t && t.everAttached ? "/ever" : ""}` +
      `${t && t.signature ? "/sig" : ""}`)
    .join(",");
  let note = `attach_unverified attempts:${att.attempts || 0}` +
    ` skip:${att.skip || "none"}`;
  if (att.finalStage) note += ` final:${att.finalStage}`;
  if (verdicts) note += ` verdicts:${verdicts}`;
  if (att.trace) note += ` trace:${att.trace}`;
  let detail = `downloaded:${att.downloaded === true}` +
    ` blob_bytes:${att.blobSize || 0}`;
  if (att.budgetMs) detail += ` budget_s:${Math.round(att.budgetMs / 1000)}`;
  return { note, detail };
}
// decideReelCompletionFlag (v2.1.86): the reel_failed value a
// posted completion writes. null = the job carried no reel —
// write nothing, the completion stays byte-identical to the
// pre-reel shape. A carried reel writes the truth: false when
// its attach verified on the form, true when it did not.
function decideReelCompletionFlag(reel) {
  if (!reel || reel.attached !== true) return null;
  return reel.attachVerified === true ? false : true;
}
// [PURE-REEL-DECIDE-END]
// [PURE-USERVIDEO-DECIDE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// User vehicle video claim-time decisions (v2.1.166, header
// note 98). decideUserVideoAttach: given the car's
// user_vehicle_videos row (the claim lookup: user + vin),
// decide what the user's own recorded video means for this
// post. Only a 'ready' row (the normalized file exists in the
// user-videos bucket) attaches — it rides INSTEAD of the
// rendered reel and the intro video. 'uploaded' /
// 'normalizing' means the user's chosen video is still being
// processed: the post HOLDS (the normalization worker
// releases the hold when the video lands ready or fails).
// Anything else (no row, 'failed', 'consumed') is a plain
// no — the post runs exactly as before this feature existed.
function decideUserVideoAttach(row) {
  if (!row || typeof row !== "object") return { attach: false };
  if (row.status === "uploaded" || row.status === "normalizing") {
    return { attach: false, pending: true, status: row.status };
  }
  if (row.status !== "ready") return { attach: false };
  if (typeof row.storage_path !== "string" || !row.storage_path.trim()) {
    return { attach: false };
  }
  return {
    attach: true,
    id: row.id || null,
    storagePath: row.storage_path.trim(),
    rawPath: (typeof row.raw_path === "string" && row.raw_path.trim())
      ? row.raw_path.trim() : null
  };
}
// decideUserVideoConsume: given the user-video record a job
// carried ({ id, storagePath, rawPath, attached,
// attachVerified } — claim time stamped the first four, the
// finish folds in the content side's verified read-back),
// decide whether a SUCCESSFUL post consumes the user's video
// (Matthew, 2026-11-20: the server copy is deleted after the
// post). Exactly the poster-reel rule: only a verified
// attach consumes — an unverified attach or a failed post
// keeps the server copy, because it is the user's only copy
// and a retry can still use it.
function decideUserVideoConsume(uv) {
  if (!uv || uv.attached !== true) {
    return { consume: false, reason: "not_attached" };
  }
  if (uv.attachVerified !== true) {
    return { consume: false, reason: "attach_unverified" };
  }
  if (!uv.id) return { consume: false, reason: "no_row_id" };
  if (!uv.storagePath) return { consume: false, reason: "no_storage_path" };
  return { consume: true, id: uv.id };
}
// [PURE-USERVIDEO-DECIDE-END]

// Claim-time wrapper (v2.1.85): fetch the car's latest reel
// ONLY for posts (the caller gates that), resolve, and log.
// Any failure resolves to null — never a throw into the claim
// loop, and never a held post: the producer's hold is what
// waits for reels, not the claim.
async function reelForJob(userId, vin) {
  try {
    const rows = await sbGet(
      `vin_reels?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}` +
      `&order=created_at.desc&limit=1&select=id,status,source,video_url,qa`);
    const d = decideReelAttach(rows && rows.length ? rows[0] : null);
    if (!d.attach) return null;
    console.log(`[AutoLaunch] VIN reel resolved at claim (${d.source} reel ${d.reelId}).`);
    return {
      url: d.url,
      reel: { id: d.reelId, source: d.source, attached: true, workerFile: d.workerFile === true, cardUrl: d.cardUrl || null }
    };
  } catch (e) {
    console.log("[AutoLaunch] VIN reel skipped at claim (reel_resolve_failed).");
    return null;
  }
}

// [REEL318-CODE-BEGIN]
// [PURE-REEL-GATE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Ready-only reel gate decisions (v2.1.118, header note 69).
// reelJobFlagged: the two flag signals in hand at claim —
// the account's vin_reel_before_post setting, and the queue
// row's own reel_requested_at marker (the producer stamped
// it when the row was inserted held). Either one marks the
// job as reel-flagged.
function reelJobFlagged(settings, item) {
  if (settings && settings.vinReelBeforePost === true) return true;
  if (item && item.reel_requested_at != null &&
      item.reel_requested_at !== "") return true;
  return false;
}
// decideReelGateClaim: may a flagged post proceed without
// its reel? Inputs are the flag signals, the car's LATEST
// reel status, and the render-restart count the row's
// error_message marker carries. ready proceeds (the reel
// rides and the content gate enforces inclusion); waived
// proceeds (the app's manual post-without-video override
// wrote that status — §3 of the 3.18 design). Everything
// else on a flagged job HOLDS — 3.19 (note 70) supersedes
// the 3.18 carve-out the Nov 14 desk proof broke: an
// account flag alone with NO reel row no longer proceeds,
// because a manual queue row never passes through the
// producer's hold — the claim now starts the render
// itself (ensureRender) and holds. A consumed reel is in
// the same case: the old clip is spent, a fresh render is
// the only way this car posts with its video. A failed
// render holds with ONE automatic restart while the
// row's restart budget lasts (restart, restarts = the
// new count), then holds for a human (attention) — never
// bare, never a render loop. An unreadable or unknown
// state holds with no insert: not-proven-ready means
// not posted, and a blind insert could duplicate a live
// job the read merely failed to see.
function decideReelGateClaim(input) {
  const o = input || {};
  const flagged = o.rowMarked === true || o.acctFlag === true;
  if (!flagged) return { flagged: false, hold: false };
  if (o.reelStatus === "ready") return { flagged: true, hold: false };
  if (o.reelStatus === "waived") {
    return { flagged: true, hold: false, waived: true };
  }
  const st = (typeof o.reelStatus === "string" && o.reelStatus)
    ? o.reelStatus : "missing";
  if (st === "missing" || st === "consumed") {
    return { flagged: true, hold: true, ensureRender: true,
      reason: "reel_not_ready:" + st };
  }
  if (st === "failed") {
    const prior = (typeof o.renderRestarts === "number" &&
      isFinite(o.renderRestarts) && o.renderRestarts > 0)
      ? Math.floor(o.renderRestarts) : 0;
    if (prior < REEL_RENDER_MAX_RESTARTS) {
      return { flagged: true, hold: true, ensureRender: true,
        restart: true, restarts: prior + 1,
        reason: "reel_not_ready:failed" };
    }
    return { flagged: true, hold: true, attention: true,
      restarts: prior, reason: "reel_render_failed_restarts_spent" };
  }
  return { flagged: true, hold: true,
    reason: "reel_not_ready:" + st };
}
// reelAbortCountFromError: the abort count a previous
// gate settle wrote into the row's error_message marker
// (reel_gate_aborts:N) — the row carries its own retry
// memory, the note-57 pattern. Absent/garbled reads 0.
function reelAbortCountFromError(errorMessage) {
  if (typeof errorMessage !== "string") return 0;
  const mm = errorMessage.match(/reel_gate_aborts:(\d+)/);
  return mm ? (parseInt(mm[1], 10) || 0) : 0;
}
// reelRenderRestartCountFromError: the automatic render
// restart count a previous claim hold wrote into the
// row's error_message marker (reel_render_restarts:N) —
// the same row-carried memory as the abort count.
// Absent/garbled reads 0.
function reelRenderRestartCountFromError(errorMessage) {
  if (typeof errorMessage !== "string") return 0;
  const mm = errorMessage.match(/reel_render_restarts:(\d+)/);
  return mm ? (parseInt(mm[1], 10) || 0) : 0;
}
// REEL_RENDER_MAX_RESTARTS (v2.1.119, header note 70): a
// failed render earns exactly ONE automatic re-render on
// a flagged account; after that the row holds loud for a
// human. The helper never loops renders and never posts
// the car bare.
const REEL_RENDER_MAX_RESTARTS = 1;
// reelGateProceedCleanup (v2.1.119, header note 70): the
// error_message a PROCEEDING claim leaves behind for a
// row an earlier cycle gate-held. undefined = the text
// carries no gate record; leave it untouched. Otherwise
// the loud hold prose is dropped (the car is posting,
// not held) and only the budget counters ride on, in
// compact form, where they were nonzero — the settle
// paths re-read them from this field. "" = no counters
// were live; the caller writes null.
function reelGateProceedCleanup(errorMessage) {
  if (typeof errorMessage !== "string") return undefined;
  if (!/reel_(gate_hold|claim_hold|needs_attention|gate_abort)/
      .test(errorMessage)) return undefined;
  const parts = [];
  const a = reelAbortCountFromError(errorMessage);
  if (a > 0) parts.push("reel_gate_aborts:" + a);
  const r = reelRenderRestartCountFromError(errorMessage);
  if (r > 0) parts.push("reel_render_restarts:" + r);
  return parts.join(" ");
}
// decideReelGateAbort: the bounded retry. Aborts 1 and 2
// return the row to held; the REEL_GATE_MAX_ABORTS-th
// abort settles it needs-attention — no silent loop.
const REEL_GATE_MAX_ABORTS = 3;
function decideReelGateAbort(priorAborts) {
  const n = (typeof priorAborts === "number" && isFinite(priorAborts) &&
    priorAborts > 0) ? Math.floor(priorAborts) : 0;
  const aborts = n + 1;
  return { aborts,
    action: aborts >= REEL_GATE_MAX_ABORTS ? "needs_attention" : "rehold" };
}
// reelGateErrorText: the loud record each gate outcome
// leaves in the row's error_message — what happened, the
// count where one applies, and the remedy.
function reelGateErrorText(kind, info) {
  const o = info || {};
  if (kind === "hold") {
    return "reel_gate_hold: reel not ready (status:" +
      (o.status || "missing") + ") \u2014 flagged post NOT attempted; " +
      "held until the reel is ready (ready-only rule, helper 2.1.129)";
  }
  if (kind === "abort") {
    // Chained stages (v2.1.122, header note 73): the post
    // DID go live — the listing was posted, the video
    // could not be put on it / confirmed on it, and the
    // listing was deleted. The text says exactly that;
    // the classic create-flow stages below keep the
    // pre-submit wording, which is true for them.
    if (o.stage === "listing_verify_failed") {
      return "reel_gate_abort:listing_verify_failed" +
        " reel_gate_aborts:" + (o.aborts || 1) + "/" +
        REEL_GATE_MAX_ABORTS +
        " \u2014 the post DID go live, but its video could " +
        "not be confirmed on the live listing after the " +
        "full patient wait (fresh reads at +2 and +5 " +
        "minutes), so the listing was deleted and the " +
        "posted stamp cleared; row returned to held " +
        "(ready-only rule, helper 2.1.129)";
    }
    if (o.stage === "editor_attach_failed") {
      return "reel_gate_abort:editor_attach_failed" +
        " reel_gate_aborts:" + (o.aborts || 1) + "/" +
        REEL_GATE_MAX_ABORTS +
        " \u2014 the post DID go live, but the video could " +
        "not be attached in the editor, so the listing " +
        "was deleted and the posted stamp cleared; row " +
        "returned to held " +
        "(ready-only rule, helper 2.1.129)";
    }
    return "reel_gate_abort:" + (o.stage || "no_register") +
      " reel_gate_aborts:" + (o.aborts || 1) + "/" + REEL_GATE_MAX_ABORTS +
      " \u2014 post aborted before submit; row returned to held " +
      "(ready-only rule, helper 2.1.129)";
  }
  if (kind === "needs_attention") {
    if (o.stage === "listing_verify_failed" ||
        o.stage === "editor_attach_failed") {
      return "reel_needs_attention: flagged post aborted " +
        (o.aborts || REEL_GATE_MAX_ABORTS) + " times (last: " +
        o.stage + ") \u2014 the post DID go live, but its " +
        "video could not be confirmed on the live " +
        "listing, so the listing was deleted; needs a " +
        "human: check the reel, or post without video " +
        "from the app " +
        "(ready-only rule, helper 2.1.129)";
    }
    return "reel_needs_attention: flagged post aborted " +
      (o.aborts || REEL_GATE_MAX_ABORTS) + " times (last: " +
      (o.stage || "no_register") + ") \u2014 NOT posted; needs a human: " +
      "check the reel, or post without video from the app " +
      "(ready-only rule, helper 2.1.129)";
  }
  if (kind === "claim_hold") {
    let s = "reel_claim_hold: " + (o.status || "missing") +
      " \u2014 flagged post held at claim, NOT attempted; the reel " +
      "must be ready before this car posts " +
      "(ready-only rule, helper 2.1.129)";
    if (o.restarts > 0) s += " reel_render_restarts:" + o.restarts;
    return s;
  }
  if (kind === "claim_restart") {
    return "reel_claim_hold: failed \u2014 the render failed; " +
      "automatic restart " + (o.restarts || 1) + "/" +
      REEL_RENDER_MAX_RESTARTS + " queued " +
      "(reel_render_restarts:" + (o.restarts || 1) + "); the " +
      "flagged post stays held until the new reel is ready " +
      "(ready-only rule, helper 2.1.129)";
  }
  if (kind === "claim_attention") {
    return "reel_needs_attention: the reel render failed and " +
      "the one automatic restart is spent " +
      "(reel_render_restarts:" +
      (o.restarts || REEL_RENDER_MAX_RESTARTS) + ") \u2014 NOT " +
      "posted; the row stays held for a human: check the " +
      "reel, or post without video from the app " +
      "(ready-only rule, helper 2.1.129)";
  }
  if (kind === "chain_aim_attention") {
    return "reel_needs_attention: the video attach " +
      "stopped because the editor that opened was a " +
      "different listing than the one this post " +
      "created \u2014 nothing was changed and the " +
      "listing was NOT deleted; a listing for this " +
      "car may be LIVE WITHOUT its video right now" +
      (o.listingUrl ? " (" + o.listingUrl + ")" :
        (o.listingId ? " (listing " + o.listingId + ")" : "")) +
      " \u2014 check it by hand NOW, then check the " +
      "reel (ready-only rule, helper 2.1.129)";
  }
  if (kind === "chain_delete_attention") {
    return "reel_needs_attention: the reel could not be put " +
      "on this car's listing and the listing could NOT be " +
      "deleted \u2014 a listing for this car may be LIVE " +
      "WITHOUT its video right now" +
      (o.listingUrl ? " (" + o.listingUrl + ")" :
        (o.listingId ? " (listing " + o.listingId + ")" : "")) +
      " \u2014 delete it by hand NOW, then check the reel " +
      "(ready-only rule, helper 2.1.129)";
  }
  if (kind === "chain_verify_attention") {
    return "reel_needs_attention: the video attach " +
      "could not be verified — the patient listing " +
      "check did not complete with two empty reads " +
      "(" + (o.why || "verify_incomplete") + "), so " +
      "the listing was NOT deleted; a listing for " +
      "this car may be LIVE WITHOUT its video right " +
      "now" +
      (o.listingUrl ? " (" + o.listingUrl + ")" :
        (o.listingId ? " (listing " + o.listingId + ")" : "")) +
      " — check it by hand NOW, then check the " +
      "reel (ready-only rule, helper 2.1.129)";
  }
  return "reel_gate: unknown outcome";
}
// [PURE-REEL-GATE-END]

// Claim-time gate check (v2.1.118, header note 69;
// extended v2.1.119, header note 70): the reel-state read
// happens ONLY for a flagged job — an unflagged claim
// takes no new branch and makes no extra fetch. An
// unreadable state holds (lookup_failed): for a flagged
// car, not-proven-ready means not posted. The 3.19
// extension closes the manual-row hole the Nov 14 desk
// proof found: on a flagged account the gate no longer
// cares who queued the row. When the decision says the
// render must exist (ensureRender), the check starts it
// here — mirroring the producer's insert — and the hold
// text it returns says exactly what happened.
async function reelGateClaimCheck(userId, item, settings) {
  if (!reelJobFlagged(settings, item)) return { hold: false };
  let status = "missing";
  try {
    const rows = await sbGet(
      `vin_reels?user_id=eq.${userId}&vin=eq.${encodeURIComponent(item.vin)}` +
      `&order=created_at.desc&limit=1&select=status`);
    if (rows && rows.length && rows[0].status) {
      status = String(rows[0].status);
    }
  } catch (e) {
    status = "lookup_failed";
  }
  const restarts = reelRenderRestartCountFromError(
    item && item.error_message);
  const d = decideReelGateClaim({
    rowMarked: !!(item && item.reel_requested_at != null &&
      item.reel_requested_at !== ""),
    acctFlag: !!(settings && settings.vinReelBeforePost === true),
    reelStatus: status,
    renderRestarts: restarts
  });
  if (!d.hold) return { hold: false };
  let errorText;
  if (d.attention === true) {
    errorText = reelGateErrorText("claim_attention",
      { restarts: d.restarts });
  } else if (d.ensureRender === true) {
    const ensured = await ensureReelRenderQueued(userId, item);
    if (d.restart === true) {
      errorText = reelGateErrorText("claim_restart",
        { restarts: d.restarts });
      console.log(`[AutoLaunch] Reel gate: VIN ${item.vin} render failed — automatic restart ${d.restarts}/${REEL_RENDER_MAX_RESTARTS} ${ensured ? "queued" : "already live"}; post held (ready-only rule).`);
    } else {
      errorText = reelGateErrorText("claim_hold",
        { status, restarts });
      console.log(`[AutoLaunch] Reel gate: VIN ${item.vin} had no live reel — render ${ensured ? "queued" : "already live"}; post held (ready-only rule).`);
    }
  } else {
    errorText = reelGateErrorText("claim_hold", { status, restarts });
  }
  return { hold: true, status, errorText };
}

// ensureReelRenderQueued (v2.1.119, header note 70):
// start the car's poster render from the claim when the
// gate holds a flagged post with nothing live behind it.
// Mirrors the producer's _queue_reel_jobs exactly — the
// same row shape, the same skip rule (never insert when
// a queued / generating / ready reel already exists for
// the VIN, poster or manual), and the same shrug at the
// partial unique index when a racing pass inserts first.
// The live state is re-read immediately before the
// insert, so a render that appeared since the gate's own
// read is never duplicated. Returns true when THIS call
// inserted the row. A failed insert still holds — the
// gate fails closed either way.
async function ensureReelRenderQueued(userId, item) {
  try {
    const rows = await sbGet(
      `vin_reels?user_id=eq.${userId}&vin=eq.${encodeURIComponent(item.vin)}` +
      `&status=in.(queued,generating,ready)&select=id&limit=1`);
    if (rows && rows.length) return false;
  } catch (e) { /* fall through: the unique index arbitrates */ }
  try {
    await sbPost("vin_reels", {
      user_id: userId,
      vin: item.vin,
      stock_number: item.stock_num || null,
      source: "poster",
      status: "queued"
    });
    return true;
  } catch (e) {
    console.log("[AutoLaunch] Reel gate: render insert raced or failed; holding anyway (ready-only rule).");
    return false;
  }
}

// Abort settle (v2.1.118, header note 69): a gated post
// the content side aborted before submit. Returns true
// when the row was settled here (re-held, or failed as
// needs-attention at the cap) — the caller then skips the
// terminal path. Returns false when a write failed, and
// the caller falls through to the ordinary failure: the
// row is never lost. Mirrors the note-57 retry settle's
// shape (failure log + tab close + slot clear).
async function settleReelGateAbort(job, reason, diags) {
  try {
    const queueId = job.queueId;
    const stage = String(reason || "").replace(/^reel_gate_abort:?/, "")
      .slice(0, 60) || "unknown";
    let prior = 0;
    try {
      const rows = await sbGet(
        `auto_posting_queue?id=eq.${queueId}&select=error_message`);
      prior = reelAbortCountFromError(
        rows && rows[0] ? rows[0].error_message : null);
    } catch (e) { /* the count restarts; the cap still bounds by row state */ }
    const d = decideReelGateAbort(prior);
    // Trace persistence (v2.1.120, header note 71): the
    // content side's forensic records ride the failure
    // message (the v3.1 diag channel) but the 3.18
    // settle dropped them — the Nov 14 aborts left no
    // field_diag behind, and the per-attempt evidence
    // died with the tab. Compacted with the failure
    // path's own compactDiagError and appended to the
    // gate record: the abort counter still reads off
    // the same field, the settle's own write is the
    // one that carries it, and the record survives
    // the tab closing. No diags -> the record is
    // byte-identical to 3.19's.
    const diagText = compactDiagError(diags);
    const withDiag = t => diagText ? (t + "\n" + diagText) : t;
    if (d.action === "needs_attention") {
      await applyFailed(queueId, withDiag(
        reelGateErrorText("needs_attention",
          { stage, aborts: d.aborts })));
    } else {
      await sbPatch(`auto_posting_queue?id=eq.${queueId}`, {
        status: "pending",
        awaiting_reel: true,
        error_message: withDiag(reelGateErrorText("abort",
          { stage, aborts: d.aborts }))
      });
    }
    // [PWV348-CLEANUP-ABORT] (v2.1.148, note 95): a
    // re-held post keeps its staged copies (the retry
    // re-stages over them idempotently if they
    // vanished); a needs-attention settle ends the
    // attempt, so its copies go.
    if (d.action !== "rehold") {
      await cleanupPwvStage348(job, "failed");
    }
    await logFailure(queueId,
      `reel_gate_abort:${stage} (${d.action} ${d.aborts}/${REEL_GATE_MAX_ABORTS})`);
    scheduleJobTabClose(job);
    await chrome.storage.local.remove(["current_posting_job"]);
    console.log(`[AutoLaunch] Reel gate: job ${queueId} aborted (${stage}) — ${d.action} ${d.aborts}/${REEL_GATE_MAX_ABORTS} (ready-only rule).`);
    return true;
  } catch (e) {
    console.warn("[AutoLaunch] Reel-gate abort settle failed:", e && e.message || e);
    return false;
  }
}
// [REEL318-CODE-END]
// [REEL321-CODE-BEGIN]
// [PURE-REEL-CHAIN-BEGIN] — extracted and unit-exercised
// by the test harness; keep free of DOM/chrome references.
// Post-then-attach chain decisions (v2.1.121, header
// note 72).
// decideGateChainAttach: may a POST completion start the
// editor-attach chain? Only a GATED poster completion
// whose reel rode but is not yet verified — the gated
// flow deliberately posts without a create-flow attach,
// so "unverified" is its normal mid-state, not an error.
// Manual reels never chain (never consumed, never
// gated), ungated posters keep the 3.20 create-flow
// outcome, and a verified attach has nothing to chain.
function decideGateChainAttach(input) {
  const o = input || {};
  if (o.gated !== true) return { queue: false, reason: "not_gated" };
  if (o.source !== "poster") {
    return { queue: false, reason: "manual_reel" };
  }
  if (o.attached !== true) {
    return { queue: false, reason: "not_attached" };
  }
  if (o.attachVerified === true) {
    return { queue: false, reason: "attach_verified" };
  }
  return { queue: true };
}
// gateChainAbortReason: the gate-abort stage a chain
// attach failure settles the parent post with. The
// editor phase's verdicts (attach_unverified, the
// settle / dwell / identity / save failures) are
// editor_attach_failed; the verify phase's — the
// reopened-editor counter failures (attach_verify*) and
// the live-listing verdict (attach_listing_verify_failed)
// — are listing_verify_failed: the clip reached the
// editor but could not be proven on the listing.
function gateChainAbortReason(failedReason) {
  const r = typeof failedReason === "string" ? failedReason : "";
  if (r === "attach_listing_verify_failed" ||
      r.indexOf("attach_verify") === 0) {
    return "listing_verify_failed";
  }
  return "editor_attach_failed";
}
// gateChainAimFromListingUrl324: the listing id a
// finished post's own URL carries (v2.1.124, header
// note 75) — the same /marketplace/item/<id> shape
// the content side parses. Anything else yields
// null.
function gateChainAimFromListingUrl324(url) {
  const m = /\/marketplace\/item\/(\d{5,})/.exec(
    typeof url === "string" ? url : "");
  return m ? m[1] : null;
}
// gateChainAimFromConfirmationId325 (v2.1.125,
// header note 76): the content side's confirmation
// harvest — the id parsed from the matched card's
// own item link at the Selling-page confirmation.
// Accepted only in the id shape the content side
// parses (5+ digits); anything else yields null and
// the finish-URL parse is the next source. The
// listing-ID memory is NEVER a seeding source
// (note 76: it lags one attach behind by
// construction).
function gateChainAimFromConfirmationId325(id) {
  if (id == null) return null;
  const s = String(id);
  return /^\d{5,}$/.test(s) ? s : null;
}
// gateChainAimRecord324: the chain record's aim
// fields for a resolved id — the canonical item URL
// is built from the id, never copied from a
// possibly-decorated source URL.
function gateChainAimRecord324(listingId) {
  if (!listingId) return null;
  const id = String(listingId);
  return {
    listingId: id,
    listingUrl: "https://www.facebook.com/marketplace/item/" + id
  };
}
// gateChainPayloadAim324: the claim payload's aim
// seed for a chain record — the stored job's
// attachVideo. Only a live attach-stage record WITH
// an id seeds; anything else leaves the payload
// exactly as 3.23 built it (no attachVideo key).
function gateChainPayloadAim324(chain) {
  const c = chain || {};
  if (c.stage !== "attach" || !c.listingId) return null;
  const rec = gateChainAimRecord324(c.listingId);
  if (typeof c.listingUrl === "string" && c.listingUrl) {
    rec.listingUrl = c.listingUrl;
  }
  rec.aimSeeded324 = true;
  return rec;
}
// [PURE-REEL-CHAIN-END]
// [PURE-REEL-VERIFY327-BEGIN] — extracted and
// unit-exercised by the test harness; keep free of
// DOM/chrome references.
// Verify-completion decisions (v2.1.127, header
// note 78).
// (v2.1.128, header note 79: the settle delay
// RELOCATED — gateChainAttachDelay327, its
// claim-loop gate and the attachNotBefore327
// chain-record stamp are gone. The minute now
// runs after the editor save, on the stored
// job's verify state (content-side
// verifyNotBefore328), so the hold sits between
// the save and the patient verify instead of
// between the post and the attach. Chain records
// written by v2.1.127 keep an inert
// attachNotBefore327 field that nothing reads.)
// decideGateChainDelete327: the ONLY road to the
// chain's delete hop (v2.1.127, header note 78).
// Two shapes earn the delete, and both PROVE the
// listing bare. (1) The completed patient verify:
// the listing-verify verdict reason, both
// fresh-load reads recorded (+2 and +5 minutes —
// the read records' own offsets are the proof),
// and every read genuinely empty (verdict "none").
// (2) A failure before any save landed — an
// editor- or listing-phase verdict: the attach
// demonstrably never happened, so the listing is
// bare by the attach's own evidence (the 3.21 rule,
// unchanged). From the moment a save DID land —
// the stage reached "verify", or a listing check
// was armed or passed — the listing's video state
// can only be proven by shape (1): every other
// failure from there (arm missing, recovery
// collapse, incarnation death, a refused report,
// a stale or never-run read) is not evidence
// about the listing and earns no delete.
function decideGateChainDelete327(input) {
  const o = input || {};
  const av = o.attachVideo || {};
  const lv = av.listingVerify || null;
  const reads = (lv && Array.isArray(lv.reads)) ? lv.reads : [];
  if (o.reason === "attach_listing_verify_failed" &&
      lv && typeof lv === "object" && reads.length >= 2) {
    let allEmpty327 = true;
    for (let i = 0; i < reads.length; i++) {
      if (!reads[i] || reads[i].verdict !== "none") {
        allEmpty327 = false;
      }
    }
    const first327 = Number(reads[0] && reads[0].offsetS);
    const second327 = Number(reads[1] && reads[1].offsetS);
    if (allEmpty327 && isFinite(first327) &&
        isFinite(second327) &&
        first327 >= 100 && second327 >= 280) {
      return { queueDelete: true,
        why: "verify_completed_empty" };
    }
  }
  const verifyEntered327 = av.stage === "verify" ||
    av.listingCheck === "pending" ||
    av.listingCheck === "passed" || reads.length > 0;
  if (verifyEntered327) {
    if (o.reason !== "attach_listing_verify_failed") {
      return { queueDelete: false, why: "not_verify_verdict" };
    }
    if (!lv || typeof lv !== "object") {
      return { queueDelete: false, why: "verify_never_armed" };
    }
    if (reads.length < 2) {
      return { queueDelete: false, why: "reads_incomplete" };
    }
    for (let i = 0; i < reads.length; i++) {
      if (!reads[i] || reads[i].verdict !== "none") {
        return { queueDelete: false, why: "read_not_empty" };
      }
    }
    return { queueDelete: false, why: "read_too_early" };
  }
  return { queueDelete: true, why: "attach_never_landed" };
}
// gateChainFailDiag327: the compact trace a chained
// attach's failure leaves when the failing path
// supplied no diagnostics of its own (v2.1.127,
// header note 78) — which path failed (the reason),
// the arm state (stage / listingCheck / aim), and
// the verify state (the save clock and every read
// with its timestamp, offset and verdict), all read
// off the stored job the background already holds.
// One record, shaped exactly like a content diag
// record, so compactDiagError files it unchanged.
function gateChainFailDiag327(job, reason) {
  const av = (job && job.attachVideo) || {};
  const lv = av.listingVerify || null;
  const reads = (lv && Array.isArray(lv.reads)) ? lv.reads : [];
  const readText = reads.map((r, i) =>
    "read" + (i + 1) + " " + ((r && r.at) || "?") +
    " @+" + ((r && r.offsetS) || 0) + "s " +
    ((r && r.verdict) || "?") + " pb:" +
    ((r && r.playback) || "?")).join(" | ");
  let saveText = "none";
  if (lv) {
    const sn = Number(lv.saveAt);
    if (isFinite(sn) && sn > 0) {
      const sd = new Date(sn);
      if (isFinite(sd.getTime())) saveText = sd.toISOString();
    }
  }
  return {
    field: "attach_fail_trace",
    element: null,
    rungsAttempted: [],
    readBack: "",
    expected: null,
    cdpError: null,
    note: "path:" + (typeof reason === "string" && reason
        ? reason.slice(0, 80) : "unknown") +
      " stage:" + (av.stage || "none") +
      " check:" + (av.listingCheck || "none") +
      " aim:" + (av.listingId ? String(av.listingId) : "none") +
      " reads:" + reads.length,
    detail: lv
      ? "saveAt:" + saveText +
        (readText ? " " + readText : "")
      : "no listingVerify state on the stored job"
  };
}
// [PURE-REEL-VERIFY327-END]

// Gate-chain state (v2.1.121, header note 72): the one
// live post-then-attach chain per VIN, kept in storage
// because the chain spans three separate claims (post,
// attach, delete) and the rows it links carry no parent
// pointer of their own. { parentQueueId, stage:
// "attach" | "delete", reason?, attachQueueId?,
// deleteQueueId?, queuedAt }. Every accessor is
// fail-open: a lost chain degrades to exactly the
// pre-3.21 end state (the parent sits posted with
// reel_failed set), never to a wedged claim.
const GATE_CHAIN_KEY = "al_gate_chain_v1";
async function getGateChainMap() {
  try {
    const got = await chrome.storage.local.get([GATE_CHAIN_KEY]);
    const m = got && got[GATE_CHAIN_KEY];
    return (m && typeof m === "object") ? m : {};
  } catch (e) { return {}; }
}
async function getGateChain(vin) {
  if (!vin) return null;
  const m = await getGateChainMap();
  return m[vin] || null;
}
async function setGateChain(vin, entry) {
  try {
    const m = await getGateChainMap();
    m[vin] = entry;
    await chrome.storage.local.set({ [GATE_CHAIN_KEY]: m });
  } catch (e) { /* fail-open: the chain is bookkeeping */ }
}
async function clearGateChain(vin) {
  try {
    const m = await getGateChainMap();
    if (m[vin]) {
      delete m[vin];
      await chrome.storage.local.set({ [GATE_CHAIN_KEY]: m });
    }
  } catch (e) { /* fail-open */ }
}
// The queue-time aim breadcrumb (v2.1.124, header
// note 75): one durable step note on the field-diag
// channel (the failure-log ring), filed against the
// attach row the moment the chain is armed — so the
// storage side of the aim story exists somewhere
// besides the console. Aim absent records id:none:
// the legacy paths ran, and the trace says so.
async function logGateChainAimSeeded324(attachQueueId, aim) {
  if (!attachQueueId) return;
  try {
    await logFailure(attachQueueId, "field_diag:aim_seeded", {
      field: "aim_seeded", element: null, rungsAttempted: [],
      readBack: "", expected: null, cdpError: null,
      note: "id:" + (aim ? aim.listingId : "none"),
      detail: aim ? aim.listingUrl : null
    });
  } catch (e) { /* the chain record is the primary record */ }
}

// The diag record a settled chain files on the parent
// post row (rides settleReelGateAbort's field_diag
// channel, note 71): which hop failed, what the delete
// proved, and the two chain row ids.
function gateChainSettleDiag(chain, outcome, deleteQueueId) {
  const c = chain || {};
  return [{
    field: "gate_chain",
    note: (c.reason || "reel_gate_abort") + " -> " + outcome +
      (c.verifyReads ? " reads: " + c.verifyReads : ""),
    detail: "attach_row:" + (c.attachQueueId || "?") +
      " delete_row:" + (deleteQueueId || c.deleteQueueId || "?")
  }];
}
// Queue the chain's delete hop (v2.1.121, header note
// 72): the producer shape every delete row carries —
// the strict matcher's target is the POSTED price (the
// price the bare listing shows), carried on the failed
// attach job. The chain record advances to "delete"
// BEFORE the row can claim, so the delete's own finish
// knows its parent whatever happens next.
async function queueGateChainDelete(job, chain, mappedReason) {
  const car = (job && job.car) || {};
  const pp = Number(job.attachPostedPrice != null
    ? job.attachPostedPrice : car.price);
  const inserted = await sbPost("auto_posting_queue", {
    user_id: job.userId,
    vin: car.vin,
    target_channel: "facebook",
    action: "delete",
    status: "pending",
    year: car.year != null ? car.year : null,
    make: car.make || null,
    model: car.model || null,
    stock_num: car.stock_num || car.stock_number || null,
    price: isFinite(pp) && pp > 0 ? Math.round(pp) : null,
    created_at: new Date().toISOString()
  });
  const row = Array.isArray(inserted) ? inserted[0] : inserted;
  // The patient verify's read sequence (v2.1.122,
  // header note 73) rides the chain record into the
  // parent's settle diag: the full read history is
  // part of the loud record, not just the verdict.
  const lvReads322 = (job.attachVideo &&
    job.attachVideo.listingVerify &&
    Array.isArray(job.attachVideo.listingVerify.reads))
    ? job.attachVideo.listingVerify.reads : [];
  const verifyReads322 = lvReads322.map((r, i) =>
    "read" + (i + 1) + " @+" + ((r && r.offsetS) || 0) + "s " +
    ((r && r.verdict) || "?") + " pb:" +
    ((r && r.playback) || "?")).join(" | ");
  await setGateChain(car.vin, {
    parentQueueId: chain.parentQueueId,
    stage: "delete",
    reason: "reel_gate_abort:" + mappedReason,
    verifyReads: verifyReads322 || null,
    attachQueueId: job.queueId || chain.attachQueueId || null,
    deleteQueueId: (row && row.id) || null,
    queuedAt: new Date().toISOString()
  });
  console.log(`[AutoLaunch] Reel chain: attach for VIN ${car.vin} failed (${mappedReason}) — queued the bare listing's delete; the post settles once the removal is proven.`);
}
// The chain's delete could not be run (its queueing
// failed, or the delete job itself failed): the parent
// post settles needs-attention IMMEDIATELY — no abort
// budget — under text that says plainly a listing may
// be live without its video, naming the listing when
// the Design-A memory knows it. The posted stamp is
// deliberately NOT cleared: the listing may really be
// live, and the stamp is the app's truth for that.
async function settleGateChainDeleteFailed(job, chain) {
  const vin = job && job.car && job.car.vin;
  let listingId = null;
  try {
    const mem = await listingIdMemoryFor(vin);
    if (mem && mem.listingId) listingId = String(mem.listingId);
  } catch (e) { /* the text stands without the id */ }
  await applyFailed(chain.parentQueueId,
    reelGateErrorText("chain_delete_attention", {
      listingId,
      listingUrl: listingId
        ? "https://www.facebook.com/marketplace/item/" + listingId
        : null
    }));
  await logFailure(chain.parentQueueId, "reel_chain_delete_failed");
  await clearGateChain(vin);
  console.warn(`[AutoLaunch] Reel chain: the bare listing for VIN ${vin} could NOT be deleted — parent ${chain.parentQueueId} settled needs-attention (a listing may be live without its video).`);
}
// The aim contradiction settle (v2.1.124, header
// note 75): the editor that opened was a DIFFERENT
// listing than the one the chain posted — the aim's
// premise broke, so the parent settles
// needs-attention IMMEDIATELY and the listing is
// left standing: deleting on a corrupted aim is the
// one unsafe move. The posted stamp is deliberately
// NOT cleared (the listing may really be live,
// possibly even with its video from an earlier hop).
async function settleGateChainAimContradicted324(job, chain) {
  const vin = job && job.car && job.car.vin;
  const aim324 = (job && job.attachVideo) || {};
  const listingId = aim324.listingId
    ? String(aim324.listingId) : null;
  const listingUrl = listingId
    ? (typeof aim324.listingUrl === "string" && aim324.listingUrl
      ? aim324.listingUrl
      : "https://www.facebook.com/marketplace/item/" + listingId)
    : null;
  await applyFailed(chain.parentQueueId,
    reelGateErrorText("chain_aim_attention",
      { listingId, listingUrl }));
  await logFailure(chain.parentQueueId,
    "reel_chain_aim_contradicted");
  await clearGateChain(vin);
  console.warn(`[AutoLaunch] Reel chain: attach for VIN ${vin} stopped on an aim contradiction — parent ${chain.parentQueueId} settled needs-attention (nothing deleted).`);
}
// The verify-incomplete settle (v2.1.127, header
// note 78): a chained attach failed in a shape that
// proves nothing about the listing — the patient
// verify never completed with two empty reads — so
// the parent post settles needs-attention
// IMMEDIATELY and the listing is left standing: the
// delete rule is earned only by a completed verify
// (decideGateChainDelete327). The posted stamp is
// deliberately NOT cleared: the listing may really
// be live, possibly even with its video (the Nov 15
// Charger failure was a refused SUCCESS report —
// the video was on the listing the whole time).
async function settleGateChainVerifyAttention327(job, chain, mappedReason, why327) {
  const vin = job && job.car && job.car.vin;
  const aim327 = (job && job.attachVideo) || {};
  let listingId = aim327.listingId
    ? String(aim327.listingId) : null;
  let listingUrl = listingId
    ? (typeof aim327.listingUrl === "string" && aim327.listingUrl
      ? aim327.listingUrl
      : "https://www.facebook.com/marketplace/item/" + listingId)
    : null;
  if (!listingId) {
    try {
      const mem = await listingIdMemoryFor(vin);
      if (mem && mem.listingId) {
        listingId = String(mem.listingId);
        listingUrl =
          "https://www.facebook.com/marketplace/item/" + listingId;
      }
    } catch (e) { /* the text stands without the id */ }
  }
  await applyFailed(chain.parentQueueId,
    reelGateErrorText("chain_verify_attention", {
      listingId, listingUrl,
      stage: mappedReason, why: why327
    }));
  await logFailure(chain.parentQueueId,
    "reel_chain_verify_attention");
  await clearGateChain(vin);
  console.warn(`[AutoLaunch] Reel chain: attach for VIN ${vin} failed without a completed patient verify (${why327}) — parent ${chain.parentQueueId} settled needs-attention (nothing deleted).`);
}

// [REEL321-CODE-END]

// Newest completed-post stamp for this user (v2.1.42): the pacing
// gate's anchor. applyPosted stamps scraped_inventory.marketplace_
// posted_at at the moment a post completes, so the newest non-null
// value IS the last completed post — no separate state to maintain.
// Returns epoch ms, or null when the user has never posted or the
// lookup failed; callers treat null as "no hold" (fail open), so a
// flaky read can never wedge the queue behind a phantom delay.
async function lastPostedAt(userId) {
  try {
    const rows = await sbGet(
      `scraped_inventory?user_id=eq.${userId}` +
      `&marketplace_posted_at=not.is.null` +
      `&order=marketplace_posted_at.desc&select=marketplace_posted_at&limit=1`
    );
    const ts = rows && rows.length ? Date.parse(rows[0].marketplace_posted_at || "") : NaN;
    return isFinite(ts) ? ts : null;
  } catch (e) {
    return null;
  }
}

// Stock number for the job payload (v2.1.44, header note 21): the
// queue row's stamped stock_num wins; when it is empty/null/
// whitespace, fall back to the inventory row's stock_number (the
// row checkQueue already fetched by the job's VIN). Returns the
// car row unchanged when it already carries a usable stock_num
// or when no source has one — the description then simply omits
// the Stock # line, exactly as before this fix.
function jobCarWithStock(carRow, queueItem) {
  if (!carRow) return carRow;
  const usable = v => (v != null && String(v).trim()) ? String(v).trim() : "";
  if (usable(carRow.stock_num)) return carRow;
  const stock = usable(queueItem && queueItem.stock_num) || usable(carRow.stock_number);
  if (!stock) return carRow;
  return Object.assign({}, carRow, { stock_num: stock });
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
const jitter = (min, max) => sleep(min + Math.random() * (max - min));

// Job-slot reconciliation (v2.1.8, header note 15). A claimed job
// may legitimately run long — confirm mode waits up to 10 minutes
// for a human Publish click, and the v2.1.7 post-publish
// verification adds up to ~4 minutes of Selling-page rescans —
// but no legitimate run approaches 45 minutes, so a "processing"
// row older than that has no living content script behind it.
const JOB_STALE_MS = 45 * 60 * 1000;
// Price updates are phase-bounded (120s editor watchdog plus
// bounded scans — well under 8 minutes end to end), so a
// processing update row older than this is wedged, not working:
// fail it early with the orphan diagnostics instead of holding
// the slot for the generic 45 minutes (live wedge 2026-11-03).
// attach_video does NOT belong to this class (v2.1.95): its
// editor flow legitimately runs long — the v2.1.94 ingest
// budget alone reaches 900s, plus the dwell and a possible
// second incarnation — so an attach shares the generic
// 45-minute limit with posts. The 8-minute class cost a live
// attach its row on 2026-11-09 (PT10582, orphaned at ~10 min
// while its editor was still working).
const UPDATE_JOB_STALE_MS = 8 * 60 * 1000;
// Orphan recovery (v2.52, header note 26): how long a stale POST
// row's recovery scan may run before the watchdog falls back to
// the blind fail. The scan's own budget is ~4 minutes of rescans
// (verifyPublished's wall-clock cap) plus render patience — six
// minutes leaves honest headroom without wedging the slot.
const ORPHAN_RECOVERY_TIMEOUT_MS = 6 * 60 * 1000;
const SELLING_PAGE_URL = "https://www.facebook.com/marketplace/you/selling";
const TERMINAL_ROW_STATUSES = ["posted", "failed", "completed"];

// Returns true when the stored job slot must be KEPT (a run is
// genuinely in flight, or this cycle could not verify either
// way), false when the slot was dead and has been cleared — the
// caller then falls through and claims fresh work in the same
// pass. Runs at most one lightweight queue-row read per cycle,
// and only when a slot is occupied.
// Arm a stale POST job for orphan-recovery verification and
// open the Selling tab that runs the scan (v2.52, header
// note 26). The stored job gains verifyPublished with
// orphanRecovery set — the content script's existing routing
// takes it from there — plus an orphanRecovery bookkeeping
// record the watchdog reads on later cycles. Returns false
// when the tab could not be opened; the caller then fails
// blind, exactly as before this fix.
async function startOrphanRecovery(job) {
  try {
    const nowIso = new Date().toISOString();
    const armed = Object.assign({}, job, {
      verifyPublished: { tries: 0, startedAt: nowIso, orphanRecovery: true },
      orphanRecovery: { requestedAt: nowIso, tabId: null }
    });
    await chrome.storage.local.set({ current_posting_job: armed });
    const tab = await chrome.tabs.create({ active: false, url: SELLING_PAGE_URL });
    if (!tab || tab.id == null) return false;
    try {
      await chrome.tabs.update(tab.id, { autoDiscardable: false });
    } catch (e) { /* non-fatal: the scan still runs, just unprotected */ }
    const { current_posting_job: cur } =
      await chrome.storage.local.get(["current_posting_job"]);
    if (cur && cur.queueId === job.queueId && cur.orphanRecovery) {
      cur.orphanRecovery.tabId = tab.id;
      await chrome.storage.local.set({ current_posting_job: cur });
    }
    console.log(`[AutoLaunch] Orphan recovery: verifying queue item ${job.queueId} on the Selling page before failing it.`);
    return true;
  } catch (e) {
    return false;
  }
}

// Job liveness (v2.54, header note 28): the content script
// asks, before filling, whether the job its tab loaded from
// storage is still this worker's live job. Definitive-only:
// "no" requires positive evidence — the slot holds a
// different job (or no job), the queue row is gone, or the
// row already sits in a state reconcileActiveJob would call
// dead (terminal, or pending again). A matching slot over a
// processing row is live, and ANY failure to check (storage
// or database) answers live too — uncertainty never blocks.
async function jobLivenessVerdict(queueId) {
  if (!queueId) return { live: true };
  let slot = null;
  try {
    const stored = await chrome.storage.local.get(["current_posting_job"]);
    slot = stored && stored.current_posting_job;
  } catch (e) {
    return { live: true };
  }
  if (!slot || slot.queueId !== queueId) {
    return { live: false, reason: "slot_moved_on" };
  }
  let rows;
  try {
    rows = await sbGet(`auto_posting_queue?id=eq.${queueId}&select=id,status`);
  } catch (e) {
    return { live: true };
  }
  const row = Array.isArray(rows) && rows.length ? rows[0] : null;
  if (!row) return { live: false, reason: "row_missing" };
  if (TERMINAL_ROW_STATUSES.includes(row.status)) {
    return { live: false, reason: "row_" + row.status };
  }
  if (row.status === "pending") {
    return { live: false, reason: "row_pending" };
  }
  return { live: true };
}

async function reconcileActiveJob(job) {
  const queueId = job && job.queueId;
  if (!queueId) {
    // A slot with no queue id can never be finished or verified —
    // it is dead by construction.
    await chrome.storage.local.remove(["current_posting_job"]);
    console.log("[AutoLaunch] Job slot cleared (slot carried no queue id).");
    return false;
  }
  let rows;
  try {
    rows = await sbGet(`auto_posting_queue?id=eq.${queueId}&select=id,status`);
  } catch (err) {
    // The lookup itself failed (network, or auth — sbFetch has
    // already recorded a session expiry if it was one). Believe
    // nothing, change nothing: keep the slot and let this cycle
    // skip, exactly as conservative as the rest of the worker.
    return true;
  }
  const row = Array.isArray(rows) && rows.length ? rows[0] : null;
  const clearSlot = async reason => {
    await chrome.storage.local.remove(["current_posting_job"]);
    console.log(`[AutoLaunch] Job slot cleared (${reason}) for queue item ${queueId}.`);
  };
  if (!row) {
    // The user cancelled the job in the app (the queue row is
    // deleted there) — the run it belonged to can never report
    // back, so the slot it wedged is dead.
    await clearSlot("queue row no longer exists");
    return false;
  }
  if (TERMINAL_ROW_STATUSES.includes(row.status)) {
    await clearSlot(`queue row already ${row.status}`);
    return false;
  }
  if (row.status === "pending") {
    // Re-queued externally (or the claim write never landed):
    // the stored run is dead either way. Clearing the slot lets
    // THIS cycle's claim pass pick the row up fresh below.
    await clearSlot("queue row is pending again");
    return false;
  }
  if (row.status === "processing") {
    const claimedAtMs = Date.parse(job.claimedAt || "");
    // A claim that cannot prove it is fresh (no readable
    // claimedAt) does not get to wedge the queue forever.
    // Phase watchdog for price updates (v2.1.73): the edit and
    // verify phases run inside a Facebook tab whose script can
    // stall without settling (soft-navigation handoff, frozen
    // timers — the 2026-11-03 E2E wedges). The phases stamp
    // stageAt when they start; if a phase runs past 150s (past
    // its own 120s watchdog) with the row still processing,
    // reload the job tab from OUTSIDE the page — a fresh script
    // boots and resumes from the stage marker. At most 2 reloads
    // per phase; beyond that the stale path below settles it.
    // v2.1.88: the same watchdog serves attach_video jobs,
    // whose stage marker rides job.attachVideo in the same
    // shape (stages "edit"/"verify").
    const phaseKey = job.action === "update_price" ? "priceUpdate"
      : job.action === "attach_video" ? "attachVideo" : null;
    const pu = phaseKey ? (job[phaseKey] || {}) : {};
    if (phaseKey &&
        (pu.stage === "edit" || pu.stage === "verify") &&
        job.tabId != null) {
      if (job.phaseReloadStage !== pu.stage) {
        job.phaseReloadStage = pu.stage;
        job.phaseReloads = 0;
      }
      const stageAgeMs = Date.now() - (Date.parse(pu.stageAt || "") || 0);
      if (isFinite(stageAgeMs) && stageAgeMs > 150 * 1000 &&
          (job.phaseReloads || 0) < 2) {
        try {
          job.phaseReloads = (job.phaseReloads || 0) + 1;
          job[phaseKey] = Object.assign({}, pu,
            { stageAt: new Date().toISOString() });
          await chrome.storage.local.set({ current_posting_job: job });
          await chrome.tabs.reload(job.tabId);
          console.warn("[AutoLaunch] " +
            (phaseKey === "priceUpdate" ? "Price-update" : "Video-attach") +
            " phase " + pu.stage +
            " stalled — reloaded the job tab (reload " +
            job.phaseReloads + " of 2).");
        } catch (e) { /* tab gone — the stale path settles it */ }
        return true;
      }
    }
    const ageMs = isFinite(claimedAtMs) ? Date.now() - claimedAtMs : Infinity;
    const staleLimitMs = job.action === "update_price"
      ? UPDATE_JOB_STALE_MS : JOB_STALE_MS;
    if (ageMs <= staleLimitMs) return true; // genuinely running
    // Orphan recovery (v2.52, header note 26): a stale POST row
    // is verified against Facebook BEFORE it may be failed —
    // the Prius lesson (2026-10-28) is that "processing" past
    // the watchdog can mean the Publish already landed and
    // only the bookkeeping died. The recovery scan settles the
    // row through the ordinary finish messages; while it is in
    // flight the slot is KEPT (returning true). Only a scan
    // that cannot start, or that produces no verdict within
    // ORPHAN_RECOVERY_TIMEOUT_MS, falls through to the blind
    // fail below — with the recovery outcome in its detail.
    let recoveryNote = "";
    // v2.1.104 (note 57): the same pre-fail verification
    // now covers orphaned update_price and delete jobs —
    // content.js runOrphanVerify settles those from the
    // same fresh Selling-page scan (the price landed, or
    // the listing is gone), and only an unverified orphan
    // falls through to the blind fail below.
    if (job.action === "post" || job.action === "update_price" || job.action === "delete") {
      const rec = job.orphanRecovery;
      if (!rec) {
        if (await startOrphanRecovery(job)) return true;
        recoveryNote = " Orphan recovery scan could not be started (no Selling tab) — failed blind.";
      } else {
        const recAgeMs = Date.now() - (Date.parse(rec.requestedAt || "") || 0);
        if (isFinite(recAgeMs) && recAgeMs <= ORPHAN_RECOVERY_TIMEOUT_MS) {
          return true; // scan in flight — its finish settles the row
        }
        recoveryNote = " Orphan recovery scan produced no verdict within 6 min — failed blind.";
      }
    }
    // Orphaned: still "processing" far beyond any legitimate
    // run, so the content script is certainly dead (its tab was
    // closed, or it crashed). Fail the row honestly — the
    // diagnostics ride error_message like every other failure —
    // clear the slot, and let the cycle continue to fresh work.
    console.warn(`[AutoLaunch] Job orphaned: queue item ${queueId} still processing ${Math.round(ageMs / 60000)} min after claim — failing it and clearing the slot.`);
    const errorMessage = compactDiagError([{
      field: "Job",
      note: "job_orphaned",
      detail: `claimed ${job.claimedAt || "unknown"}, still "processing" after 45+ min — content script presumed dead (tab closed or crashed).${recoveryNote}`
    }]);
    try {
      await applyFailed(queueId, errorMessage);
    } catch (err) {
      if (err instanceof SbAuthError) {
        // Same stash-and-replay as finishJobFailed, so the
        // failure lands when the next fresh token arrives instead
        // of being lost with the dead token.
        await chrome.storage.local.set({
          autolaunch_pending_finish: { outcome: "failed", queueId, errorMessage }
        });
      } else {
        throw err;
      }
    }
    await logFailure(queueId, "job_orphaned");
    await clearSlot("orphaned processing row failed");
    return false;
  }
  // A status vocabulary this build does not know: change nothing.
  return true;
}

let isChecking = false;

// [PURE-PRICE-UPDATE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Claim-time basis validation for a price-update job (v2.1.62,
// header note 34; §4E revision v2.1.130, header note 81): the
// job was queued for ONE specific drift — the dealer's price
// moved to the row's price. At claim time the inventory row
// is re-read, and the job runs while the drift's TARGET half
// still exists: the car is still posted, and the dealer's
// current price still equals the job's TO price. The FROM
// half is no longer a basis: the listing's current price is
// never identity (§4E) — it may read anything, including a
// price that already moved past the stamped one, and the
// content flow's VIN/stock identity gate is the authority
// on whether the listing it opens is really this car. A
// dealer price that moved AGAIN still fails here with
// price_basis_changed, and the next sync's drift pass
// re-queues the truth. Pure: (queue item, inventory row)
// -> verdict.
function priceUpdateClaimGate(item, carRow) {
  if (!item || item.action !== "update_price") {
    return { ok: false, reason: "not_a_price_update" };
  }
  const fromRaw = Number(item.update_from_price);
  const fromPrice = isFinite(fromRaw) && fromRaw > 0 ? fromRaw : null;
  const toPrice = Number(item.price);
  if (!isFinite(toPrice) || toPrice <= 0) {
    return { ok: false, reason: "price_update_payload_invalid" };
  }
  if (!carRow) {
    return { ok: false, reason: "inventory_row_missing" };
  }
  if (!carRow.marketplace_posted_at) {
    return { ok: false, reason: "listing_not_posted" };
  }
  if (Number(carRow.price) !== toPrice) {
    return { ok: false, reason: "price_basis_changed" };
  }
  return { ok: true, fromPrice, toPrice };
}
// [PURE-PRICE-UPDATE-END]
// [PURE-PRICE-GATE-347-BEGIN] — extracted and unit-exercised
// by the test harness; keep free of DOM/chrome references.
// Price-edit minimum-delta gate (v2.1.147, header note 94;
// Matthew, 2026-11-18): an update_price job exists to move a
// listing's price to the dealer's current price — but a drift
// smaller than $500 is not worth a Facebook session. The BMW
// job chased a $13 drift ($19,333 -> $19,320) through three
// attempts and the delete-and-repost ladder and lost the
// listing doing it, and every editor cycle is traffic on an
// account Meta already watches. So at claim time, after the
// basis gate has proven the drift is real, a drift under the
// minimum settles the row COMPLETED without opening a tab:
// the listing keeps its price, the row carries the skip on
// its error_message (plain words first, then the markers —
// the priceRecoveryRecord338 composition, where the queue
// card surfaces it), and the stamp never advances, so the
// next drift is still measured from the listing's real
// price — small ticks accumulate toward the minimum instead
// of each one resetting the clock. Fail-safe toward
// editing: a from or to price that does not parse as a
// positive number NEVER skips — the job runs exactly as
// before. Pure: (queue item) -> verdict.
const PRICE_EDIT_MIN_DELTA = 500;
function priceEditDelta347(fromRaw, toRaw) {
  const from = Number(fromRaw);
  const to = Number(toRaw);
  if (!isFinite(from) || from <= 0 || !isFinite(to) || to <= 0) {
    return null;
  }
  return Math.abs(to - from);
}
function priceEditSkipRecord347(delta, from, to) {
  return "Price change skipped — $" + delta + " under the $" +
    PRICE_EDIT_MIN_DELTA + " minimum (listing $" + from +
    ", dealer $" + to + "). price_edit_skipped:below_min_delta" +
    " price_edit_delta:" + delta +
    " price_edit_min_delta:" + PRICE_EDIT_MIN_DELTA;
}
function decidePriceEditMinDelta347(item) {
  const it = item || {};
  const delta = priceEditDelta347(it.update_from_price, it.price);
  if (delta === null) {
    return { skip: false, reason: "prices_unparseable" };
  }
  if (delta >= PRICE_EDIT_MIN_DELTA) {
    return { skip: false, reason: "delta_meets_minimum", delta };
  }
  const from = Number(it.update_from_price);
  const to = Number(it.price);
  return { skip: true, reason: "below_min_delta", delta, from, to,
    settle: "completed",
    errorMessage: priceEditSkipRecord347(delta, from, to) };
}
// [PURE-PRICE-GATE-347-END]

// [PURE-PWV-348-BEGIN] — extracted and unit-exercised
// by harness_helper_348.js; keep pure (no extension
// APIs, no network, no DOM) so the harness can lift
// this span verbatim.
//
// Post-with-video (v2.1.148, header note 95; spec
// post-with-video-spec-2026-11-18 + its addenda): a
// post whose car has a ready reel stages its media on
// disk first — Downloads/AutoLaunch/<stock_number>/,
// photos numbered in listing order + the reel as
// reel.mp4 — and the create flow feeds the staged
// files through the composer's own controls (photos
// batch, then the SEPARATE "Add video" tile), waits
// out Facebook's video-loading gate, and only then
// walks the form. Staging path construction, the
// generalized hold decision, and the cleanup gate
// live here; the worker side is [PWV348-RUNTIME].

const PWV348_ROOT = "AutoLaunch";

// One path segment from a stock number: keep the
// characters a folder name can carry, collapse the
// rest. An empty result means "no usable stock".
function pwv348SanitizeStock(stock) {
  const s = String(stock == null ? "" : stock).trim()
    .replace(/[^A-Za-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return s.slice(0, 40);
}

function pwv348VinTail(vin, n) {
  const v = String(vin == null ? "" : vin).trim().toUpperCase();
  return v ? v.slice(-n) : "";
}

// The staging folder for a car (spec addendum 2): the
// stock number; on collision (or a stock that needs
// disambiguating) the VIN tail joins it; with no
// stock at all the folder is the VIN tail alone.
// Never empty.
function pwv348Folder(stock, vin, collides) {
  const s = pwv348SanitizeStock(stock);
  if (s && !collides) return s;
  const tail6 = pwv348VinTail(vin, 6);
  if (s && tail6) return s + "-" + tail6;
  if (s) return s;
  const tail8 = pwv348VinTail(vin, 8);
  return tail8 ? "VIN-" + tail8 : "car";
}

// The staged photo's file name: zero-padded position
// in listing order; the extension comes from the
// source URL when it is a known image type, else .jpg.
function pwv348PhotoName(index, url) {
  const nn = String(index + 1).padStart(2, "0");
  const m = /\.(jpe?g|png|webp)(?:[?#]|$)/i.exec(String(url || ""));
  const ext = m ? "." + m[1].toLowerCase().replace("jpeg", "jpg") : ".jpg";
  return nn + ext;
}

// The full relative staging plan for a car: every
// path is Downloads-relative and passes pwv348PathSafe
// by construction.
function pwv348StagePaths(folder, photoUrls) {
  const photos = (Array.isArray(photoUrls) ? photoUrls : [])
    .map((u, i) => PWV348_ROOT + "/" + folder + "/" + pwv348PhotoName(i, u));
  return { photos, reel: PWV348_ROOT + "/" + folder + "/reel.mp4" };
}

// The attach-path migration (spec addendum 2): the
// editor-attach reel download lands in the same
// per-car folder.
function pwv348AttachRelativePath(folder, filename) {
  return PWV348_ROOT + "/" + folder + "/" + filename;
}

// The cleanup fence: a staged path is deletable ONLY
// if it provably lives inside Downloads/AutoLaunch/ —
// no parent hops, no backslashes, never absolute.
function pwv348PathSafe(relPath) {
  if (typeof relPath !== "string") return false;
  if (relPath.indexOf("/") === 0) return false;
  if (relPath.indexOf(PWV348_ROOT + "/") !== 0) return false;
  if (relPath.indexOf("..") >= 0 || relPath.indexOf("\\") >= 0) return false;
  return relPath.length > PWV348_ROOT.length + 1;
}

// Generalized hold (spec Rule 1): a post whose reel
// is still coming (queued / generating) WAITS — for
// every account, flagged or not. A ready reel
// proceeds (it rides the job); failed / consumed /
// waived / missing / unreadable proceed exactly as
// the pre-.148 flow decided (the flagged gate still
// owns its own cases).
function decidePwvHold348(input) {
  const status = input && typeof input.reelStatus === "string"
    ? input.reelStatus : null;
  if (status === "queued" || status === "generating") {
    return { hold: true, status };
  }
  return { hold: false, status };
}

function pwv348HoldText(status) {
  return "Post-with-video hold (v2.1.148): this car's reel is still " +
    status + " — the post waits so the video can ride the listing " +
    "from the start; it claims again when the reel is ready.";
}

// Cleanup gate: staged copies are deleted only when
// the record belongs to THIS job and the job's end is
// known — proven (the post verified live) or failed
// (the attempt is over; everything re-stages next
// time). Any other outcome keeps the files. And every
// recorded path must pass the fence, or nothing is
// deleted at all.
function decidePwvStageCleanup348(input) {
  const rec = input && input.record;
  if (!rec || typeof rec !== "object") return { clean: false, paths: [] };
  if (String(rec.queueId) !== String(input && input.queueId)) {
    return { clean: false, paths: [] };
  }
  const outcome = input && input.outcome;
  if (outcome !== "proven" && outcome !== "failed") {
    return { clean: false, paths: [] };
  }
  const items = [];
  if (Array.isArray(rec.photos)) items.push.apply(items, rec.photos);
  if (rec.reel) items.push(rec.reel);
  const paths = [];
  for (const it of items) {
    if (!it || typeof it.relPath !== "string") continue;
    if (!pwv348PathSafe(it.relPath)) return { clean: false, paths: [] };
    paths.push(it.relPath);
  }
  if (!paths.length) return { clean: false, paths: [] };
  return { clean: true, paths };
}

// The dealer photo set for staging, mirroring the
// content side's photoUrls() + the dealer side of
// planPhotoAttach(): custom photos first, then the
// primary image, then the photo arrays; deduped by
// photo key (URL minus its width parameter, widest
// variant winning, first-seen order kept); capped at
// 20 — 19 when the reel's end card rides as the last
// photo — so the staged set is exactly the set the
// composer receives.
function pwv348PhotoKey(url) {
  try {
    const u = new URL(url);
    u.searchParams.delete("width");
    return u.toString();
  } catch (e) { return String(url); }
}

function pwv348PhotoWidth(url) {
  try {
    const u = new URL(url);
    const w = parseInt(u.searchParams.get("width") || "0", 10);
    return isNaN(w) ? 0 : w;
  } catch (e) { return 0; }
}

function pwv348PhotoUrls(car, cardUrl) {
  if (!car || typeof car !== "object") return [];
  const raw = [];
  const push = v => {
    if (typeof v === "string" && v.trim()) raw.push(v.trim());
  };
  const pushAll = v => {
    if (Array.isArray(v)) v.forEach(push);
    else if (typeof v === "string") {
      v.split(",").map(s => s.trim()).filter(Boolean).forEach(push);
    }
  };
  pushAll(car.custom_photo_urls);
  push(car.image_url);
  pushAll(car.photos);
  pushAll(car.images);
  pushAll(car.image_urls);
  pushAll(car.photo_urls);
  const byKey = new Map();
  const order = [];
  for (const u of raw) {
    const k = pwv348PhotoKey(u);
    if (!byKey.has(k)) { byKey.set(k, u); order.push(k); }
    else if (pwv348PhotoWidth(u) > pwv348PhotoWidth(byKey.get(k))) {
      byKey.set(k, u);
    }
  }
  const out = order.map(k => byKey.get(k)).slice(0, 20);
  if (cardUrl) return out.slice(0, 19);
  return out;
}
// [PURE-PWV-348-END]

// [PURE-PWV-352-BEGIN] — flat staging names + the
// completion sweep (v2.1.152, pure: no extension
// APIs, no network, no DOM — the harness lifts this
// span verbatim, like the 348 block above).
//
// Why (Matthew's design call, Nov 18): .148-.151
// staged a car's media into
// Downloads/AutoLaunch/<stock_number>/ with generic
// names (01.jpg, 02.jpg, ..., reel.mp4). Post-proof
// cleanup deletes the files, but the downloads API
// cannot delete the FOLDER, so empty shells
// accumulate in Downloads/AutoLaunch/. Flattening
// naively — every car in one folder under generic
// names — was rejected on sight: two cars' "01.jpg"
// would collide, and wrong photos on a listing is a
// disaster class. So the car's identity moves INTO
// the file name: flat in Downloads/AutoLaunch/,
// every file prefixed with the car's staging base
// (<stock>, or <stock>-<VIN tail> on collision —
// the .148 folder rule, moved into the filename):
//   photos:  <base>-01.jpg, <base>-02.png, ...
//   reel:    <base>-reel.mp4
//   attach:  <base>-autolaunch-reel-<...>.mp4
// (the attach download keeps its worker-guarded
// temp name behind the same prefix, so the two
// flows never share a path). The end card is not
// staged to disk by the post flow (it rides the
// classic attach as a URL), so no card name exists
// here. Only NEW staging writes the flat layout:
// .148-.151 records keep their folder paths and are
// honored exactly as written (see the runtime).

// The staging base for a car: the sanitized stock
// number; on collision (the previous record's
// folder was this stock, for a DIFFERENT car) the
// VIN tail joins it; with no stock at all the base
// is the VIN tail alone. Never empty. Mirrors
// pwv348Folder's rule, segment for segment — what
// changes is where the result is used (a filename
// prefix, not a folder).
function pwv352StageBase(stock, vin, collides) {
  const s = pwv348SanitizeStock(stock);
  if (s && !collides) return s;
  const tail6 = pwv348VinTail(vin, 6);
  if (s && tail6) return s + "-" + tail6;
  if (s) return s;
  const tail8 = pwv348VinTail(vin, 8);
  return tail8 ? "VIN-" + tail8 : "car";
}

// One staged photo's file name: the base, a dash,
// and the .148 numbered name (zero-padded position
// in listing order, extension from the source URL).
function pwv352PhotoName(base, index, url) {
  return base + "-" + pwv348PhotoName(index, url);
}

// The full relative staging plan for a car, FLAT:
// every path is Downloads/AutoLaunch/<name> and
// passes pwv348PathSafe by construction.
function pwv352StagePaths(base, photoUrls) {
  const photos = (Array.isArray(photoUrls) ? photoUrls : [])
    .map((u, i) => PWV348_ROOT + "/" + pwv352PhotoName(base, i, u));
  return { photos, reel: PWV348_ROOT + "/" + base + "-reel.mp4" };
}

// The attach-path migration, flattened: the editor-
// attach reel download lands flat under the same
// base, its guarded temp name behind the prefix —
// flat like the post staging, and never the post
// reel's own path.
function pwv352AttachRelativePath(base, filename) {
  return PWV348_ROOT + "/" + base + "-" +
    String(filename == null ? "" : filename);
}

// The completion sweep (pure): when a job's cleanup
// runs under the 348 gate, which OTHER staged files
// may go with it? Only leftovers of the SAME car
// from a SUPERSEDED staging attempt — records the
// runtime remembered when a newer record for the
// same VIN replaced them. The bounds are the whole
// design:
// - an extra record counts only when its VIN equals
//   the completing record's VIN, its queue id
//   differs (it is not this job), and it carries the
//   SAME flat base352 (so a legacy folder record is
//   never swept by a flat job, nor the reverse);
// - an item counts only when its relPath sits under
//   this base's prefix inside Downloads/AutoLaunch/
//   AND passes the 348 path fence;
// - the completing record's own items are excluded
//   (the 348 cleanup proper owns them);
// - unrecorded files are never seen here at all —
//   the sweep reads records, never the disk.
// Returns the extra ITEMS (the runtime removes by
// download id, exactly like the cleanup proper).
function pwv352SweepItems(record, extraRecords) {
  const rec = record && typeof record === "object" ? record : null;
  if (!rec) return [];
  const vin = String(rec.vin || "");
  const base = typeof rec.base352 === "string" ? rec.base352 : "";
  if (!vin || !base) return [];
  const queueId = String(rec.queueId == null ? "" : rec.queueId);
  const prefix = PWV348_ROOT + "/" + base + "-";
  const own = new Set();
  const collectOwn = r => {
    if (!r || typeof r !== "object") return;
    if (Array.isArray(r.photos)) {
      for (const p of r.photos) {
        if (p && typeof p.relPath === "string") own.add(p.relPath);
      }
    }
    if (r.reel && typeof r.reel.relPath === "string") {
      own.add(r.reel.relPath);
    }
  };
  collectOwn(rec);
  const out = [];
  const seen = new Set();
  for (const r of Array.isArray(extraRecords) ? extraRecords : []) {
    if (!r || typeof r !== "object") continue;
    if (String(r.vin || "") !== vin) continue;
    if (String(r.queueId == null ? "" : r.queueId) === queueId) continue;
    if (typeof r.base352 !== "string" || r.base352 !== base) continue;
    const items = [];
    if (Array.isArray(r.photos)) items.push.apply(items, r.photos);
    if (r.reel) items.push(r.reel);
    for (const it of items) {
      if (!it || typeof it.relPath !== "string") continue;
      if (own.has(it.relPath) || seen.has(it.relPath)) continue;
      if (it.relPath.indexOf(prefix) !== 0) continue;
      if (!pwv348PathSafe(it.relPath)) continue;
      seen.add(it.relPath);
      out.push(it);
    }
  }
  return out;
}
// [PURE-PWV-352-END]

// [PURE-CLAIM-BEGIN] — extracted and unit-exercised by the
// test harness; keep free of DOM/chrome references.
// The claim ACTION ALLOWLIST (v2.1.88, header note 43):
// the actions this build knows how to run. checkQueue
// selects work ONLY through claimActionOf: a row whose
// action is anything else — a future producer's new verb,
// a hand-written row — is NEVER claimed, and in particular
// never claimed as a post (the pre-2.88 selection treated
// every unrecognized action as a post). A row with no
// action (or an empty one) is a post: that is the queue's
// founding shape.
const CLAIM_KNOWN_ACTIONS = ["post", "delete", "share", "update_price", "attach_video", "reconcile", "verify_listing"];
function claimActionOf(item) {
  const a = item && typeof item.action === "string" && item.action
    ? item.action : "post";
  return CLAIM_KNOWN_ACTIONS.indexOf(a) >= 0 ? a : null;
}
// [PURE-CLAIM-END]

// [PURE-ATTACH-VIDEO-BEGIN] — extracted and unit-exercised
// by the test harness; keep free of DOM/chrome references.
// Claim-time basis validation for an attach_video job
// (v2.1.88, header note 43), the price-update gate's twin:
// the job exists to put a video on ONE live listing — the
// car must still be posted, and its stamped posted price
// must still equal the price stamped on the row (the
// strict matcher's target). Any drift means the world
// moved — fail the row untouched with a named reason.
// Pure: (queue item, inventory row) -> verdict.
function attachVideoClaimGate(item, carRow) {
  if (!item || item.action !== "attach_video") {
    return { ok: false, reason: "not_an_attach_job" };
  }
  const postedPrice = Number(item.price);
  if (!isFinite(postedPrice) || postedPrice <= 0) {
    return { ok: false, reason: "attach_payload_invalid" };
  }
  if (!carRow) {
    return { ok: false, reason: "inventory_row_missing" };
  }
  if (!carRow.marketplace_posted_at) {
    return { ok: false, reason: "listing_not_posted" };
  }
  if (Number(carRow.marketplace_posted_price) !== postedPrice) {
    return { ok: false, reason: "attach_price_basis_changed" };
  }
  return { ok: true, postedPrice };
}
// decideAttachQueue (v2.1.88): given the reel record a
// POST completion folded (claim time stamped { id, source,
// attached }, the finish folded in attachVerified), decide
// whether the completion queues the edit-flow attach job.
// Exactly the completions whose poster reel was attached
// but NOT verified queue one — a verified attach consumed
// its reel (nothing left to attach), a manual reel is out
// of scope (never queued, never consumed), and a job that
// carried no reel has nothing to queue for.
function decideAttachQueue(reel) {
  if (!reel || reel.attached !== true) {
    return { queue: false, reason: "no_reel_attached" };
  }
  if (reel.source !== "poster") {
    return { queue: false, reason: "manual_reel" };
  }
  if (reel.attachVerified === true) {
    return { queue: false, reason: "attach_verified" };
  }
  return { queue: true };
}
// [PURE-ATTACH-VIDEO-END]

// [PURE-ADOPT-340-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Orphaned attach adoption (v2.1.140, header note 90): an
// attach_video row with NO live gate-chain record for its
// VIN is an orphan — its chain concluded (or never armed)
// in an earlier build or session, and the 3.21 claim rule
// leaves it dormant forever: the app's own Retry button
// manufactures exactly this state (a failed attach returns
// to pending; the chain record that once claimed it is
// gone). Adoption claims such a row as a PLAIN attach job
// (no chain record is written, no gateChain flag rides the
// payload): the existing claim gates still prove the basis
// (attachVideoClaimGate: car posted, stamped price equal;
// reelForJob: a ready poster reel), the content side still
// identity-verifies the listing before touching it, and a
// failure settles on the row alone — never a chain delete
// hop. The age floor closes the one structural race: a
// gated post's finish writes its chain record in the same
// job-slot occupation that queues the row, so a row younger
// than the floor can still be mid-arming; an older row's
// missing record is a fact, not a timing artifact.
// Pure: (queue item, chain record|null, now ms) -> boolean.
const ATTACH_ADOPT_MIN_AGE_MS_340 = 120000;
function decideAttachAdoption340(item, chain, nowMs) {
  if (!item || item.action !== "attach_video") return false;
  if (chain) return false;
  if (!item.vin) return false;
  const price = Number(item.price);
  if (!isFinite(price) || price <= 0) return false;
  const created = Date.parse(item.created_at || "");
  if (!isFinite(created)) return false;
  if (typeof nowMs !== "number" || !isFinite(nowMs)) return false;
  return nowMs - created >= ATTACH_ADOPT_MIN_AGE_MS_340;
}
// [PURE-ADOPT-340-END]
// [WORKER-HEALTH-304-BEGIN] ===============================
// Worker health + failure recovery (v2.1.104, header note
// 57): keep-awake, the permission self-check, the
// session-expired surface, and the list_never_grew retry
// verdict. Everything here is fail-safe by construction —
// a failure inside any of it is logged and swallowed, and
// can never block a claim, a finish, or a capture.

// [PURE-KEEP-AWAKE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Keep-awake decision (v2.1.104, header note 57): "work
// pending" is the claim cycle's own verdict (a job in
// flight, a non-empty queue fetch, rows waiting on the
// cap/pacing, or auto-reply hub duty). Pending -> hold the
// system awake (request once). Idle -> count a streak;
// the hold releases only after TWO consecutive idle
// observations, i.e. a full claim cycle drained with
// nothing in flight — a single quiet cycle between two
// busy ones never drops the hold mid-backlog.
function alKeepAwakeDecide(state, workPending) {
  const held = !!(state && state.held);
  const streak = state && typeof state.idleStreak === "number" ? state.idleStreak : 0;
  if (workPending) {
    return { held: true, idleStreak: 0, action: held ? "none" : "request" };
  }
  const next = streak + 1;
  if (held && next >= 2) {
    return { held: false, idleStreak: 0, action: "release" };
  }
  return { held: held, idleStreak: next, action: "none" };
}
// [PURE-KEEP-AWAKE-END]

// [KA-FN-BEGIN]
let alKeepAwakeState = { held: false, idleStreak: 0 };
async function alKeepAwakeCycle(workPending) {
  try {
    const d = alKeepAwakeDecide(alKeepAwakeState, !!workPending);
    alKeepAwakeState = { held: d.held, idleStreak: d.idleStreak };
    if (d.action === "request" && chrome.power && chrome.power.requestKeepAwake) {
      await chrome.power.requestKeepAwake("display");
      console.log("[AutoLaunch] Keep-awake ON (display \u2014 work pending).");
    } else if (d.action === "release" && chrome.power && chrome.power.releaseKeepAwake) {
      await chrome.power.releaseKeepAwake();
      console.log("[AutoLaunch] Keep-awake OFF (queue drained).");
    }
  } catch (e) {
    // Fail-safe: keep-awake is a convenience, never a gate.
    console.warn("[AutoLaunch] keep-awake cycle failed (continuing):", e && e.message ? e.message : e);
  }
}
// [KA-FN-END]

// Best-effort release on worker suspension — the one
// teardown path the worker controls. (A user who toggles
// the helper OFF on its card stops the worker entirely,
// which ends the hold with it: no keep-awake while off.)
if (chrome.runtime && chrome.runtime.onSuspend) {
  chrome.runtime.onSuspend.addListener(() => {
    try {
      if (alKeepAwakeState.held && chrome.power && chrome.power.releaseKeepAwake) {
        chrome.power.releaseKeepAwake();
      }
    } catch (e) { /* best effort */ }
    alKeepAwakeState = { held: false, idleStreak: 0 };
  });
}

// 82. KEEP-AWAKE LEVEL: DISPLAY (v2.1.132, the 3.32
// build — Matthew, 2026-11-16): note 57's hold requested
// the "system" level — CPU awake, display free to sleep.
// On a dealership desk PC the display sleeping is what
// trips the inactivity lock, and the lock is what pauses
// this worker, so the hold now requests "display": the
// system AND the screen stay awake while work is pending,
// the same ground Matthew's PowerShell keep-awake block
// holds (SetThreadExecutionState with the display flag).
// Same "power" permission, same decider, same release
// rules — only the level changed. Honest limits: no
// keep-awake outranks a closed lid, a manual lock, or an
// IT policy that force-sleeps the machine.

// Auto-reply hub duty (v2.1.104, note 57): with the
// availability toggle ON, this install owes the inbox hub
// its watch — pending auto-sends live in that runtime,
// not in the posting queue — so an otherwise-idle cycle
// still counts as work pending. Read ONLY on the idle
// path (an empty queue fetch or a foreign lease), so a
// busy cycle pays nothing for it; any failure reads as
// no duty (the hold simply follows the queue).
async function alHubDutyOn(userId) {
  if (!userId) return false;
  try {
    const rows = await sbGet(`user_settings?user_id=eq.${userId}&select=luca_autoreply_availability`);
    return !!(rows && rows[0] && rows[0].luca_autoreply_availability === true);
  } catch (e) { return false; }
}
async function alKeepAwakeIdle(userId) {
  await alKeepAwakeCycle(await alHubDutyOn(userId));
}

// [PURE-NEVER-GREW-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// list_never_grew retry verdict (v2.1.104, header note 57):
// the failure earns ONE automatic requeue — unless the
// marker of a previous retry is already on the row's
// error_message or in this install's memory, in which
// case the failure is terminal, exactly as before.
function alNeverGrewRetryEligible(reason, rowErrorMessage, storageRetried) {
  if (reason !== "list_never_grew") return false;
  if (storageRetried) return false;
  if (String(rowErrorMessage || "").includes("list_never_grew_retry")) return false;
  return true;
}
// [PURE-NEVER-GREW-END]

// [PERM-FN-BEGIN]
// Permission self-check (v2.1.104, header note 57; audit
// #4, helper half): Chrome can leave an updated helper
// with a permission un-granted (the user must re-approve
// it on the extension card), and until now nothing ever
// looked — jobs just failed one by one. The check runs
// on install/startup and at the top of every claim cycle
// (deduplicated while in flight). It is DETECTION ONLY:
// claiming behavior is unchanged. A missing set is
// recorded in al_permissions_state, written as a NAMED
// structured last-error when the missing set CHANGES
// (missing_permissions: [...]), and read by the ping
// reply as permissions_ok.
let alPermissionsOkCache = null;
let alPermissionsCheckInFlight = null;
async function alPermissionsCheckNow() {
  const state = { ok: null, missing: [], at: new Date().toISOString() };
  try {
    if (chrome.permissions && chrome.permissions.contains &&
        chrome.runtime && chrome.runtime.getManifest) {
      const mf = chrome.runtime.getManifest() || {};
      const required = Array.isArray(mf.permissions) ? mf.permissions.slice() : [];
      if (!required.includes("debugger")) required.push("debugger");
      const all = await chrome.permissions.contains({ permissions: required });
      if (all) {
        state.ok = true;
      } else {
        state.ok = false;
        for (const p of required) {
          let has = true;
          try { has = await chrome.permissions.contains({ permissions: [p] }); }
          catch (e) { has = true; /* a broken probe is not a missing grant */ }
          if (!has) state.missing.push(p);
        }
      }
    }
  } catch (e) { /* detection only — never break the worker */ }
  alPermissionsOkCache = state.ok;
  try {
    const prev = (await chrome.storage.local.get(["al_permissions_state"])).al_permissions_state;
    await chrome.storage.local.set({ al_permissions_state: state });
    const prevKey = prev && prev.ok === false && Array.isArray(prev.missing)
      ? prev.missing.slice().sort().join(",") : "";
    const curKey = state.ok === false ? state.missing.slice().sort().join(",") : "";
    if (curKey && curKey !== prevKey) {
      await chrome.storage.local.set({ autolaunch_last_error: {
        queueId: null,
        reason: "missing_permissions",
        missing_permissions: state.missing,
        at: state.at
      } });
    }
  } catch (e) { /* surfacing is best-effort */ }
  return state;
}
function alPermissionsCycleCheck() {
  if (alPermissionsCheckInFlight) return alPermissionsCheckInFlight;
  const p = alPermissionsCheckNow().catch(() => null);
  alPermissionsCheckInFlight = p;
  p.then(() => { if (alPermissionsCheckInFlight === p) alPermissionsCheckInFlight = null; });
  return p;
}
// [PERM-FN-END]
if (chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(() => { alPermissionsCycleCheck(); });
}
if (chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => { alPermissionsCycleCheck(); });
}

// [SESS-FN-BEGIN]
// Session-expired surface (v2.1.104, header note 57;
// audit #5, helper half): markSessionExpired sets the
// persistent al_session_expired state beside the legacy
// flag; the next call that carries the user's token and
// SUCCEEDS clears both (a bare 200 on an anon-key call
// proves nothing about the user session, so the header
// must carry the stored token itself). A fresh token via
// the bridge handoff clears them too (see the
// AUTOLAUNCH_SET_USER_ID handler).
let alSessionExpiredKnown = false;
async function alNoteAuthenticatedSuccess(headers) {
  try {
    const auth = headers && typeof headers === "object" ? headers.Authorization : null;
    if (!auth) return;
    const tok = await storedAccessToken();
    if (!tok || auth !== `Bearer ${tok}`) return;
    if (!alSessionExpiredKnown) {
      const got = await chrome.storage.local.get(["al_session_expired"]);
      if (got.al_session_expired !== true) return;
    }
    alSessionExpiredKnown = false;
    await chrome.storage.local.set({
      autolaunch_session_expired: false,
      al_session_expired: false
    });
  } catch (e) { /* surfacing is best-effort */ }
}
// [SESS-FN-END]
// [SESS356-BEGIN] — session self-healing
// (v2.1.156, header note 97; spec:
// helper-session-self-healing, 2026-11-16).
// The helper holds only a COPY of the app's
// Supabase access token; copies die on the
// 1-hour token clock and the helper cannot
// mint its own. Through .155 the first 401
// latched autolaunch_session_expired at once
// and the helper waited — silently, possibly
// forever — for the app to spontaneously push
// a fresh copy (2026-11-16: thirteen attach
// jobs sat an hour; 2026-11-19: chat capture
// died the same way). Now the worker ASKS:
// the first auth failure of an episode runs
// one bounded request round — every open app
// tab is asked through the bridge
// (AUTOLAUNCH_REQUEST_TOKEN), the app answers
// through the existing login handoff, and the
// interrupted work resumes (the claim cycle
// re-runs; a stashed finish replays). Failed
// rounds back off 1 -> 5 -> 15 minutes; the
// expired latch is the LAST resort (after 3
// failed rounds), and one new round is
// permitted each time the 15-minute cap
// lapses. A token that answers an ask is
// believed only once it PROVES itself: a
// changed value clears through the existing
// handoff, a same-value answer is validated
// with the settings read (H4), and until the
// first authenticated success the episode
// stays open (awaitVerify), so a still-bad
// token converts the next 401 into backoff
// instead of a fresh ask — no retry carousel.
// SESSION_SELF_HEAL is the kill switch: OFF
// restores .155 exactly (401 -> latch -> wait
// for a push). The token itself is never
// logged, never in an error string, never in
// a pong — reason strings and booleans only.
// [PURE-SESS356-BEGIN] — extracted and
// unit-exercised by the test harness; keep
// free of DOM/chrome references.
const SESS356_BACKOFF_MS = [60000, 300000, 900000];
function sessHeal356Zero() {
  return { rounds: 0, nextAskAt: 0, awaitVerify: false };
}
function sessHeal356Plan(state, now, healOn) {
  if (!healOn) return { action: "off" };
  const s = state || sessHeal356Zero();
  if (s.awaitVerify) return { action: "await_verify" };
  if (typeof s.nextAskAt === "number" && now < s.nextAskAt) {
    return { action: "wait", waitMs: s.nextAskAt - now };
  }
  return { action: "ask" };
}
function sessHeal356AfterFailure(state, now) {
  const s = state || sessHeal356Zero();
  const rounds = (typeof s.rounds === "number" ? s.rounds : 0) + 1;
  const idx = Math.min(rounds - 1, SESS356_BACKOFF_MS.length - 1);
  return {
    rounds,
    nextAskAt: now + SESS356_BACKOFF_MS[idx],
    awaitVerify: false,
    latch: rounds >= 3
  };
}
// [PURE-SESS356-END]
const SESSION_SELF_HEAL = true;
let alSessHeal356Busy = false;
let alSessHeal356Validating = false;
let alSessHeal356Waiter = null;
let alSessHeal356Rerun = false;
async function alSessHeal356Load() {
  try {
    const got = await chrome.storage.local.get(["al_sess_heal"]);
    const s = got && got.al_sess_heal;
    if (s && typeof s === "object") {
      return {
        rounds: typeof s.rounds === "number" ? s.rounds : 0,
        nextAskAt: typeof s.nextAskAt === "number" ? s.nextAskAt : 0,
        awaitVerify: s.awaitVerify === true
      };
    }
  } catch (e) { /* heal is best-effort */ }
  return sessHeal356Zero();
}
async function alSessHeal356Save(state) {
  try {
    await chrome.storage.local.set({ al_sess_heal: {
      rounds: state.rounds, nextAskAt: state.nextAskAt,
      awaitVerify: state.awaitVerify === true
    } });
  } catch (e) { /* heal is best-effort */ }
}
// The SET_USER_ID handler calls this AFTER its
// storage write lands: a token delivered while
// a request round is outstanding is that
// round's answer, whatever its value. The
// round wakes once the episode is marked
// awaitVerify, so the answer's validity — not
// its novelty — decides what happens next.
function alSessHeal356NoteAnswer() {
  const w = alSessHeal356Waiter;
  if (!w) return;
  alSessHeal356Waiter = null;
  (async () => {
    const s = await alSessHeal356Load();
    s.awaitVerify = true;
    await alSessHeal356Save(s);
    w.resolve(true);
  })();
}
async function requestFreshToken356() {
  if (!SESSION_SELF_HEAL) return false;
  if (alSessHeal356Busy) return false;
  alSessHeal356Busy = true;
  try {
    const state = await alSessHeal356Load();
    const plan = sessHeal356Plan(state, Date.now(), SESSION_SELF_HEAL);
    if (plan.action !== "ask") return false;
    let tabs = [];
    try { tabs = await chrome.tabs.query({}); } catch (e) { tabs = []; }
    const appTabs = (tabs || []).filter(t => t && t.id != null && isAppUrl(t.url));
    const reqId = "tok356-" + Date.now().toString(36) + "-" +
      Math.random().toString(36).slice(2, 8);
    let answered = false;
    if (appTabs.length) {
      answered = await new Promise((resolve) => {
        let settled = false;
        const done = (v) => {
          if (settled) return;
          settled = true;
          alSessHeal356Waiter = null;
          resolve(v);
        };
        alSessHeal356Waiter = { reqId, resolve: (v) => done(v) };
        setTimeout(() => done(false), 5000);
        let sent = 0;
        for (const t of appTabs) {
          try {
            chrome.tabs.sendMessage(t.id,
              { type: "AUTOLAUNCH_REQUEST_TOKEN", reqId },
              () => { void chrome.runtime.lastError; });
            sent++;
          } catch (e) { /* a dead bridge on this tab — the next may answer */ }
        }
        if (!sent) done(false);
      });
    }
    if (!answered) {
      const ns = sessHeal356AfterFailure(state, Date.now());
      await alSessHeal356Save(ns);
      if (ns.latch) await markSessionExpired();
      return false;
    }
    // An answer landed. A CHANGED token already
    // cleared the expired flags inside the
    // SET_USER_ID handler; the episode zeroes
    // on the first authenticated success
    // (alSessHeal356NoteSuccess).
    const chk = await chrome.storage.local.get(["autolaunch_session_expired"]);
    if (chk.autolaunch_session_expired !== true) return true;
    // SAME token value (spec H4): prove it or
    // fail the round — validate with the
    // cheapest authenticated read the worker
    // already makes, the settings read at the
    // top of checkQueue.
    const uid = (await chrome.storage.local.get(["autolaunch_user_id"])).autolaunch_user_id;
    let valid = false;
    if (uid) {
      alSessHeal356Validating = true;
      try { await userSettings(uid); valid = true; }
      catch (e) { valid = false; }
      alSessHeal356Validating = false;
    }
    if (valid) {
      await chrome.storage.local.set({
        autolaunch_session_expired: false,
        al_session_expired: false
      });
      alSessionExpiredKnown = false;
      await alSessHeal356Save(sessHeal356Zero());
      await flushPendingFinish();
      checkQueue();
      return true;
    }
    const ns2 = sessHeal356AfterFailure(await alSessHeal356Load(), Date.now());
    await alSessHeal356Save(ns2);
    if (ns2.latch) await markSessionExpired();
    return false;
  } catch (e) {
    return false; /* heal is best-effort; the 401 throw stands */
  } finally {
    alSessHeal356Busy = false;
  }
}
// sbFetch's auth-failure hook (spec H1): the
// first failure of an episode asks before
// anything is allowed to latch. While a round
// is in flight or a validation read is running
// this is a no-op — that machinery owns the
// outcome.
async function alSessHeal356OnAuthFailure() {
  if (!SESSION_SELF_HEAL) return;
  if (alSessHeal356Busy || alSessHeal356Validating) return;
  try {
    const state = await alSessHeal356Load();
    if (state.awaitVerify) {
      // A token that answered our ask still
      // fails: that round failed — convert it
      // (a second 401 in the same episode goes
      // straight to backoff, never a fresh ask).
      const ns = sessHeal356AfterFailure(state, Date.now());
      await alSessHeal356Save(ns);
      if (ns.latch) await markSessionExpired();
      return;
    }
    const plan = sessHeal356Plan(state, Date.now(), SESSION_SELF_HEAL);
    if (plan.action !== "ask") return;
    const healed = await requestFreshToken356();
    if (healed) {
      // Resume the interrupted work once, with
      // the new token: a claim cycle in flight
      // re-runs from its finally; a finish that
      // is about to stash replays on the next
      // macrotask, after its catch has landed.
      if (isChecking) alSessHeal356Rerun = true;
      setTimeout(() => { flushPendingFinish(); }, 0);
    }
  } catch (e) { /* heal is best-effort */ }
}
// checkQueue's latched branch (spec H2): the
// latch is the last resort, not the end — once
// the 15-minute cap lapses, one new round is
// permitted.
async function alSessHeal356CapRound() {
  if (!SESSION_SELF_HEAL || alSessHeal356Busy) return false;
  const state = await alSessHeal356Load();
  if (!(state.rounds >= 3)) return false;
  if (Date.now() < state.nextAskAt) return false;
  return requestFreshToken356();
}
// A call that carried the stored token and
// SUCCEEDED proves the session — the episode
// resets (spec H2). Mirrors
// alNoteAuthenticatedSuccess's header check:
// a bare anon-key 200 proves nothing.
async function alSessHeal356NoteSuccess(headers) {
  if (!SESSION_SELF_HEAL) return;
  try {
    const auth = headers && typeof headers === "object" ? headers.Authorization : null;
    if (!auth) return;
    const tok = await storedAccessToken();
    if (!tok || auth !== `Bearer ${tok}`) return;
    const s = await alSessHeal356Load();
    if (s.rounds > 0 || s.awaitVerify || s.nextAskAt > 0) {
      await alSessHeal356Save(sessHeal356Zero());
    }
  } catch (e) { /* best-effort */ }
}
// [SESS356-END]
// [WORKER-HEALTH-304-END] =================================

async function checkQueue() {
  if (isChecking) return;
  isChecking = true;
  try {
    const {
      autolaunch_user_id: userId,
      autolaunch_access_token: accessToken,
      autolaunch_session_expired: sessionExpired,
      current_posting_job: activeJob
    } = await chrome.storage.local.get([
      "autolaunch_user_id", "autolaunch_access_token",
      "autolaunch_session_expired", "current_posting_job"
    ]);
    alPermissionsCycleCheck();
    if (!userId) { await alKeepAwakeCycle(false); return; }  // not signed in to AutoLaunch yet
    if (sessionExpired) {
      // [SESS356] the latch is the last resort, not the
      // end (spec H2): once the 15-minute cap lapses,
      // one new ask round is permitted before waiting.
      const healed356 = SESSION_SELF_HEAL ? await alSessHeal356CapRound() : false;
      if (!healed356) { await alKeepAwakeCycle(false); return; }  // dead token — wait for a fresh one via the bridge
    }
    if (!accessToken) {                // bridge hasn't delivered a session yet
      await noteWaitingForLogin();
      await alKeepAwakeCycle(false);
      return;
    }
    if (activeJob) {
      // One car at a time, always — but verify the stored job is
      // still a live run before honouring the slot (v2.1.8): a
      // run stopped out-of-band (row cancelled in the app, tab
      // closed) never sends its finish, and an unreconciled slot
      // would wedge every future claim behind it, silently.
      const slotKept = await reconcileActiveJob(activeJob);
      if (slotKept) { await alKeepAwakeCycle(true); return; }
      // The slot was dead and has been cleared — fall through and
      // claim fresh work in this same pass.
    }

    const settings = await userSettings(userId);

    // One-active-helper lease (v2.1.60, header note 32): only
    // ONE helper instance per account may claim. The lease rode
    // this cycle's settings fetch — no extra round trip. Foreign
    // + unexpired -> claim nothing and stay dormant (the cycle
    // keeps polling; the lease may expire or be yielded).
    // Otherwise renew — ONE PATCH, expiry now + TTL — and claim
    // as before. A failed renew throws into the cycle's catch:
    // no claim happens on an unproven lease (fail closed). The
    // gate sits AFTER job-slot reconciliation on purpose: the
    // lease gates NEW claims only, never the bookkeeping of a
    // job already in flight.
    const myInstanceId = await getOrCreateInstanceId();
    if (helperLeaseDecision(settings.leaseId, settings.leaseExpiresAt, myInstanceId, Date.now()) === "foreign") {
      console.log("[AutoLaunch] Another computer holds this account's helper lease — standing by, no claims this cycle.");
      await alKeepAwakeIdle(userId);
      return;
    }
    await sbPatch(`user_settings?user_id=eq.${userId}`, {
      helper_lease_id: myInstanceId,
      helper_lease_expires_at: new Date(Date.now() + HELPER_LEASE_TTL_MS).toISOString()
    });

    // The claim set (v2.1.4): Marketplace POST rows (target_channel
    // 'marketplace') and Facebook DELETE rows (target_channel
    // 'facebook', action 'delete') — the jobs this helper runs.
    // v2.1.55 adds Facebook SHARE rows (target_channel 'facebook',
    // action 'share') to the same set. v2.1.62 adds Facebook
    // PRICE UPDATE rows (action 'update_price') the same way.
    // Other channels' rows belong to other workers; never touch them.
    const queueItems = await sbGet(
      `auto_posting_queue?user_id=eq.${userId}&status=eq.pending` +
      `&awaiting_reel=eq.false` +
      `&target_channel=in.(marketplace,facebook)&order=created_at.asc&limit=5`
    );
    if (!queueItems.length) { await alKeepAwakeIdle(userId); return; }

    // Daily safety limit — enforced here too, not just in the UI,
    // and it gates POSTS only: a removal is not a post, and being at
    // the cap must never strand a listing the user asked to take down.
    let atLimit = false;
    if (settings.limit < 999) {
      const postedToday = await todaysPostCount(userId);
      atLimit = postedToday >= settings.limit;
      if (atLimit) {
        console.log(`[AutoLaunch] Daily limit reached (${postedToday}/${settings.limit}). Posts wait; deletes, shares and price updates still run.`);
      }
    }
    // Post pacing (v2.1.42, header note 19): post_delay_minutes is
    // the minimum gap between a COMPLETED post and claiming the
    // next POST row. Deletes are exempt, exactly like the daily
    // limit — pacing spaces posts, never removals. No configured
    // delay (0) means no gate; a missing last-post stamp (never
    // posted, or the lookup failed) also means no gate.
    // v2.1.88: the some() reads through the claim allowlist —
    // only a claimable POST can hold the cycle for pacing;
    // an unknown action never triggers the lookup.
    let pacingHeld = false;
    if (settings.delayMinutes > 0 && queueItems.some(q => claimActionOf(q) === "post")) {
      const lastPost = await lastPostedAt(userId);
      if (lastPost !== null) {
        const sinceMin = (Date.now() - lastPost) / 60000;
        if (sinceMin < settings.delayMinutes) {
          pacingHeld = true;
          console.log(`[AutoLaunch] Post pacing: last post ${Math.floor(sinceMin)} min ago; holding posts ~${Math.ceil(settings.delayMinutes - sinceMin)} more min (delay ${settings.delayMinutes} min). Deletes, shares and price updates still run.`);
        }
      }
    }
    // Gate-chain records (v2.1.121, header note 72): read
    // once per claim cycle — the selection loop consults
    // them for attach rows, the payload assembly for the
    // chain flag. Fail-open: an unreadable map simply
    // leaves every attach row dormant, as in 3.20.
    const gateChainMap321 = await getGateChainMap();
    let item = null;
    let itemAction = null;
    // [ADOPT-340-DECL-BEGIN]
    let adoptedAttach340 = false;
    // [ADOPT-340-DECL-END]
    for (const q of queueItems) {
      // The claim ACTION ALLOWLIST (v2.1.88, header note 43):
      // only actions this build knows are selectable at all.
      // An unknown action is skipped — NEVER claimed as a
      // post — and the skip is logged so a future producer's
      // row is visible in the console instead of silently
      // becoming a listing.
      const a = claimActionOf(q);
      if (a === null) {
        console.warn(`[AutoLaunch] Queue row ${q.id} carries unknown action "${q.action}" — not claimed (allowlist).`);
        continue;
      }
      if (a === "attach_video") {
        // Post-hoc attach claims are DORMANT in this build
        // (v2.1.118, header note 69): the revamp attaches
        // poster reels at creation, ready-only, so no
        // attach row is ever claimed here. The row is left
        // pending, untouched; the editor machinery below
        // stays in place, un-run.
        // 3.21 exception (header note 72): a row a live
        // gate chain is waiting on (its parent post is up
        // and the reel still has to be put on the listing)
        // IS claimed — the chain record, keyed by VIN, is
        // the only thing that can wake an attach row, and
        // dedupe guarantees at most one live attach row
        // per VIN for it to mean.
        const chain321 = gateChainMap321[q.vin];
        if (chain321 && chain321.stage === "attach" &&
            chain321.parentQueueId) {
          item = q; itemAction = "attach_video"; break;
        }
        // [ADOPT-340-BEGIN] — orphaned attach adoption
        // (v2.1.140, header note 90): no live chain record
        // for this VIN and the row is past the arming
        // window — claim it as a plain attach job under
        // decideAttachAdoption340. The basis gates below
        // (posted stamp + price, ready poster reel) still
        // run exactly as for a chained claim; no chain
        // record is written and no gateChain flag rides
        // the payload, so its finishes settle on the row
        // alone.
        if (decideAttachAdoption340(q, chain321 || null, Date.now())) {
          item = q; itemAction = "attach_video";
          adoptedAttach340 = true; break;
        }
        // [ADOPT-340-END]
        console.log(`[AutoLaunch] Queue row ${q.id} is an attach_video row — not claimed (3.18: editor attach dormant).`);
        continue;
      }
      // [PRICE-RECOVERY-338-DUE-BEGIN] — price recovery
      // backoff (v2.1.138, header note 88): an update_price
      // row inside its 24h recovery window, on the same
      // helper version that failed it, is skipped — never
      // claimed early, and never blocking the rows behind
      // it. A helper version change makes it due at once.
      if (a === "update_price" &&
          !priceRecoveryDue338(parsePriceRecovery338(q.error_message),
            PRICE_RECOVERY_VERSION_338, Date.now())) {
        console.log(`[AutoLaunch] Queue row ${q.id} is a price update in recovery backoff — not claimed yet.`);
        continue;
      }
      // [PRICE-RECOVERY-338-DUE-END]
      if (a !== "post") { item = q; itemAction = a; break; }
      if (!atLimit && !pacingHeld) { item = q; itemAction = "post"; break; }
    }
    // [ENV-DEFER-339-CLAIM-BEGIN] — attach claim-window
    // diagnostic (v2.1.139, header note 89): if this
    // cycle's window held attach rows and none was
    // claimed, record the window + chain states
    // (throttled, fail-open) — the dormancy that kept
    // attach rows unclaimed for a whole evening on
    // 2026-11-16 was invisible in every record the
    // helper kept.
    await noteAttachClaimWindow339(queueItems, gateChainMap321, itemAction);
    // [ENV-DEFER-339-CLAIM-END]
    if (!item) { await alKeepAwakeCycle(true); return; } // only posts waiting, and the cap (or pacing) says wait — still pending work
    const isDelete = itemAction === "delete";
    const isShare = itemAction === "share";
    // Price updates (v2.1.62, header note 34) ride the delete/share
    // exemptions everywhere below: not a post — never capped, never
    // paced, never photo-gated, never intro-video'd.
    const isUpdatePrice = itemAction === "update_price";
    // Edit-flow video attach (v2.1.88, header note 43): the
    // same exemptions, for the same reason — it edits a live
    // listing; it does not post one.
    const isAttachVideo = itemAction === "attach_video";
    // [RECONCILE-336-CLAIM-BEGIN] — reconciliation sweep
    // (v2.1.136, header note 86): a reconcile row carries
    // no car and no VIN — it is an account-level read, not
    // a listing action — so it branches off BEFORE the car
    // fetch and every car-shaped gate below. The claim is
    // the same conditional patch every action uses;
    // launchReconcileSweep336 owns the run from there
    // (run row, job slot, background tab) and
    // finishReconcileSweep336 settles the row when the
    // content side reports back.
    const isReconcile = itemAction === "reconcile";
    if (isReconcile) {
      const claimed336 = await sbPatch(
        `auto_posting_queue?id=eq.${item.id}&status=eq.pending`,
        { status: "processing" }
      );
      if (!claimed336.length) return; // someone/something else took it
      await launchReconcileSweep336(item, userId);
      await alKeepAwakeCycle(true);
      return;
    }
    // [RECONCILE-336-CLAIM-END]
    // [VERIFY-342-CLAIM-BEGIN] — verify_listing
    // (v2.1.142, header note 92): a read-only ground-truth
    // read for Luna Repairs (spec §4: verify before
    // repair). The row carries a car identity but no
    // posting intent, so it branches off beside reconcile,
    // BEFORE the car fetch and every posting gate below.
    // The claim is the same conditional patch every action
    // uses; launchVerifyListing342 owns the run from there
    // and finishVerifyListing342 settles the row.
    const isVerifyListing = itemAction === "verify_listing";
    if (isVerifyListing) {
      const claimed342 = await sbPatch(
        `auto_posting_queue?id=eq.${item.id}&status=eq.pending`,
        { status: "processing" }
      );
      if (!claimed342.length) return; // someone/something else took it
      await launchVerifyListing342(item, userId);
      await alKeepAwakeCycle(true);
      return;
    }
    // [VERIFY-342-CLAIM-END]

    const cars = await sbGet(
      `scraped_inventory?vin=eq.${encodeURIComponent(item.vin)}&user_id=eq.${userId}&limit=1`
    );
    let carRow = cars.length ? cars[0] : null;
    if (isUpdatePrice) {
      // Basis validation (v2.1.62, header note 34): the exact
      // drift this row was queued for must still exist — the car
      // still posted, its stamped posted price still the row's
      // FROM price, its current price still the row's TO price.
      // Anything else means the world moved; fail the row
      // untouched (the next sync re-queues the truth) rather
      // than editing a listing on stale instructions.
      const gate = priceUpdateClaimGate(item, carRow);
      if (!gate.ok) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, gate.reason);
        console.log(`[AutoLaunch] Price update for VIN ${item.vin} not claimed: ${gate.reason}.`);
        return;
      }
    }
    // [PRICE-GATE-347-BEGIN] — minimum-delta settle
    // (v2.1.147, header note 94): the basis gate above has
    // proven this drift is real; a drift under
    // PRICE_EDIT_MIN_DELTA settles the row completed HERE —
    // still pending, never claimed, no job stored, no tab
    // opened, no Facebook action of any kind. The settle
    // mirrors the verify finish's completed shape (status +
    // executed_at + the record riding error_message, where
    // the queue card surfaces it). A skip is not a failure:
    // no logFailure, no recovery markers — the row is done,
    // and a fresh row is queued only when the dealer's price
    // has moved $500 or more from the listing's price.
    if (isUpdatePrice) {
      const minDelta347 = decidePriceEditMinDelta347(item);
      if (minDelta347.skip) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, {
          status: "completed",
          executed_at: new Date().toISOString(),
          error_message: minDelta347.errorMessage
        });
        console.log(`[AutoLaunch] Price update for VIN ${item.vin} skipped: $${minDelta347.delta} under the $${PRICE_EDIT_MIN_DELTA} minimum — settled without opening Facebook.`);
        return;
      }
    }
    // [PRICE-GATE-347-END]
    let attachReelHit = null;
    if (isAttachVideo) {
      // Basis validation (v2.1.88, header note 43), the price
      // gate's twin: the car still posted, its stamped posted
      // price still the row's price — and a ready POSTER reel
      // must still exist for the VIN (the completion that
      // queued this row left it ready; anything else means
      // the world moved). Fail the row untouched on any miss.
      const gate = attachVideoClaimGate(item, carRow);
      if (!gate.ok) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, gate.reason);
        console.log(`[AutoLaunch] Video attach for VIN ${item.vin} not claimed: ${gate.reason}.`);
        return;
      }
      const hit = await reelForJob(userId, item.vin);
      if (!hit || !hit.reel || hit.reel.source !== "poster") {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, "attach_reel_not_ready");
        console.log(`[AutoLaunch] Video attach for VIN ${item.vin} not claimed: no ready poster reel.`);
        return;
      }
      attachReelHit = hit;
    }
    if (!carRow && !isDelete && !isShare) {
      // Queue row points at a car that no longer exists: fail it loudly
      // instead of leaving it pending forever.
      await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
      await logFailure(item.id, "inventory_row_missing");
      return;
    }
    if (!carRow && (isDelete || isShare)) {
      // A delete can outlive its inventory row — by design: the
      // delete-job contract is producer-agnostic (the Remove button
      // today; an inventory-lifecycle auto-removal rule later, which
      // fires exactly when the car LEAVES inventory). The payload
      // therefore falls back to the queue row's own year/make/model
      // AND price, which producers stamp on the row at insert. Only a
      // row stamped without a price leaves the matcher nothing strict
      // to match — and then it refuses (listing_not_found) rather
      // than guessing at a twin.
      carRow = {
        vin: item.vin,
        year: item.year != null ? item.year : null,
        make: item.make || null,
        model: item.model || null,
        stock_num: item.stock_num || null,
        price: item.price != null ? Number(item.price) : null
      };
    }
    if (carRow && (isDelete || isShare) && carRow.price == null && item.price != null) {
      // Inventory row exists but carries no price; the row's stamped
      // price is the better evidence for the strict match.
      carRow = Object.assign({}, carRow, { price: Number(item.price) });
    }

    // NO-PHOTO RULE (mirrors hasRealPhoto in the web app): a vehicle with
    // no real photos is never posted — its photos may have vanished after
    // it was queued. Fail the row loudly, same as a missing car, instead
    // of handing a photo-less listing to Facebook. POSTS ONLY: a delete
    // removes a listing, and a car whose photos vanished is exactly the
    // car whose listing should come down.
    if (!isDelete && !isShare && !isUpdatePrice && !isAttachVideo) {
      // Fallback placeholders are never real photos: the old hotlinked
      // Unsplash URL (rows stored before 2.1.11 may still carry it), the
      // local fallback asset in both the absolute Pages form a stored
      // row could carry and the relative form the app now uses.
      const FALLBACK_PHOTOS = [
        "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800&auto=format&fit=crop&q=80",
        "https://mdemoss-bdc.github.io/AutoLaunch/luna-rebuild/assets/no-photo.png",
        "assets/no-photo.png"
      ];
      const usablePhoto = u => {
        if (!u || typeof u !== "string") return false;
        let s = u.trim();
        if (s.startsWith("//")) s = "https:" + s;
        return /^https?:\/\//i.test(s) && !s.includes("/static/") && !FALLBACK_PHOTOS.includes(s);
      };
      const hasPhoto = usablePhoto(carRow.image_url) ||
        (Array.isArray(carRow.custom_photo_urls) && carRow.custom_photo_urls.some(usablePhoto));
      if (!hasPhoto) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}&status=eq.pending`, { status: "failed" });
        await logFailure(item.id, "no_photos");
        return;
      }
    }

    // Conditional claim: only succeeds while the row is still pending.
    const claimed = await sbPatch(
      `auto_posting_queue?id=eq.${item.id}&status=eq.pending`,
      { status: "processing" }
    );
    if (!claimed.length) return; // someone/something else took it
    // [ADOPT-340-CLAIM-BEGIN] — the adoption breadcrumb
    // (v2.1.140, header note 90): filed on the failure-log
    // channel the claim-window diagnostic uses, so a desk
    // proof can see the row ran adopted. Fail-open: the
    // claim stands without its breadcrumb.
    if (isAttachVideo && adoptedAttach340) {
      try {
        await logFailure(item.id, "attach_adopted_340");
      } catch (e) { /* breadcrumb only */ }
      console.log(`[AutoLaunch] Attach row ${item.id} adopted (no live chain record for VIN ${item.vin}) — running as a plain attach job.`);
    }
    // [ADOPT-340-CLAIM-END]

    // Claim-time stamp check (v2.52, header note 26): the car
    // already carries marketplace_posted_at — an earlier run
    // reached Facebook and only its bookkeeping was lost (the
    // false-failure class behind the 2026-10-28 Passport
    // duplicates). Complete the row as posted WITHOUT storing
    // a job or opening a tab, and WITHOUT touching the stamp:
    // the existing value is the truth. The row's executed_at
    // fingerprints this path (applyPosted rows carry none).
    if (!isDelete && !isShare && !isUpdatePrice && !isAttachVideo && carRow.marketplace_posted_at) {
      await sbPatch(`auto_posting_queue?id=eq.${item.id}`,
        { status: "posted", executed_at: new Date().toISOString() });
      console.log(`[AutoLaunch] already_posted_at_claim: queue item ${item.id} (VIN ${item.vin}) already carries marketplace_posted_at ${carRow.marketplace_posted_at} — completed without posting.`);
      return;
    }

    const jobPayload = {
      queueId: item.id,
      userId,
      car: jobCarWithStock(carRow, item),
      action: isDelete ? "delete" : isShare ? "share" : isUpdatePrice ? "update_price" : isAttachVideo ? "attach_video" : "post",
      fullAuto: settings.fullAuto,
      dealershipName: settings.dealershipName,
      dealershipAddress: settings.dealershipAddress,
      // Rep contact pair (v2.1.90, header note 45): carried
      // exactly like the dealership identity; both composers
      // append the closing line only when both are present.
      repName: settings.repName,
      repPhone: settings.repPhone,
      includeStock: settings.includeStock,
      // Rich descriptions (v2.1.98, header note 51): the
      // account switch, carried exactly like includeStock.
      richDesc: settings.richDesc === true,
      shareToFeed: settings.shareToFeed === true,
      // Share details text (v2.1.56, header note 30): the row's
      // share_text rides SHARE jobs only; the content script
      // places it in the share composer before confirming.
      // Absent (a pre-column row) the job carries "" and the
      // share fails honestly rather than posting bare.
      shareText: isShare && typeof item.share_text === "string" ? item.share_text : "",
      // Price update (v2.1.62, header note 34; §4E revision
      // v2.1.130, header note 81): the FROM price (what the
      // listing showed when the job was queued — evidence for
      // the scan notes, no longer a match target or a gate)
      // and the TO price (what the editor sets), carried only
      // on update_price jobs; the basis gate above has proven
      // the TO half against the fresh inventory row.
      updateFromPrice: isUpdatePrice ? Number(item.update_from_price) : null,
      updateToPrice: isUpdatePrice ? Number(item.price) : null,
      // The queue row's stamped price (v2.1.62): the price a post
      // publishes with, written to the inventory row as
      // marketplace_posted_price when the post completes.
      queuePrice: item.price != null ? Number(item.price) : null,
      // Edit-flow video attach (v2.1.88, header note 43): the
      // POSTED price (the strict matcher's target — the
      // inventory row's current price may already have moved)
      // and the resolved poster reel, carried only on
      // attach_video jobs; the claim gate above has already
      // proven both against the fresh rows.
      attachPostedPrice: isAttachVideo ? Number(item.price) : null,
      attachReel: attachReelHit
        ? { url: attachReelHit.url, reelId: attachReelHit.reel.id } : null,
      claimedAt: new Date().toISOString()
    };
    // Listing-ID memory (2.91 build): the stored Facebook
    // listing ID for this VIN rides update_price and
    // attach_video jobs, so their listing phases can
    // navigate straight to the listing's editor when an
    // editor-URL pattern is known. Absent (never harvested,
    // or cleared after a failed attempt) the job runs
    // exactly as before. §4E (v2.1.130, header note 81):
    // delete jobs carry it too — not for navigation, but
    // as the identity anchor that tells this VIN's card
    // from a twin's when the strict match cannot.
    if (isUpdatePrice || isAttachVideo || isDelete) {
      const listingMem = await listingIdMemoryFor(item.vin);
      if (listingMem) jobPayload.listingMemory = listingMem;
    }
    // [PRICE-RECOVERY-338-PAYLOAD-BEGIN] — the row's
    // recovery markers ride the payload (v2.1.138, header
    // note 88): the content side reads the spent-attempt
    // count to run verify-before-retry and to know when
    // the escalation budget is exhausted.
    if (isUpdatePrice) {
      jobPayload.priceRecovery = {
        attempts: parsePriceRecovery338(item.error_message).attempts
      };
    }
    // [PRICE-RECOVERY-338-PAYLOAD-END]
    // [DELETE-SETTLE-354-BEGIN] — the finish banner's
    // settle projection (v2.1.154, header note 94): a
    // delete's row settles back to pending exactly
    // when the worker's one list_never_grew auto-retry
    // will fire — its eligibility is decided at finish
    // time from the row's error and the retry memory,
    // so the banner's projection is computed here from
    // those same inputs (the worker's own verdict
    // function), plus the env-defer the content side
    // detects itself from its diagnostics. "retry"
    // means the settled outcome will be deferred-held,
    // never failed.
    if (isDelete) {
      let storageRetried354 = false;
      try {
        const got354 = await chrome.storage.local.get(["al_never_grew_retried"]);
        storageRetried354 = Array.isArray(got354.al_never_grew_retried) &&
          got354.al_never_grew_retried.includes(item.id);
      } catch (e) { /* memory is a backstop, not a gate */ }
      jobPayload.deleteSettle354 =
        alNeverGrewRetryEligible("list_never_grew", item.error_message, storageRetried354)
          ? "retry" : "terminal";
    }
    // [DELETE-SETTLE-354-END]
    // Gate chain (v2.1.121, header note 72): an attach
    // job claimed under a live chain record carries the
    // flag — its verify verdict is read on the live
    // listing page, and its finish propagates to the
    // parent post row. No record, no flag: the job is
    // exactly a 3.20 attach job.
    if (isAttachVideo && gateChainMap321[item.vin] &&
        gateChainMap321[item.vin].stage === "attach") {
      jobPayload.gateChain = true;
      // Aim seeding (v2.1.124, header note 75): the
      // chain record's listing identity rides the
      // payload, so the claimed attach job STARTS with
      // its aim in the stored job itself — no editor
      // incarnation has to produce it as a side effect.
      const aimPayload324 =
        gateChainPayloadAim324(gateChainMap321[item.vin]);
      if (aimPayload324) jobPayload.attachVideo = aimPayload324;
    }
    // [ADOPT-340-PAYLOAD-BEGIN] — an adopted orphan
    // (v2.1.140, header note 90) carries its provenance on
    // the payload only: no finish consults it (the absence
    // of a chain record is what keeps its settles plain);
    // it exists so the stored job says how it came to run.
    if (isAttachVideo && adoptedAttach340) {
      jobPayload.attachAdopted = true;
    }
    // [ADOPT-340-PAYLOAD-END]
    // Intro video (v2.1.53, header note 27): resolved at claim
    // time and carried on the job; posts only — a delete has no
    // composer to attach to. Absent = the post runs exactly as
    // before this version.
    if (!isDelete && !isShare && !isUpdatePrice && !isAttachVideo) {
      // VIN reel (v2.1.85, header note 40): a ready reel for
      // this car replaces the intro video for this post — it
      // rides the same job slot the content side already
      // attaches from. No ready reel: the intro resolution
      // runs exactly as before.
      // User vehicle video (v2.1.166, header note 98): the
      // user's own recorded video outranks the rendered
      // reel — a ready one rides as this post's reelHit
      // (same staging, same attach), and one still
      // processing HOLDS the post (the normalization worker
      // releases the hold when the video lands ready or
      // fails; the claim then attaches it or falls back).
      // No row / failed / consumed: the reel resolution
      // below runs exactly as before.
      const uvHit166 = await userVideoForJob(userId, item.vin);
      if (uvHit166 && uvHit166.pending) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}`, {
          status: "pending",
          awaiting_reel: true,
          error_message: "user_video_processing:" + uvHit166.status
        });
        await logFailure(item.id, "user_video_claim_hold:" + uvHit166.status);
        console.log(`[AutoLaunch] User video: post for VIN ${item.vin} held — the user's video is still processing (${uvHit166.status}).`);
        return;
      }
      const reelHit = uvHit166 || await reelForJob(userId, item.vin);
      if (reelHit) {
        if (reelHit.userVideo) jobPayload.userVideo = reelHit.userVideo;
        jobPayload.introVideo = { url: reelHit.url, videoId: null };
        jobPayload.reel = reelHit.reel;
        // Ready-only gate (v2.1.118, header note 69): a
        // FLAGGED job whose poster reel rides carries the
        // gate onto the job — the content side aborts
        // rather than post bare if the clip never lands,
        // and the finish re-holds instead of settling.
        if (reelHit.reel && (reelHit.reel.source === "poster" ||
            reelHit.reel.source === "uservideo") &&
            reelJobFlagged(settings, item)) {
          jobPayload.reelGate = true;
        }
        // [PWV348-STAGE-BEGIN] — post-with-video
        // (v2.1.148, header note 95): a ready reel means
        // this post stages its media and carries the
        // video through the CREATE flow (the Nov 18
        // walkthrough flow) instead of posting bare and
        // chaining an editor attach. The introVideo slot
        // is suppressed — the content side feeds the
        // staged files instead — and a gated job's gate
        // becomes the pwv gate (same settle, new abort
        // reasons). Staging failure leaves the payload
        // exactly as .147 built it: the proven flow
        // runs, with the failure on the failure log.
        try {
          const staged348 = await stagePwvMedia348(userId, item, carRow, reelHit);
          if (staged348.ok) {
            delete jobPayload.introVideo;
            if (jobPayload.reelGate === true) {
              jobPayload.pwvGate348 = true;
              delete jobPayload.reelGate;
            }
            // [PWV350-GATESETTLE-BEGIN] — the projected
            // settle for this job's NEXT gate abort
            // (v2.1.150): the worker's settle rule is a
            // pure function of the row's current abort
            // count, so the finish banner can say re-hold
            // vs FAILED truthfully before the settle runs.
            if (jobPayload.pwvGate348 === true) {
              jobPayload.gateSettle350 =
                decideReelGateAbort(
                  reelAbortCountFromError(item.error_message)).action ===
                    "needs_attention" ? "failed" : "rehold";
            }
            // [PWV350-GATESETTLE-END]
            jobPayload.postWithVideo = {
              staged: true, folder: staged348.folder,
              photoCount: staged348.photoCount,
              reelBytes: staged348.reelBytes || 0
            };
          } else {
            console.warn("[AutoLaunch] Post-with-video staging failed; running the pre-.148 flow.", staged348.error);
            await logFailure(item.id, "pwv348_stage_failed:" + staged348.error).catch(() => {});
          }
        } catch (e) {
          console.warn("[AutoLaunch] Post-with-video staging threw; running the pre-.148 flow.", e);
        }
        // [PWV348-STAGE-END]
      } else {
        // Ready-only gate (v2.1.118, header note 69): a
        // flagged post with NO ready reel is NOT posted —
        // the row returns to held with the reason on its
        // record, no tab opens, and a later ready release
        // claims it again. Unflagged rows never reach the
        // check (no extra read, no new branch taken).
        const gate = await reelGateClaimCheck(userId, item, settings);
        if (gate.hold) {
          // Ready-only claim hold (v2.1.119, header note
          // 70): the row returns to held under the gate's
          // own loud text — the check may have started
          // the render itself — and gains the producer's
          // reel_requested_at marker when it never
          // carried one, so a helper-held manual row is
          // downstream-identical to a producer hold.
          const holdPatch = {
            status: "pending",
            awaiting_reel: true,
            error_message: gate.errorText ||
              reelGateErrorText("hold", { status: gate.status })
          };
          if (item.reel_requested_at == null ||
              item.reel_requested_at === "") {
            holdPatch.reel_requested_at = new Date().toISOString();
          }
          await sbPatch(`auto_posting_queue?id=eq.${item.id}`, holdPatch);
          await logFailure(item.id, "reel_claim_hold:" + gate.status);
          console.log(`[AutoLaunch] Reel gate: flagged post for VIN ${item.vin} held — reel not ready (${gate.status}); not posted (ready-only rule).`);
          return;
        }
        // [PWV348-HOLD-BEGIN] — generalized hold
        // (v2.1.148, header note 95; spec Rule 1): an
        // UNFLAGGED post whose reel is still coming
        // (queued / generating) waits too — the video
        // rides the listing from the start instead of
        // chasing it through the editor afterwards.
        // Flagged rows never reach here (the gate above
        // owns them); cars with no reel coming read no
        // row — or a terminal status — and proceed
        // exactly as .147. The hold write is the gate's
        // own shape, so the app's ready-release frees
        // the row identically.
        if (!reelJobFlagged(settings, item)) {
          const pwvHold348 = await pwv348ReelComingHold(userId, item);
          if (pwvHold348.hold) {
            const pwvHoldPatch348 = {
              status: "pending",
              awaiting_reel: true,
              error_message: pwv348HoldText(pwvHold348.status)
            };
            if (item.reel_requested_at == null ||
                item.reel_requested_at === "") {
              pwvHoldPatch348.reel_requested_at = new Date().toISOString();
            }
            await sbPatch(`auto_posting_queue?id=eq.${item.id}`, pwvHoldPatch348);
            await logFailure(item.id, "pwv348_claim_hold:" + pwvHold348.status);
            console.log(`[AutoLaunch] Post-with-video: post for VIN ${item.vin} held — reel ${pwvHold348.status}; not posted (spec Rule 1).`);
            return;
          }
        }
        // [PWV348-HOLD-END]
        const intro = await introVideoForJob(userId, settings);
        if (intro) jobPayload.introVideo = intro;
      }
    }
    // Marker hygiene (v2.1.119, header note 70): a post
    // that was gate-held in an earlier cycle and is
    // proceeding NOW sheds the loud hold prose — it is
    // posting, not held — while the budget counters the
    // settle paths re-read (abort count, render restarts)
    // ride on in compact form. Only proceed paths reach
    // here; the claim hold returned above. A failed
    // cleanup write is cosmetic and never blocks a post.
    try {
      const gateCleanup = reelGateProceedCleanup(item.error_message);
      if (gateCleanup !== undefined) {
        await sbPatch(`auto_posting_queue?id=eq.${item.id}`, {
          error_message: gateCleanup === "" ? null : gateCleanup
        });
      }
    } catch (e) { /* marker hygiene only */ }
    await chrome.storage.local.set({ current_posting_job: jobPayload });

    await jitter(1500, 4000); // human pacing, never machine-gun tabs
    // Background-tab rule (v2.1.12, extended v2.1.13): EVERY job now
    // works in an inactive tab so the helper never pulls the user
    // away from what they are doing (and the user browsing elsewhere
    // can't disturb the form). v2.1.12 kept confirm-mode posts in
    // front because a human must click Publish; Matthew overruled
    // that after watching his son's test — the filled tab simply
    // waits in the background with its review banner, and the user
    // clicks over to it when they are ready to publish.
    // v2.1.76 fronted scan tabs in this window and v2.1.77
    // moved them to a helper window (header notes 35/37);
    // both mechanisms are REMOVED in v2.1.78 (header
    // note 39): a scan no longer needs its page rendered —
    // the content side renders the target card through the
    // Selling list's own search (content.js header note 38)
    // — so every job's tab is created the same plain way
    // again, scan jobs included.
    const jobUrl = (isDelete || isShare || isUpdatePrice || isAttachVideo)
      ? "https://www.facebook.com/marketplace/you/selling"
      : "https://www.facebook.com/marketplace/create/vehicle";
    const jobTab = await chrome.tabs.create({ active: false, url: jobUrl });
    if (jobTab && jobTab.id != null && chrome.tabs.update) {
      try {
        // A background tab must not be discarded by Memory Saver
        // while the content script is mid-run.
        await chrome.tabs.update(jobTab.id, { autoDiscardable: false });
      } catch (e) { /* non-fatal: the job still runs, just unprotected */ }
    }
    // Record the tab THIS worker opened for THIS job (note 14):
    // a successful finish closes exactly that tab ~4s after the
    // success banner lands. Written as a follow-up merge because
    // the job record was stored (and the pacing jitter spent)
    // before the tab existed.
    if (jobTab && jobTab.id != null) {
      const { current_posting_job: j } =
        await chrome.storage.local.get(["current_posting_job"]);
      if (j && j.queueId === item.id) {
        j.tabId = jobTab.id;
        await chrome.storage.local.set({ current_posting_job: j });
      }
    }
    await alKeepAwakeCycle(true);
  } catch (err) {
    console.error("[AutoLaunch] Queue check error:", err);
  } finally {
    isChecking = false;
    // [SESS356] a heal that landed mid-cycle re-runs
    // the cycle once with the fresh token (spec H1).
    if (alSessHeal356Rerun) { alSessHeal356Rerun = false; checkQueue(); }
  }
}

// --- Photo relay --------------------------------------------------------
// The content script (on facebook.com) cannot fetch dealer photo URLs
// itself — page CORS. This worker can: extension fetches backed by host
// permissions are not page-CORS-bound. Returns the bytes base64-encoded
// (chunked conversion — String.fromCharCode on a whole 15MB buffer would
// blow the argument limit) with the content type; every failure is a
// structured { ok:false, error } so the content script can fall through
// to the photo-proxy and, failing that, the honest job failure.
const PHOTO_MAX_BYTES = 15 * 1024 * 1024; // ~15MB — dealer photos are ~50KB

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}

async function fetchPhotoForContent(url) {
  if (!url || typeof url !== "string" || !/^https?:\/\//i.test(url)) {
    return { ok: false, error: "photo_url_not_http" };
  }
  let res;
  try {
    res = await fetch(url);
  } catch (e) {
    return { ok: false, error: "photo_fetch_threw" };
  }
  if (!res.ok) return { ok: false, error: `photo_http_${res.status}` };
  const contentType = res.headers.get("content-type") || "";
  if (contentType && !contentType.toLowerCase().startsWith("image/")) {
    return { ok: false, error: "photo_not_an_image" };
  }
  const buffer = await res.arrayBuffer();
  if (!buffer.byteLength) return { ok: false, error: "photo_empty" };
  if (buffer.byteLength > PHOTO_MAX_BYTES) {
    return { ok: false, error: "photo_too_large" };
  }
  return {
    ok: true,
    base64: arrayBufferToBase64(buffer),
    contentType: contentType || "image/jpeg"
  };
}

// --- Video relay (v2.1.53, header note 27) ----------------------
// The intro-video twin of the photo relay above: the content
// script cannot fetch the storage URL itself (page CORS), this
// worker can. The app's own upload cap is 50 MB, so the relay
// cap matches it; anything larger is a structured refusal, and
// the content script skips the attach and posts without it.
const VIDEO_MAX_BYTES = 50 * 1024 * 1024; // the app's intro upload cap
const VIDEO_FETCH_TIMEOUT_MS = 30 * 1000; // abort budget (v2.54, note 28)

async function fetchVideoForContent(url) {
  if (!url || typeof url !== "string" || !/^https?:\/\//i.test(url)) {
    return { ok: false, error: "video_url_not_http" };
  }
  // Bounded (v2.54, header note 28): the fetch and the body
  // read share one 30s abort budget. In 2.53 this was a bare
  // fetch whose promise could hang unsettled forever — and
  // did, wedging a post behind the previous banner step. A
  // stall now answers the structured refusal below.
  const controller = new AbortController();
  const timer = setTimeout(() => {
    try { controller.abort(); } catch (e) { /* no-op */ }
  }, VIDEO_FETCH_TIMEOUT_MS);
  try {
    let res;
    try {
      res = await fetch(url, { signal: controller.signal });
    } catch (e) {
      if (controller.signal.aborted) {
        return { ok: false, error: "video_fetch_timeout" };
      }
      return { ok: false, error: "video_fetch_threw" };
    }
    if (!res.ok) return { ok: false, error: `video_http_${res.status}` };
    const contentType = res.headers.get("content-type") || "";
    const ct = contentType.toLowerCase();
    if (ct && !ct.startsWith("video/") && !ct.includes("octet-stream")) {
      return { ok: false, error: "video_not_a_video" };
    }
    let buffer;
    try {
      buffer = await res.arrayBuffer();
    } catch (e) {
      if (controller.signal.aborted) {
        return { ok: false, error: "video_fetch_timeout" };
      }
      throw e; // as before: the relay handler answers video_relay_failed
    }
    if (!buffer.byteLength) return { ok: false, error: "video_empty" };
    if (buffer.byteLength > VIDEO_MAX_BYTES) {
      return { ok: false, error: "video_too_large" };
    }
    return {
      ok: true,
      base64: arrayBufferToBase64(buffer),
      contentType: contentType || "video/mp4"
    };
  } finally {
    clearTimeout(timer);
  }
}


// --- CDP trusted input (filler v3) ---------------------------------------
// Minimal protocol the content script drives:
//   { type: "AUTOLAUNCH_CDP", action: "attach" }
//   { type: "AUTOLAUNCH_CDP", action: "click", x, y }
//   { type: "AUTOLAUNCH_CDP", action: "clickSeq", x, y }  (v2.1.9)
//   { type: "AUTOLAUNCH_CDP", action: "insertText", text }
//   { type: "AUTOLAUNCH_CDP", action: "key", key, code, text?, modifiers? }
//   { type: "AUTOLAUNCH_CDP", action: "setFile", url, filename, selector, queueId, vin }  (v2.1.89)
//   { type: "AUTOLAUNCH_CDP", action: "detach" }
// Every reply is { ok: true, ... } or { ok: false, error } — an attach
// failure (another debugger, e.g. the user's own DevTools, is attached)
// surfaces as an error, never a throw, so the caller's verify-or-report
// remains the arbiter. Sessions are tracked per tab; Chrome's own
// onDetach (tab closed, user cancels the infobar) cleans the map.
const cdpSessions = new Map(); // tabId -> protocol version

function cdpAttachOnce(tabId) {
  return new Promise(resolve => {
    chrome.debugger.attach({ tabId }, "1.3", () => {
      const err = chrome.runtime.lastError;
      if (err) {
        resolve({ ok: false, error: "cdp_attach_failed: " + (err.message || "unknown") });
        return;
      }
      cdpSessions.set(tabId, "1.3");
      resolve({ ok: true });
    });
  });
}

async function cdpAttach(tabId) {
  if (cdpSessions.has(tabId)) return { ok: true, already: true };
  let res = await cdpAttachOnce(tabId);
  // The classic refusal is the user having DevTools (or another
  // debugger) on the same tab. That can be transient — retry ONCE
  // after a pause before giving the rung up; the error string keeps
  // the browser's exact reason either way (v3.1).
  if (!res.ok && /another debugger is already attached/i.test(res.error || "")) {
    await sleep(3000);
    res = await cdpAttachOnce(tabId);
  }
  return res;
}

function cdpSendCommand(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, result => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message || "cdp_command_failed"));
      else resolve(result);
    });
  });
}

function cdpDetach(tabId) {
  if (!cdpSessions.has(tabId)) return Promise.resolve({ ok: true, already: false });
  return new Promise(resolve => {
    chrome.debugger.detach({ tabId }, () => {
      void chrome.runtime.lastError; // detaching a dead session is fine
      cdpSessions.delete(tabId);
      resolve({ ok: true });
    });
  });
}

async function handleCdp(message, tabId) {
  switch (message.action) {
    case "attach":
      return cdpAttach(tabId);
    case "detach":
      return cdpDetach(tabId);
    case "emuFocus": {
      // [EMU317] (v2.1.117, note 68): focus
      // emulation for the auto-reply delivery — a
      // background tab's document never holds OS
      // focus (the 3.16 trace: hasFocus FALSE for
      // the whole run), and the page's editor
      // treats input into an unfocused document
      // as noise. The override is scoped to this
      // CDP session; the content side disables it
      // again before detach.
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      await cdpSendCommand(tabId, "Emulation.setFocusEmulationEnabled", { enabled: message.enabled === true });
      return { ok: true };
    }
    case "click": {
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      const x = Number(message.x), y = Number(message.y);
      if (!isFinite(x) || !isFinite(y)) return { ok: false, error: "cdp_bad_coordinates" };
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mousePressed", x, y, button: "left", clickCount: 1 });
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mouseReleased", x, y, button: "left", clickCount: 1 });
      return { ok: true };
    }
    case "clickSeq": {
      // v2.1.9 (header note 16): a full mouse SEQUENCE — move,
      // press, brief pause, release — for menus that arm on
      // hover/press timing and shrug off the instantaneous
      // press+release pair above.
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      const x = Number(message.x), y = Number(message.y);
      if (!isFinite(x) || !isFinite(y)) return { ok: false, error: "cdp_bad_coordinates" };
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mouseMoved", x, y });
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mousePressed", x, y, button: "left", clickCount: 1 });
      await sleep(90);
      await cdpSendCommand(tabId, "Input.dispatchMouseEvent",
        { type: "mouseReleased", x, y, button: "left", clickCount: 1 });
      return { ok: true };
    }
    case "insertText": {
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      await cdpSendCommand(tabId, "Input.insertText", { text: String(message.text || "") });
      return { ok: true };
    }
    case "key": {
      if (!cdpSessions.has(tabId)) return { ok: false, error: "cdp_not_attached" };
      if (!message.key) return { ok: false, error: "cdp_key_missing" };
      const base = {
        key: String(message.key),
        code: String(message.code || message.key),
        modifiers: Number(message.modifiers) || 0
      };
      // `text` makes printable keys actually produce characters in
      // fields that read it from the key event (native selects do).
      if (message.text) base.text = String(message.text);
      await cdpSendCommand(tabId, "Input.dispatchKeyEvent",
        Object.assign({ type: "keyDown" }, base));
      await cdpSendCommand(tabId, "Input.dispatchKeyEvent",
        Object.assign({ type: "keyUp" }, base));
      return { ok: true };
    }
    case "setStaged348":
      // [PWV348-DISPATCH] (v2.1.148, note 95): the
      // post-with-video staged file-set — the paths
      // come from the worker's staging record for the
      // job, never from the page.
      return cdpSetStagedFiles348(tabId, message);
    case "setFile": {
      // v2.1.89 (header note 44): picker-equivalent file
      // injection for the editor attach — download the
      // reel to a real path, then DOM.setFileInputFiles
      // on the input the content script marked. Every
      // failure is the structured {ok:false, error} the
      // content side falls back on.
      return cdpSetFileInputFiles(tabId, message);
    }
    case "netWitnessStart": {
      // v2.1.126 (header note 77): open the network
      // witness on this tab for the attach delivery
      // window. Fail-open in the caller: a witness
      // that cannot start never blocks the attach.
      const att326 = await cdpAttach(tabId);
      if (!att326.ok) return att326;
      try {
        await cdpSendCommand(tabId, "Network.enable", {});
      } catch (e) {
        return { ok: false, error: "netwit_enable_failed" };
      }
      netWitnessSessions326.set(tabId,
        createNetWitnessState326(Date.now()));
      return { ok: true };
    }
    case "netWitnessMark": {
      // The content side's DataTransfer set has no
      // background moment of its own; it stamps the
      // file-set anchor through here (first set only,
      // the reducer keeps the earliest).
      const st326 = netWitnessSessions326.get(tabId);
      if (st326) netWitnessMarkFileSet326(st326, Date.now());
      return { ok: true, active: !!st326 };
    }
    case "netWitnessStop": {
      const st326b = netWitnessSessions326.get(tabId);
      if (!st326b) return { ok: true, summary: null };
      netWitnessSessions326.delete(tabId);
      try {
        await cdpSendCommand(tabId, "Network.disable", {});
      } catch (e) { /* the session may already be gone */ }
      return { ok: true, summary: netWitnessSummary326(st326b) };
    }
    default:
      return { ok: false, error: "cdp_unknown_action" };
  }
}

chrome.debugger.onDetach.addListener(source => {
  if (source && source.tabId != null) cdpSessions.delete(source.tabId);
  // v2.1.126 (header note 77): a detached tab's
  // network witness dies with its session.
  if (source && source.tabId != null) {
    netWitnessSessions326.delete(source.tabId);
  }
});
chrome.tabs.onRemoved.addListener(tabId => {
  cdpSessions.delete(tabId);
});

// --- CDP reel file injection (v2.1.89, header note 44) -------------------
// The editor attach's file set, picker-equivalent: the reel
// is saved to a real on-disk path by chrome.downloads, then
// DOM.setFileInputFiles hands that path to the editor's
// marked video input over the note-9 CDP session. The
// download record is kept in chrome.storage.local (key
// autolaunch_cdp_reel_file) so cleanup can find it even if
// this worker restarted between the set and the settle.

// [PURE-CDP-FILE-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of chrome/fetch references.
// The setFile request's shape gate: an https reel URL and
// exactly the temp-file name shape the content side
// builds (reelTempFilename) — no paths, no traversal.
function cdpReelFileRequestGuard(message) {
  const url = message && typeof message.url === "string" ? message.url : "";
  const filename = message && typeof message.filename === "string"
    ? message.filename : "";
  if (!/^https:\/\//i.test(url)) {
    return { ok: false, error: "cdp_file_url_invalid" };
  }
  if (!/^autolaunch-reel-[A-Za-z0-9._-]+\.mp4$/.test(filename) ||
      filename.indexOf("..") >= 0 || filename.indexOf("/") >= 0 ||
      filename.indexOf("\\") >= 0) {
    return { ok: false, error: "cdp_file_name_invalid" };
  }
  return { ok: true, url, filename };
}
// Cleanup fires only for the attach job the record was
// written for — the queue id must match the settling job.
function decideCdpFileCleanup(record, job) {
  if (!record || !job) return false;
  if (job.action !== "attach_video") return false;
  return record.queueId != null && record.queueId === job.queueId;
}
// [PURE-CDP-FILE-END]
// [PURE-NETWIT-BEGIN] — extracted and unit-exercised
// by the test harness; keep these free of chrome/DOM
// references (values in, values out).
// The network witness's classification (v2.1.126,
// header note 77): a request is MEDIA-UPLOAD traffic
// when it is a POST and either its host names an
// upload endpoint or its path (query stripped) names
// a media/video upload surface. Only method, host
// and the truncated query-free path are ever kept —
// no headers, no bodies, no cookies, no tokens.
const NETWIT_STORE_CAP326 = 200;
const NETWIT_PATH_MAX326 = 48;
function netWitnessClass326(url) {
  let host = "", path = "";
  try {
    const u = new URL(String(url || ""));
    host = u.hostname || "";
    path = u.pathname || "";
  } catch (e) {
    const m = /^[a-z][a-z0-9+.-]*:/i.exec(String(url || ""));
    return { host: "", path: m ? m[0].slice(0, -1) + ":" : "",
      upload: false };
  }
  if (path.length > NETWIT_PATH_MAX326)
    path = path.slice(0, NETWIT_PATH_MAX326);
  const upload = host.toLowerCase().includes("upload") ||
    /\/(media|video|rupload|upload)/i.test(path);
  return { host, path, upload };
}
function createNetWitnessState326(nowMs) {
  return { t0: nowMs, fileSetAt: null, totalReqs: 0,
    stored: {}, storedCount: 0, dropped: 0,
    uploadPosts: 0, uploads: [], failCounts: {} };
}
// The file-set anchor: the FIRST set of the window
// is the one upload offsets are measured against.
function netWitnessMarkFileSet326(state, nowMs) {
  if (state && state.fileSetAt == null) state.fileSetAt = nowMs;
  return state;
}
function netWitnessOnRequest326(state, ev) {
  if (!state || !ev) return state;
  state.totalReqs += 1;
  const cls = netWitnessClass326(ev.url);
  const isUpload = String(ev.method || "").toUpperCase() === "POST" &&
    cls.upload;
  const id = String(ev.requestId);
  const prev = state.stored[id];
  if (prev) {
    // A redirect re-fires requestWillBeSent under the
    // same id: refresh the record, never double-count.
    prev.method = String(ev.method || "");
    prev.host = cls.host; prev.path = cls.path;
    prev.at = ev.nowMs;
    return state;
  }
  const rec = { method: String(ev.method || ""), host: cls.host,
    path: cls.path, upload: isUpload, at: ev.nowMs,
    status: null, failed: null };
  if (state.storedCount < NETWIT_STORE_CAP326) {
    state.stored[id] = rec; state.storedCount += 1;
  } else if (isUpload) {
    // Upload traffic always earns a slot: evict the
    // oldest stored non-upload record.
    let evicted = false;
    for (const k of Object.keys(state.stored)) {
      if (!state.stored[k].upload) {
        delete state.stored[k]; evicted = true; break;
      }
    }
    if (evicted) state.stored[id] = rec;
    else state.dropped += 1;
  } else state.dropped += 1;
  if (isUpload) {
    state.uploadPosts += 1;
    if (state.uploads.length < 20) state.uploads.push(rec);
  }
  return state;
}
function netWitnessOnResponse326(state, ev) {
  if (!state || !ev) return state;
  const rec = state.stored[String(ev.requestId)];
  if (rec) rec.status = ev.status;
  return state;
}
function netWitnessOnFailed326(state, ev) {
  if (!state || !ev) return state;
  const err = String(ev.errorText || "unknown");
  state.failCounts[err] = (state.failCounts[err] || 0) + 1;
  const rec = state.stored[String(ev.requestId)];
  if (rec) rec.failed = err;
  return state;
}
function netWitnessOnFinished326(state, ev) {
  if (!state || !ev) return state;
  const id = String(ev.requestId);
  const rec = state.stored[id];
  // Finished non-upload records free their slot;
  // upload records stay — the summary reads them.
  if (rec && !rec.upload) {
    delete state.stored[id]; state.storedCount -= 1;
  }
  return state;
}
function netWitnessSummary326(state) {
  if (!state) return "off";
  const first = state.uploads[0] || null;
  const fms = !first ? "none"
    : (state.fileSetAt != null
        ? String(first.at - state.fileSetAt) : "unmarked");
  const fst = !first ? "none"
    : (first.failed ? "fail:" + first.failed
      : (first.status != null ? String(first.status) : "pending"));
  const fails = Object.keys(state.failCounts);
  const fstr = fails.length
    ? fails.map(k => k + " x" + state.failCounts[k]).join(",")
    : "none";
  return "reqs:" + state.totalReqs +
    " upload_posts:" + state.uploadPosts +
    " first_upload_ms:" + fms +
    " first_upload_status:" + fst +
    " fails:" + fstr +
    (state.dropped ? " dropped:" + state.dropped : "");
}
// [PURE-NETWIT-END]

const CDP_REEL_DOWNLOAD_TIMEOUT_MS = 90 * 1000;

function waitForDownloadComplete(downloadId) {
  return new Promise(resolve => {
    let settled = false;
    const finish = v => {
      if (settled) return;
      settled = true;
      try { chrome.downloads.onChanged.removeListener(onChanged); } catch (e) {}
      resolve(v);
    };
    const onChanged = delta => {
      if (!delta || delta.id !== downloadId || !delta.state) return;
      if (delta.state.current === "complete") finish({ ok: true });
      else if (delta.state.current === "interrupted") {
        finish({ ok: false,
          error: "downloads_interrupted:" +
            ((delta.error && delta.error.current) || "unknown") });
      }
    };
    chrome.downloads.onChanged.addListener(onChanged);
    // The download may have finished before the listener
    // attached (a small reel on a fast disk) — check once.
    try {
      chrome.downloads.search({ id: downloadId }, items => {
        if (items && items[0] && items[0].state === "complete") {
          finish({ ok: true });
        } else if (items && items[0] && items[0].state === "interrupted") {
          finish({ ok: false,
            error: "downloads_interrupted:" + (items[0].error || "unknown") });
        }
      });
    } catch (e) { /* the listener + timeout still stand */ }
    setTimeout(() => finish({ ok: false, error: "downloads_timeout" }),
      CDP_REEL_DOWNLOAD_TIMEOUT_MS);
  });
}

// Ensure the reel sits at a real on-disk path: reuse the
// recorded download when it is this URL's and the file is
// still there (refreshing the record to the CURRENT job,
// so its settle cleans up); otherwise download it under
// the deterministic name and record it for cleanup.
async function ensureCdpReelFile(message) {
  const guard = cdpReelFileRequestGuard(message);
  if (!guard.ok) return guard;
  // [PWV348-ENSURE-BEGIN] — attach staging migration
  // (v2.1.148, header note 95; spec addendum 2): the
  // editor-attach reel download moves into
  // Downloads/AutoLaunch/<stock_number>/ — every
  // helper-staged file lives in the one folder. The
  // delegated path mirrors this function's discipline
  // exactly; any job-less call keeps the original.
  if (guard.ok && (message.queueId || message.vin)) {
    return ensureCdpReelFile348(message, guard);
  }
  // [PWV348-ENSURE-END]
  const stored = await chrome.storage.local.get(["autolaunch_cdp_reel_file"]);
  const prev = stored.autolaunch_cdp_reel_file;
  if (prev && prev.url === guard.url && prev.downloadId != null) {
    const items = await new Promise(resolve => {
      try { chrome.downloads.search({ id: prev.downloadId }, resolve); }
      catch (e) { resolve(null); }
    });
    if (items && items[0] && items[0].state === "complete" &&
        items[0].exists !== false && items[0].filename) {
      await chrome.storage.local.set({
        autolaunch_cdp_reel_file: Object.assign({}, prev, {
          queueId: message.queueId || null, vin: message.vin || null,
          at: new Date().toISOString()
        })
      });
      return { ok: true, path: items[0].filename, reused: true };
    }
  }
  const downloadId = await new Promise(resolve => {
    try {
      chrome.downloads.download(
        { url: guard.url, filename: guard.filename,
          conflictAction: "overwrite" },
        id => {
          const err = chrome.runtime.lastError;
          resolve(err || id == null ? null : id);
        });
    } catch (e) { resolve(null); }
  });
  if (downloadId == null) return { ok: false, error: "downloads_start_failed" };
  const done = await waitForDownloadComplete(downloadId);
  if (!done.ok) return done;
  const items = await new Promise(resolve => {
    try { chrome.downloads.search({ id: downloadId }, resolve); }
    catch (e) { resolve(null); }
  });
  const path = items && items[0] && items[0].filename;
  if (!path) return { ok: false, error: "downloads_path_unresolved" };
  await chrome.storage.local.set({
    autolaunch_cdp_reel_file: {
      downloadId, path, url: guard.url,
      queueId: message.queueId || null, vin: message.vin || null,
      at: new Date().toISOString()
    }
  });
  return { ok: true, path, reused: false };
}

// The injection itself: DOM.setFileInputFiles on the
// input the content script marked, over the note-9
// session (attached here when the rung-3 ladder has not
// already attached it).
async function cdpSetFileInputFiles(tabId, message) {
  const file = await ensureCdpReelFile(message);
  if (!file.ok) return file;
  const attach = await cdpAttach(tabId);
  if (!attach.ok) return attach;
  const selector = typeof message.selector === "string" && message.selector
    ? message.selector : 'input[data-autolaunch-cdp-target="1"]';
  try {
    await cdpSendCommand(tabId, "DOM.enable", {});
    const doc = await cdpSendCommand(tabId, "DOM.getDocument", { depth: -1 });
    const rootId = doc && doc.root && doc.root.nodeId;
    if (!rootId) return { ok: false, error: "cdp_no_document" };
    const found = await cdpSendCommand(tabId, "DOM.querySelector",
      { nodeId: rootId, selector });
    const nodeId = found && found.nodeId;
    if (!nodeId) return { ok: false, error: "cdp_node_not_found" };
    await cdpSendCommand(tabId, "DOM.setFileInputFiles",
      { nodeId, files: [file.path] });
    // v2.1.126 (header note 77): the file-set anchor
    // for the network witness, when one is watching
    // this tab (the reducer keeps the first set).
    const wit326 = netWitnessSessions326.get(tabId);
    if (wit326) netWitnessMarkFileSet326(wit326, Date.now());
    return { ok: true, path: file.path, reused: file.reused === true };
  } catch (e) {
    return { ok: false,
      error: "cdp_set_files_failed: " + ((e && e.message) || "unknown") };
  }
}

// The network witness's live sessions (v2.1.126,
// header note 77): tabId -> pure-reducer state. The
// debugger event router below feeds Network events
// ONLY for tabs with an active session; stop (or the
// tab's detach, above) drops the session. Nothing is
// persisted — the summary the content side records
// at the attach verdict is the only artifact.
const netWitnessSessions326 = new Map();
chrome.debugger.onEvent.addListener((source, method, params) => {
  try {
    if (!source || source.tabId == null) return;
    const st = netWitnessSessions326.get(source.tabId);
    if (!st || !params) return;
    if (method === "Network.requestWillBeSent") {
      netWitnessOnRequest326(st, {
        requestId: params.requestId,
        method: params.request && params.request.method,
        url: params.request && params.request.url,
        nowMs: Date.now() });
    } else if (method === "Network.responseReceived") {
      netWitnessOnResponse326(st, {
        requestId: params.requestId,
        status: params.response && params.response.status });
    } else if (method === "Network.loadingFailed") {
      netWitnessOnFailed326(st, {
        requestId: params.requestId,
        errorText: params.errorText });
    } else if (method === "Network.loadingFinished") {
      netWitnessOnFinished326(st, {
        requestId: params.requestId });
    }
  } catch (e) { /* the witness never wedges the worker */ }
});

// [PWV348-RUNTIME-BEGIN] — post-with-video staging
// (v2.1.148, header note 95): the worker side of the
// pure block above. Stages a post job's media into
// Downloads/AutoLaunch/<stock_number>/ through the
// downloads API (subfolder paths; zero user input, no
// zip anywhere), serves the staged files to the
// content side's CDP file-set, migrates the editor
// attach download into the same folder, and cleans
// the staged copies up under the pure gate. All
// downloads use the CDP machinery's callback
// discipline (note 44).

const PWV348_STAGE_KEY = "autolaunch_pwv_stage_348";

async function pwv348GetStageRecord() {
  try {
    const got = await chrome.storage.local.get([PWV348_STAGE_KEY]);
    return got[PWV348_STAGE_KEY] || null;
  } catch (e) { return null; }
}

async function pwv348SetStageRecord(rec) {
  try {
    if (rec) await chrome.storage.local.set({ [PWV348_STAGE_KEY]: rec });
    else await chrome.storage.local.remove([PWV348_STAGE_KEY]);
  } catch (e) { /* staging bookkeeping never breaks a job */ }
}

// Download one URL to a Downloads-relative path and
// wait for it to land. Resolves {downloadId, path,
// bytes}; throws an Error naming the failed stage.
async function pwv348DownloadTo(url, relPath) {
  const downloadId = await new Promise(resolve => {
    try {
      chrome.downloads.download(
        { url, filename: relPath, conflictAction: "overwrite" },
        id => {
          const err = chrome.runtime.lastError;
          resolve(err || id == null ? null : id);
        });
    } catch (e) { resolve(null); }
  });
  if (downloadId == null) throw new Error("pwv348_download_start_failed");
  const done = await waitForDownloadComplete(downloadId);
  if (!done.ok) throw new Error("pwv348_" + (done.error || "download_failed"));
  const items = await new Promise(resolve => {
    try { chrome.downloads.search({ id: downloadId }, resolve); }
    catch (e) { resolve(null); }
  });
  const item = items && items[0];
  if (!item || !item.filename) {
    throw new Error("pwv348_download_path_unresolved");
  }
  return { downloadId, path: item.filename, bytes: item.fileSize || 0 };
}

// Delete staged files by download id (the downloads
// API resolves the on-disk path itself, so cleanup
// can never wander outside what it staged). Fail-open
// per file, mirroring cleanupCdpReelFile.
async function pwv348RemoveDownloads(items) {
  for (const it of items || []) {
    if (!it || it.downloadId == null) continue;
    await new Promise(resolve => {
      try {
        chrome.downloads.removeFile(it.downloadId,
          () => { void chrome.runtime.lastError; resolve(); });
      } catch (e) { resolve(); }
    });
    await new Promise(resolve => {
      try {
        chrome.downloads.erase({ id: it.downloadId },
          () => { void chrome.runtime.lastError; resolve(); });
      } catch (e) { resolve(); }
    });
  }
}

// Stage a claimed post job's media: the dealer photos
// (numbered, listing order) + the ready reel. The
// folder is the car's stock number; a collision with
// the previous record's folder (same stock, different
// car) falls back to stock+VIN per the spec addendum.
// Any failure removes what landed and reports — the
// caller then runs the pre-.148 flow unchanged.
async function stagePwvMedia348(userId, item, carRow, reelHit) {
  const car = jobCarWithStock(carRow, item) || {};
  const stock = car.stock_num || car.stock_number || item.stock_num || "";
  const vin = item.vin || car.vin || "";
  const prev = await pwv348GetStageRecord();
  const collides = !!(prev && prev.folder &&
    pwv348SanitizeStock(stock) &&
    prev.folder === pwv348SanitizeStock(stock) &&
    String(prev.vin || "") !== String(vin || ""));
  // [PWV352-FLAT-BEGIN] — flat staging (v2.1.152):
  // new downloads write the flat plan (the car's
  // identity in every file name, [PURE-PWV-352]);
  // the folder is still computed and still rides
  // the record, because the collision test above
  // reads the PREVIOUS record's folder and the
  // .148-.151 records carry nothing else to compare
  // against. A superseded record for THIS car (same
  // VIN, an older queue row) is remembered before
  // it is replaced, so the completion cleanup can
  // sweep its leftovers; another car's record is
  // never remembered — it is not this job's family.
  const base352 = pwv352StageBase(stock, vin, collides);
  const folder = pwv348Folder(stock, vin, collides);
  const cardUrl = reelHit && reelHit.reel && reelHit.reel.cardUrl
    ? reelHit.reel.cardUrl : "";
  const photoUrls = pwv348PhotoUrls(car, cardUrl);
  const plan = pwv352StagePaths(base352, photoUrls);
  const rec = {
    queueId: item.id, vin, folder, base352,
    photos: [], reel: null, at: Date.now()
  };
  if (prev && String(prev.vin || "") === String(vin || "") &&
      String(prev.queueId) !== String(item.id)) {
    await pwv352RememberStageRecord(prev);
  }
  // [PWV352-FLAT-END]
  try {
    for (let i = 0; i < photoUrls.length; i++) {
      const d = await pwv348DownloadTo(photoUrls[i], plan.photos[i]);
      // [PWV350-SIZE-RECORD] — the expected size
      // and source URL ride the record (v2.1.150),
      // so the set-time size proof can name a
      // truncated file instead of feeding it to
      // Facebook unnamed.
      rec.photos.push({
        downloadId: d.downloadId, relPath: plan.photos[i], path: d.path,
        url: photoUrls[i], bytes: d.bytes || 0
      });
    }
    const rd = await pwv348DownloadTo(reelHit.url, plan.reel);
    rec.reel = { downloadId: rd.downloadId, relPath: plan.reel, path: rd.path,
      url: reelHit.url, bytes: rd.bytes || 0 };
    await pwv348SetStageRecord(rec);
    return {
      ok: true, folder, photoCount: rec.photos.length,
      reelBytes: rd.bytes || 0, record: rec
    };
  } catch (e) {
    const landed = rec.photos.slice();
    if (rec.reel) landed.push(rec.reel);
    await pwv348RemoveDownloads(landed);
    return { ok: false, error: String((e && e.message) || e) };
  }
}

// The generalized hold's read (spec Rule 1): the
// latest reel row for this VIN, decided purely. A
// failed read never holds a post.
async function pwv348ReelComingHold(userId, item) {
  try {
    const rows = await sbGet(
      `vin_reels?user_id=eq.${userId}&vin=eq.${encodeURIComponent(item.vin)}` +
      `&select=status&order=created_at.desc&limit=1`);
    const status = rows && rows[0] ? rows[0].status : null;
    return decidePwvHold348({ reelStatus: status });
  } catch (e) {
    return { hold: false, status: null };
  }
}

// Cleanup under the pure gate: proven (the post
// verified live) or failed (the attempt is over).
// Anything else — including a record belonging to
// another job — keeps the files. Fail-open throughout.
async function cleanupPwvStage348(job, outcome) {
  try {
    if (!job || job.action !== "post") return;
    const rec = await pwv348GetStageRecord();
    const verdict = decidePwvStageCleanup348({
      record: rec, queueId: job.queueId, outcome
    });
    if (!verdict.clean) return;
    const items = [];
    if (Array.isArray(rec.photos)) items.push.apply(items, rec.photos);
    if (rec.reel) items.push(rec.reel);
    await pwv348RemoveDownloads(items);
    await pwv348SetStageRecord(null);
    // [PWV352-SWEEP-BEGIN] — the completion sweep
    // (v2.1.152): leftovers of the SAME car from a
    // superseded staging attempt — remembered when
    // the newer record replaced theirs — go with
    // the job's own files. The pure decider bounds
    // it: same VIN, same flat base, this car's
    // prefix, the 348 path fence, recorded files
    // only (never a disk scan, never another car,
    // never outside Downloads/AutoLaunch/). Removal
    // is by download id, like everything else. A
    // legacy folder-layout record sweeps nothing:
    // it carries no base352, so the decider returns
    // empty and its cleanup stays exactly .148's.
    const sweep352 = pwv352SweepItems(rec,
      await pwv352GetStageHistory());
    if (sweep352.length) {
      await pwv348RemoveDownloads(sweep352);
      await pwv352ForgetStageRecords(sweep352);
    }
    // [PWV352-SWEEP-END]
    console.log(`[AutoLaunch] Post-with-video: staged media for job ${job.queueId} cleaned up (${outcome}).`);
  } catch (e) { /* cleanup never breaks a finish */ }
}


// [PWV352-RUNTIME-BEGIN] — flat staging bookkeeping
// (v2.1.152): the remembered superseded records the
// completion sweep reads. When stagePwvMedia348
// replaces a staging record for the SAME car (same
// VIN, an older queue row — a superseded attempt),
// the old record is kept here instead of vanishing,
// so the completing job's cleanup can sweep its
// leftover files under the pure decider's bounds
// ([PURE-PWV-352]). Bounded (the last 8), fail-open
// throughout: bookkeeping never breaks a job, and a
// record is forgotten once its files have been
// swept.
const PWV352_STAGE_HISTORY_KEY = "autolaunch_pwv_stage_history_352";

async function pwv352GetStageHistory() {
  try {
    const got = await chrome.storage.local.get([PWV352_STAGE_HISTORY_KEY]);
    const h = got[PWV352_STAGE_HISTORY_KEY];
    return Array.isArray(h) ? h : [];
  } catch (e) { return []; }
}

async function pwv352RememberStageRecord(rec) {
  try {
    if (!rec || typeof rec !== "object") return;
    const key = String(rec.queueId == null ? "" : rec.queueId);
    const hist = await pwv352GetStageHistory();
    const kept = hist.filter(r => !r || typeof r !== "object" ||
      String(r.queueId == null ? "" : r.queueId) !== key);
    kept.push(rec);
    await chrome.storage.local.set({
      [PWV352_STAGE_HISTORY_KEY]: kept.slice(-8) });
  } catch (e) { /* bookkeeping never breaks a job */ }
}

// Forget every remembered record that contributed
// a swept file (its files are gone; remembering it
// longer could only re-offer dead download ids).
async function pwv352ForgetStageRecords(sweptItems) {
  try {
    if (!sweptItems || !sweptItems.length) return;
    const paths = new Set(sweptItems
      .map(i => i && i.relPath).filter(Boolean));
    if (!paths.size) return;
    const hist = await pwv352GetStageHistory();
    const kept = hist.filter(r => {
      if (!r || typeof r !== "object") return false;
      const items = [];
      if (Array.isArray(r.photos)) items.push.apply(items, r.photos);
      if (r.reel) items.push(r.reel);
      return !items.some(i => i && paths.has(i.relPath));
    });
    if (kept.length !== hist.length) {
      await chrome.storage.local.set({
        [PWV352_STAGE_HISTORY_KEY]: kept });
    }
  } catch (e) { /* bookkeeping never breaks a job */ }
}
// [PWV352-RUNTIME-END]
// The staged file-set the content side asks for
// (handleCdp "setStaged348"): the paths come from the
// staging record for THIS queue row — never from the
// page — and the set runs through the same CDP
// DOM.setFileInputFiles machinery as the editor
// attach (note 44's picker-equivalent).
async function cdpSetStagedFiles348(tabId, message) {
  const rec = await pwv348GetStageRecord();
  if (!rec || String(rec.queueId) !== String(message.queueId || "")) {
    return { ok: false, error: "pwv348_no_stage_record" };
  }
  let paths = [];
  if (message.kind === "photos") {
    paths = (rec.photos || []).map(p => p.path).filter(Boolean);
  } else if (message.kind === "video") {
    paths = rec.reel && rec.reel.path ? [rec.reel.path] : [];
  }
  if (!paths.length) return { ok: false, error: "pwv348_no_staged_files" };
  // [PWV349-VERIFY-BEGIN] — prove each staged file is
  // still on disk at set time, through the record's
  // own download ids: a staged file that vanished
  // after staging names itself here instead of dying
  // unnamed at the set. (Staging already waits for
  // download completion; this closes the window
  // between staging and the set.)
  const stagedItems349 = message.kind === "video"
    ? (rec.reel ? [rec.reel] : [])
    : (rec.photos || []);
  for (const it349 of stagedItems349) {
    if (!it349 || it349.downloadId == null) continue;
    const found349 = await new Promise(resolve => {
      try { chrome.downloads.search({ id: it349.downloadId }, resolve); }
      catch (e) { resolve(null); }
    });
    const dit349 = found349 && found349[0];
    if (!dit349 || dit349.state !== "complete" ||
        dit349.exists === false || !dit349.filename) {
      return { ok: false,
        error: "pwv349_staged_file_missing:" +
          String(it349.relPath || it349.path || "?")
            .split("/").pop() };
    }
  }
  // [PWV349-VERIFY-END]
  // [PWV350-SIZE-BEGIN] — size proof (v2.1.150):
  // existence is not wholeness, and downloads in this
  // environment have a documented truncation history
  // (Facebook's "Oops" over the Tacoma composer is
  // consistent with its uploader choking on a bad
  // file). Each staged file's expected size rides its
  // staging record; a mismatch re-downloads the file
  // once, and if it still mismatches the file names
  // itself here and the set is refused (photos ->
  // classic fallback; reel -> abort before Publish,
  // as today). Entries staged before sizes were
  // recorded carry no expectation and skip this axis.
  for (const it350 of stagedItems349) {
    if (!it350 || it350.downloadId == null) continue;
    const expected350 = it350.bytes || 0;
    if (!expected350 || !it350.url || !it350.relPath) continue;
    const cur350 = await new Promise(resolve => {
      try { chrome.downloads.search({ id: it350.downloadId }, resolve); }
      catch (e) { resolve(null); }
    });
    const dit350 = cur350 && cur350[0];
    if (!dit350 || dit350.state !== "complete" ||
        dit350.exists === false) {
      continue; // the existence axis above already refused these
    }
    if ((dit350.fileSize || 0) === expected350) continue;
    let fixed350 = false;
    try {
      const oldId350 = it350.downloadId;
      const d350 = await pwv348DownloadTo(it350.url, it350.relPath);
      if ((d350.bytes || 0) === expected350) {
        it350.downloadId = d350.downloadId;
        it350.path = d350.path;
        await pwv348SetStageRecord(rec);
        try {
          chrome.downloads.erase({ id: oldId350 }, () => {
            void chrome.runtime.lastError;
          });
        } catch (e) {}
        fixed350 = true;
      }
    } catch (e) { /* the named refusal below */ }
    if (!fixed350) {
      return { ok: false,
        error: "pwv350_staged_size_mismatch:" +
          String(it350.relPath).split("/").pop() };
    }
  }
  // A repaired re-download may have landed at a
  // refreshed path: re-derive the set's paths from
  // the record before the set runs.
  paths = stagedItems349.map(p350 => p350.path).filter(Boolean);
  if (!paths.length) {
    return { ok: false, error: "pwv348_no_staged_files" };
  }
  // [PWV350-SIZE-END]
  const attach = await cdpAttach(tabId);
  if (!attach.ok) return attach;
  const selector = typeof message.selector === "string" && message.selector
    ? message.selector : 'input[data-autolaunch-cdp-target="1"]';
  try {
    await cdpSendCommand(tabId, "DOM.enable", {});
    const doc = await cdpSendCommand(tabId, "DOM.getDocument", { depth: -1 });
    const rootId = doc && doc.root && doc.root.nodeId;
    if (!rootId) return { ok: false, error: "cdp_no_document" };
    // [PWV349-NODE-BEGIN] — the marked node can lag a
    // composer re-render by a breath: one short wait
    // and a fresh resolution before the refusal is
    // real. The error, when it is real, stays the
    // named cdp_node_not_found.
    let found = await cdpSendCommand(tabId, "DOM.querySelector",
      { nodeId: rootId, selector });
    if (!(found && found.nodeId)) {
      await new Promise(r349 => setTimeout(r349, 700));
      found = await cdpSendCommand(tabId, "DOM.querySelector",
        { nodeId: rootId, selector });
    }
    const nodeId = found && found.nodeId;
    if (!nodeId) return { ok: false, error: "cdp_node_not_found" };
    // [PWV349-NODE-END]
    await cdpSendCommand(tabId, "DOM.setFileInputFiles",
      { nodeId, files: paths });
    return { ok: true, count: paths.length };
  } catch (e) {
    return { ok: false,
      error: "cdp_set_staged_failed: " + ((e && e.message) || "unknown") };
  }
}

// Attach staging migration (spec addendum 2): the
// editor-attach reel download lands in the same
// per-car folder as the post staging. Delegated to
// from ensureCdpReelFile (see [PWV348-ENSURE] there);
// the record key and shape are the originals, plus
// the folder it landed in. Mirrors ensureCdpReelFile's
// reuse / download / record discipline exactly.
async function ensureCdpReelFile348(message, guard) {
  let stock = "", vin = message.vin || "";
  try {
    if (message.queueId) {
      const rows = await sbGet(
        `auto_posting_queue?id=eq.${message.queueId}&select=stock_num,vin`);
      if (rows && rows[0]) {
        stock = rows[0].stock_num || "";
        vin = rows[0].vin || vin;
      }
    }
  } catch (e) { /* the VIN fallback names the folder */ }
  const folder = pwv348Folder(stock, vin, false);
  // [PWV352-ATTACH-BEGIN] — the attach download
  // flattens too (v2.1.152): flat under the car's
  // base, the guarded temp name behind the prefix.
  // The reuse test accepts either record key — a
  // .148-.151 record (folder348) still reuses its
  // file, whose recorded folder path is honored
  // exactly as written; a .152 record reuses by
  // base (base352).
  const base352 = pwv352StageBase(stock, vin, false);
  const stored = await chrome.storage.local.get(["autolaunch_cdp_reel_file"]);
  const prev = stored.autolaunch_cdp_reel_file;
  if (prev && prev.url === guard.url && prev.downloadId != null &&
      (prev.folder348 === folder || prev.base352 === base352)) {
  // [PWV352-ATTACH-END]
    const items = await new Promise(resolve => {
      try { chrome.downloads.search({ id: prev.downloadId }, resolve); }
      catch (e) { resolve(null); }
    });
    if (items && items[0] && items[0].state === "complete" &&
        items[0].exists !== false && items[0].filename) {
      await chrome.storage.local.set({
        autolaunch_cdp_reel_file: Object.assign({}, prev, {
          queueId: message.queueId || null, vin: message.vin || null,
          at: new Date().toISOString()
        })
      });
      return { ok: true, path: items[0].filename, reused: true };
    }
  }
  const relPath = pwv352AttachRelativePath(base352, guard.filename);
  const downloadId = await new Promise(resolve => {
    try {
      chrome.downloads.download(
        { url: guard.url, filename: relPath,
          conflictAction: "overwrite" },
        id => {
          const err = chrome.runtime.lastError;
          resolve(err || id == null ? null : id);
        });
    } catch (e) { resolve(null); }
  });
  if (downloadId == null) return { ok: false, error: "downloads_start_failed" };
  const done = await waitForDownloadComplete(downloadId);
  if (!done.ok) return done;
  const items = await new Promise(resolve => {
    try { chrome.downloads.search({ id: downloadId }, resolve); }
    catch (e) { resolve(null); }
  });
  const path = items && items[0] && items[0].filename;
  if (!path) return { ok: false, error: "downloads_path_unresolved" };
  await chrome.storage.local.set({
    autolaunch_cdp_reel_file: {
      downloadId, path, url: guard.url,
      queueId: message.queueId || null, vin: message.vin || null,
      folder348: folder, base352, at: new Date().toISOString()
    }
  });
  return { ok: true, path, reused: false };
}
// [PWV348-RUNTIME-END]

// Temp-file cleanup at the attach job's settle (success
// and failure alike, from the finish functions): erase
// the storage record first so a repeated call is a
// no-op, then remove the file and its download-history
// entry. Fail-open throughout — a leftover temp file is
// litter, never a wedge.
async function cleanupCdpReelFile(job) {
  try {
    const stored = await chrome.storage.local.get(["autolaunch_cdp_reel_file"]);
    const record = stored.autolaunch_cdp_reel_file;
    if (!decideCdpFileCleanup(record, job)) return;
    await chrome.storage.local.remove(["autolaunch_cdp_reel_file"]);
    if (record.downloadId != null) {
      await new Promise(resolve => {
        try {
          chrome.downloads.removeFile(record.downloadId,
            () => { void chrome.runtime.lastError; resolve(); });
        } catch (e) { resolve(); }
      });
      await new Promise(resolve => {
        try {
          chrome.downloads.erase({ id: record.downloadId },
            () => { void chrome.runtime.lastError; resolve(); });
        } catch (e) { resolve(); }
      });
    }
  } catch (e) { /* fail-open */ }
}

// Failure-log writes are serialized through this chain (v3.1): the
// get-modify-write cycle is not atomic, and near-simultaneous callers
// (four field diags landing alongside the job failure) could read the
// same base log and overwrite each other's entries.
let failureLogChain = Promise.resolve();
function logFailure(queueId, reason, extra) {
  const run = failureLogChain.then(() => logFailureNow(queueId, reason, extra));
  failureLogChain = run.catch(() => {});
  return run;
}

async function logFailureNow(queueId, reason, extra) {
  const { autolaunch_failure_log: log = [] } = await chrome.storage.local.get(["autolaunch_failure_log"]);
  const entry = Object.assign(
    { queueId, reason, at: new Date().toISOString() },
    extra || {}
  );
  log.unshift(entry);
  await chrome.storage.local.set({
    autolaunch_failure_log: log.slice(0, 25),
    autolaunch_last_error: { queueId, reason, at: entry.at }
  });
}

// [PURE-DIAG-BEGIN] — extracted and unit-exercised by the test harness;
// keep free of chrome/fetch references.
// Compact the content script's per-field forensic records into the
// JSON string stored in the queue row's error_message (diag-to-DB,
// v3.1; form map v3.2; step notes v2.1.3): per field {field, tag,
// type, role, ariaLabel, outerHTML (≤160 chars), rungsAttempted,
// readBack, cdpError, note, detail (≤200 chars)}, plus the form_map
// entry whose formMap lists the failing step's visible controls
// {tag, type, role, ariaLabel, containerLabel (≤120 chars)}. The
// whole string is capped at 6000 chars — shed formMap entries first
// (halve, then drop), then outerHTML, then readBack + detail, then
// hard-truncate, so the field names + rungs + cdpError + notes
// survive.
function compactDiagError(diags) {
  if (!Array.isArray(diags) || !diags.length) return null;
  const fields = diags.map(d => {
    const el = (d && d.element) || {};
    return {
      field: (d && d.field) || null,
      tag: el.tag || null,
      type: el.type || null,
      role: el.role || null,
      ariaLabel: el.ariaLabel || null,
      outerHTML: el.outerHTML ? String(el.outerHTML).slice(0, 160) : null,
      rungsAttempted: (d && Array.isArray(d.rungsAttempted)) ? d.rungsAttempted.slice() : [],
      readBack: (d && d.readBack != null) ? String(d.readBack).slice(0, 120) : null,
      cdpError: (d && d.cdpError) || null,
      note: (d && d.note) || null,
      detail: (d && d.detail != null) ? String(d.detail).slice(0, 200) : null,
      formMap: (d && Array.isArray(d.formMap))
        ? d.formMap.slice(0, 12).map(m => ({
            tag: (m && m.tag) || null,
            type: (m && m.type) || null,
            role: (m && m.role) || null,
            ariaLabel: (m && m.ariaLabel) || null,
            containerLabel: (m && m.containerLabel != null)
              ? String(m.containerLabel).slice(0, 120) : null
          }))
        : null
    };
  });
  let out = JSON.stringify({ field_diag: fields });
  if (out.length > 6000) {
    fields.forEach(f => { if (Array.isArray(f.formMap)) f.formMap = f.formMap.slice(0, 6); });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) {
    fields.forEach(f => { f.formMap = null; });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) {
    fields.forEach(f => { f.outerHTML = null; });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) {
    fields.forEach(f => { f.readBack = null; f.detail = null; });
    out = JSON.stringify({ field_diag: fields });
  }
  if (out.length > 6000) out = out.slice(0, 6000);
  return out;
}
// [PURE-DIAG-END]

// [RECONCILE-336-BEGIN] — reconciliation sweep (v2.1.136,
// header note 86). REPORT-ONLY by construction: the only
// writes this block performs are its own reconciliation
// rows, its own queue row's completion, and the job-slot /
// tab bookkeeping every finish performs. It never writes
// scraped_inventory, never inserts a queue row, and the
// content side (content.js note 86) only scrolls, opens
// and reads Facebook pages — no control on any page is
// ever activated.
//
// The sweep exists because the posted stamp is written
// once and never re-verified: a listing that leaves
// Facebook by any path the helper does not drive (a hand
// delete, a Facebook removal) leaves the app believing a
// phantom. The sweep reads the seller's real Selling page
// fresh, matches what it finds against the stamped set,
// and files the drift — matched / phantom / orphan — for
// a human to act on. Repairs are a separate, later,
// human-tapped step; nothing here queues one. The row
// that claims a sweep is produced with target_channel
// 'facebook' (or 'marketplace') and awaiting_reel false,
// like the scan jobs it rides beside; it carries no VIN.

// [PURE-RECONCILE-336-BEGIN] — extracted and unit-exercised
// by the test harness; keep free of DOM/chrome references.
// The matching decider. believed = the stamped set
// [{vin, stock_number|stock_num, stamp_price (or
// marketplace_posted_price)}]; scanned = what the Selling
// page actually holds [{listingId, title, price, vin,
// stock, readOk}]. Identity is VIN first, then stock
// number — never title, never price (the twin rule: two
// same-model cars are told apart by their VINs or not at
// all). A listing whose VIN names a believed car is that
// car's listing or its duplicate — never a stock match
// for a different car. A scanned listing whose
// description could not be read (readOk false) carries no
// proven identity and can only be an orphan; the run that
// carries it is scan-incomplete, so its phantoms are
// unconfirmed by construction. A duplicate listing for an
// already-matched car is an orphan (first match wins).
// Price drift never unmakes a match: both prices ride the
// item and a human reads the difference.
function decideReconciliation336(believed, scanned) {
  const norm = v => String(v == null ? "" : v).trim().toUpperCase();
  const priceOf = v => {
    const n = Number(v);
    return isFinite(n) && n > 0 ? Math.round(n) : null;
  };
  const cars = (Array.isArray(believed) ? believed : []).map(b => ({
    vin: norm(b && b.vin),
    stock: norm(b && (b.stock_number != null ? b.stock_number : b.stock_num)),
    stampPrice: priceOf(b && (b.stamp_price != null
      ? b.stamp_price : b.marketplace_posted_price)),
    matched: false
  }));
  const byVin = new Map(), byStock = new Map();
  cars.forEach((c, i) => {
    if (c.vin && !byVin.has(c.vin)) byVin.set(c.vin, i);
    if (c.stock && !byStock.has(c.stock)) byStock.set(c.stock, i);
  });
  const items = [];
  const list = Array.isArray(scanned) ? scanned : [];
  for (const s of list) {
    const vin = norm(s && s.vin);
    const stock = norm(s && s.stock);
    const listingId = s && s.listingId != null ? String(s.listingId) : null;
    const listingPrice = priceOf(s && s.price);
    let ci = -1, via = null;
    if (s && s.readOk !== false) {
      if (vin && byVin.has(vin)) {
        const cand = byVin.get(vin);
        if (!cars[cand].matched) { ci = cand; via = "vin"; }
      } else if (stock && byStock.has(stock)) {
        const cand = byStock.get(stock);
        if (!cars[cand].matched) { ci = cand; via = "stock"; }
      }
    }
    if (ci >= 0) {
      const c = cars[ci];
      c.matched = true;
      items.push({
        kind: "matched",
        stock_number: c.stock || stock || null,
        vin: c.vin || vin || null,
        listing_id: listingId,
        listing_price: listingPrice,
        stamp_price: c.stampPrice
      });
    } else {
      items.push({
        kind: "orphan",
        stock_number: stock || null,
        vin: vin || null,
        listing_id: listingId,
        listing_price: listingPrice,
        stamp_price: null
      });
    }
  }
  for (const c of cars) {
    if (!c.matched) {
      items.push({
        kind: "phantom",
        stock_number: c.stock || null,
        vin: c.vin || null,
        listing_id: null,
        listing_price: null,
        stamp_price: c.stampPrice
      });
    }
  }
  const counts = { matched: 0, phantom: 0, orphan: 0 };
  for (const it of items) counts[it.kind]++;
  return { items, counts };
}
// [PURE-RECONCILE-336-END]

// [PURE-RECONCILE-GUARD-337-BEGIN] — extracted and
// unit-exercised by the test harness; keep free of
// DOM/chrome references. The completeness guard
// (v2.1.137, header note 87): a scan that saw NO
// listings while the app believes cars are posted has
// proven nothing — the first desk run's zero-card
// settle filed every stamped car as a phantom.
// Whatever the content side claims, such a run is
// incomplete and its phantoms unconfirmed.
function reconcileCompleteness337(input) {
  const o = input || {};
  const seen = Number(o.listingsSeen) || 0;
  const believed = Number(o.believedCount) || 0;
  const zeroGuard = seen === 0 && believed > 0;
  return {
    complete: o.scanComplete === true && !zeroGuard,
    zeroGuard
  };
}
// [PURE-RECONCILE-GUARD-337-END]

// [PURE-RECONCILE-NOTE-337-BEGIN] — extracted and
// unit-exercised by the test harness; keep free of
// DOM/chrome references. The run note (v2.1.137, note
// 87): why the scan is incomplete, in plain words,
// plus what the scan actually saw — final URL, page
// title, per-check ids/census/anchors, the chrome
// signals that fired, tab visibility, and whether the
// page looked like a login redirect — so a bad run
// diagnoses itself from its own row. Null when the
// scan was complete (nothing to explain).
function reconcileScanNote337(input) {
  const o = input || {};
  if (o.complete) return null;
  let note = "scan incomplete — phantoms unconfirmed (the Selling page " +
    "did not fully settle, or a listing's description could not be read)";
  if (o.zeroGuard) {
    note = "scan incomplete — the scan saw no listings on the Selling page " +
      "while the app believes " + (Number(o.believedCount) || 0) +
      " cars are posted, so every phantom in this run is unconfirmed";
  }
  const d = o.diag || {};
  const parts = [];
  if (d.url) parts.push("url=" + String(d.url).slice(0, 110));
  if (d.title) parts.push("title=" + String(d.title).slice(0, 60));
  if (d.login) parts.push("login_suspected=1");
  if (d.checks != null) parts.push("checks=" + d.checks);
  if (Array.isArray(d.trace) && d.trace.length) {
    parts.push("ids/census/anchors=" + d.trace.join(","));
  }
  if (d.settleReason) parts.push("settle=" + d.settleReason);
  if (d.vis) parts.push("vis=" + d.vis);
  if (d.sawHidden) parts.push("saw_hidden=1");
  if (d.signals) {
    const on = Object.keys(d.signals).filter(k => d.signals[k]);
    parts.push("signals=" + (on.length ? on.join("+") : "none"));
  }
  if (parts.length) note += " | scan saw: " + parts.join(" ");
  return note.slice(0, 900);
}
// [PURE-RECONCILE-NOTE-337-END]

// [PURE-VERIFY-SETTLE-342-BEGIN]
// The verify settle (v2.1.142, header note 92): a pure
// ruling on a verify report. A verdict the content side
// composed (identity ruled on the opened listing) settles
// the row "completed" with the verdict riding its
// error_message — the exact contract luna-repairs
// consumes. Anything else (no verdict, a read that never
// landed, a checkpoint) settles "failed"; the repairs
// function reads a failed verify as "no verdict" and may
// ask again later. This decider never invents a verdict.
function decideVerifySettle342(message) {
  const m = message || {};
  if (m.ok === true && m.verdict && typeof m.verdict === "object" &&
      typeof m.verdict.listing_present === "boolean" &&
      typeof m.verdict.identity_ok === "boolean") {
    return { settle: "completed",
      errorMessage: "luna_verdict:" + JSON.stringify(m.verdict) };
  }
  const reason = String(m.error || "no_verdict").slice(0, 120);
  return { settle: "failed", errorMessage: "verify_failed:" + reason };
}
// [PURE-VERIFY-SETTLE-342-END]

// Launch (v2.1.142, note 92): the luna-repairs function
// queues a verify_listing row when a proposed repair
// needs Facebook ground truth. The row carries its
// request in share_text ({luna_verify:{repair_id,
// checks}}) and the car's identity on the row itself.
// Launch mirrors the reconcile shape — job slot first,
// then a background tab on the Selling page — plus the
// car identity the content runner aims with. The job is
// READ-ONLY end to end: it never clicks a control,
// never edits, never deletes.
async function launchVerifyListing342(item, userId) {
  try {
    let checks = ["listing_present"];
    let repairId = null;
    try {
      const req = JSON.parse(item.share_text || "{}");
      if (req && req.luna_verify) {
        if (Array.isArray(req.luna_verify.checks) && req.luna_verify.checks.length) {
          checks = req.luna_verify.checks;
        }
        repairId = req.luna_verify.repair_id || null;
      }
    } catch (e) { /* the defaults above stand */ }
    await chrome.storage.local.remove(["verify_listing_state"]);
    // [VERIFY-ADDR-345-BEGIN]
    // Address-first (v2.1.145, note 93): the price /
    // delete / gate flows remember most listing IDs
    // per VIN (listing_id_by_vin; listingIdMemoryFor
    // is its reader). When an ID is on file, the job
    // carries it and the tab opens on that listing
    // directly — the .144 Selling-page scan settles
    // before its scroll reaches deep cards on big
    // accounts and reported a provably-live listing
    // absent. No entry: today's behavior exactly
    // (Selling page, no listingId on the job). The
    // runner treats a stored address as a lead, not
    // a conclusion: a stale address falls back to
    // the scan, and only a scan miss concludes
    // absence.
    const memAddr = await listingIdMemoryFor(item.vin || null);
    const addrId = memAddr && memAddr.listingId
      ? String(memAddr.listingId) : null;
    const jobAddr = {
      queueId: item.id,
      userId,
      action: "verify_listing",
      vin: item.vin || null,
      stockNum: item.stock_num || null,
      year: item.year || null,
      make: item.make || null,
      model: item.model || null,
      price: typeof item.price === "number" ? item.price : null,
      checks,
      repairId,
      claimedAt: new Date().toISOString()
    };
    if (addrId) jobAddr.listingId = addrId;
    const startUrl = addrId
      ? "https://www.facebook.com/marketplace/item/" + addrId + "/"
      : "https://www.facebook.com/marketplace/you/selling";
    // [VERIFY-ADDR-345-END]
    await chrome.storage.local.set({ current_posting_job: jobAddr });
    await jitter(1200, 2500); // human pacing, as every job launch
    const tab = await chrome.tabs.create({
      active: false,
      url: startUrl
    });
    if (tab && tab.id != null) {
      try {
        await chrome.tabs.update(tab.id, { autoDiscardable: false });
      } catch (e) { /* non-fatal: the read still runs, just unprotected */ }
      const { current_posting_job: j } =
        await chrome.storage.local.get(["current_posting_job"]);
      if (j && j.queueId === item.id) {
        j.tabId = tab.id;
        await chrome.storage.local.set({ current_posting_job: j });
      }
    }
    console.log(`[AutoLaunch] Verify listing launched (queue item ${item.id}, vin ${item.vin || "?"}).`);
  } catch (err) {
    console.warn("[AutoLaunch] Verify listing launch failed:",
      err && err.message ? err.message : err);
    try {
      await sbPatch(`auto_posting_queue?id=eq.${item.id}`, { status: "failed" });
      await logFailure(item.id, "verify_launch_failed");
    } catch (e) { /* nothing left to write with */ }
    try {
      await chrome.storage.local.remove(["current_posting_job"]);
    } catch (e) { /* slot hygiene only */ }
  }
}

// Finish (v2.1.142, note 92): the content side reports
// its reads; the pure decider rules the settle. The tab
// closes either way (a verify never leaves a tab
// behind) and the slot frees for the next job.
async function finishVerifyListing342(message) {
  const { current_posting_job: job } =
    await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== message.queueId || job.action !== "verify_listing") return;
  const ruled = decideVerifySettle342(message);
  try {
    if (ruled.settle === "completed") {
      await sbPatch(`auto_posting_queue?id=eq.${job.queueId}`, {
        status: "completed",
        executed_at: new Date().toISOString(),
        error_message: ruled.errorMessage
      });
      console.log(`[AutoLaunch] Verify listing settled with a verdict (queue item ${job.queueId}).`);
    } else {
      // v2.1.143: the reason rides the row itself — verify
      // rows are Luna's own bookkeeping, and luna-repairs
      // reads the failure text from the row when it counts
      // silent failures and escalates (spec §11). Before
      // this, the reason reached only the local failure log
      // and the console, so an escalation carried no
      // diagnostics.
      await sbPatch(`auto_posting_queue?id=eq.${job.queueId}`, {
        status: "failed",
        error_message: ruled.errorMessage
      });
      await logFailure(job.queueId, ruled.errorMessage);
      console.log(`[AutoLaunch] Verify listing produced no verdict (queue item ${job.queueId}): ${ruled.errorMessage}`);
    }
  } catch (e) { /* the watchdog settles a stuck row */ }
  try {
    if (job.tabId != null) await chrome.tabs.remove(job.tabId);
  } catch (e) { /* tab already gone */ }
  await chrome.storage.local.remove(["current_posting_job"]);
}

// Launch (v2.1.136, note 86): the run row first (its id
// rides the job), then the job slot, then the background
// tab on the Selling page — the exact launch shape every
// scan job uses, minus the car. Any failure fails the
// queue row honestly and closes the run row as failed;
// nothing is left processing on a launch that never
// reached Facebook.
async function launchReconcileSweep336(item, userId) {
  let runId = null;
  try {
    const runRows = await sbPost("reconciliation_runs", {
      user_id: userId, status: "running"
    });
    runId = runRows && runRows[0] ? runRows[0].id : null;
    if (!runId) throw new Error("reconcile_run_insert_empty");
    await chrome.storage.local.remove(["reconcile_scan_state"]);
    await chrome.storage.local.set({
      current_posting_job: {
        queueId: item.id,
        userId,
        action: "reconcile",
        reconcileRunId: runId,
        claimedAt: new Date().toISOString()
      }
    });
    await jitter(1200, 2500); // human pacing, as every job launch
    const tab = await chrome.tabs.create({
      active: false,
      url: "https://www.facebook.com/marketplace/you/selling"
    });
    if (tab && tab.id != null) {
      try {
        await chrome.tabs.update(tab.id, { autoDiscardable: false });
      } catch (e) { /* non-fatal: the sweep still runs, just unprotected */ }
      const { current_posting_job: j } =
        await chrome.storage.local.get(["current_posting_job"]);
      if (j && j.queueId === item.id) {
        j.tabId = tab.id;
        await chrome.storage.local.set({ current_posting_job: j });
      }
    }
    console.log(`[AutoLaunch] Reconciliation sweep launched (run ${runId}, queue item ${item.id}).`);
  } catch (err) {
    console.warn("[AutoLaunch] Reconciliation sweep launch failed:",
      err && err.message ? err.message : err);
    if (runId) {
      try {
        await sbPatch(`reconciliation_runs?id=eq.${runId}`, {
          status: "failed",
          note: "launch_failed: " +
            String((err && err.message) || err || "unknown").slice(0, 300),
          finished_at: new Date().toISOString()
        });
      } catch (e) { /* the queue-row failure below still lands */ }
    }
    try {
      await sbPatch(`auto_posting_queue?id=eq.${item.id}`, { status: "failed" });
      await logFailure(item.id, "reconcile_launch_failed");
    } catch (e) { /* nothing left to write with */ }
    try {
      await chrome.storage.local.remove(["current_posting_job"]);
    } catch (e) { /* slot hygiene only */ }
  }
}

// Finish (v2.1.136, note 86): the content side reports
// the raw scan; the believed set is read FRESH here, the
// pure decider rules, and the run + items land in the
// reconciliation tables. The queue row ends "completed"
// (a failed scan ends it "failed" with the reason in its
// failure log) — the same settle shape as a share. The
// stamps are never touched: a phantom is a report, not a
// repair.
// Note 87 (v2.1.137): completeness now passes through
// the zero-card guard (a scan that saw no listings
// while stamps exist is never complete), and the run
// note is composed by reconcileScanNote337, which
// files what the scan actually saw beside the reason.
async function finishReconcileSweep336(message) {
  const { current_posting_job: job } =
    await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== message.queueId || job.action !== "reconcile") return;
  const runId = job.reconcileRunId || message.runId || null;
  try {
    if (!runId) throw new Error("reconcile_run_id_missing");
    if (message.ok === false) {
      await sbPatch(`reconciliation_runs?id=eq.${runId}`, {
        status: "failed",
        note: "scan_failed: " +
          String(message.error || "unknown").slice(0, 300),
        finished_at: new Date().toISOString()
      });
      await sbPatch(`auto_posting_queue?id=eq.${job.queueId}`, { status: "failed" });
      await logFailure(job.queueId,
        "reconcile_scan_failed:" + String(message.error || "unknown").slice(0, 120));
      console.log(`[AutoLaunch] Reconciliation sweep failed: ${message.error || "unknown"}`);
    } else {
      const believedRows = await sbGet(
        `scraped_inventory?user_id=eq.${job.userId}` +
        `&marketplace_posted_at=not.is.null` +
        `&select=vin,stock_number,marketplace_posted_price&limit=2000`
      );
      const believed = (believedRows || []).map(r => ({
        vin: r.vin,
        stock_number: r.stock_number,
        stamp_price: r.marketplace_posted_price
      }));
      const scanned = Array.isArray(message.scanned) ? message.scanned : [];
      const verdict = decideReconciliation336(believed, scanned);
      if (verdict.items.length) {
        const rows = verdict.items.map(it =>
          Object.assign({ run_id: runId, user_id: job.userId }, it));
        for (let i = 0; i < rows.length; i += 100) {
          await sbPost("reconciliation_items", rows.slice(i, i + 100));
        }
      }
      const seenCount = Number(message.cardsSeen) || scanned.length;
      const guard337 = reconcileCompleteness337({
        scanComplete: message.scanComplete === true,
        listingsSeen: seenCount,
        believedCount: believed.length
      });
      const complete = guard337.complete;
      await sbPatch(`reconciliation_runs?id=eq.${runId}`, {
        status: "completed",
        scan_complete: complete,
        listings_seen: seenCount,
        matched_count: verdict.counts.matched,
        phantom_count: verdict.counts.phantom,
        orphan_count: verdict.counts.orphan,
        note: reconcileScanNote337({
          complete,
          zeroGuard: guard337.zeroGuard,
          believedCount: believed.length,
          diag: message.scanDiag || null
        }),
        finished_at: new Date().toISOString()
      });
      // [RECONCILE-YIELD-339-NOTE-BEGIN] — card-yield
      // instrumentation (v2.1.139, header note 89): the
      // content side's per-card yield tally (why each
      // rendered card produced no listing ID) rides the
      // run note as an append, so a scan that saw cards
      // but read no IDs explains itself card-class by
      // card-class. Fail-open: the run's own settle
      // above stands either way.
      try {
        const yield339 = message.scanDiag && message.scanDiag.yield339;
        if (yield339 && Number(yield339.unidentified) > 0 &&
            typeof yield339.summary === "string" && yield339.summary) {
          const cur = await sbGet(
            `reconciliation_runs?id=eq.${runId}&select=note`);
          const curNote = cur && cur[0] ? String(cur[0].note || "") : "";
          const appended = (curNote ? curNote + " | " : "") +
            "card yield: " + yield339.summary;
          await sbPatch(`reconciliation_runs?id=eq.${runId}`, {
            note: appended.slice(0, 900)
          });
        }
      } catch (e) { /* the run note above stands */ }
      // [RECONCILE-YIELD-339-NOTE-END]
      await sbPatch(`auto_posting_queue?id=eq.${job.queueId}`, {
        status: "completed", executed_at: new Date().toISOString()
      });
      console.log(`[AutoLaunch] Reconciliation sweep done: ` +
        `${verdict.counts.matched} matched, ${verdict.counts.phantom} phantom, ` +
        `${verdict.counts.orphan} orphan (scan ${complete ? "complete" : "INCOMPLETE"}).`);
    }
  } catch (err) {
    console.warn("[AutoLaunch] Reconciliation finish failed:",
      err && err.message ? err.message : err);
    try {
      await sbPatch(`auto_posting_queue?id=eq.${job.queueId}`, { status: "failed" });
      await logFailure(job.queueId, "reconcile_finish_failed");
    } catch (e) { /* a dead token leaves the run visibly stale instead */ }
  }
  await chrome.storage.local.remove(["current_posting_job"]);
  scheduleJobTabClose(job);
}
// [RECONCILE-336-END]

// [PRICE-RECOVERY-338-BEGIN] — price-edit escalation ladder
// (v2.1.138, header note 88). Spec: the failure-recovery
// spec of 2026-11-15, amendment of 2026-11-16 ("price-edit
// escalation to delete+repost — APPROVED"), with §3 budgets
// and §6 marker-first bookkeeping. The ladder, for
// update_price jobs only:
//   1. The edit itself runs exactly as before (§4E identity:
//      car + VIN + stock; the price shown is never a gate).
//   2. A RETRY (the row's error_message carries recovery
//      markers from a prior failed attempt) first re-reads
//      the listing on a patient fresh load — the content
//      side's preverify. Target price already live settles
//      the job as success and advances the stamp (the
//      Sonata/Corolla false-failure cure); old price proven
//      live arms the escalation proof for this run; an
//      unreadable listing fails safe WITHOUT counting an
//      attempt (an unverifiable read is not an attempt).
//   3. Failures settle here, not in the blind terminal
//      path: attempts are counted in error_message markers
//      (recovery_attempts:N/3, recovery_failed_at,
//      recovery_helper, recovery_next), the row re-queues
//      to pending inside a 24h backoff (immediate when the
//      helper version changed since the last attempt — the
//      claim side's due gate reads the same markers), and
//      the app's manual Retry (status pending +
//      error_message null) resets the budget by erasing
//      the markers. Budget: 3 attempts.
//   4. When the final attempt fails with the old price
//      proven live by this run's preverify, the content
//      side converts the job in place: it opens the listing
//      and proves identity there (§4E delete identity:
//      car + VIN), then flips the STORED job to a delete —
//      the ordinary delete flow performs the removal and
//      its fresh-load proof; no parallel deleter exists.
//      Only a delete that finishes here (stamp cleared)
//      queues the fresh post row, in the producers' own
//      shape, at the car's current dealer price; the post
//      path's claim-time reel gate owns reel holds as
//      usual. Identity unverifiable, listing unreadable,
//      or delete unverifiable stops the ladder with a
//      plain-words needs-you failure and NO repost — a
//      duplicate listing is the one outcome worse than a
//      stale price.
// recovery_of is written on the REPOST row (its lineage:
// the price row it descends from); the price row itself is
// re-queued in place, so it is its own lineage.
// [PURE-PRICE-RECOVERY-338-BEGIN] — extracted and
// unit-exercised by the test harness; keep these free of
// DOM/chrome references (values in, values out).
const PRICE_RECOVERY_MAX_ATTEMPTS_338 = 3;
const PRICE_RECOVERY_BACKOFF_MS_338 = 24 * 60 * 60 * 1000;
// The marker read: recovery state lives in the row's
// error_message (no schema change) and is regex-found
// anywhere in it, so it survives composition with the
// field_diag JSON the failure settles append after it.
function parsePriceRecovery338(errorMessage) {
  const out = { attempts: 0, next: null, helper: null, failedAt: null };
  const text = String(errorMessage == null ? "" : errorMessage);
  if (!text) return out;
  const a = text.match(/recovery_attempts:(\d+)\s*\/\s*(\d+)/);
  if (a) out.attempts = parseInt(a[1], 10) || 0;
  const n = text.match(/recovery_next:(\S+)/);
  if (n) out.next = n[1];
  const h = text.match(/recovery_helper:(\S+)/);
  if (h) out.helper = h[1];
  const f = text.match(/recovery_failed_at:(\S+)/);
  if (f) out.failedAt = f[1];
  return out;
}
// The claim-time due gate: a row with attempts spent is
// due when its backoff has passed, when no backoff was
// recorded, or IMMEDIATELY when the helper version changed
// since the last attempt (a new build may have fixed the
// failure). A row with no markers is a first attempt —
// always due.
function priceRecoveryDue338(parsed, currentVersion, nowMs) {
  if (!parsed || !(parsed.attempts > 0)) return true;
  if (!parsed.next) return true;
  if (parsed.helper && currentVersion &&
      parsed.helper !== currentVersion) return true;
  const nextMs = Date.parse(parsed.next);
  if (!isFinite(nextMs)) return true;
  return nowMs >= nextMs;
}
// The failure settle decision. Attempts count ACTIONS
// TAKEN (an edit attempted); the unverifiable and
// listing-gone verdicts arrive with their own reasons and
// never burn one. Everything else burns one; the budget
// is PRICE_RECOVERY_MAX_ATTEMPTS_338.
function decidePriceFailure338(input) {
  const spentRaw = input && input.attemptsSpent;
  const spent = (typeof spentRaw === "number" && isFinite(spentRaw) &&
    spentRaw > 0) ? Math.floor(spentRaw) : 0;
  const reason = String((input && input.reason) || "");
  if (reason === "price_recovery_unverifiable") {
    return { outcome: "requeue", kind: "unverifiable", attempts: spent };
  }
  if (reason === "price_recovery_listing_gone") {
    return { outcome: "terminal", kind: "gone", attempts: spent };
  }
  if (reason === "price_escalation_identity") {
    return { outcome: "terminal", kind: "needs_you",
      attempts: Math.min(spent + 1, PRICE_RECOVERY_MAX_ATTEMPTS_338) };
  }
  const attempts = spent + 1;
  if (attempts >= PRICE_RECOVERY_MAX_ATTEMPTS_338) {
    return { outcome: "terminal", kind: "needs_you", attempts };
  }
  return { outcome: "requeue", kind: "retry", attempts };
}
// The record written into error_message: a plain-words
// sentence a human can act on, then the §6 markers. The
// failure settles append the compacted field_diag JSON
// after it (the reel-gate settle's composition), and the
// markers stay regex-findable anywhere in the field.
function priceRecoveryRecord338(input) {
  const kind = String((input && input.kind) || "retry");
  const attempts = (input && input.attempts) || 0;
  const failedAt = (input && input.failedAt) || "";
  const helper = (input && input.helper) || "";
  const markers = "recovery_attempts:" + attempts + "/" +
    PRICE_RECOVERY_MAX_ATTEMPTS_338 +
    (failedAt ? " recovery_failed_at:" + failedAt : "") +
    (helper ? " recovery_helper:" + helper : "");
  if (kind === "unverifiable") {
    return "Price update paused: the listing could not be read on " +
      "Facebook, so this try was NOT counted as an attempt — " +
      "AutoLaunch will check again automatically. " + markers +
      ((input && input.next) ? " recovery_next:" + input.next : "");
  }
  if (kind === "gone") {
    return "Price update stopped: this car's listing is no longer " +
      "on Facebook, so there is nothing to update. " + markers;
  }
  if (kind === "needs_you") {
    return "Needs you: the price could not be updated after " +
      PRICE_RECOVERY_MAX_ATTEMPTS_338 + " attempts, and AutoLaunch " +
      "could not safely finish removing the listing to post it " +
      "fresh — please check this car on Facebook. " + markers;
  }
  if (kind === "escalated") {
    return "The price would not update after " +
      PRICE_RECOVERY_MAX_ATTEMPTS_338 + " attempts, so the old " +
      "listing was removed and the car was queued to post fresh " +
      "at the current price. " + markers +
      ((input && input.repostRowId)
        ? " price_repost_row:" + input.repostRowId : "");
  }
  return "Price update attempt " + attempts + " of " +
    PRICE_RECOVERY_MAX_ATTEMPTS_338 + " did not stick — AutoLaunch " +
    "will try again automatically. " + markers +
    ((input && input.next) ? " recovery_next:" + input.next : "");
}
// [PURE-PRICE-RECOVERY-338-END]
// The version the markers stamp and the due gate compares
// against — this build's own manifest version.
const PRICE_RECOVERY_VERSION_338 = (() => {
  try { return chrome.runtime.getManifest().version || ""; }
  catch (e) { return ""; }
})();
// The ordinary price-failure settle (ladder rungs 2–3):
// re-queue the SAME row with its markers, or fail it
// terminally with the needs-you record. Settles the stored
// job exactly like the reel-gate settle does (failure log
// + tab close + slot clear). Returns false only by
// throwing — the caller catches and falls through to the
// ordinary terminal path, so a failed write never loses
// the row.
async function settlePriceFailure338(job, reason, diags) {
  const queueId = job.queueId;
  const rec = job.priceRecovery || {};
  const dec = decidePriceFailure338(
    { attemptsSpent: rec.attempts || 0, reason });
  const failedAt = new Date();
  const nextIso = dec.outcome === "requeue"
    ? new Date(failedAt.getTime() + PRICE_RECOVERY_BACKOFF_MS_338).toISOString()
    : null;
  const record = priceRecoveryRecord338({
    kind: dec.kind, attempts: dec.attempts,
    failedAt: failedAt.toISOString(),
    helper: PRICE_RECOVERY_VERSION_338, next: nextIso
  });
  const diagText = compactDiagError(diags);
  const errorMessage = diagText ? record + "\n" + diagText : record;
  if (dec.outcome === "requeue") {
    await sbPatch(`auto_posting_queue?id=eq.${queueId}`, {
      status: "pending", error_message: errorMessage
    });
  } else {
    await applyFailed(queueId, errorMessage);
  }
  await logFailure(queueId,
    "price_recovery:" + dec.kind + " (" + dec.attempts + "/" +
    PRICE_RECOVERY_MAX_ATTEMPTS_338 + ")");
  scheduleJobTabClose(job);
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log(`[AutoLaunch] Price recovery: job ${queueId} ${dec.kind} — attempts ${dec.attempts}/${PRICE_RECOVERY_MAX_ATTEMPTS_338} (${dec.outcome}).`);
  return true;
}
// The escalation-stop settle: the ladder reached for the
// delete and could not prove it safe (identity wrong or
// unreadable, or the converted delete itself failed).
// Terminal, plain-words needs-you, markers at the spent
// budget — and NEVER a repost: this function contains no
// queue insert, by design (the duplicate-listing guard).
async function settlePriceEscalationFailure338(job, reason, diags) {
  const queueId = job.queueId;
  const esc = job.priceEscalation || {};
  const attempts = (typeof esc.attempts === "number" && esc.attempts > 0)
    ? Math.min(esc.attempts, PRICE_RECOVERY_MAX_ATTEMPTS_338)
    : PRICE_RECOVERY_MAX_ATTEMPTS_338;
  const record = priceRecoveryRecord338({
    kind: "needs_you", attempts,
    failedAt: new Date().toISOString(),
    helper: PRICE_RECOVERY_VERSION_338
  });
  const escDiag = {
    field: "price_escalation", element: null, rungsAttempted: [],
    readBack: "", expected: null, cdpError: null,
    note: "escalation stopped (" +
      String(reason || "unknown").slice(0, 80) +
      ") — no repost was queued",
    detail: null
  };
  const allDiags = [escDiag].concat(Array.isArray(diags) ? diags : []);
  const diagText = compactDiagError(allDiags);
  const errorMessage = diagText ? record + "\n" + diagText : record;
  await applyFailed(queueId, errorMessage);
  await logFailure(queueId,
    "price_escalation_needs_you (" + attempts + "/" +
    PRICE_RECOVERY_MAX_ATTEMPTS_338 + ")");
  scheduleJobTabClose(job);
  await chrome.storage.local.remove(["current_posting_job"]);
  console.warn(`[AutoLaunch] Price escalation stopped for job ${queueId}: ${reason} — no repost queued.`);
  return true;
}
// The escalation success settle: runs ONLY from a delete
// finish (the removal is proven and the stamp is clear).
// Queues exactly one fresh post row in the producers' own
// shape — the scraper's auto-post row (target_channel
// "marketplace", the car's current dealer price re-read
// from inventory at settle time) with the action spelled
// out and the lineage marker on it; awaiting_reel stays
// false because the post path's claim-time reel gate owns
// holds for every post row. A live post row for the VIN
// already standing is adopted, never duplicated. Then the
// escalation record lands on the settled price row
// (fail-open, the writeReelAttachDiag precedent). Fully
// fail-open: the delete stands whatever happens here.
async function settlePriceEscalationDeleted338(jobLike) {
  try {
    const queueId = jobLike.queueId;
    const userId = jobLike.userId;
    const vin = jobLike.car && jobLike.car.vin;
    const esc = jobLike.priceEscalation || {};
    if (!queueId || !userId || !vin) return;
    let repostId = null;
    const existing = await sbGet(
      `auto_posting_queue?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}` +
      `&action=eq.post&status=in.(pending,processing)&select=id&limit=1`);
    if (existing && existing.length) {
      repostId = existing[0].id;
    } else {
      let carRow = null;
      try {
        const cars = await sbGet(
          `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}&limit=1`);
        carRow = cars && cars.length ? cars[0] : null;
      } catch (e) { /* the escalation record still lands below */ }
      const invPrice = carRow ? Number(carRow.price) : NaN;
      const price = (isFinite(invPrice) && invPrice > 0)
        ? Math.round(invPrice)
        : (esc.toPrice != null ? esc.toPrice : null);
      const inserted = await sbPost("auto_posting_queue", {
        user_id: userId,
        vin,
        target_channel: "marketplace",
        action: "post",
        status: "pending",
        year: carRow ? (carRow.year ?? null) : (jobLike.car.year ?? null),
        make: carRow ? (carRow.make || null) : (jobLike.car.make || null),
        model: carRow ? (carRow.model || null) : (jobLike.car.model || null),
        stock_num: carRow ? (carRow.stock_number || null)
          : (jobLike.car.stock_num || null),
        price,
        awaiting_reel: false,
        error_message: "recovery_of:" + queueId,
        created_at: new Date().toISOString()
      });
      const row = Array.isArray(inserted) ? inserted[0] : inserted;
      repostId = row && row.id ? row.id : null;
    }
    const record = priceRecoveryRecord338({
      kind: "escalated",
      attempts: (typeof esc.attempts === "number" && esc.attempts > 0)
        ? esc.attempts : PRICE_RECOVERY_MAX_ATTEMPTS_338,
      failedAt: esc.armedAt || null,
      helper: PRICE_RECOVERY_VERSION_338,
      repostRowId: repostId
    });
    try {
      await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
        { error_message: record });
    } catch (e) { /* best-effort record; delete + repost stand */ }
    console.log(`[AutoLaunch] Price escalation complete for job ${queueId}: listing removed, repost row ${repostId || "(already standing)"} queued.`);
  } catch (e) {
    console.warn("[AutoLaunch] Price escalation repost settle failed (the listing IS deleted and its stamp IS clear):", e && e.message || e);
  }
}
// [PRICE-RECOVERY-338-END]
// [ENV-DEFER-339-BEGIN] — environment starvation is a
// DEFER, not a FAIL (v2.1.139, header note 89). Ground
// truth (Matthew's desk, 2026-11-16 evening): every
// failure that night carried vis:hidden — the desk PC
// slept/locked in bursts, and in a hidden/frozen tab
// Facebook renders only the Selling list's boot chunk
// (~5 cards) and its file uploader never starts. Seven
// attach jobs died attach_unverified with the network
// witness at upload_posts:0 (the reel downloaded fine,
// CDP delivery engaged — the upload simply never began);
// four deletes burned FAILED on scans of a 5-card
// render; one post's chained attach and chained delete
// both starved into reel_needs_attention. None of those
// verdicts proved anything about the listings — the
// environment could not work, so the job must not be
// charged with the failure.
// The contract:
//   - The content side owns the page evidence. Its pure
//     deciders (content.js, note 89) evaluate the
//     starvation signatures at the failure sites — a
//     Selling scan that sampled a hidden tab and never
//     grew past the boot-chunk census with zero strict
//     matches, or an editor attach whose network witness
//     recorded zero upload POSTs across the full
//     delivery — and record ONE step note (field
//     "env_starvation") when a signature holds.
//   - This side owns the bookkeeping: the pure decider
//     below re-validates the note (action allowlist +
//     the facts recorded on the note itself) and the
//     settle returns the row to pending under an
//     env_deferred: marker. NO failure counter moves:
//     the price ladder's recovery_attempts are neither
//     incremented nor erased (existing markers are
//     carried over verbatim), the list_never_grew retry
//     is not consumed, and no gate-chain hop advances —
//     the settle returns from finishJobFailed before
//     the chain propagation, so a starved chained
//     attach never escalates to a delete that would
//     starve the same way.
//   - Genuine failures are untouched: identity
//     mismatches on a readable page, an editor that
//     never appears on a healthy rendered page, a save
//     Facebook drops on a healthy page, a wrong-VIN
//     twin — none of them can produce the note, and
//     the decider defers nothing without it.
// [PURE-ENV-DEFER-339-BEGIN] — extracted and
// unit-exercised by the test harness; keep free of
// DOM/chrome references (values in, values out).
const ENV_DEFER_ACTIONS_339 = ["attach_video", "delete", "update_price"];
const ENV_DEFER_CENSUS_CEILING_339 = 5;
const ENV_DEFER_CLAIM_DIAG_THROTTLE_MS_339 = 10 * 60 * 1000;
// The failure-settle decider: defer only when the
// content side's starvation note rides the failure's
// diagnostics AND the facts recorded on the note still
// corroborate it (the note is evidence, not a verdict
// this side takes on faith).
function decideEnvDefer339(input) {
  const o = input || {};
  if (ENV_DEFER_ACTIONS_339.indexOf(o.action) < 0) {
    return { defer: false, why: "action_not_deferrable" };
  }
  const diags = Array.isArray(o.diags) ? o.diags : [];
  let note = null;
  for (const d of diags) {
    if (d && d.field === "env_starvation" &&
        typeof d.note === "string" &&
        d.note.indexOf("env_starved:") === 0) { note = d; break; }
  }
  if (!note) return { defer: false, why: "no_starvation_note" };
  const kind = note.note.slice("env_starved:".length);
  const detail = String(note.detail || "");
  if (kind === "scan") {
    if (!/(^|\s)vis:hidden/.test(detail)) {
      return { defer: false, why: "note_vis_unproven" };
    }
    const cm = detail.match(/census:(\d+)/);
    if (!cm) return { defer: false, why: "note_census_missing" };
    if (Number(cm[1]) > ENV_DEFER_CENSUS_CEILING_339) {
      return { defer: false, why: "census_grew" };
    }
    return { defer: true, kind: "scan" };
  }
  if (kind === "attach_net") {
    const um = detail.match(/upload_posts:(\d+)/);
    if (!um) return { defer: false, why: "note_witness_missing" };
    if (Number(um[1]) !== 0) {
      return { defer: false, why: "uploads_flowed" };
    }
    return { defer: true, kind: "attach_net" };
  }
  return { defer: false, why: "unknown_kind" };
}
// The record written into the deferred row's
// error_message: begins with the env_deferred: marker,
// carries the original failure reason and an ISO
// timestamp, and — for a price row mid-ladder — the
// ladder's existing recovery markers carried over
// verbatim, so a defer neither burns nor resets the
// budget (the claim due gate and the ladder read them
// exactly as before). The caller appends the compacted
// field_diag after it, the 338 composition.
function envDeferRecord339(input) {
  const o = input || {};
  let out = "env_deferred:" + String(o.kind || "scan") +
    " reason:" + String(o.reason || "unknown") +
    " at:" + String(o.at || "");
  const rec = o.recovery || null;
  if (rec && rec.attempts > 0) {
    out += " recovery_attempts:" + rec.attempts + "/" +
      (rec.max || 3);
    if (rec.failedAt) out += " recovery_failed_at:" + rec.failedAt;
    if (rec.helper) out += " recovery_helper:" + rec.helper;
    if (rec.next) out += " recovery_next:" + rec.next;
  }
  return out;
}
// The attach claim-window diagnostic decider (note 89,
// the claim wart): an attach row is claimable only
// through a live gate-chain record at stage "attach"
// (checkQueue's 3.21 exception) — a row whose chain
// record is gone can sit at the head of the created_at
// window forever, invisible: two attach rows were
// never claimed on 2026-11-16 while newer chained rows
// claimed all night. The writer below records the
// window whenever attach rows were in it and none was
// claimed; this decider throttles it to one record per
// distinct window signature per throttle window, so a
// permanently dormant row produces a steady heartbeat
// of evidence, not a flood.
function attachClaimDiag339(input) {
  const o = input || {};
  if (!(Number(o.attachCount) > 0)) {
    return { record: false, why: "no_attach_rows" };
  }
  if (o.itemAction === "attach_video") {
    return { record: false, why: "attach_claimed" };
  }
  const key = String(o.key || "");
  if (key && key === o.lastKey &&
      typeof o.lastAt === "number" && isFinite(o.lastAt) &&
      typeof o.nowMs === "number" &&
      (o.nowMs - o.lastAt) < ENV_DEFER_CLAIM_DIAG_THROTTLE_MS_339) {
    return { record: false, why: "throttled" };
  }
  return { record: true, why: "window_unclaimed" };
}
// [PURE-ENV-DEFER-339-END]

// The defer settle: the row returns to pending under
// the env_deferred: marker, with the compacted
// diagnostics appended (the evidence survives for the
// morning read). Slot hygiene mirrors the other
// requeue settles (failure log + tab close + slot
// clear); the CDP reel-file cleanup deliberately does
// NOT run — a deferred attach may still need its file,
// the list_never_grew precedent. Any write failure
// returns false and the ordinary terminal path below
// proceeds — a row is never lost to a defer.
async function settleEnvDefer339(job, reason, diags) {
  const queueId = job.queueId;
  const verdict = decideEnvDefer339({
    action: job.action, diags
  });
  if (!verdict.defer) return false;
  let recovery = null;
  try {
    const rows = await sbGet(
      `auto_posting_queue?id=eq.${queueId}&select=error_message`);
    const prev = rows && rows[0] ? rows[0].error_message : null;
    const parsed = parsePriceRecovery338(prev);
    if (parsed && parsed.attempts > 0) {
      recovery = {
        attempts: parsed.attempts,
        max: PRICE_RECOVERY_MAX_ATTEMPTS_338,
        failedAt: parsed.failedAt, helper: parsed.helper,
        next: parsed.next
      };
    }
  } catch (e) { /* the defer stands without the carry-over */ }
  const record = envDeferRecord339({
    kind: verdict.kind, reason,
    at: new Date().toISOString(), recovery
  });
  const diagText = compactDiagError(diags);
  const errorMessage = diagText ? record + "\n" + diagText : record;
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`, {
    status: "pending", error_message: errorMessage
  });
  await logFailure(queueId, "env_deferred:" + verdict.kind);
  scheduleJobTabClose(job);
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log(`[AutoLaunch] Job ${queueId} deferred (environment starved: ${verdict.kind}) — back to pending under the env_deferred marker; no failure budget burned.`);
  return true;
}

// The claim-window diagnostic writer (note 89):
// whenever a claim cycle's window held attach rows and
// none was claimed, file the window's row ids and each
// attach row's chain state (stage, or "none") on the
// first dormant attach row's failure-log channel —
// throttled by attachClaimDiag339. Fail-open: the
// diagnostic can never block or break a claim cycle.
const ATTACH_CLAIM_DIAG_KEY_339 = "al_attach_claim_diag_339";
async function noteAttachClaimWindow339(queueItems, chainMap, itemAction) {
  try {
    const items = Array.isArray(queueItems) ? queueItems : [];
    const attachRows = items.filter(q => claimActionOf(q) === "attach_video");
    if (!attachRows.length) return;
    const stages = attachRows.map(q => {
      const c = chainMap && q.vin ? chainMap[q.vin] : null;
      return (c && c.stage) ? String(c.stage) : "none";
    });
    const key = attachRows.map(q => q.id).join(",") + "|" + stages.join(",");
    let last = {};
    try {
      const got = await chrome.storage.local.get([ATTACH_CLAIM_DIAG_KEY_339]);
      last = (got && got[ATTACH_CLAIM_DIAG_KEY_339]) || {};
    } catch (e) { /* memory is a throttle, not a gate */ }
    const verdict = attachClaimDiag339({
      attachCount: attachRows.length, itemAction, key,
      lastKey: last.key || null,
      lastAt: typeof last.at === "number" ? last.at : null,
      nowMs: Date.now()
    });
    if (!verdict.record) return;
    try {
      await chrome.storage.local.set({
        [ATTACH_CLAIM_DIAG_KEY_339]: { key, at: Date.now() }
      });
    } catch (e) { /* the log entry below still lands */ }
    await logFailure(attachRows[0].id, "attach_claim_window_339", {
      field: "attach_claim_window",
      note: "attach rows in the claim window were not claimed",
      detail: ("window:" + items.map(q => q.id).join(",") +
        " attach:" + attachRows.map(q => q.id).join(",") +
        " chains:" + stages.join(",")).slice(0, 200)
    });
    console.log("[AutoLaunch] Attach claim window diagnostic filed (attach rows present, none claimed).");
  } catch (e) { /* fail-open: diagnostics never block claims */ }
}
// [ENV-DEFER-339-END]

// The DB writes that end a job, split out so a finish that collides with
// a dead token can be stashed and replayed when a fresh token arrives
// (see autolaunch_pending_finish below) instead of being lost.
async function applyPosted(queueId, vin, userId, postedPrice, reel) {
  // v2.1.86: a job that carried a reel also writes the
  // completion's reel_failed truth (decideReelCompletionFlag);
  // no reel -> the patch is exactly the pre-2.86 shape.
  const completion = { status: "posted" };
  const reelFlag = decideReelCompletionFlag(reel);
  if (reelFlag !== null) completion.reel_failed = reelFlag;
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`, completion);
  // Posted-price stamp (v2.1.62, header note 34): alongside the
  // posted-at stamp, record the price the post actually used —
  // the queue row's stamped price, carried on the job — as
  // marketplace_posted_price. It is the price the live listing
  // carries: removals match against it, and the drift pass diffs
  // the dealer's current price against it. A missing/invalid
  // price leaves the column untouched (null = fall back to the
  // current price, the pre-feature behavior).
  const stamp = { marketplace_posted_at: new Date().toISOString() };
  const pp = Number(postedPrice);
  if (isFinite(pp) && pp > 0) stamp.marketplace_posted_price = Math.round(pp);
  await sbPatch(
    `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}`,
    stamp
  );
}

// VIN reel attach diagnostics (v2.1.86, header note 41): an
// unverified attach files its forensics in the queue row's
// error_message, in the field_diag shape the failure path
// uses (compactDiagError) — the app never renders a posted
// row's error_message; the record exists for the database.
// STRICTLY FAIL-OPEN: a diag write may never fail a post
// whose listing is already live.
async function writeReelAttachDiag(queueId, errorMessage) {
  if (!errorMessage) return;
  try {
    await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
      { error_message: errorMessage });
  } catch (e) { /* the post stands; the console keeps the story */ }
}

// [USERVIDEO-166-BEGIN]
// 98. USER VEHICLE VIDEOS (v2.1.166 — Matthew, 2026-11-20):
// a user can record their own video of a car in the app
// (rebuild); it uploads to the private user-videos bucket
// and the VIN Reels stack normalizes it to the house spec
// (720p max H.264 MP4). At claim time the user's video
// OUTRANKS the rendered reel: a ready one resolves here as
// the job's reelHit (signed URL — the bucket is private),
// so the existing Downloads/AutoLaunch staging and the
// create-flow attach run it unchanged; a still-processing
// one HOLDS the post (user_video_processing:<status>; the
// normalization worker releases the hold when the video
// lands ready or fails). After a post is confirmed with
// the video attached AND verified, the server copies are
// deleted and the state row is marked consumed — the
// poster-reel consume rule, word for word (Matthew's hard
// requirement: the server copy is deleted after the post;
// a failed or unverified post keeps it, because it is the
// user's only copy). Deliberately NOT built here: no
// edit-flow attach for user videos (decideAttachQueue is
// untouched) — a repost of an already-posted car carries
// photos only in v1, and the server copy survives for the
// user's next fresh post.
// Claim-time wrapper: fetch the car's user-video row,
// decide, and — for a ready video — mint the signed URL
// the staging/download path will fetch. Any failure
// resolves to a plain no — never a throw into the claim
// loop.
async function userVideoForJob(userId, vin) {
  try {
    const rows = await sbGet(
      `user_vehicle_videos?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}` +
      `&limit=1&select=id,status,storage_path,raw_path`);
    const d = decideUserVideoAttach(rows && rows.length ? rows[0] : null);
    if (d.pending) return { pending: true, status: d.status };
    if (!d.attach) return null;
    const url = await userVideoSignedUrl(d.storagePath);
    if (!url) {
      console.log("[AutoLaunch] User video skipped at claim (user_video_sign_failed).");
      return null;
    }
    console.log(`[AutoLaunch] User video resolved at claim (row ${d.id}).`);
    return {
      url,
      reel: { id: null, source: "uservideo", attached: true, cardUrl: null },
      userVideo: { id: d.id, storagePath: d.storagePath, rawPath: d.rawPath, attached: true }
    };
  } catch (e) {
    console.log("[AutoLaunch] User video skipped at claim (user_video_resolve_failed).");
    return null;
  }
}

// Signed URL for a user-videos object: the bucket is
// private, so the helper signs with the user's own session
// (storage RLS: the path's first folder is the user id).
// One hour covers the claim -> stage -> attach window.
async function userVideoSignedUrl(storagePath) {
  const res = await fetch(
    `${SUPABASE_URL}/storage/v1/object/sign/user-videos/${storagePath}`,
    { method: "POST", headers: await sbHeaders(), body: JSON.stringify({ expiresIn: 3600 }) });
  if (!res.ok) return null;
  const j = await res.json().catch(() => null);
  return (j && typeof j.signedURL === "string" && j.signedURL)
    ? `${SUPABASE_URL}/storage/v1${j.signedURL}` : null;
}

// User-video consumption: after a post SUCCEEDS with the
// user's video attached and verified, the server copies
// have done their job — delete the normalized file (and
// any raw still present) from the user-videos bucket and
// mark the state row consumed (the row stays as the audit
// trail, paths nulled). STRICTLY FAIL-OPEN, exactly like
// consumeJobReel: the post is confirmed before this runs
// and nothing here may surface as a post failure.
async function consumeJobUserVideo(userId, vin, userVideo) {
  try {
    const d = decideUserVideoConsume(userVideo);
    if (!d.consume) return;
    const prefixes = [userVideo.storagePath];
    if (userVideo.rawPath && userVideo.rawPath !== userVideo.storagePath) {
      prefixes.push(userVideo.rawPath);
    }
    try {
      const res = await fetch(`${SUPABASE_URL}/storage/v1/object/user-videos`, {
        method: "DELETE",
        headers: await sbHeaders(),
        body: JSON.stringify({ prefixes })
      });
      if (!res.ok) {
        console.warn(`[AutoLaunch] User video storage delete returned ${res.status}; marking consumed anyway.`);
      }
    } catch (e) {
      console.warn("[AutoLaunch] User video storage delete failed; marking consumed anyway.");
    }
    await sbPatch(`user_vehicle_videos?id=eq.${d.id}`, {
      status: "consumed",
      storage_path: null,
      raw_path: null,
      consumed_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });
    console.log(`[AutoLaunch] User video ${d.id} consumed (posted for VIN ${vin}; server copies deleted).`);
  } catch (e) {
    console.warn("[AutoLaunch] User video consumption failed (non-fatal; the post stands).");
  }
}
// [USERVIDEO-166-END]
// VIN Reel consumption (v2.1.85, header note 40; since
// v2.1.86 the attach must be form-verified, note 41): after a post
// SUCCEEDS with a poster reel attached, the reel's job is done
// — delete its storage object and mark the row consumed (the
// Facebook post keeps its own copy; the app already ignores
// consumed rows). STRICTLY FAIL-OPEN: the post is confirmed
// before this runs, and nothing here may ever surface as a
// post failure. Delete-then-mark, the README's order: if the
// mark fails the row stays ready over a dead URL (the next
// claim's attach would fail honestly and post without it);
// if the delete fails the object lingers unviewed.
async function consumeJobReel(userId, vin, reel) {
  try {
    const d = decideReelConsume(reel);
    if (!d.consume) {
      if (reel && reel.attached === true && reel.source !== "poster") {
        console.log("[AutoLaunch] VIN reel attached was a manual reel — left in place (never consumed).");
      }
      return;
    }
    try {
      // v2.1.90 (header note 45): the end-card still beside
      // the mp4 is the reel's second object — it is deleted
      // in the same call, so a consumed reel leaves nothing
      // behind. A reel rendered before cards existed simply
      // has no second prefix hit; the delete is unaffected.
      const res = await fetch(`${SUPABASE_URL}/storage/v1/object/vin-reels`, {
        method: "DELETE",
        headers: await sbHeaders(),
        body: JSON.stringify({ prefixes: [`${userId}/${vin}.mp4`, `${userId}/${vin}-card.jpg`] })
      });
      if (!res.ok) {
        console.warn(`[AutoLaunch] VIN reel storage delete returned ${res.status}; marking consumed anyway.`);
      }
    } catch (e) {
      console.warn("[AutoLaunch] VIN reel storage delete failed; marking consumed anyway.");
    }
    await sbPatch(`vin_reels?id=eq.${d.reelId}`, {
      status: "consumed",
      consumed_at: new Date().toISOString()
    });
    console.log(`[AutoLaunch] VIN reel ${d.reelId} consumed (poster reel for VIN ${vin}).`);
  } catch (e) {
    console.warn("[AutoLaunch] VIN reel consumption failed (non-fatal; the post stands).");
  }
}

// Delete completion (v2.1.4): the queue row ends "completed" —
// there is no check constraint on status (verified against the live
// schema), and the app's queue view renders the value — with
// executed_at stamped, and the car's marketplace_posted_at cleared.
// That column is the app's ONLY derivation of "Posted", so clearing
// it is what truthfully returns the car to unposted once the listing
// is verifiably gone from Facebook.
async function applyDeleted(queueId, vin, userId) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
  await sbPatch(
    `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}`,
    // The posted price clears with the posted stamp (v2.1.62):
    // no live listing, no posted price — the invariant the
    // drift pass and the removal matcher both rely on.
    { marketplace_posted_at: null, marketplace_posted_price: null }
  );
}

// Share completion (v2.1.55, header note 29): the queue row ends
// "completed" with executed_at stamped — and NOTHING else. A
// share never touches scraped_inventory: the listing stays
// posted and marketplace_posted_at keeps its value.
async function applyShared(queueId) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
}

// Price-update completion (v2.1.62, header note 34): the queue
// row ends "completed" with executed_at stamped, and the car's
// marketplace_posted_price advances to the price the listing now
// shows. marketplace_posted_at is NEVER touched here — a price
// update is not a post, and that stamp feeds both the
// today's-posts count and the pacing anchor.
async function applyPriceUpdated(queueId, vin, userId, newPrice) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
  const np = Number(newPrice);
  if (isFinite(np) && np > 0) {
    await sbPatch(
      `scraped_inventory?vin=eq.${encodeURIComponent(vin)}&user_id=eq.${userId}`,
      { marketplace_posted_price: Math.round(np) }
    );
  }
}

// Edit-flow attach completion (v2.1.88, header note 43):
// the queue row ends "completed" with executed_at stamped —
// the price-update completion's exact semantics, since an
// attach is not a post: scraped_inventory's posted stamps
// are NEVER touched here (the daily count and the pacing
// anchor read them). The parent post row's reel_failed flag
// then clears — the car is no longer "posted without
// video". The parent is matched by user + VIN among posted
// rows still carrying the flag; a swept parent (the app
// ages finished rows out) matches nothing and the clear is
// skipped silently. The clear is fail-open: the attach DID
// land, and its own row already says so.
async function applyVideoAttached(queueId, vin, userId) {
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
    { status: "completed", executed_at: new Date().toISOString() });
  try {
    await sbPatch(
      `auto_posting_queue?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}&status=eq.posted&reel_failed=eq.true`,
      { reel_failed: false }
    );
  } catch (e) { /* the attach stands; the flag clear is bookkeeping */ }
}

// [PURE-RICHDESC-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// Rich listing descriptions (2026-11-10 — Matthew's
// build, promoted from the rebuild (bde99546) as
// v2.1.98; header note 51 in the content script and
// the worker): the emoji format the competitor posters use, fed
// ONLY by the car's scraped VDP payload (scraped_inventory
// .vdp_features — highlights, factory packages, exact-phrase
// claims, and the most specific engine/transmission strings,
// captured by the rebuild scraper from the dealer's own
// vehicle page). GROUNDING RULE: nothing renders that is not
// in the payload — no invented features, no inferred claims,
// no fact-asserting blurbs; the feature names print plain.
// When the account's rich_descriptions setting is off the
// composers never call this; when it is on but the car
// carries no usable payload, buildRichDescription returns ""
// and every composer falls back to the plain template
// BYTE-IDENTICAL to before this feature existed. PRICE
// RULE: package dollar values are factory OPTION prices,
// not the car's price — a package prints as its name only
// (richPackageName strips the value tail), and a final guard
// refuses the rich text outright when any $ figure other
// than the advertised price line survives. The one exception
// is the composer's own facts block: the advertised "Price:"
// line, which the guard counts exactly.
// Category map: the Highlighted Features shortlist is sorted
// by keyword, tested in the order safety → capability →
// tech → comfort (first match wins), so "Adaptive Cruise
// Control" lands in safety (adaptive cruise beats the plain
// cruise-control comfort term) and heated tech never
// outranks a safety term. Unmatched items are still real
// scraped features — they print under MORE FEATURES, capped
// like every section (section cap 6, package cap 8) so the
// post stays readable.
const RICH_SECTION_CAP = 6;
const RICH_PACKAGE_CAP = 8;
const RICH_FEATURE_CATEGORIES = [
  { key: "safety", re: /\b(blind spot|lane|collision|brake assist|emergency brak|automatic braking|backup camera|back-up camera|rear view camera|rearview camera|parking sensor|park assist|parking assist|cross traffic|pedestrian|airbags?|air bags?|traction control|stability control|tire pressure|tpms|anti-lock|antilock|abs|adaptive cruise|hill hold|hill descent|daytime running)\b/ },
  { key: "capability", re: /\b(4wd|awd|4x4|four-wheel|all-wheel|front-wheel drive|rear-wheel drive|tow|towing|hitch|trailer|payload|bed liner|tonneau|skid plate|off-road|off road|differential|transfer case|axle ratio|ground clearance|fox racing|roof rack|running boards?|side steps?|locking hubs?|sway control)\b/ },
  { key: "tech", re: /\b(bluetooth|carplay|android auto|navigation|wi-fi|wifi|hotspot|usb|touchscreen|touch screen|infotainment|satellite radio|siriusxm|hd radio|speakers?|sound system|audio system|wireless charging|aux input|voice recognition|voice control|sync|uconnect|onstar|telematics|hands-free|hands free)\b/ },
  { key: "comfort", re: /\b(heated|cooled|ventilated|leather|seats?|seating|sunroof|moonroof|climate|air conditioning|a\/c|remote start|remote engine start|keyless|cruise control|lumbar|armrest|steering wheel|memory|dual-zone|tri-zone|floor mats|all-weather)\b/ }
];
function richFeatureCategory(name) {
  const t = String(name == null ? "" : name).toLowerCase();
  for (let i = 0; i < RICH_FEATURE_CATEGORIES.length; i++) {
    if (RICH_FEATURE_CATEGORIES[i].re.test(t)) {
      return RICH_FEATURE_CATEGORIES[i].key;
    }
  }
  return "other";
}
function richPackageName(pkg) {
  // "Spray-In Bed Liner ($595 value)" → "Spray-In Bed
  // Liner": only a parenthetical carrying a $ figure is
  // stripped, so a real name parenthetical survives.
  return String(pkg == null ? "" : pkg)
    .replace(/\s*\([^)]*\$[^)]*\)\s*$/, "")
    .trim();
}
function richTrimDisplay(car) {
  // The stored trim is slug-corrupted on most rows — the
  // VDP URL slug glued to the VIN ("SE-1FADP3KE3GL273598",
  // "HYBRID-RX-350h-LUXURY-AWD-<VIN>"). Repair ONLY that
  // exact shape: strip the "-<VIN>" tail and un-slug the
  // remainder ("Black-Edition" → "Black Edition"). A clean
  // stored trim passes through untouched.
  let t = String((car && car.trim) || "").trim();
  const vin = String((car && car.vin) || "").trim();
  if (t && vin &&
      t.toUpperCase().endsWith("-" + vin.toUpperCase())) {
    t = t.slice(0, t.length - vin.length - 1)
      .replace(/-/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }
  return t;
}
function richCleanFeedString(s) {
  // Polish (2.99): the dealer feed's raw "-inc:" artifact
  // prints as ", incl. " - the FIRST occurrence only, words
  // after it verbatim; a string ending right at the
  // fragment drops it. Punctuation only (no-invention
  // rule); a string without the artifact passes through
  // untouched, so unaffected cars render byte-identical.
  const t = String(s == null ? "" : s);
  const frag = " -inc: ";
  const i = t.indexOf(frag);
  if (i >= 0) return t.slice(0, i) + ", incl. " + t.slice(i + frag.length);
  const tail = " -inc:";
  if (t.endsWith(tail)) return t.slice(0, t.length - tail.length).trimEnd();
  return t;
}
function buildRichDescription(car, settings) {
  const vf = (car && typeof car.vdp_features === "object" &&
    car.vdp_features) ? car.vdp_features : null;
  if (!vf) return "";
  const s = settings || {};
  const highlights = (Array.isArray(vf.highlights)
    ? vf.highlights : [])
    .map(x => String(x == null ? "" : x).trim())
    .filter(x => x);
  const claims = (vf.claims && typeof vf.claims === "object")
    ? vf.claims : {};
  const packages = (Array.isArray(vf.packages) ? vf.packages : [])
    .map(richPackageName)
    .filter(x => x);
  const anyClaim = claims.one_owner === true ||
    claims.no_accidents === true;
  if (!highlights.length && !packages.length && !anyClaim) {
    return "";
  }
  // Mileage posture: the composer's rules exactly (stored
  // >= 300 wins; an exact stored 1,000 on a New car is the
  // new-car default; below 300 / absent = unproven → the
  // 1,000 working figure with the default disclosure).
  const stored = (car.mileage != null && car.mileage !== "")
    ? Number(car.mileage) : null;
  const isNew = /^new$/i.test(String(car.condition || "").trim());
  const lm = (stored !== null && stored >= 300)
    ? { miles: stored, defaulted: isNew && stored === 1000 }
    : { miles: 1000, defaulted: true };
  const title = (`${car.year || ""} ${car.make || ""} ` +
    `${car.model || "Vehicle"} ${richTrimDisplay(car)}`)
    .trim().replace(/\s+/g, " ");
  const stockRaw = (car.stock_num != null &&
    String(car.stock_num).trim())
    ? car.stock_num : car.stock_number;
  const stock = stockRaw != null ? String(stockRaw).trim() : "";
  const carfax = car.carfax_url != null
    ? String(car.carfax_url).trim() : "";
  const engine = richCleanFeedString(typeof vf.engine_detail === "string"
    ? vf.engine_detail.trim() : "");
  const trans = richCleanFeedString(typeof vf.transmission_detail === "string"
    ? vf.transmission_detail.trim() : "");
  // The facts block: the composer's lines, in the
  // composer's order, under the emoji header — Price
  // (omitted when there is no usable advertised price: the
  // scraper's call/none states, or a non-positive stored
  // price), then VIN, Stock # (setting-gated), the CARFAX
  // line, and the mileage-default disclosure verbatim.
  const lines = [];
  lines.push(`🔥 ${title} 🔥`);
  if (car.color &&
      String(car.color).trim().toLowerCase() !== "standard") {
    lines.push(`🎨 Color: ${car.color}`);
  }
  if (car.interior_color &&
      String(car.interior_color).trim().toLowerCase() !== "standard") {
    lines.push(`🪑 Interior: ${car.interior_color}`);
  }
  if (lm.miles != null) {
    lines.push(`🛣️ Miles: ${lm.miles.toLocaleString()}`);
  }
  const engParts = [];
  if (engine) engParts.push(`Engine: ${engine}`);
  if (trans) engParts.push(`Transmission: ${trans}`);
  if (engParts.length) {
    lines.push(`⚙️ ${engParts.join(" | ")}`);
  }
  const priceStatus = String(car.price_status || "")
    .trim().toLowerCase();
  const priceNum = car.price != null ? Number(car.price) : 0;
  const hasPrice = priceStatus !== "call" &&
    priceStatus !== "none" && priceNum > 0;
  if (hasPrice) {
    lines.push(`Price: $${priceNum.toLocaleString()}`);
  }
  if (car.vin) lines.push(`VIN: ${car.vin}`);
  if (s.includeStock === true && stock) {
    lines.push(`Stock #: ${stock}`);
  }
  if (carfax) lines.push(`CARFAX report: ${carfax}`);
  if (lm.defaulted) {
    lines.push(isNew
      ? "Brand new vehicle — the mileage shown is a listing default; actual miles may be less."
      : "Mileage shown is a listing default — exact miles were not published for this vehicle; ask us for the current odometer reading.");
  }
  // Intro: real attributes only — the body word comes from
  // the car's own scraped body_type, the rest is generic
  // connective phrasing that asserts nothing.
  const bt = String(car.body_type || "").trim().toLowerCase();
  const bodyWord = bt.includes("truck") ? "truck"
    : bt.includes("suv") ? "SUV"
    : bt.includes("van") ? "van"
    : bt.includes("coupe") ? "coupe"
    : bt.includes("convertible") ? "convertible"
    : bt.includes("hatchback") ? "hatchback"
    : bt.includes("sedan") ? "sedan" : "vehicle";
  lines.push("");
  lines.push(`Looking for your next ${bodyWord}? This ${title} is on the lot and ready to go — here's what it brings:`);
  // HIGHLIGHTS: the scraped claims first (exact-phrase
  // flags only — never inferred), then the factory
  // packages by NAME.
  const hl = [];
  if (claims.one_owner === true) hl.push("✅ ONE OWNER! 👤");
  if (claims.no_accidents === true) hl.push("✅ NO ACCIDENTS!");
  if (packages.length) {
    hl.push("✅ Factory packages:");
    for (const p of packages.slice(0, RICH_PACKAGE_CAP)) {
      hl.push(`• ${p}`);
    }
  }
  // Categorized sections from the highlights shortlist.
  const buckets = { comfort: [], tech: [], safety: [], capability: [], other: [] };
  const seenH = new Set();
  for (const h of highlights) {
    const k = h.toLowerCase();
    if (seenH.has(k)) continue;
    seenH.add(k);
    buckets[richFeatureCategory(h)].push(h);
  }
  const SECTION_ORDER = [
    ["comfort", "👑 COMFORT & CONVENIENCE 👑"],
    ["tech", "📶 TECH & CONNECTIVITY 📶"],
    ["safety", "🛡️ SAFETY & DRIVER ASSIST 🛡️"],
    ["capability", "⚡ CAPABILITY ⚡"],
    ["other", "🔹 MORE FEATURES 🔹"]
  ];
  const sections = [];
  if (hl.length) {
    sections.push("✨ VEHICLE HIGHLIGHTS ✨\n" + hl.join("\n"));
  }
  for (const [key, head] of SECTION_ORDER) {
    const items = buckets[key].slice(0, RICH_SECTION_CAP);
    if (items.length) {
      sections.push(head + "\n" +
        items.map(i => `• ${i}`).join("\n"));
    }
  }
  if (!sections.length) return "";
  let desc = lines.join("\n") + "\n\n" + sections.join("\n\n");
  // Closing: the existing tagline, dealer block, and rep
  // contact line — the composer's elements, unchanged (the
  // contact pair through the same both-required rule as
  // repContactLine in the helper composers; the app mirror
  // inlines the pair the same way its plain path does).
  desc += "\n\nInspected and frontline ready. Message to set up a test drive!";
  const dealerLines = [s.dealershipName, s.dealershipAddress]
    .map(x => typeof x === "string" ? x.trim() : "")
    .filter(x => x);
  if (dealerLines.length) desc += `\n\n${dealerLines.join("\n")}`;
  const rn = typeof s.repName === "string" ? s.repName.trim() : "";
  const rp = typeof s.repPhone === "string" ? s.repPhone.trim() : "";
  if (rn && rp) desc += `\n\nCall or text ${rn} · ${rp}`;
  // PRICE GUARD: every $ in the text must be the advertised
  // price itself; anything else refuses the rich text and
  // the composer falls back to the plain template.
  const dollarCount = (desc.match(/\$/g) || []).length;
  const priceCount = hasPrice
    ? desc.split(`$${priceNum.toLocaleString()}`).length - 1
    : 0;
  if (dollarCount !== priceCount) return "";
  return desc;
}
// [PURE-RICHDESC-END]

// [PURE-CONTACT-BEGIN] — extracted and unit-exercised by
// the test harness; keep free of DOM/chrome references.
// The rep contact line (v2.1.90, header note 45): the ONE
// formatter behind all three description mirrors (the
// listing buildDescription, the worker's
// buildShareTextForCar, the app's buildShareDetailsText)
// and the reel end card's text. BOTH values required —
// either blank (or not a string at all) and the answer is
// the empty string, which every composer appends as
// nothing: the description stays byte-identical to before
// the feature existed.
function repContactLine(name, phone) {
  const n = typeof name === "string" ? name.trim() : "";
  const p = typeof phone === "string" ? phone.trim() : "";
  if (!n || !p) return "";
  return `Call or text ${n} · ${p}`;
}
// [PURE-CONTACT-END]

// The share row's details text (v2.1.56, header note 30): a
// worker-side rebuild of the listing description from the same
// inputs the posting composer's buildDescription uses — the
// description TEXT itself is built in the content script at
// post time and never reported back to the worker, so the
// worker reconstructs it from the job's car row and the
// claim-time settings riding the job (dealership identity,
// include_stock). Mirrors buildDescription + listingMileage
// line for line; the app carries the third copy of this
// builder (buildShareDetailsText) — keep all three in step.
function buildShareTextForCar(car, job) {
  if (!car) return "";
  // Rich descriptions (v2.1.98, header note 51): mirror
  // of the composer's branch — the job carries richDesc
  // from the same claim-time settings read; ON + a usable
  // payload and the share text IS the rich listing text,
  // byte for byte.
  if (job && job.richDesc === true) {
    const rich = buildRichDescription(car, {
      includeStock: job.includeStock === true,
      dealershipName: job.dealershipName,
      dealershipAddress: job.dealershipAddress,
      repName: job.repName,
      repPhone: job.repPhone
    });
    if (rich) return rich;
  }
  const norm = v => String(v == null ? "" : v).trim().toLowerCase().replace(/\s+/g, " ");
  const stored = car.mileage != null && car.mileage !== "" ? Number(car.mileage) : null;
  const isNew = /^new$/i.test(String(car.condition || "").trim());
  const lm = (stored !== null && stored >= 300)
    ? { miles: stored, defaulted: isNew && stored === 1000, isNew }
    : { miles: 1000, defaulted: true, isNew };
  const title = `${car.year || ""} ${car.make || ""} ${car.model || "Vehicle"} ${car.trim || ""}`.trim();
  const stockRaw = (car.stock_num != null && String(car.stock_num).trim())
    ? car.stock_num : car.stock_number;
  const stock = stockRaw != null ? String(stockRaw).trim() : "";
  // CARFAX report line (v2.1.61, header note 33): mirrors the
  // composer exactly — the car's stored carfax_url (scraper-
  // captured from its VDP badge) joins the facts block under the
  // stock line; absent or blank, the text is byte-identical to
  // 2.1.60. The claim-time car fetch is select-*, so the field
  // rides the job's car row with no new plumbing.
  const carfax = car.carfax_url != null ? String(car.carfax_url).trim() : "";
  let desc =
    `${title}\n` +
    `Price: $${(car.price || 0).toLocaleString()}\n` +
    (lm.miles != null ? `Mileage: ${lm.miles.toLocaleString()} miles\n` : "") +
    (car.color && norm(car.color) !== "standard" ? `Exterior: ${car.color}\n` : "") +
    (car.transmission ? `Transmission: ${car.transmission}\n` : "") +
    (car.vin ? `VIN: ${car.vin}\n` : "") +
    (job && job.includeStock === true && stock ? `Stock #: ${stock}\n` : "") +
    (carfax ? `CARFAX report: ${carfax}\n` : "") +
    (lm.defaulted
      ? (lm.isNew
        ? `\nBrand new vehicle — the mileage shown is a listing default; actual miles may be less.`
        : `\nMileage shown is a listing default — exact miles were not published for this vehicle; ask us for the current odometer reading.`)
      : "") +
    `\nInspected and frontline ready. Message to set up a test drive!`;
  const dealerLines = [
    job && typeof job.dealershipName === "string" ? job.dealershipName.trim() : "",
    job && typeof job.dealershipAddress === "string" ? job.dealershipAddress.trim() : ""
  ].filter(s => s);
  if (dealerLines.length) desc += `\n\n${dealerLines.join("\n")}`;
  // Rep contact line (v2.1.90, header note 45): the closing
  // line, after the dealership block — the third mirror
  // agrees byte for byte through repContactLine.
  const contact = repContactLine(job && job.repName, job && job.repPhone);
  if (contact) desc += `\n\n${contact}`;
  return desc;
}

// Post-success feed share (v2.1.55, header note 29): when the
// job's claim-time settings carried shareToFeed, queue ONE share
// row for the just-posted car — the producer contract the app's
// "Share to my feed" button writes (target_channel 'facebook',
// action 'share', the car's year/make/model/stock/price stamped
// on the row for the strict matcher). Dedupe-checked against
// live share rows for the VIN first, exactly like the app's
// producer. STRICTLY FAIL-OPEN: called only after the post is
// already final, wrapped so nothing it does can throw into,
// fail, or delay the completed post — worst case the share is
// skipped and the skip is logged.
async function maybeQueueFeedShare(job) {
  try {
    if (!job || job.shareToFeed !== true || !job.car || !job.car.vin || !job.userId) return;
    const car = job.car;
    const existing = await sbGet(
      `auto_posting_queue?user_id=eq.${job.userId}&vin=eq.${encodeURIComponent(car.vin)}&action=eq.share&status=in.(pending,processing)&select=id&limit=1`);
    if (existing && existing.length) {
      console.log(`[AutoLaunch] share_to_feed: a share for VIN ${car.vin} is already queued — not queueing another.`);
      return;
    }
    await sbPost("auto_posting_queue", {
      user_id: job.userId,
      vin: car.vin,
      target_channel: "facebook",
      action: "share",
      status: "pending",
      year: car.year != null ? car.year : null,
      make: car.make || null,
      model: car.model || null,
      stock_num: car.stock_num || car.stock_number || null,
      price: car.price != null ? Number(car.price) : null,
      // The details text (v2.1.56, header note 30) rides the
      // row so the share can carry the listing's description
      // into the feed post.
      share_text: buildShareTextForCar(car, job) || null,
      created_at: new Date().toISOString()
    });
    console.log(`[AutoLaunch] share_to_feed: queued a feed share for VIN ${car.vin} (posted car, toggle on).`);
  } catch (e) {
    console.warn("[AutoLaunch] share_to_feed: queueing the feed share failed and was skipped — the post itself is unaffected.", e && e.message || e);
  }
}

// Post-completion edit-flow attach queueing (v2.1.88,
// header note 43): when a post's poster reel was attached
// but NOT verified (decideAttachQueue), queue ONE
// attach_video row so a later claim can put the video on
// the live listing through its Edit form — the surface
// that keeps it. The row carries the producer shape the
// strict matcher needs: the car's year/make/model/stock
// and the POSTED price. Dedupe-checked against live attach
// rows for the VIN first, exactly like the feed share.
// STRICTLY FAIL-OPEN: called only after the post is
// already final; worst case the attach is skipped and the
// reel simply stays ready.
async function maybeQueueAttachVideo(userId, vin, carLike, postedPrice, reel, chainParentId, listingUrl, listingId) {
  try {
    // No NEW editor-attach rows for poster reels in this
    // build (v2.1.118, header note 69): decideAttachQueue
    // only ever queues poster reels, and under the
    // ready-only gate an unverified gated post aborts
    // instead of completing — the backstop's premise is
    // gone, and rows nothing claims are just noise. The
    // decision function itself is unchanged, dormant.
    // 3.21 exception (header note 72): a GATED poster
    // completion starts the post-then-attach chain — it
    // posted WITHOUT a create-flow attach on purpose, so
    // the editor attach is the plan, not a backstop.
    // decideGateChainAttach is the only road past this
    // early return, and only finishJobPosted's gated
    // call (and its replay) can open it.
    if (reel && reel.source === "poster" &&
        !decideGateChainAttach({
          gated: !!chainParentId,
          source: reel.source,
          attached: reel.attached === true,
          attachVerified: reel.attachVerified === true
        }).queue) {
      console.log(`[AutoLaunch] edit-flow attach: not queueing an attach row for VIN ${vin} — 3.18 attaches poster reels at creation.`);
      return;
    }
    const d = decideAttachQueue(reel);
    if (!d.queue) return;
    if (!userId || !vin || !carLike) return;
    const pp = Number(postedPrice);
    if (!isFinite(pp) || pp <= 0) return;
    // Aim seeding (v2.1.124, header note 75;
    // v2.1.125, header note 76): for a CHAINED
    // queueing, resolve the listing's identity NOW —
    // from the finish's confirmation id first (the
    // id the content side harvested from the matched
    // card's own item link — the one proven-live
    // witness), a parse of the finish URL second.
    // The listing-ID memory is NOT a seeding source:
    // it is written at editor-enter and lags one
    // attach behind (note 76). The aim rides the
    // chain record (both writes below) and, at claim
    // time, the attach job's payload: the verify's
    // target exists before the attach row is ever
    // claimed, instead of depending on a side effect
    // inside the editor incarnation. No source yields
    // an id: NOTHING is seeded — the chain is written
    // exactly as 3.23 wrote it and the unseeded attach
    // adopts the editor its scan opens (note 76).
    let aim324 = null;
    if (chainParentId) {
      aim324 = gateChainAimRecord324(
        gateChainAimFromConfirmationId325(listingId));
      if (!aim324) {
        aim324 = gateChainAimRecord324(
          gateChainAimFromListingUrl324(listingUrl));
      }
    }
    const existing = await sbGet(
      `auto_posting_queue?user_id=eq.${userId}&vin=eq.${encodeURIComponent(vin)}&action=eq.attach_video&status=in.(pending,processing)&select=id&limit=1`);
    if (existing && existing.length) {
      // 3.21 (header note 72): a gated completion chains
      // onto the row that is already live for this VIN —
      // dedupe is VIN-scoped, so that row IS this post's
      // attach; arming the chain to it claims it for the
      // parent below.
      if (chainParentId) {
        const entry324 = {
          parentQueueId: chainParentId,
          stage: "attach",
          attachQueueId: existing[0].id || null,
          queuedAt: new Date().toISOString()
        };
        if (aim324) Object.assign(entry324, aim324);
        await setGateChain(vin, entry324);
        await logGateChainAimSeeded324(
          existing[0].id || null, aim324);
      }
      console.log(`[AutoLaunch] edit-flow attach: an attach for VIN ${vin} is already queued — not queueing another.`);
      return;
    }
    const inserted321 = await sbPost("auto_posting_queue", {
      user_id: userId,
      vin,
      target_channel: "facebook",
      action: "attach_video",
      status: "pending",
      year: carLike.year != null ? carLike.year : null,
      make: carLike.make || null,
      model: carLike.model || null,
      stock_num: carLike.stock_num || carLike.stock_number || null,
      price: Math.round(pp),
      created_at: new Date().toISOString()
    });
    // 3.21 (header note 72): the chain record is written
    // only once the row exists — a failed insert leaves
    // no chain behind, exactly the pre-3.21 end state.
    if (chainParentId) {
      const row321 = Array.isArray(inserted321) ? inserted321[0] : inserted321;
      const entry324 = {
        parentQueueId: chainParentId,
        stage: "attach",
        attachQueueId: (row321 && row321.id) || null,
        queuedAt: new Date().toISOString()
      };
      if (aim324) Object.assign(entry324, aim324);
      await setGateChain(vin, entry324);
      await logGateChainAimSeeded324(
        (row321 && row321.id) || null, aim324);
    }
    console.log(`[AutoLaunch] edit-flow attach: queued a video attach for VIN ${vin} (create-flow attach unverified).`);
  } catch (e) {
    console.warn("[AutoLaunch] edit-flow attach: queueing failed and was skipped — the post itself is unaffected.", e && e.message || e);
  }
}

async function applyFailed(queueId, errorMessage) {
  if (errorMessage) {
    try {
      await sbPatch(`auto_posting_queue?id=eq.${queueId}`,
        { status: "failed", error_message: errorMessage });
      return;
    } catch (err) {
      // An auth failure would doom the retry too — rethrow so the
      // caller stashes the finish for the next token. Any other
      // rejection (e.g. the diagnostics write itself) must NOT cost
      // the failure state: fall through to the status-only write.
      if (err instanceof SbAuthError) throw err;
      console.warn("[AutoLaunch] error_message write rejected; failing the row without diagnostics.");
    }
  }
  await sbPatch(`auto_posting_queue?id=eq.${queueId}`, { status: "failed" });
}

async function flushPendingFinish() {
  const { autolaunch_pending_finish: pending } =
    await chrome.storage.local.get(["autolaunch_pending_finish"]);
  if (!pending) return;
  try {
    if (pending.outcome === "posted") {
      await applyPosted(pending.queueId, pending.vin, pending.userId, pending.postedPrice, pending.reel);
      // v2.1.86: file the attach diagnostics the original
      // finish captured, if any.
      if (pending.reelDiag) await writeReelAttachDiag(pending.queueId, pending.reelDiag);
      // v2.1.85: consume the reel the original job attached
      // (v2.1.86: only on its verified attach — the stashed
      // reel record carries the verdict).
      await consumeJobReel(pending.userId, pending.vin, pending.reel);
      await consumeJobUserVideo(pending.userId, pending.vin, pending.userVideo);
      // v2.1.88: the replayed finish queues the edit-flow
      // attach backstop exactly like the direct one.
      await maybeQueueAttachVideo(pending.userId, pending.vin, pending.shareCar, pending.postedPrice, pending.reel, pending.gateChainParent || null, pending.listingUrl || null, pending.listingId || null);
      // The share the post earned rides the stash (v2.1.55):
      // queued on replay, still fail-open.
      await maybeQueueFeedShare({ userId: pending.userId, shareToFeed: pending.shareToFeed, car: pending.shareCar, includeStock: pending.includeStock === true, richDesc: pending.richDesc === true, dealershipName: pending.dealershipName || "", dealershipAddress: pending.dealershipAddress || "", repName: pending.repName || "", repPhone: pending.repPhone || "" });
    } else if (pending.outcome === "shared") {
      await applyShared(pending.queueId);
    } else if (pending.outcome === "price_updated") {
      await applyPriceUpdated(pending.queueId, pending.vin, pending.userId, pending.price);
    } else if (pending.outcome === "video_attached") {
      await applyVideoAttached(pending.queueId, pending.vin, pending.userId);
      // v2.1.88: consume the reel on the verified post-save
      // read that settled this finish, exactly like the
      // direct path.
      await consumeJobReel(pending.userId, pending.vin,
        { id: pending.reelId || null, source: "poster", attached: true, attachVerified: true });
      // v2.1.121 (header note 72): a replayed attach
      // finish closes its gate chain like the direct one.
      if (pending.gateChainClear) await clearGateChain(pending.vin);
    } else if (pending.outcome === "deleted") {
      await applyDeleted(pending.queueId, pending.vin, pending.userId);
      // v2.1.121 (header note 72): a replayed delete
      // finish settles its gate chain's parent exactly
      // like the direct one (the stamp is already clear).
      if (pending.gateChain && pending.gateChain.parentQueueId) {
        await settleReelGateAbort(
          { queueId: pending.gateChain.parentQueueId, tabId: null },
          pending.gateChain.reason || "reel_gate_abort:editor_attach_failed",
          gateChainSettleDiag(pending.gateChain, "listing deleted (replayed finish); posted stamp cleared", pending.queueId));
        await clearGateChain(pending.vin);
      }
      // [PRICE-RECOVERY-338-REPLAY-BEGIN] — a replayed
      // escalation delete queues its repost exactly like
      // the direct finish (v2.1.138, header note 88).
      if (pending.priceEscalation) {
        await settlePriceEscalationDeleted338({
          queueId: pending.queueId, userId: pending.userId,
          car: { vin: pending.vin },
          priceEscalation: pending.priceEscalation
        });
      }
      // [PRICE-RECOVERY-338-REPLAY-END]
    } else {
      await applyFailed(pending.queueId, pending.errorMessage || null);
    }
    await chrome.storage.local.remove(["autolaunch_pending_finish"]);
    console.log("[AutoLaunch] Replayed a job finish that was waiting on a fresh session token.");
  } catch (e) {
    // Still can't write — sbFetch already marked the session expired if
    // that's the cause. Leave the record; the next new token retries it.
  }
}


// Tab auto-close (v2.1.7, header note 14): ~4s after a finish —
// long enough for a success banner to be read — close the tab
// this worker opened for the job. Called from every finish,
// success or failure. Before 2.92, finishJobFailed never called
// it (a failed job's tab stayed open as evidence); Matthew
// retired that policy on 2026-11-09 — the diagnostics ride the
// job's DB record, and one leftover tab per failed job littered
// the user's browser across a batch. A tab the user already
// closed is a silent no-op.
function scheduleJobTabClose(job) {
  if (!chrome.tabs || typeof chrome.tabs.remove !== "function") return;
  // The job's own tab, plus the orphan-recovery tab when this
  // finish came from a recovery scan (v2.52, header note 26).
  const ids = [];
  if (job && job.tabId != null) ids.push(job.tabId);
  if (job && job.orphanRecovery && job.orphanRecovery.tabId != null &&
      !ids.includes(job.orphanRecovery.tabId)) {
    ids.push(job.orphanRecovery.tabId);
  }
  if (!ids.length) return;
  setTimeout(() => {
    for (const tabId of ids) {
      try {
        const p = chrome.tabs.remove(tabId);
        if (p && typeof p.catch === "function") p.catch(() => {});
      } catch (e) { /* the tab is already gone — nothing to do */ }
    }
  }, 4000);
}

// The ONLY two ways a job ends. Called by the content script via message.
async function finishJobPosted(queueId, listingUrl, reelAttach, listingId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  // VIN reel attach verdict (v2.1.86, header note 41): the
  // content side's read-back rides the posted message; fold
  // it into the reel record the finish acts on. No verdict
  // on record (a recovery scan settled this job) leaves
  // attachVerified unset — consumption reads that as
  // unverified and keeps the reel. (v2.1.87, header note
  // 42: the verdict riding the message is now the BINDING
  // pre-Publish one, and the diag's note/detail are built
  // by reelAttachDiagFields — per-attempt verdicts, the
  // budget, the compact counter trace.)
  const reel = job.reel
    ? { ...job.reel, attachVerified: !!(reelAttach && reelAttach.verified === true) }
    : null;
  // User vehicle video (v2.1.166, header note 98): the same
  // verdict fold for the user's own video — its consumption
  // reads it exactly like the reel's.
  const userVideo = job.userVideo
    ? { ...job.userVideo, attachVerified: !!(reelAttach && reelAttach.verified === true) }
    : null;
  const reelDiag = (reel && reel.attachVerified !== true && reelAttach)
    ? compactDiagError([{
        field: "reel_attach",
        rungsAttempted: [],
        readBack: reelAttach.readBack != null ? String(reelAttach.readBack) : null,
        ...reelAttachDiagFields(reelAttach)
      }])
    : null;
  try {
    await applyPosted(queueId, job.car.vin, job.userId,
      job.queuePrice != null ? job.queuePrice : job.car.price, reel);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The listing really is live; only the bookkeeping failed. Stash
      // the finish and replay it on the next token rather than losing
      // the confirmation (or wedging every future check behind a job
      // whose browser-side work is already done).
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "posted", queueId,
          vin: job.car.vin, userId: job.userId,
          // v2.1.62: the posted price rides the stash so a
          // replayed finish stamps marketplace_posted_price
          // exactly like the direct one.
          postedPrice: job.queuePrice != null ? job.queuePrice
            : (job.car.price != null ? Number(job.car.price) : null),
          listingUrl: listingUrl || null,
          // v2.1.125 (header note 76): the confirmation
          // harvest rides the stash, so a replayed finish
          // seeds the chain exactly like the direct one.
          listingId: listingId || null,
          // v2.1.85: the reel the job attached rides the stash,
          // so a replayed finish consumes it exactly like the
          // direct one.
          reel,
          userVideo,
          // v2.1.86: the attach diagnostics ride the stash, so
          // a replayed finish files them exactly like the
          // direct one.
          reelDiag,
          // v2.1.121 (header note 72): the gated chain's
          // parent rides the stash, so a replayed finish
          // starts the chain exactly like the direct one.
          gateChainParent: job.reelGate === true ? queueId : null,
          shareToFeed: job.shareToFeed === true,
          // v2.1.56: the settings the share text is built from
          // ride the stash too, so a replayed share row is
          // identical to the direct one.
          includeStock: job.includeStock === true,
          // Rich descriptions (v2.1.98, header note 51):
          // the switch rides the stash beside include_stock.
          richDesc: job.richDesc === true,
          dealershipName: job.dealershipName || "",
          dealershipAddress: job.dealershipAddress || "",
          // v2.1.90: the contact pair rides the stash too, so
          // a replayed finish builds the identical share text.
          repName: job.repName || "",
          repPhone: job.repPhone || "",
          shareCar: {
            vin: job.car.vin,
            year: job.car.year != null ? job.car.year : null,
            make: job.car.make || null,
            model: job.car.model || null,
            stock_num: job.car.stock_num || job.car.stock_number || null,
            price: job.car.price != null ? Number(job.car.price) : null,
            // v2.1.56: the remaining buildShareTextForCar
            // inputs, so the replay builds the same text.
            trim: job.car.trim || null,
            mileage: job.car.mileage != null ? job.car.mileage : null,
            color: job.car.color || null,
            transmission: job.car.transmission || null,
            condition: job.car.condition || null,
            // Rich descriptions (v2.1.98, header note 51):
            // the rich renderer's remaining inputs, so the
            // replayed share is identical to the direct one.
            vdp_features: job.car.vdp_features || null,
            interior_color: job.car.interior_color || null,
            body_type: job.car.body_type || null,
            price_status: job.car.price_status || null
          }
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Posted confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  if (reelDiag) await writeReelAttachDiag(queueId, reelDiag);
  // VIN reel consumption (v2.1.85; verified gate v2.1.86):
  // the post is confirmed — consume the poster reel it
  // carried, but only on a form-verified attach. Fail-open.
  await consumeJobReel(job.userId, job.car.vin, reel);
  // User vehicle video consumption (v2.1.166, header note
  // 98): a verified post with the user's video deletes its
  // server copies. Fail-open, like the reel's.
  await consumeJobUserVideo(job.userId, job.car.vin, userVideo);
  // Edit-flow attach backstop (v2.1.88, header note 43):
  // an unverified poster attach queues its second chance
  // through the listing's Edit form. Fail-open.
  await maybeQueueAttachVideo(job.userId, job.car.vin, job.car,
    job.queuePrice != null ? job.queuePrice : job.car.price, reel,
    job.reelGate === true ? queueId : null, listingUrl || null,
    listingId || null);
  // [PWV348-CLEANUP-POSTED] (v2.1.148, note 95): the
  // post is proven live — the staged copies have done
  // their job and are deleted under the pure gate.
  await cleanupPwvStage348(job, "proven");
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Posted confirmed for queue item", queueId, listingUrl || "");
  scheduleJobTabClose(job);
  // Feed share (v2.1.55, header note 29): the post is final —
  // queue the share its toggle earned. Never throws.
  await maybeQueueFeedShare(job);
}

// The delete counterpart of finishJobPosted (v2.1.4). Called by the
// content script ONLY after it verified the listing card is gone
// from the selling page — never on a click alone.
async function finishJobDeleted(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  // Gate chain (v2.1.121, header note 72): this delete
  // may be the chain's removal hop — its confirmed
  // completion (the stamp clear inside applyDeleted) is
  // what releases the parent post row's gate-abort
  // settle. Read the record before the writes; a delete
  // with no chain behind it is untouched.
  const chain321 = await getGateChain(job.car.vin);
  const chainForJob321 = (chain321 && chain321.stage === "delete" &&
    chain321.parentQueueId) ? chain321 : null;
  try {
    await applyDeleted(queueId, job.car.vin, job.userId);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The listing really is deleted; only the bookkeeping failed.
      // Stash + replay on the next fresh token, like the posted path.
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "deleted", queueId,
          vin: job.car.vin, userId: job.userId,
          // [PRICE-RECOVERY-338-STASH-BEGIN]
          priceEscalation: job.priceEscalation || null,
          // [PRICE-RECOVERY-338-STASH-END]
          gateChain: chainForJob321 ? {
            parentQueueId: chainForJob321.parentQueueId,
            reason: chainForJob321.reason || null,
            attachQueueId: chainForJob321.attachQueueId || null
          } : null
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Delete confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  // Gate chain (v2.1.121, header note 72): the delete is
  // proven and the stamp is clear — NOW the parent post
  // row settles as a gate abort (budget++, re-held while
  // budget remains), with the chain's diag on its record.
  // The settle is best-effort bookkeeping on top of a
  // proven deletion; its own failure never un-deletes.
  if (chainForJob321) {
    try {
      await settleReelGateAbort(
        { queueId: chainForJob321.parentQueueId, tabId: job.tabId != null ? job.tabId : null },
        chainForJob321.reason || "reel_gate_abort:editor_attach_failed",
        gateChainSettleDiag(chainForJob321, "listing deleted + fresh-load confirmed; posted stamp cleared", queueId));
    } catch (e) {
      console.warn("[AutoLaunch] Reel chain: settling the parent post failed (the listing IS deleted and the stamp IS clear):", e && e.message || e);
    }
    await clearGateChain(job.car.vin);
  }
  // [PRICE-RECOVERY-338-DELETED-BEGIN] — escalation settle
  // (v2.1.138, header note 88): this delete was a price
  // escalation's removal hop — the removal is proven and
  // the stamp is clear, so queue the fresh post row and
  // record the escalation on the settled price row. The
  // settle is fail-open; the delete stands either way.
  if (job.priceEscalation) {
    await settlePriceEscalationDeleted338(job);
  }
  // [PRICE-RECOVERY-338-DELETED-END]
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Delete confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// The share counterpart of finishJobDeleted (v2.1.55, header
// note 29). Called by the content script ONLY after the share
// dialog completed — never on a click alone. Settles the row
// "completed"; the car's posted stamp is untouched.
async function finishJobShared(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  try {
    await applyShared(queueId);
  } catch (err) {
    if (err instanceof SbAuthError) {
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "shared", queueId,
          vin: job.car.vin, userId: job.userId
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Share confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Share confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// The price-update counterpart of finishJobDeleted (v2.1.62,
// header note 34). Called by the content script ONLY after its
// fresh Selling-page scan proved the listing now shows the new
// price — never on the editor's Save click alone. Settles the
// row "completed" and advances the car's posted price; the
// posted-at stamp is never touched.
async function finishJobPriceUpdated(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  try {
    await applyPriceUpdated(queueId, job.car.vin, job.userId, job.updateToPrice);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The listing really does show the new price; only the
      // bookkeeping failed. Stash + replay on the next fresh
      // token, like the other finishes.
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "price_updated", queueId,
          vin: job.car.vin, userId: job.userId,
          price: job.updateToPrice != null ? job.updateToPrice : null
        }
      });
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Price update confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Price update confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// The edit-flow attach counterpart of finishJobPriceUpdated
// (v2.1.88, header note 43). Called by the content script
// ONLY after its reopened editor read the Videos counter
// back at >= 1 post-save — never on the Save click alone.
// Settles the row "completed", consumes the poster reel on
// that verified read, and clears the parent post row's
// reel_failed flag (inside applyVideoAttached).
async function finishJobVideoAttached(queueId) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  const reelId = job.attachReel && job.attachReel.reelId ? job.attachReel.reelId : null;
  try {
    await applyVideoAttached(queueId, job.car.vin, job.userId);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // The video really is on the listing; only the
      // bookkeeping failed. Stash + replay on the next
      // fresh token, like the other finishes.
      await chrome.storage.local.set({
        autolaunch_pending_finish: {
          outcome: "video_attached", queueId,
          vin: job.car.vin, userId: job.userId, reelId,
          gateChainClear: job.gateChain === true
        }
      });
      await cleanupCdpReelFile(job);
      await chrome.storage.local.remove(["current_posting_job"]);
      console.warn("[AutoLaunch] Video attach confirmed on Facebook; the queue update is waiting on a fresh session token.");
      scheduleJobTabClose(job);
      return;
    }
    throw err;
  }
  // The reel's job is done — consume it on the verified
  // post-save read (the note-41 rule, fed a verified
  // record). Fail-open, exactly like the post path's.
  await consumeJobReel(job.userId, job.car.vin,
    { id: reelId, source: "poster", attached: true, attachVerified: true });
  // Gate chain (v2.1.121, header note 72): a chained
  // attach that reached its live-listing verdict closes
  // the chain — the parent post's success bookkeeping is
  // this finish's own (the reel is consumed above; the
  // reel_failed flag was cleared inside
  // applyVideoAttached).
  if (job.gateChain === true) await clearGateChain(job.car.vin);
  // v2.1.89: the attach job is settled — the CDP temp
  // file goes away with it (fail-open).
  await cleanupCdpReelFile(job);
  await chrome.storage.local.remove(["current_posting_job"]);
  console.log("[AutoLaunch] Video attach confirmed for queue item", queueId);
  scheduleJobTabClose(job);
}

// [PWV350-DIAG-HELPER-BEGIN] — terminal pwv failures must
// persist their failure code + field_diag on the queue row
// (v2.1.150). The .149 Tacoma and RAV4 photo failures
// settled status='failed' with error_message NULL: the
// worker's terminal-write allowlist in finishJobFailed
// had no branch for a post's own failure reason, so
// errorMessage came out null, applyFailed wrote status
// only, and the only copy of the reason was the banner.
// For pwv posts the stored text is reason + compacted
// diag (the gate-abort path's own shape); every other
// job keeps the legacy allowlist untouched.
function pwv350TerminalErrorMessage(job, reason, diagText, legacy) {
  const isPwv = !!job && job.action === "post" &&
    (job.pwvGate348 === true ||
     (job.postWithVideo && job.postWithVideo.staged === true));
  if (!isPwv || typeof reason !== "string" || !reason) return legacy;
  return diagText ? (reason + "\n" + diagText) : reason;
}
// [PWV350-DIAG-HELPER-END]

async function finishJobFailed(queueId, reason, diags) {
  const { current_posting_job: job } = await chrome.storage.local.get(["current_posting_job"]);
  if (!job || job.queueId !== queueId) return;
  // Ready-only gate (v2.1.118, header note 69): a
  // reel_gate_abort on a gated post is NOT a terminal
  // failure — the row returns to held (bounded), or
  // settles needs-attention at the cap. A settle that
  // cannot write falls through to the ordinary terminal
  // path below; the row is never lost.
  if (job.action === "post" && job.reelGate === true &&
      typeof reason === "string" && reason.startsWith("reel_gate_abort")) {
    const settled = await settleReelGateAbort(job, reason, diags).catch(() => false);
    if (settled) return;
    console.warn("[AutoLaunch] Reel-gate abort settle failed to write; failing the row terminally instead.");
  }
  // [PWV348-FAILROUTE-BEGIN] — post-with-video gate
  // aborts (v2.1.148, header note 95): a pwv-gated post
  // whose staged video never landed settles exactly
  // like a gated one — re-held (bounded), then
  // needs-attention — through the same settle.
  if (job.action === "post" && job.pwvGate348 === true &&
      typeof reason === "string" && reason.startsWith("reel_gate_abort")) {
    const settledPwv348 = await settleReelGateAbort(job, reason, diags).catch(() => false);
    if (settledPwv348) return;
    console.warn("[AutoLaunch] Post-with-video abort settle failed to write; failing the row terminally instead.");
  }
  // [PWV348-FAILROUTE-END]
  // [ENV-DEFER-339-FAIL-BEGIN] — environment starvation
  // (v2.1.139, header note 89): a failure the content
  // side's evidence proves environmental settles as a
  // DEFER — the row returns to pending under the
  // env_deferred: marker and NO budget moves. The
  // interception sits ahead of every other settle on
  // purpose: ahead of the list_never_grew retry (whose
  // one-shot budget a starved scan must not consume),
  // ahead of the price ladder (whose recovery_attempts
  // a starved attempt must not increment), and ahead
  // of the gate-chain propagation at the bottom of
  // this function (a starved chained attach must not
  // escalate to a delete that would starve the same
  // way — the chain record stays at stage "attach" and
  // the deferred row is claimed again through it when
  // the environment heals).
  if (job && (job.action === "attach_video" || job.action === "delete" ||
              job.action === "update_price")) {
    const settledEnv339 = await settleEnvDefer339(job, reason, diags)
      .catch(() => false);
    if (settledEnv339) return;
  }
  // [ENV-DEFER-339-FAIL-END]
  // ONE automatic retry for list_never_grew (v2.1.104,
  // note 57): a scan whose list never grew proved nothing
  // about the listing — the tab may simply have been
  // starved of rendering. The job returns to pending ONCE,
  // its row carrying the retry marker in error_message
  // (and this install remembering the id as a backstop);
  // a second list_never_grew falls through to the ordinary
  // terminal failure below. The retry settles the stored
  // job exactly like the finally block below (failure log
  // + tab close + slot clear) — except the CDP reel-file
  // cleanup, which must NOT run: a retried job may still
  // need its file. A failed requeue write also falls
  // through to the terminal path — never a lost row.
  if (reason === "list_never_grew") {
    let rowError = null;
    try {
      const rows = await sbGet(`auto_posting_queue?id=eq.${queueId}&select=error_message`);
      rowError = rows && rows[0] ? rows[0].error_message : null;
    } catch (e) { /* the install-memory check still applies */ }
    let storageRetried = false;
    try {
      const got = await chrome.storage.local.get(["al_never_grew_retried"]);
      storageRetried = Array.isArray(got.al_never_grew_retried) &&
        got.al_never_grew_retried.includes(queueId);
    } catch (e) { /* memory is a backstop, not a gate */ }
    if (alNeverGrewRetryEligible(reason, rowError, storageRetried)) {
      let requeued = false;
      try {
        await sbPatch(`auto_posting_queue?id=eq.${queueId}`, {
          status: "pending",
          error_message: "list_never_grew_retry: the scan list never grew; auto-requeued once (note 57)"
        });
        requeued = true;
      } catch (e) {
        console.warn("[AutoLaunch] list_never_grew auto-retry write failed; failing terminally.", e);
      }
      if (requeued) {
        try {
          const got = await chrome.storage.local.get(["al_never_grew_retried"]);
          const list = Array.isArray(got.al_never_grew_retried)
            ? got.al_never_grew_retried.slice(-49) : [];
          list.push(queueId);
          await chrome.storage.local.set({ al_never_grew_retried: list });
        } catch (e) { /* the row marker is the primary record */ }
        await logFailure(queueId, "list_never_grew (auto-retry 1/1)");
        scheduleJobTabClose(job);
        await chrome.storage.local.remove(["current_posting_job"]);
        console.log(`[AutoLaunch] Job ${queueId} failed list_never_grew — auto-requeued once (note 57).`);
        return;
      }
    }
  }
  // [PRICE-RECOVERY-338-FAIL-BEGIN] — price recovery
  // settles (v2.1.138, header note 88): a job carrying an
  // armed escalation settles through the escalation stop
  // (terminal needs-you, never a repost); an ordinary
  // update_price failure carrying recovery state settles
  // through the ladder (bounded requeue with markers, or
  // terminal at budget). A settle that cannot write falls
  // through to the ordinary terminal path below — the row
  // is never lost.
  if (job && job.priceEscalation) {
    const settledEsc338 = await settlePriceEscalationFailure338(job, reason, diags).catch(() => false);
    if (settledEsc338) return;
    console.warn("[AutoLaunch] Price escalation settle failed to write; failing the row terminally instead.");
  }
  if (job && job.action === "update_price" && job.priceRecovery) {
    const settledPrice338 = await settlePriceFailure338(job, reason, diags).catch(() => false);
    if (settledPrice338) return;
    console.warn("[AutoLaunch] Price recovery settle failed to write; failing the row terminally instead.");
  }
  // [PRICE-RECOVERY-338-FAIL-END]
  // No silent chain fails (v2.1.127, header note 78):
  // a chained attach that fails with NO diagnostics
  // of its own — the background's sender-discipline
  // refusals pass an empty array; a lost incarnation
  // may pass none — still leaves its trace: the
  // stored job the background already holds carries
  // the arm state and the patient verify's read
  // records, and gateChainFailDiag327 compacts them
  // into the one record that rides the compaction
  // below. A chained attach failing with a NULL
  // error_message is impossible from here on.
  if (job && job.action === "attach_video" &&
      job.gateChain === true &&
      (!Array.isArray(diags) || !diags.length)) {
    diags = [gateChainFailDiag327(job, reason)];
  }
  // Diag-to-DB (v3.1): the content script's forensic records arrive in
  // this message; for a fields_unfilled failure they are compacted
  // into the row's error_message in the same write that fails it.
  // Delete jobs (v2.1.4) compact too — there the records are the
  // delete step notes (match scan, outcome), the evidence that says
  // WHY nothing was deleted. A publish_unverified failure (v2.1.7)
  // compacts as well: its records are the Selling-page verify scans,
  // the evidence that the listing truly was not there. v2.52:
  // duplicate_rejected and job_orphaned (the orphan-recovery
  // verdicts) compact too — the same scan records are the evidence
  // for those honest failures.
  let errorMessage =
    ((typeof reason === "string" && reason.startsWith("fields_unfilled")) ||
     reason === "publish_unverified" ||
     reason === "publish_button_not_found" ||
     reason === "duplicate_rejected" ||
     reason === "job_orphaned" ||
     (job && (job.action === "delete" || job.action === "share" ||
              job.action === "update_price" || job.action === "attach_video")))
      ? compactDiagError(diags)
      : null;
  // [PWV350-DIAGPERSIST-BEGIN] — see
  // pwv350TerminalErrorMessage: a pwv post's terminal
  // failure never again lands as failed-with-NULL.
  errorMessage = pwv350TerminalErrorMessage(job, reason,
    compactDiagError(diags), errorMessage);
  // [PWV350-DIAGPERSIST-END]
  try {
    await applyFailed(queueId, errorMessage);
  } catch (err) {
    if (err instanceof SbAuthError) {
      // Same stash-and-replay as the posted path, so the row doesn't
      // sit in "processing" forever behind a dead token. The compacted
      // diagnostics ride the stash so the replay keeps them.
      await chrome.storage.local.set({
        autolaunch_pending_finish: { outcome: "failed", queueId, errorMessage }
      });
    } else {
      throw err; // the finally below still logs + clears, as before
    }
  } finally {
    await logFailure(queueId, reason || "unknown");
    // v2.1.89: a failed attach job settles too — clean up
    // its CDP temp file (the pure gate no-ops for any
    // other action and for a missing record).
    await cleanupCdpReelFile(job);
    // [PWV348-CLEANUP-FAILED] (v2.1.148, note 95): a
    // failed post's staged copies are deleted at
    // settle — everything re-stages next attempt.
    await cleanupPwvStage348(job, "failed");
    // 2.92 (Matthew, 2026-11-09): close the failed job's tab too.
    // The compacted diagnostics were written to the job's DB
    // record by applyFailed above, so the tab is no longer the
    // evidence — leaving it open just littered the browser.
    scheduleJobTabClose(job);
    await chrome.storage.local.remove(["current_posting_job"]);
    console.warn("[AutoLaunch] Job failed:", queueId, reason);
  }
  // Gate-chain failure propagation (v2.1.121, header
  // note 72): a TERMINAL failure of a chained attach
  // (the never-grew retry above returns earlier; a
  // requeued failure has not failed yet) starts the
  // delete hop; a terminal failure of the chain's
  // delete settles the parent needs-attention at once.
  // No chain record — or a job that is not one of the
  // chain's hops — and this block is inert.
  try {
    if (job && job.car && job.car.vin &&
        (job.action === "attach_video" || job.action === "delete")) {
      const chain321 = await getGateChain(job.car.vin);
      if (chain321 && chain321.parentQueueId) {
        if (job.action === "attach_video" && chain321.stage === "attach") {
          // Gate chain (v2.1.124, header note 75): an
          // aim contradiction is not a delete verdict —
          // the chain's identity premise broke, so the
          // parent settles needs-attention at once and
          // the listing is left standing for a human.
          if (reason === "attach_aim_contradicted") {
            await settleGateChainAimContradicted324(job, chain321);
          } else {
          const mapped321 = gateChainAbortReason(reason);
          // Delete gate (v2.1.127, header note 78):
          // the delete hop is earned only by proof
          // the listing is bare — a patient verify
          // that ran to completion with both reads
          // genuinely empty, or a failure before any
          // save landed (decideGateChainDelete327
          // reads the proof off the stored job).
          // Every other failure shape settles the
          // parent needs-attention with the stamp
          // standing: a failure that proves nothing
          // about the listing never deletes it.
          const deleteGate327 = decideGateChainDelete327({
            reason,
            attachVideo: job.attachVideo
          });
          if (!deleteGate327.queueDelete) {
            await settleGateChainVerifyAttention327(
              job, chain321, mapped321, deleteGate327.why);
          } else {
          let deleteQueued321 = false;
          try {
            await queueGateChainDelete(job, chain321, mapped321);
            deleteQueued321 = true;
          } catch (e321) {
            console.warn("[AutoLaunch] Reel chain: queueing the delete failed:", e321 && e321.message || e321);
          }
          if (!deleteQueued321) {
            await settleGateChainDeleteFailed(job, chain321);
          }
          }
          }
        } else if (job.action === "delete" && chain321.stage === "delete") {
          await settleGateChainDeleteFailed(job, chain321);
        }
      }
    }
  } catch (e) {
    console.warn("[AutoLaunch] Reel chain: failure propagation failed (the row settles above stand):", e && e.message || e);
  }
}

// --- DealerCenter DWS helper-side sync (v2.1.80; fetch shape 2.81; postpass wiring 2.82) ----
// dws_sync.js (importScripts at the top of this file) crawls
// Cloudflare-blocked DealerCenter sites from THIS browser over
// plain fetch and lands the cars itself. Background fetch only:
// no tab is created, navigated, or focused for a sync — the user
// keeps working wherever they are. The deps below hand the sync
// this worker's own Supabase plumbing and lease machinery; the
// sync path honors the lease exactly like the posting claims do.
async function dwsFetchText(url, opts) {
  const init = {};
  if (opts && opts.method) init.method = opts.method;
  // 2.81: ride the browser's own cookies for the dealer site
  // (including any Cloudflare clearance it earned by browsing), so
  // a sync request is server-visibly the dealer's own browser —
  // the premise of the whole feature. The 2.80 wrapper sent no
  // cookies, the one remaining difference from the site's own
  // same-origin requests; its page 2-4 fragment POSTs came back
  // as HTTP-200 bodies with no cards in them on the live run.
  init.credentials = (opts && opts.credentials) || "include";
  if (opts && opts.form) {
    init.headers = { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" };
    init.body = new URLSearchParams(opts.form).toString();
  }
  if (opts && opts.headers) {
    init.headers = { ...(init.headers || {}), ...opts.headers };
  }
  const res = await fetch(url, init);
  return { status: res.status, text: await res.text() };
}

function checkDwsSyncSafe() {
  if (typeof AutoLaunchDwsSync === "undefined" ||
      !AutoLaunchDwsSync || !AutoLaunchDwsSync.checkDwsSync) return;
  AutoLaunchDwsSync.checkDwsSync({
    storageGet: (keys) => chrome.storage.local.get(keys),
    storageSet: (obj) => chrome.storage.local.set(obj),
    sbGet: sbGet,
    sbPatch: sbPatch,
    sbPost: sbPost,
    sbUpsert: sbUpsert,
    getInstanceId: getOrCreateInstanceId,
    leaseDecision: helperLeaseDecision,
    leaseTtlMs: HELPER_LEASE_TTL_MS,
    fetchText: dwsFetchText,
    now: () => Date.now(),
    log: (...args) => console.log(...args)
  }).catch(err => console.warn("[AutoLaunch] DWS sync cycle failed:", err));
}

// --- Wiring ---------------------------------------------------------------

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(POLL_ALARM, { periodInMinutes: POLL_MINUTES });
  alHubSelfRefreshOnVersionChange();
  checkQueue();
  checkDwsSyncSafe();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(POLL_ALARM, { periodInMinutes: POLL_MINUTES });
  alHubSelfRefreshOnVersionChange();
  checkQueue();
  checkDwsSyncSafe();
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === POLL_ALARM) { checkQueue(); checkOutboundReplies(); checkDwsSyncSafe(); lucaAutoReplyProcessPending(); lucaAutoReplyProcessCandidates(); lucaAutoReply2ProcessPending(); /*LUCA2*/ }
});

// The app is served from two first-party origins: the custom domain
// and the GitHub Pages mirror (the rebuild preview rides the mirror).
// The bridge handshake is accepted from either, and from nowhere else.
// v2.1.49: autolaunch.org added — before this the worker trusted only
// the mirror, so on the custom domain the app could never hand over
// the session token and the queue poller stayed parked.
function isAppUrl(url) {
  const u = url || "";
  return u.startsWith("https://autolaunch.org/") ||
         u.startsWith("https://mdemoss-bdc.github.io/");
}

// ---- listing-ID memory (2.91 build) --------------------------------
// VIN -> { listingId, editorUrlPattern }: the Facebook listing
// ID for a car this helper has provably stood in front of —
// harvested by the content script at the post flow's Selling-
// page verify (the strictly matched card's own link) and at
// the top of the update_price / attach_video editor phases
// (the editor URL the tab actually landed on, its ID replaced
// by "{id}" so the pattern can be re-aimed). The worker owns
// the map (chrome.storage.local) and rides the entry on
// update_price / attach_video job payloads at claim time, so
// those listing phases can navigate straight to the editor
// instead of coaxing the virtualized Selling list into
// rendering the card from a background tab. The editor
// phases' identity gates remain the only authority on
// whether the landed editor is really this car's listing; a
// failed memory-nav attempt clears the entry (the content
// side asks via AUTOLAUNCH_LISTING_ID_CLEAR) and falls back
// to the ordinary search-assist scan, once.
const LISTING_ID_MAP_KEY = "listing_id_by_vin";
async function listingIdMemoryFor(vin) {
  if (!vin) return null;
  try {
    const got = await chrome.storage.local.get([LISTING_ID_MAP_KEY]);
    const map = got && got[LISTING_ID_MAP_KEY];
    const entry = map && typeof map === "object" ? map[vin] : null;
    if (entry && typeof entry.listingId === "string" && entry.listingId) {
      return {
        listingId: entry.listingId,
        editorUrlPattern: typeof entry.editorUrlPattern === "string" && entry.editorUrlPattern
          ? entry.editorUrlPattern : null
      };
    }
  } catch (e) { /* memory is an optimization, never a gate */ }
  return null;
}
async function recordListingIdMemory(vin, listingId, editorUrlPattern) {
  if (!vin || !listingId) return;
  try {
    const got = await chrome.storage.local.get([LISTING_ID_MAP_KEY]);
    const map = (got && got[LISTING_ID_MAP_KEY] && typeof got[LISTING_ID_MAP_KEY] === "object")
      ? got[LISTING_ID_MAP_KEY] : {};
    const prev = map[vin] && typeof map[vin] === "object" ? map[vin] : {};
    map[vin] = {
      listingId: String(listingId),
      // A harvest that saw no editor URL (the post-verify
      // card link) must not erase a pattern an editor
      // landing already taught us.
      editorUrlPattern: editorUrlPattern || prev.editorUrlPattern || null,
      updatedAt: new Date().toISOString()
    };
    await chrome.storage.local.set({ [LISTING_ID_MAP_KEY]: map });
  } catch (e) { /* fail-open: the scan path still stands */ }
}
async function clearListingIdMemory(vin) {
  if (!vin) return;
  try {
    const got = await chrome.storage.local.get([LISTING_ID_MAP_KEY]);
    const map = got && got[LISTING_ID_MAP_KEY];
    if (map && typeof map === "object" && vin in map) {
      delete map[vin];
      await chrome.storage.local.set({ [LISTING_ID_MAP_KEY]: map });
    }
  } catch (e) { /* fail-open */ }
}

// Handshake path 1 (the real one): bridge.js on the AutoLaunch origin.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  if (message.type === "AUTOLAUNCH_PING") {
    // Setup-page liveness/readiness ping (header note 17). Only the
    // bridge on the AutoLaunch origin may ask — same sender discipline
    // as the login handoff below — and the answer is a boolean about
    // the stored session token, never the token itself.
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const token = await storedAccessToken();
      // v2.1.24: report our own version so the setup page can say
      // "out of date" instead of a bare "ready" for an old helper.
      let version = null;
      try { version = chrome.runtime.getManifest().version || null; } catch (e) { /* keep null */ }
      // v2.1.104 (note 57): health signals ride the reply —
      // permissions_ok from the permission self-check's last
      // recorded state (null = not checked yet / the API is
      // unavailable) and session_expired from the persistent
      // surfaced state, so the app can show WHY a helper is
      // quiet instead of guessing at a silent one.
      const health = await chrome.storage.local.get(
        ["al_permissions_state", "al_session_expired"]);
      sendResponse({
        hasToken: !!token,
        version,
        permissions_ok: health.al_permissions_state &&
          typeof health.al_permissions_state.ok === "boolean"
          ? health.al_permissions_state.ok : null,
        session_expired: health.al_session_expired === true
      });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_GET_INSTALL_ID") {
    // Trial-abuse install id (v2.1.45): only the bridge on the
    // AutoLaunch origin may ask — same sender discipline as the ping
    // above. The answer is the install UUID itself (never a user id,
    // never the session token).
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const installId = await getOrCreateInstallId();
      sendResponse({ installId });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_GET_INSTANCE_ID") {
    // One-active-helper instance id (v2.1.60, header note 32):
    // only the bridge on the AutoLaunch origin may ask — same
    // sender discipline as the install id above. The Extension
    // page's takeover button writes this id onto the user's own
    // settings row as the lease holder; the answer is the
    // instance UUID itself (never a user id, never the token).
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const instanceId = await getOrCreateInstanceId();
      sendResponse({ instanceId });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_CAPTURE_CHAT" && message.capture) {
    // Only the capture script on facebook.com may hand us a chat —
    // same sender discipline as the ping above.
    const fromFb = (sender.tab && sender.tab.url || "").startsWith("https://www.facebook.com/");
    if (!fromFb) return;
    (async () => {
      try {
        // Hub containment (v2.1.103, note 56): a capture that
        // arrives from the worker's OWN inbox hub tab is list
        // surface by definition — handleCaptureChat drops its
        // full captures (its stub captures still flow).
        let fromHubTab = false;
        try {
          const hubStore = await chrome.storage.local.get(["luca_auto_reply_hub"]);
          fromHubTab = !!(sender.tab && sender.tab.id != null && hubStore.luca_auto_reply_hub
            && hubStore.luca_auto_reply_hub.tabId === sender.tab.id);
        } catch (e) { /* containment is best-effort; the id guard still applies */ }
        const result = await handleCaptureChat(message.capture, { fromHubTab });
        sendResponse(Object.assign({ ok: true }, result));
      } catch (err) {
        console.warn("[AutoLaunch] chat capture failed:", err && err.message ? err.message : err);
        sendResponse({ ok: false, error: (err && err.code) || "save_failed" });
      }
    })();
    return true;
  }

  // [DLVTRACE315-ROUTE-BEGIN] delivery trace (v2.1.115, note 66)
  if (message.type === "AUTOLAUNCH_TRACE") {
    if (!(sender && sender.tab && /^https:\/\/www\.facebook\.com\//.test(sender.tab.url || ""))) return false;
    if (typeof alTraceIngest === "function") alTraceIngest(message);
    return false;
  }
  // [DLVTRACE315-ROUTE-END]
  if (message.type === "AUTOLAUNCH_CHAT_SNIPPETS" && Array.isArray(message.snippets)) {
    const fromFbSnip = (sender.tab && sender.tab.url || "").startsWith("https://www.facebook.com/");
    if (!fromFbSnip) return;
    (async () => {
      try { await handleChatSnippets(message.snippets); } catch (e) { /* next pass retries */ }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_REPLY_RESULT" && message.messageId) {
    // Only a Facebook tab may report a delivery (same discipline as
    // the job-finish messages). The result flips the queued reply's
    // status in the database — that status is the rep's receipt.
    const senderUrl = (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    (async () => {
      await finishOutboundReply(message.messageId, !!message.ok, message.error || null);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_SET_USER_ID" && message.userId) {
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      const updates = { autolaunch_user_id: message.userId };
      let freshToken = false;
      if (message.accessToken) {
        const { autolaunch_access_token: oldToken } =
          await chrome.storage.local.get(["autolaunch_access_token"]);
        if (message.accessToken !== oldToken) {
          // A NEW token revives an expired session: store it, clear the
          // expired stop, and (below) replay any stashed job finish
          // before resuming claims. The token value is never logged.
          updates.autolaunch_access_token = message.accessToken;
          updates.autolaunch_session_expired = false;
          updates.al_session_expired = false;
          alSessionExpiredKnown = false;
          freshToken = true;
        }
      }
      await chrome.storage.local.set(updates);
      sendResponse({ status: "connected" });
      alSessHeal356NoteAnswer();
      if (freshToken) await flushPendingFinish();
      checkQueue();
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_SYNC_REQUEST") {
    // App-driven inbound sync (v2.1.38): the Prospects screen asks for
    // a capture pass NOW because the Facebook tab's own timers are
    // throttled while it sits in the background. Only the bridge on
    // the AutoLaunch origin may ask. We drive the best Facebook tab's
    // capture script and answer only when it confirms the writes.
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    (async () => {
      let synced = false;
      try {
        const tabs = await chrome.tabs.query({ url: ["https://www.facebook.com/*"] });
        // Ask EVERY Facebook tab (v2.1.39): each one captures what
        // IT can see — a list tab contributes snippets, the thread's
        // own tab the full conversation. The first version stopped at
        // the first tab that answered, which starved the thread tab
        // whenever another tab replied first.
        const attempts = tabs.slice(0, 3).map(t => new Promise(resolve => {
          let done = false;
          const timer = setTimeout(() => { if (!done) { done = true; resolve(false); } }, 8000);
          try {
            chrome.tabs.sendMessage(t.id, { type: "AUTOLAUNCH_SYNC_NOW" }, resp => {
              if (done) return;
              done = true;
              clearTimeout(timer);
              resolve(!chrome.runtime.lastError && !!(resp && resp.ok));
            });
          } catch (e) {
            if (!done) { done = true; clearTimeout(timer); resolve(false); }
          }
        }));
        const results = await Promise.all(attempts);
        synced = results.some(Boolean);
      } catch (e) { /* answer what we have */ }
      sendResponse({ ok: synced });
    })();
    return true;
  }

  if (message.type === "AUTOLAUNCH_NUDGE_OUTBOUND") {
    // Only the bridge on the AutoLaunch origin may nudge (same sender
    // discipline as the login handoff). Runs the outbound claim
    // immediately — the 1-minute alarm stays as the safety net.
    const fromApp = isAppUrl(sender.tab && sender.tab.url);
    if (!fromApp) return;
    checkOutboundReplies();
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "AUTOLAUNCH_FETCH_PHOTO") {
    // Only the Facebook content script may use the relay (it is the one
    // CORS-blocked from dealer photo servers), and only real URLs — the
    // http(s) check lives in fetchPhotoForContent.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    fetchPhotoForContent(message.url)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ ok: false, error: "photo_relay_failed" }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_FETCH_VIDEO") {
    // Intro-video relay (v2.1.53, header note 27): same sender
    // discipline as the photo relay — only the Facebook content
    // script may use it, and only real URLs (the http(s) check
    // lives in fetchVideoForContent).
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    fetchVideoForContent(message.url)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ ok: false, error: "video_relay_failed" }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_LIVENESS") {
    // Job liveness (v2.54, header note 28): same sender
    // discipline as the relays above — only the Facebook
    // content script may ask. The verdict is definitive-only
    // (jobLivenessVerdict); even a handler-level failure
    // answers live, never an abort.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    jobLivenessVerdict(message.queueId)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ live: true }));
    return true;
  }


  if (message.type === "AUTOLAUNCH_CDP") {
    // Only the Facebook content script may drive trusted input, and only
    // on its own tab (sender.tab is authoritative — content scripts
    // cannot spoof another tab's id).
    const tabId = sender && sender.tab && sender.tab.id;
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (tabId == null || !senderUrl.startsWith("https://www.facebook.com/")) return;
    handleCdp(message, tabId)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: "cdp_error: " + (err && err.message || "unknown") }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_FIELD_DIAG") {
    // A required field defeated every fill rung. Record the forensics
    // (element identity, rungs attempted, value read back) in the same
    // failure log the job reasons land in, so the NEXT failure is never
    // a guessing game. Reason strings + element metadata only.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    const diag = message.diag || {};
    logFailure(message.queueId || null, "field_diag:" + (diag.field || "unknown"), {
      field: diag.field || null,
      element: diag.element || null,
      rungsAttempted: Array.isArray(diag.rungsAttempted) ? diag.rungsAttempted : [],
      readBack: diag.readBack != null ? String(diag.readBack) : null,
      expected: diag.expected != null ? String(diag.expected) : null,
      cdpError: diag.cdpError || null,
      note: diag.note || null,
      detail: diag.detail != null ? String(diag.detail) : null
    })
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_LISTING_ID" && message.vin && message.listingId) {
    // Listing-ID harvest (2.91 build): only the Facebook
    // content script may teach the memory — same sender
    // discipline as the job-finish messages below.
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    recordListingIdMemory(message.vin, message.listingId,
      typeof message.editorUrlPattern === "string" && message.editorUrlPattern
        ? message.editorUrlPattern : null)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_LISTING_ID_CLEAR" && message.vin) {
    // A memory-nav attempt failed (2.91 build): the stored
    // ID is suspect, so the entry dies and the next job for
    // this car scans the ordinary way (and re-harvests on
    // its next proven landing).
    const senderUrl = (sender && sender.url) ||
      (sender && sender.tab && sender.tab.url) || "";
    if (!senderUrl.startsWith("https://www.facebook.com/")) return;
    clearListingIdMemory(message.vin)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_POSTED") {
    finishJobPosted(message.queueId, message.listingUrl, message.reelAttach || null, message.listingId || null)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_DELETED") {
    // Only the Facebook content script reports deletes (same sender
    // discipline as the other job-finish messages' storage contract —
    // finishJobDeleted additionally requires the id to match the
    // currently claimed job).
    // v2.1.16 second witness: a delete may only be CLAIMED from the
    // Selling page. Facebook's SPA can drift the job tab elsewhere
    // (Friend Requests, 2026-10-23) without a reload, and a report
    // from any other page is a scan of the wrong room — refuse it
    // and fail the job honestly instead of clearing the stamp.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/you\/(selling|dashboard)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "delete_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobDeleted(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_SHARED") {
    // Same Selling-page sender discipline as AUTOLAUNCH_JOB_DELETED
    // (v2.1.55): a share may only be CLAIMED from the Selling page —
    // a report from anywhere else is a scan of the wrong room.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/you\/(selling|dashboard)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "share_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobShared(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_PRICE_UPDATED") {
    // Same Selling-page sender discipline as AUTOLAUNCH_JOB_DELETED
    // (v2.1.62): a price update may only be CLAIMED from the
    // Selling page, where the content script's verifying scan ran —
    // a report from anywhere else is a scan of the wrong room.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/you\/(selling|dashboard)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "price_update_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobPriceUpdated(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "AUTOLAUNCH_JOB_VIDEO_ATTACHED") {
    // Sender discipline (v2.1.88, header note 43): an attach
    // is claimed from the Selling page OR the listing's edit
    // surface — the verdict evidence is the editor's own
    // Videos counter, read in a reopened editor after Save,
    // and the flow reports from whichever of those rooms the
    // reopened editor lives in. A report from anywhere else
    // is a read of the wrong room — refuse and fail honestly.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (/^https:\/\/www\.facebook\.com\/marketplace\/item\//.test(senderUrl)) {
      // 3.21 (header note 72): a gate-chain attach reads
      // its verdict on the LIVE LISTING page — the one
      // other room this report may legitimately come
      // from, and only while the stored job is that
      // chain's attach, mid-listing-check. Anything else
      // from an item page is refused like any wrong room.
      (async () => {
        let ok321 = false;
        try {
          const stored321 = await chrome.storage.local.get(["current_posting_job"]);
          const j321 = stored321 && stored321.current_posting_job;
          ok321 = !!(j321 && j321.queueId === message.queueId &&
            j321.action === "attach_video" && j321.gateChain === true &&
            j321.attachVideo && (j321.attachVideo.listingCheck === "pending" ||
              j321.attachVideo.listingCheck === "passed"));
        } catch (e) { /* refused below */ }
        if (ok321) {
          finishJobVideoAttached(message.queueId)
            .then(() => sendResponse({ ok: true }))
            .catch(() => sendResponse({ ok: false }));
        } else {
          finishJobFailed(message.queueId,
            "attach_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
            .then(() => sendResponse({ ok: false }))
            .catch(() => sendResponse({ ok: false }));
        }
      })();
      return true;
    }
    if (!/^https:\/\/www\.facebook\.com\/marketplace\/(you\/(selling|dashboard)|edit)/.test(senderUrl)) {
      finishJobFailed(message.queueId,
        "attach_reported_from_wrong_page:" + senderUrl.slice(0, 80), [])
        .then(() => sendResponse({ ok: false }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    finishJobVideoAttached(message.queueId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  // [VERIFY-342-ROUTE-BEGIN]
  if (message.type === "AUTOLAUNCH_VERIFY_RESULT") {
    // Verify report (v2.1.142, note 92): only a
    // Marketplace content script may report one (the
    // same sender discipline as the sweep);
    // finishVerifyListing342 additionally requires the
    // stored job to be this verify.
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\//.test(senderUrl)) {
      console.warn("[AutoLaunch] Verify result refused — not from a Marketplace page:",
        senderUrl.slice(0, 80));
      return;
    }
    finishVerifyListing342(message)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  // [VERIFY-342-ROUTE-END]
  // [RECONCILE-336-ROUTE-BEGIN]
  if (message.type === "AUTOLAUNCH_RECONCILE_RESULT") {
    // Reconciliation sweep report (v2.1.136, note 86):
    // only the Facebook content script reports a sweep —
    // the scan is read on the Selling page and the listing
    // pages, and nowhere else is this sweep's room (the
    // same sender discipline as the job finishes;
    // finishReconcileSweep336 additionally requires the
    // stored job to be this sweep).
    const senderUrl = (sender && sender.tab && sender.tab.url) ||
      (sender && sender.url) || "";
    if (!/^https:\/\/www\.facebook\.com\/marketplace\//.test(senderUrl)) {
      console.warn("[AutoLaunch] Reconcile result refused — not from a Marketplace page:",
        senderUrl.slice(0, 80));
      return;
    }
    finishReconcileSweep336(message)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  // [RECONCILE-336-ROUTE-END]
  if (message.type === "AUTOLAUNCH_JOB_FAILED") {
    finishJobFailed(message.queueId, message.reason, message.diags)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});

// Handshake path 2 (legacy, kept for compatibility): a page that knows the
// extension id can still set the user id externally. manifest.json limits
// this to the AutoLaunch origin via externally_connectable.
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message && message.type === "SET_USER_ID" && message.userId) {
    chrome.storage.local.set({ autolaunch_user_id: message.userId }, () => {
      sendResponse({ status: "connected" });
      checkQueue();
    });
    return true;
  }
});
